package com.offlinelocal.videoeditor;

import android.content.ContentValues;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;

import androidx.exifinterface.media.ExifInterface;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;

public final class BitmapUtils {

    private BitmapUtils() {}

    /** 按可用内存推导安全的最大边长，避免大图直接 OOM。 */
    /**
     * 解码上限按可用堆分档。
     * 之前 heap≥400MB 就直接给 4096：一张 4096×4096 的 ARGB 就要 64MB，
     * 而马赛克还有 pixelated / blurred 两份全尺寸缓存，峰值很容易冲到 200MB+。
     * 现在抬高门槛，并把上限收到 3584（对手机修图够用，画面不糊）。
     */
    public static int safeMaxDim() {
        long heapMb = Runtime.getRuntime().maxMemory() / (1024 * 1024);
        if (heapMb >= 512) return 3584;
        if (heapMb >= 300) return 3072;
        if (heapMb >= 200) return 2560;
        if (heapMb >= 128) return 2048;
        return 1600;
    }

    /** 只读尺寸（不占位图内存），拼图先据此算输出分辨率。返回 {宽, 高}，失败返回 null。 */
    public static int[] sizeOf(Context ctx, Uri uri) {
        BitmapFactory.Options bounds = new BitmapFactory.Options();
        bounds.inJustDecodeBounds = true;
        try (InputStream is = ctx.getContentResolver().openInputStream(uri)) {
            BitmapFactory.decodeStream(is, null, bounds);
        } catch (Exception e) {
            return null;
        }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null;
        return new int[]{bounds.outWidth, bounds.outHeight};
    }

    /** 按原图分辨率解码（sample=1），OOM 时逐档回退。 */
    public static Bitmap loadOriginal(Context ctx, Uri uri) throws Exception {
        try {
            return loadOnce(ctx, uri, Integer.MAX_VALUE);
        } catch (OutOfMemoryError oom) {
            System.gc();
            return load(ctx, uri, safeMaxDim());
        }
    }

    /** 读取图片，按需降采样并修正 EXIF 方向；内存不足时自动再降一档。 */
    public static Bitmap load(Context ctx, Uri uri, int maxDim) throws Exception {
        int dim = Math.max(256, maxDim);
        for (int attempt = 0; attempt < 3; attempt++) {
            try {
                return loadOnce(ctx, uri, dim);
            } catch (OutOfMemoryError | IllegalStateException e) {
                System.gc();
                dim = dim / 2;
                if (dim < 512) throw new Exception("这张图片太大，当前设备内存处理不了");
            }
        }
        throw new Exception("这张图片太大，当前设备内存处理不了");
    }

    private static Bitmap loadOnce(Context ctx, Uri uri, int maxDim) throws Exception {
        BitmapFactory.Options bounds = new BitmapFactory.Options();
        bounds.inJustDecodeBounds = true;
        try (InputStream is = ctx.getContentResolver().openInputStream(uri)) {
            BitmapFactory.decodeStream(is, null, bounds);
        }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) {
            throw new Exception("无法解析该图片");
        }
        int sample = 1;
        int maxSide = Math.max(bounds.outWidth, bounds.outHeight);
        while (maxSide / sample > maxDim) {
            sample *= 2;
        }
        BitmapFactory.Options opts = new BitmapFactory.Options();
        opts.inSampleSize = sample;
        opts.inPreferredConfig = Bitmap.Config.ARGB_8888;
        Bitmap bmp;
        try (InputStream is = ctx.getContentResolver().openInputStream(uri)) {
            bmp = BitmapFactory.decodeStream(is, null, opts);
        }
        if (bmp == null) throw new Exception("无法解码该图片");

        int degrees = 0;
        boolean mirror = false;
        try (InputStream is = ctx.getContentResolver().openInputStream(uri)) {
            ExifInterface exif = new ExifInterface(is);
            int o = exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);
            switch (o) {
                case ExifInterface.ORIENTATION_ROTATE_90: degrees = 90; break;
                case ExifInterface.ORIENTATION_ROTATE_180: degrees = 180; break;
                case ExifInterface.ORIENTATION_ROTATE_270: degrees = 270; break;
                case ExifInterface.ORIENTATION_FLIP_HORIZONTAL: mirror = true; break;
                case ExifInterface.ORIENTATION_FLIP_VERTICAL: mirror = true; degrees = 180; break;
                case ExifInterface.ORIENTATION_TRANSPOSE: mirror = true; degrees = 90; break;
                case ExifInterface.ORIENTATION_TRANSVERSE: mirror = true; degrees = 270; break;
                default: break;
            }
        } catch (Throwable ignored) {
            ExportDiag.warn("bitmap_load", ignored);
        }

        if (degrees != 0 || mirror) {
            Matrix m = new Matrix();
            if (mirror) m.setScale(-1f, 1f);
            if (degrees != 0) m.postRotate(degrees);
            try {
                Bitmap rotated = Bitmap.createBitmap(bmp, 0, 0, bmp.getWidth(), bmp.getHeight(), m, true);
                if (rotated != bmp) bmp = rotated;
            } catch (OutOfMemoryError e) {
                // 保持原图
            }
        }
        return bmp;
    }

    /** 保存图片到相册（Pictures/LocalVideo）。 */
    public static Uri saveImage(Context ctx, Bitmap bitmap, String displayName) throws Exception {
        return saveImage(ctx, bitmap, displayName, 95);
    }

    public static Uri saveImage(Context ctx, Bitmap bitmap, String displayName, int quality) throws Exception {
        ContentValues cv = new ContentValues();
        cv.put(MediaStore.Images.Media.DISPLAY_NAME, displayName);
        cv.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P) {
            File dir = new File(Environment.getExternalStoragePublicDirectory(
                    Environment.DIRECTORY_PICTURES), "LocalVideo");
            if (!dir.exists() && !dir.mkdirs()) throw new Exception("无法创建相册目录");
            cv.put(MediaStore.Images.Media.DATA, new File(dir, displayName).getAbsolutePath());
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            cv.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/LocalVideo");
            cv.put(MediaStore.Images.Media.IS_PENDING, 1);
        }
        Uri uri = ctx.getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv);
        if (uri == null) throw new Exception("相册写入失败");
        try (OutputStream os = ctx.getContentResolver().openOutputStream(uri)) {
            if (os == null) throw new Exception("相册写入失败");
            bitmap.compress(Bitmap.CompressFormat.JPEG, quality, os);
            os.flush();
        } catch (Exception e) {
            ctx.getContentResolver().delete(uri, null, null);
            throw e;
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            cv.clear();
            cv.put(MediaStore.Images.Media.IS_PENDING, 0);
            ctx.getContentResolver().update(uri, cv, null, null);
        }
        return uri;
    }

    /** 把导出目录里的视频发布到相册（Movies/LocalVideo）。 */
    /** 把导出的音频写进系统「音乐」目录。 */
    public static Uri publishAudio(Context ctx, File file, String displayName) throws Exception {
        ContentValues cv = new ContentValues();
        cv.put(MediaStore.Audio.Media.DISPLAY_NAME, displayName);
        cv.put(MediaStore.Audio.Media.MIME_TYPE, "audio/mp4");
        cv.put(MediaStore.Audio.Media.TITLE, displayName);
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P) {
            File dir = new File(Environment.getExternalStoragePublicDirectory(
                    Environment.DIRECTORY_MUSIC), "LocalVideo");
            if (!dir.exists() && !dir.mkdirs()) throw new Exception("无法创建音乐目录");
            cv.put(MediaStore.Audio.Media.DATA, new File(dir, displayName).getAbsolutePath());
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            cv.put(MediaStore.Audio.Media.RELATIVE_PATH, Environment.DIRECTORY_MUSIC + "/LocalVideo");
            cv.put(MediaStore.Audio.Media.IS_PENDING, 1);
        }
        Uri uri = ctx.getContentResolver().insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, cv);
        if (uri == null) throw new Exception("音乐目录写入失败");
        try (InputStream is = new FileInputStream(file);
             OutputStream os = ctx.getContentResolver().openOutputStream(uri)) {
            if (os == null) throw new Exception("音乐目录写入失败");
            byte[] buf = new byte[8192];
            int n;
            while ((n = is.read(buf)) > 0) os.write(buf, 0, n);
            os.flush();
        } catch (Exception e) {
            ctx.getContentResolver().delete(uri, null, null);
            throw e;
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ContentValues done = new ContentValues();
            done.put(MediaStore.Audio.Media.IS_PENDING, 0);
            ctx.getContentResolver().update(uri, done, null, null);
        }
        return uri;
    }

    public static Uri publishVideo(Context ctx, File file, String displayName) throws Exception {
        ContentValues cv = new ContentValues();
        cv.put(MediaStore.Video.Media.DISPLAY_NAME, displayName);
        cv.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4");
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P) {
            File dir = new File(Environment.getExternalStoragePublicDirectory(
                    Environment.DIRECTORY_MOVIES), "LocalVideo");
            if (!dir.exists() && !dir.mkdirs()) throw new Exception("无法创建相册目录");
            cv.put(MediaStore.Video.Media.DATA, new File(dir, displayName).getAbsolutePath());
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            cv.put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/LocalVideo");
            cv.put(MediaStore.Video.Media.IS_PENDING, 1);
        }
        Uri uri = ctx.getContentResolver().insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, cv);
        if (uri == null) throw new Exception("相册写入失败");
        try (InputStream is = new FileInputStream(file);
             OutputStream os = ctx.getContentResolver().openOutputStream(uri)) {
            if (os == null) throw new Exception("相册写入失败");
            byte[] buf = new byte[8192];
            int n;
            while ((n = is.read(buf)) > 0) os.write(buf, 0, n);
            os.flush();
        } catch (Exception e) {
            ctx.getContentResolver().delete(uri, null, null);
            throw e;
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            cv.clear();
            cv.put(MediaStore.Video.Media.IS_PENDING, 0);
            ctx.getContentResolver().update(uri, cv, null, null);
        }
        return uri;
    }
}
