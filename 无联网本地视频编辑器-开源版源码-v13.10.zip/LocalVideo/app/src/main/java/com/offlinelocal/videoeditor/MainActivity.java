package com.offlinelocal.videoeditor;

import android.content.Intent;
import android.graphics.Bitmap;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.card.MaterialCardView;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private ActivityResultLauncher<String[]> imagePicker;
    private ActivityResultLauncher<String[]> videoPicker;
    private ActivityResultLauncher<String[]> batchPicker;
    private ActivityResultLauncher<String[]> collagePicker;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        imagePicker = registerForActivityResult(new ActivityResultContracts.OpenDocument(), this::openImage);
        videoPicker = registerForActivityResult(new ActivityResultContracts.OpenDocument(), this::openVideo);
        batchPicker = registerForActivityResult(new ActivityResultContracts.OpenMultipleDocuments(),
                this::openBatch);
        collagePicker = registerForActivityResult(new ActivityResultContracts.OpenMultipleDocuments(),
                this::openCollage);

        for (int id : new int[]{R.id.cardVideo, R.id.cardImage, R.id.cardBatch,
                R.id.cardCollage, R.id.cardContinue}) {
            View card = findViewById(id);
            UiAnim.press(card, 0.97f);
        }
        findViewById(R.id.cardImage).setOnClickListener(v -> imagePicker.launch(new String[]{"image/*"}));
        findViewById(R.id.cardVideo).setOnClickListener(v -> videoPicker.launch(new String[]{"video/*", "image/gif", "image/*"}));
        findViewById(R.id.cardBatch).setOnClickListener(v -> batchPicker.launch(new String[]{"image/*"}));
        findViewById(R.id.cardCollage).setOnClickListener(v -> collagePicker.launch(new String[]{"image/*"}));
        findViewById(R.id.cardContinue).setOnClickListener(v -> openDraft());
        findViewById(R.id.btnHistory).setOnClickListener(v ->
                startActivity(new Intent(this, HistoryActivity.class)));
        findViewById(R.id.btnAbout).setOnClickListener(v -> showAbout());

        renderContinue();
        renderRecent();
        renderProjects();

        showCrashReportIfAny();
        showOnboardingIfFirstRun();
    }

    // ---------------- 首次启动 ----------------

    private void showOnboardingIfFirstRun() {
        android.content.SharedPreferences sp = getSharedPreferences("freecut_app", MODE_PRIVATE);
        if (sp.getBoolean("onboarded", false)) return;
        sp.edit().putBoolean("onboarded", true).apply();
        new MaterialAlertDialogBuilder(this)
                .setTitle("欢迎使用 无联网本地视频编辑器")
                .setMessage("· 所有编辑都在本机完成，不联网、不上传任何素材\n"
                        + "· 首次选择图片/视频时系统会询问访问权限，只用于读取你选中的文件\n"
                        + "· 成片保存在相册 Pictures/LocalVideo（图片）与 Movies/LocalVideo（视频）\n"
                        + "· 视频导出较慢属于正常现象，进度条会显示百分比，期间可离开界面等它跑完")
                .setPositiveButton("开始使用", null)
                .show();
    }

    private void showCrashReportIfAny() {
        if (!LocalVideoApp.hasCrash(this)) return;
        String detail = LocalVideoApp.readCrash(this, 1200);
        new MaterialAlertDialogBuilder(this)
                .setTitle("上次运行出现过异常")
                .setMessage("为了便于排查，已记录一份本地日志（不会上传）。"
                        + "完整日志在文件里，这里只显示开头：\n\n" + detail)
                .setPositiveButton("我知道了", (d, w) -> LocalVideoApp.clearCrash(this))
                .setNegativeButton("保留日志", null)
                .setNeutralButton("导出日志", (d, w) -> shareCrash(LocalVideoApp.crashFile(this), "崩溃日志"))
                .show();
    }

    /** 把日志文件交给系统分享面板；导出到 cache 再由 FileProvider 授权，不申请存储权限。 */
    private void shareCrash(java.io.File src, String tag) {
        try {
            java.io.File out = src;
            if (!src.getParentFile().getName().equals("logs")) {
                out = LocalVideoApp.exportCrash(this);
                if (out == null) {
                    toast("没有可导出的日志");
                    return;
                }
            }
            android.net.Uri uri = androidx.core.content.FileProvider.getUriForFile(
                    this, getPackageName() + ".fileprovider", out);
            android.content.Intent i = new android.content.Intent(android.content.Intent.ACTION_SEND);
            i.setType("text/plain");
            i.putExtra(android.content.Intent.EXTRA_STREAM, uri);
            i.putExtra(android.content.Intent.EXTRA_SUBJECT, "无联网本地视频编辑器 " + tag);
            i.addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(android.content.Intent.createChooser(i, "导出" + tag));
        } catch (Throwable t) {
            toast("导出失败：" + t.getClass().getSimpleName());
        }
    }

    /** 历史崩溃日志：最多 5 份，点一条即可导出。 */
    private void showCrashHistory() {
        java.io.File[] logs = LocalVideoApp.crashHistory(this);
        if (logs.length == 0) {
            toast("还没有历史崩溃日志");
            return;
        }
        String[] labels = new String[logs.length];
        java.text.SimpleDateFormat f = new java.text.SimpleDateFormat("MM-dd HH:mm", java.util.Locale.US);
        for (int i = 0; i < logs.length; i++) {
            labels[i] = f.format(new java.util.Date(logs[i].lastModified())) + " · " + logs[i].length() + " 字节";
        }
        new MaterialAlertDialogBuilder(this)
                .setTitle("故障日志（最近 " + logs.length + " 条）")
                .setItems(labels, (d, which) -> shareCrash(logs[which], "崩溃日志"))
                .setNegativeButton("关闭", null)
                .show();
    }

    private void showAbout() {
        String version = "未知";
        try {
            version = getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
        } catch (Exception ignored) {
        }
        new MaterialAlertDialogBuilder(this)
                .setTitle("无联网本地视频编辑器 " + version)
                .setMessage("包名：" + getPackageName() + "\n"
                        + "定位：完全离线的图片 / 视频编辑器\n\n"
                        + "开源组件：\n"
                        + "· AndroidX（AppCompat / Media3 / ExifInterface）— Apache License 2.0\n"
                        + "· Material Components — Apache License 2.0\n"
                        + "· 测试期使用 Robolectric — MIT（不随 APK 发布）\n\n"
                        + "隐私：应用不申请网络权限，素材与成片只在设备本地处理。")
                .setNeutralButton("清理预览缓存", (d, w) -> confirmClearCache())
                .setNegativeButton("故障日志", (d, w) -> showCrashHistory())
                .setPositiveButton("关闭", null)
                .show();
    }

    /** 导出目录里的预览残留会一直涨，给用户一个一键清空入口。 */
    private void confirmClearCache() {
        Work.run(() -> {
            final long bytes = ProjectStore.cacheBytes(this);
            runOnUiThread(() -> new MaterialAlertDialogBuilder(this)
                    .setTitle("清理预览缓存")
                    .setMessage("导出目录当前占用 " + fmtBytes(bytes)
                            + "\n（预览残留会被清掉，相册里已导出的成片不受影响）")
                    .setNegativeButton("取消", null)
                    .setPositiveButton("清理", (d2, w2) -> {
                        ProjectStore.clearCache(this);
                        toast("已清理 " + fmtBytes(bytes));
                    })
                    .show());
        });
    }

    private String fmtBytes(long bytes) {
        if (bytes >= 1024L * 1024L) {
            return String.format(Locale.US, "%.1f MB", bytes / 1024f / 1024f);
        }
        return (bytes / 1024) + " KB";
    }

    // ---------------- 继续上次编辑 ----------------

    private void renderContinue() {
        View card = findViewById(R.id.cardContinue);
        if (card == null) return;
        int n = ProjectStore.draftClipCount(this);
        JSONObject draft = ProjectStore.loadDraftData(this);
        if (n <= 0 || draft == null) {
            card.setVisibility(View.GONE);
            return;
        }
        long dur = clipsDuration(draft);
        TextView sub = findViewById(R.id.tvContinueSub);
        if (sub != null) {
            sub.setText(n + " 段" + (dur > 0 ? " · " + fmtDuration(dur) : "")
                    + " · " + relativeTime(ProjectStore.draftUpdatedAt(this)));
        }
        card.setVisibility(View.VISIBLE);
        loadThumb(findViewById(R.id.ivContinueThumb), firstClipUri(draft));
    }

    private void openDraft() {
        try {
            startActivity(VideoEditorActivity.buildDraftIntent(this));
        } catch (Exception e) {
            toast("打不开草稿：" + e.getMessage());
        }
    }

    // ---------------- 最近打开 ----------------

    /** 最近打开：一行缩略图，点一下直接进编辑器，省掉一次找文件。 */
    private void renderRecent() {
        LinearLayout row = findViewById(R.id.rowRecent);
        View box = findViewById(R.id.boxRecent);
        if (row == null || box == null) return;
        row.removeAllViews();
        List<RecentStore.Item> list = RecentStore.all(this);
        if (list.isEmpty()) {
            box.setVisibility(View.GONE);
            return;
        }
        box.setVisibility(View.VISIBLE);
        for (RecentStore.Item item : list) {
            String label = item.name == null || item.name.isEmpty()
                    ? ("video".equals(item.kind) ? "视频" : "图片") : item.name;
            if (label.length() > 9) label = label.substring(0, 9) + "…";

            LinearLayout cell = new LinearLayout(this);
            cell.setOrientation(LinearLayout.VERTICAL);
            LinearLayout.LayoutParams cellLp = new LinearLayout.LayoutParams(
                    dp(96), ViewGroup.LayoutParams.WRAP_CONTENT);
            cellLp.setMarginEnd(dp(8));
            cell.setLayoutParams(cellLp);

            ImageView thumb = new ImageView(this);
            thumb.setLayoutParams(new LinearLayout.LayoutParams(dp(96), dp(96)));
            thumb.setScaleType(ImageView.ScaleType.CENTER_CROP);
            thumb.setBackgroundResource(R.drawable.bg_thumb);
            thumb.setContentDescription(label);
            cell.addView(thumb);

            TextView tv = new TextView(this);
            tv.setText(label);
            tv.setTextSize(11);
            tv.setTextColor(getColor(R.color.text_3));
            tv.setMaxLines(1);
            tv.setEllipsize(android.text.TextUtils.TruncateAt.END);
            tv.setPadding(0, dp(4), 0, 0);
            tv.setLayoutParams(new LinearLayout.LayoutParams(dp(96), ViewGroup.LayoutParams.WRAP_CONTENT));
            cell.addView(tv);

            cell.setOnClickListener(v -> openRecent(item));
            loadThumb(thumb, item.uri);
            row.addView(cell);
        }
    }

    /**
     * 打开最近文件前先验一下权限。
     * 之前直接 startActivity，MediaStore 的临时授权一失效就抛
     * SecurityException（用户看到的就是"上次运行出现过异常"），
     * 而且那一项还会一直留在列表里，点一次崩一次。
     */
    private void openRecent(RecentStore.Item item) {
        Uri uri = Uri.parse(item.uri);
        if (!canRead(uri)) {
            boolean recovered = tryPersist(uri);
            if (!recovered) {
                RecentStore.remove(this, item.uri);
                renderRecent();
                toast("这个文件的访问权限已失效，请重新选择一次");
                return;
            }
        }
        try {
            if ("video".equals(item.kind)) {
                startActivity(VideoEditorActivity.buildIntent(this, uri));
            } else {
                startActivity(ImageEditorActivity.buildIntent(this, uri));
            }
        } catch (SecurityException e) {
            RecentStore.remove(this, item.uri);
            renderRecent();
            toast("这个文件的访问权限已失效，请重新选择一次");
        } catch (Exception e) {
            toast("打不开这个文件：" + e.getMessage());
        }
    }

    // ---------------- 我的工程 ----------------

    /** 我的工程：两列卡片网格，点一下继续编辑，长按删除。RecyclerView 复用卡片，滚动不掉帧。 */
    private void renderProjects() {
        androidx.recyclerview.widget.RecyclerView list = findViewById(R.id.listProjects);
        View box = findViewById(R.id.boxProjects);
        if (list == null || box == null) return;
        List<ProjectStore.Meta> metas = ProjectStore.list(this);
        if (metas.isEmpty()) {
            box.setVisibility(View.GONE);
            list.setAdapter(null);
            return;
        }
        box.setVisibility(View.VISIBLE);
        if (list.getLayoutManager() == null) {
            androidx.recyclerview.widget.GridLayoutManager lm =
                    new androidx.recyclerview.widget.GridLayoutManager(this, 2);
            list.setLayoutManager(lm);
            final int gap = dp(6);
            list.addItemDecoration(new androidx.recyclerview.widget.RecyclerView.ItemDecoration() {
                @Override
                public void getItemOffsets(android.graphics.Rect r, View view,
                                           androidx.recyclerview.widget.RecyclerView parent,
                                           androidx.recyclerview.widget.RecyclerView.State state) {
                    r.set(gap, gap, gap, gap);
                }
            });
            list.setHasFixedSize(false);
        }
        list.setAdapter(new ProjectAdapter(metas));
    }

    private class ProjectAdapter extends androidx.recyclerview.widget.RecyclerView.Adapter<ProjectAdapter.Holder> {

        private final List<ProjectStore.Meta> data;

        ProjectAdapter(List<ProjectStore.Meta> data) {
            this.data = data;
        }

        class Holder extends androidx.recyclerview.widget.RecyclerView.ViewHolder {
            final MaterialCardView card;
            final ImageView cover;
            final TextView title;
            final TextView meta;
            String boundId;

            Holder(MaterialCardView card, ImageView cover, TextView title, TextView meta) {
                super(card);
                this.card = card;
                this.cover = cover;
                this.title = title;
                this.meta = meta;
            }
        }

        @Override
        public Holder onCreateViewHolder(android.view.ViewGroup parent, int viewType) {
            MaterialCardView card = new MaterialCardView(MainActivity.this);
            androidx.recyclerview.widget.RecyclerView.LayoutParams lp =
                    new androidx.recyclerview.widget.RecyclerView.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.WRAP_CONTENT);
            card.setLayoutParams(lp);
            card.setCardBackgroundColor(getColor(R.color.bg_s1));
            card.setRadius(dp(16));
            card.setCardElevation(0f);
            card.setStrokeColor(getColor(R.color.divider));
            card.setStrokeWidth(dp(1));
            card.setRippleColor(android.content.res.ColorStateList.valueOf(getColor(R.color.accent)));
            card.setClickable(true);
            card.setFocusable(true);

            LinearLayout box = new LinearLayout(MainActivity.this);
            box.setOrientation(LinearLayout.VERTICAL);

            ImageView cover = new ImageView(MainActivity.this);
            cover.setLayoutParams(new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, dp(96)));
            cover.setScaleType(ImageView.ScaleType.CENTER_CROP);
            cover.setBackgroundResource(R.drawable.bg_thumb);
            box.addView(cover);

            LinearLayout textBox = new LinearLayout(MainActivity.this);
            textBox.setOrientation(LinearLayout.VERTICAL);
            textBox.setPadding(dp(12), dp(10), dp(12), dp(12));

            TextView tvTitle = new TextView(MainActivity.this);
            tvTitle.setTextSize(14);
            tvTitle.setTextColor(getColor(R.color.text_1));
            tvTitle.setMaxLines(1);
            tvTitle.setEllipsize(android.text.TextUtils.TruncateAt.END);
            textBox.addView(tvTitle);

            TextView tvMeta = new TextView(MainActivity.this);
            tvMeta.setTextSize(11);
            tvMeta.setTextColor(getColor(R.color.text_3));
            tvMeta.setMaxLines(1);
            tvMeta.setPadding(0, dp(4), 0, 0);
            textBox.addView(tvMeta);

            box.addView(textBox);
            card.addView(box);
            return new Holder(card, cover, tvTitle, tvMeta);
        }

        @Override
        public void onBindViewHolder(Holder h, int position) {
            final ProjectStore.Meta m = data.get(position);
            String title = m.title == null || m.title.isEmpty()
                    ? getString(R.string.untitled_project) : m.title;
            h.title.setText(title);
            h.meta.setText(m.clipCount + " 段 · " + fmtDuration(m.durationMs)
                    + " · " + relativeTime(m.updatedAt));
            h.cover.setContentDescription(title);
            h.boundId = m.id;
            h.cover.setTag(m.id);
            h.cover.setImageBitmap(null);
            loadProjectCover(h.cover, m.id);
            h.card.setOnClickListener(v -> {
                try {
                    startActivity(VideoEditorActivity.buildProjectIntent(MainActivity.this, m.id));
                } catch (Exception e) {
                    toast("打不开这个工程：" + e.getMessage());
                }
            });
            h.card.setOnLongClickListener(v -> {
                new MaterialAlertDialogBuilder(MainActivity.this)
                        .setTitle(R.string.delete_project)
                        .setMessage("删除「" + title + "」？素材文件不会动，只删工程参数。")
                        .setPositiveButton(R.string.delete, (d, w) -> {
                            ProjectStore.delete(MainActivity.this, m.id);
                            renderProjects();
                        })
                        .setNegativeButton(R.string.cancel, null)
                        .show();
                return true;
            });
        }

        @Override
        public int getItemCount() {
            return data.size();
        }
    }

    // ---------------- 缩略图 ----------------

    /** 工程封面：读工程 JSON + 解码都在后台线程，首页滚动不会卡在磁盘 IO 上。 */
    private void loadProjectCover(final ImageView iv, final String projectId) {
        if (iv == null || projectId == null) return;
        iv.setTag(projectId);
        Work.run(() -> {
            Bitmap bmp = null;
            try {
                JSONObject data = ProjectStore.load(this, projectId);
                String uriStr = firstClipUri(data);
                if (uriStr != null && !uriStr.isEmpty()) {
                    Uri uri = Uri.parse(uriStr);
                    String type = getContentResolver().getType(uri);
                    if (type != null && type.startsWith("video")) {
                        bmp = videoFrame(uri);
                    } else {
                        bmp = BitmapUtils.load(this, uri, 512);
                    }
                }
            } catch (Throwable ignored) {
            }
            if (bmp == null) return;
            final Bitmap out = bmp;
            runOnUiThread(() -> {
                if (projectId.equals(iv.getTag())) {
                    iv.setImageBitmap(out);
                } else if (!out.isRecycled()) {
                    out.recycle();
                }
            });
        });
    }

    /** 给 ImageView 异步加载缩略图；视频取首帧，图片按 256px 降采样。 */
    private void loadThumb(final ImageView iv, final String uriStr) {
        if (iv == null || uriStr == null || uriStr.isEmpty()) return;
        iv.setTag(uriStr);
        final String type;
        try {
            type = getContentResolver().getType(Uri.parse(uriStr));
        } catch (Exception e) {
            return;
        }
        Work.run(() -> {
            Bitmap bmp = null;
            try {
                Uri uri = Uri.parse(uriStr);
                if (type != null && type.startsWith("video")) {
                    bmp = videoFrame(uri);
                } else {
                    bmp = BitmapUtils.load(MainActivity.this, uri, 256);
                }
            } catch (Throwable ignored) {
            }
            if (bmp == null) return;
            final Bitmap out = bmp;
            runOnUiThread(() -> {
                Object tag = iv.getTag();
                if (tag != null && tag.equals(uriStr)) {
                    iv.setImageBitmap(out);
                } else if (!out.isRecycled()) {
                    out.recycle();
                }
            });
        });
    }

    private Bitmap videoFrame(Uri uri) {
        MediaMetadataRetriever r = new MediaMetadataRetriever();
        try {
            r.setDataSource(this, uri);
            if (android.os.Build.VERSION.SDK_INT >= 27) {
                return r.getScaledFrameAtTime(0,
                        MediaMetadataRetriever.OPTION_CLOSEST_SYNC, 512, 512);
            }
            Bitmap b = r.getFrameAtTime(0, MediaMetadataRetriever.OPTION_CLOSEST_SYNC);
            if (b == null) b = r.getFrameAtTime();
            if (b == null) return null;
            float scale = 512f / Math.max(b.getWidth(), b.getHeight());
            if (scale >= 1f) return b;
            Bitmap small = Bitmap.createScaledBitmap(b,
                    Math.max(2, (int) (b.getWidth() * scale)),
                    Math.max(2, (int) (b.getHeight() * scale)), true);
            if (small != b) b.recycle();
            return small;
        } catch (Exception e) {
            return null;
        } finally {
            try {
                r.release();
            } catch (Exception ignored) {
            }
        }
    }

    // ---------------- 小工具 ----------------

    private static String firstClipUri(JSONObject data) {
        if (data == null) return null;
        JSONArray arr = data.optJSONArray("clips");
        if (arr == null || arr.length() == 0) return null;
        JSONObject first = arr.optJSONObject(0);
        if (first == null) return null;
        String uri = first.optString("uri", "");
        return uri.isEmpty() ? null : uri;
    }

    private static long clipsDuration(JSONObject data) {
        if (data == null) return 0;
        JSONArray arr = data.optJSONArray("clips");
        if (arr == null) return 0;
        long sum = 0;
        for (int i = 0; i < arr.length(); i++) {
            JSONObject c = arr.optJSONObject(i);
            if (c == null) continue;
            sum += Math.max(0, c.optLong("endMs", 0) - c.optLong("startMs", 0));
        }
        return sum;
    }

    private static String fmtDuration(long ms) {
        long s = Math.max(0, ms / 1000);
        return String.format(Locale.US, "%d:%02d", s / 60, s % 60);
    }

    private static String relativeTime(long t) {
        if (t <= 0) return "";
        long diff = Math.max(0, System.currentTimeMillis() - t);
        long minute = 60_000L;
        long hour = 60 * minute;
        long day = 24 * hour;
        if (diff < minute) return "刚刚";
        if (diff < hour) return (diff / minute) + " 分钟前";
        if (diff < day) return (diff / hour) + " 小时前";
        if (diff < 2 * day) return "昨天";
        return (diff / day) + " 天前";
    }

    private boolean canRead(Uri uri) {
        try {
            getContentResolver().openFileDescriptor(uri, "r").close();
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private boolean tryPersist(Uri uri) {
        try {
            getContentResolver().takePersistableUriPermission(uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION);
            return canRead(uri);
        } catch (Exception e) {
            return false;
        }
    }

    private void toast(String msg) {
        android.widget.Toast.makeText(this, msg, android.widget.Toast.LENGTH_SHORT).show();
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    private void openImage(Uri uri) {
        if (uri == null) return;
        takePersist(uri);
        RecentStore.touch(this, uri.toString(), nameOf(uri, "image"), "image");
        try {
            startActivity(ImageEditorActivity.buildIntent(this, uri));
        } catch (Exception e) {
            toast("打不开这张图：" + e.getMessage());
        }
        renderRecent();
    }

    private void openVideo(Uri uri) {
        if (uri == null) return;
        // 动图（GIF 等）归到视频编辑：先离线转成短视频，再走原有视频链路
        if (GifToVideo.isAnimated(this, uri)) {
            toast("动图正在转成短视频…");
            Work.run(this, () -> {
                java.io.File f = GifToVideo.convert(this, uri, new java.io.File(getCacheDir(), "gif"));
                runOnUiThread(() -> {
                    if (f == null) {
                        toast("这个动图解不开，换一个试试");
                        return;
                    }
                    Uri u = androidx.core.content.FileProvider.getUriForFile(
                            this, getPackageName() + ".fileprovider", f);
                    openVideo(u);
                });
            });
            return;
        }
        String type = null;
        try {
            type = getContentResolver().getType(uri);
        } catch (Throwable ignore) {
        }
        if (type != null && type.startsWith("image/")) {
            toast("图片正在转成 3 秒片段…");
            Work.run(this, () -> {
                java.io.File f = GifToVideo.convertStill(this, uri,
                        new java.io.File(getCacheDir(), "gif"), 3000);
                runOnUiThread(() -> {
                    if (f == null) {
                        toast("这张图转不成片段，换一张试试");
                        return;
                    }
                    Uri u = androidx.core.content.FileProvider.getUriForFile(
                            this, getPackageName() + ".fileprovider", f);
                    openVideo(u);
                });
            });
            return;
        }
        takePersist(uri);
        RecentStore.touch(this, uri.toString(), nameOf(uri, "video"), "video");
        try {
            startActivity(VideoEditorActivity.buildIntent(this, uri));
        } catch (Exception e) {
            toast("打不开这个视频：" + e.getMessage());
        }
        renderRecent();
    }

    /** OpenDocument 给的是一次性授权，必须转成持久授权，"最近打开"才有意义。 */
    private void takePersist(Uri uri) {
        try {
            getContentResolver().takePersistableUriPermission(uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } catch (Exception ignored) {
        }
    }

    private String nameOf(Uri uri, String kind) {
        try (android.database.Cursor c = getContentResolver().query(uri,
                new String[]{android.provider.OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                String n = c.getString(0);
                if (n != null && !n.isEmpty()) return n;
            }
        } catch (Exception ignored) {
        }
        return "video".equals(kind) ? "视频" : "图片";
    }

    private void openCollage(java.util.List<Uri> uris) {
        if (uris == null || uris.size() < 2) {
            android.widget.Toast.makeText(this, "拼图至少选两张", android.widget.Toast.LENGTH_SHORT).show();
            return;
        }
        startActivity(CollageActivity.buildIntent(this, new ArrayList<>(uris)));
    }

    private void openBatch(java.util.List<Uri> uris) {
        if (uris == null || uris.isEmpty()) return;
        startActivity(BatchActivity.buildIntent(this, new ArrayList<>(uris)));
    }
}
