package com.offlinelocal.videoeditor;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.DashPathEffect;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

/**
 * 图片编辑画布 v3：
 *   - 图层模型：文字 / 贴纸 / 涂鸦 / 马赛克 / 形状（矩形·圆·直线·箭头）
 *   - 每层可设混合模式（正常 / 正片叠底 / 滤色 / 叠加）与透明度
 *   - 裁剪、90°旋转、翻转、任意角度微调、相框模板
 *   - 20 步撤销 / 重做；长按可临时看原图
 *   - 预览与导出共用同一套渲染逻辑
 */
public class EditImageView extends View {

    public enum Mode {NONE, CROP, DRAW, TEXT, MOSAIC, SHAPE, WATERMARK}

    public enum LayerType {TEXT, STICKER, STROKE, MOSAIC, SHAPE}

    public static class Layer {
        public LayerType type;
        public Matrix matrix = new Matrix();
        public float alpha = 1f;
        public int blend = 0;          // 0 正常 1 正片叠底 2 滤色 3 叠加

        // 文字
        public String text;
        public float textSize;
        public int textColor = Color.WHITE;
        public int align = 1;          // 0 左 1 中 2 右
        public int typeface = 0;       // 0 常规 1 衬线 2 等宽
        public float strokeWidth = 0f;
        public int strokeColor = Color.BLACK;
        public boolean shadow = true;
        public int textBgColor = 0;      // 0 = 无底色
        public float textBgPad = 8f;

        // 贴纸
        Bitmap sticker;
        float stickerW, stickerH;

        // 涂鸦 / 马赛克 / 形状
        public int mosaicStyle = 0;

        // 编组（0 = 未编组；同号图层一起移动/删除）
        public int groupId = 0;

        // 蒙版：0 无 / 1 矩形 / 2 圆形 / 3 线性渐变（数值是相对图层局部外框的 0~1）
        public int maskType = 0;
        public float maskL = 0.08f, maskT = 0.08f, maskR = 0.92f, maskB = 0.92f;
        public int maskDir = 0;          // 0 纵向渐隐 1 横向渐隐
        public float maskFeather = 0.25f;
        public Path fillPath = null;        // 马赛克笔迹的实心化区域（缓存）
        public float fillForWidth = -1f;
        public boolean fillDirty = true;
        Path path;
        int color;
        float width;
        int block = 0;

        // 形状（bitmap 坐标系）
        int shapeType = 0;             // 0 矩形 1 圆 2 直线 3 箭头
        float x1, y1, x2, y2;

        public String label() {
            switch (type) {
                case TEXT:
                    return "文";
                case STICKER:
                    return "贴";
                case STROKE:
                    return "笔";
                case SHAPE:
                    return "形";
                default:
                    return "码";
            }
        }

        Layer copy() {
            Layer l = new Layer();
            l.type = type;
            l.matrix = new Matrix(matrix);
            l.alpha = alpha;
            l.blend = blend;
            l.text = text;
            l.textSize = textSize;
            l.textColor = textColor;
            l.align = align;
            l.typeface = typeface;
            l.strokeWidth = strokeWidth;
            l.strokeColor = strokeColor;
            l.shadow = shadow;
            l.textBgColor = textBgColor;
            l.textBgPad = textBgPad;
            l.sticker = sticker;
            l.stickerW = stickerW;
            l.stickerH = stickerH;
            l.path = path == null ? null : new Path(path);
            l.color = color;
            l.width = width;
            l.block = block;
            l.groupId = groupId;
            l.maskType = maskType;
            l.maskL = maskL;
            l.maskT = maskT;
            l.maskR = maskR;
            l.maskB = maskB;
            l.maskDir = maskDir;
            l.maskFeather = maskFeather;
            l.shapeType = shapeType;
            l.x1 = x1;
            l.y1 = y1;
            l.x2 = x2;
            l.y2 = y2;
            return l;
        }
    }

    private Bitmap base;
    /**
     * 大图手势期间的降采样底图：拖动/双指缩放时画这张（≤1600px），松手再画全清晰原图。
     * 4000px 的图每帧都要重新采样一遍，这就是"拖动一顿一顿"的主因。
     */
    private Bitmap gestureBase;
    private boolean gestureActive = false;
    private int gestureBaseToken = 0;
    /** 本次触摸序列锁定在哪个对象上：true=画布，false=图层。中途不再切换。 */
    private boolean gestureOnCanvas;
    private final ColorMatrix colorMatrix = new ColorMatrix();
    private ColorMatrixColorFilter colorFilter = new ColorMatrixColorFilter(new ColorMatrix());

    private final List<Layer> layers = new ArrayList<>();
    private Layer selected = null;

    private Mode mode = Mode.NONE;
    private final RectF cropRect = new RectF();
    private boolean cropVisible = false;
    private float cropAspect = 0f;

    private final Matrix toView = new Matrix();
    private final Matrix toBitmap = new Matrix();
    /** 最终显示的合成矩阵 = toView + 微调旋转。绘制、命中、选中框、拖动统一用它，避免各算一套。 */
    private final Matrix viewMat = new Matrix();
    private float scale = 1f;
    private float offX = 0f;
    private float offY = 0f;

    private final Paint bitmapPaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final Paint strokePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private int textBgDefault = 0;
    private float textBgPadDefault = 8f * 3f;
    private final Paint shapePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint uiPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint borderPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    private int drawColor = 0xFFFF5A5A;
    private float drawWidthDp = 4f;
    private int mosaicBlockDp = 14;
    private int mosaicWidthDp = 18;   // 笔刷大小（默认约手指肚宽度）
    private int mosaicStyle = 0;      // 0 像素块 1 磨砂模糊 2 色块遮挡
    private int borderColor = 0;
    private float borderWidthDp = 0f;
    private int shapeType = 3;

    private float vignette = 0f;
    private int gradDir = 0;        // 0=关 1=上 2=下 3=左 4=右下斜
    private float gradStrength = 0f;          // 0~1 暗角强度
    private String tileWatermark = null;  // 水印文字
    private float tileAlpha = 0.25f;
    private boolean wmTiled = false;      // false=单个，true=铺满
    private float wmFX = 0.5f, wmFY = 0.92f;   // 单个水印的相对位置（0~1）
    private float wmSizeRatio = 0.055f;        // 字号 = 图宽 * 该比例
    private int wmColor = 0xFFFFFFFF;
    private float wmRotation = 0f;
    private float fineRotation = 0f;      // 待应用的微调角度（预览态）
    private boolean showOriginal = false;

    private int cropHandle = -1;
    private boolean drawing = false;
    // 画面双指缩放 / 平移（"看清细节"用，和图层自身的缩放互不干扰）
    private float userZoom = 1f;
    private float userPanX = 0f, userPanY = 0f;
    private boolean viewZoomMode = false;
    private float zoomStartDist = 0f, zoomStartZoom = 1f;
    private float zoomFocusX = 0f, zoomFocusY = 0f;

    private final java.util.Map<Layer, Matrix> groupDragStart = new java.util.HashMap<>();

    private Layer dragging = null;
    private float lastDx, lastDy;
    // 拖动用「按下时的矩阵 + 相对下按点的总位移」重算，避免逐帧累加误差/缩放倍率不一致
    private final Matrix dragStartMatrix = new Matrix();
    /** 编组整体拖动时，每个成员按下瞬间的矩阵 */
    private final java.util.List<Matrix> groupStart = new ArrayList<>();
    private final java.util.List<Layer> groupMembers = new ArrayList<>();
    private float dragStartX, dragStartY;

    // 形状拖拽
    private boolean shaping = false;
    private float shapeX1, shapeY1, shapeX2, shapeY2;

    // 双指手势
    private boolean pinching = false;
    private boolean pinchHistoryPushed = false;
    private float gestureStartDist = 0f;
    private float gestureStartAngle = 0f;
    private float gestureCx = 0f, gestureCy = 0f;
    private Matrix gestureBaseMatrix = new Matrix();

    private Bitmap maskScratch = null;
    private Bitmap pixelatedCache = null;
    private Bitmap blurredCache = null;

    // 撤销 / 重做
    private static final int HISTORY_LIMIT = 60;   // 多步撤销（步数仍受内存预算裁剪）
    private final List<Object[]> undoStack = new ArrayList<>();
    private final List<Object[]> redoStack = new ArrayList<>();

    /** 图层选中变化时回调（供界面刷新图层列表）。 */
    public Runnable onLayerChanged;

    private final float density;

    public EditImageView(Context c) {
        this(c, null);
    }

    public EditImageView(Context c, AttributeSet a) {
        super(c, a);
        density = c.getResources().getDisplayMetrics().density;
        strokePaint.setStyle(Paint.Style.STROKE);
        strokePaint.setStrokeCap(Paint.Cap.ROUND);
        strokePaint.setStrokeJoin(Paint.Join.ROUND);
        shapePaint.setStyle(Paint.Style.STROKE);
        shapePaint.setStrokeCap(Paint.Cap.ROUND);
        shapePaint.setStrokeJoin(Paint.Join.ROUND);
    }

    // ============ 基础 ============

    /** 主动回收马赛克/蒙版的大位图缓存，避免离开页面后仍占着整张图的显存/堆。 */
    /** 只放整图马赛克/模糊缓存（切工具时调用），保留蒙版 scratch。 */
    public void trimImageCaches() {
        if (pixelatedCache != null && !pixelatedCache.isRecycled()) pixelatedCache.recycle();
        if (blurredCache != null && !blurredCache.isRecycled()) blurredCache.recycle();
        pixelatedCache = null;
        blurredCache = null;
    }

    public void releaseCaches() {
        if (pixelatedCache != null && !pixelatedCache.isRecycled()) pixelatedCache.recycle();
        if (blurredCache != null && !blurredCache.isRecycled()) blurredCache.recycle();
        if (maskScratch != null && !maskScratch.isRecycled()) maskScratch.recycle();
        pixelatedCache = null;
        blurredCache = null;
        maskScratch = null;
    }

    @Override
    protected void onDetachedFromWindow() {
        releaseCaches();
        super.onDetachedFromWindow();
    }

    public void setBitmap(Bitmap bitmap) {
        base = bitmap;
        rebuildGestureBase();
        layers.clear();
        selected = null;
        cropVisible = false;
        pixelatedCache = null;
        blurredCache = null;
        fineRotation = 0f;
        undoStack.clear();
        redoStack.clear();
        recompute();
        invalidate();
    }

    public Bitmap getBase() {
        return base;
    }

    /** 后台准备一张长边 1600 的手势预览图，准备好后自动用上。 */
    private void rebuildGestureBase() {
        final Bitmap src = base;
        final int token = ++gestureBaseToken;
        Bitmap old = gestureBase;
        gestureBase = null;
        if (old != null && !old.isRecycled() && old != src) old.recycle();
        if (src == null || Math.max(src.getWidth(), src.getHeight()) <= 1600) {
            invalidate();
            return;
        }
        Work.run(() -> {
            int w = src.getWidth(), h = src.getHeight();
            float k = 1600f / Math.max(w, h);
            Bitmap small = null;
            try {
                small = Bitmap.createScaledBitmap(src,
                        Math.max(2, (int) (w * k)), Math.max(2, (int) (h * k)), true);
            } catch (Throwable ignored) {
            }
            final Bitmap out = small;
            if (out == null) return;
            post(() -> {
                if (token != gestureBaseToken || base != src) {
                    if (!out.isRecycled()) out.recycle();
                    return;
                }
                Bitmap prev = gestureBase;
                gestureBase = out;
                if (prev != null && !prev.isRecycled() && prev != out) prev.recycle();
                invalidate();
            });
        });
    }

    /** 清空撤销/重做栈（恢复草稿、换图时用，避免历史引用旧底图）。 */
    public void clearHistory() {
        undoStack.clear();
        redoStack.clear();
        pinching = false;
        dragging = null;
        invalidate();
    }

    public void clearOverlays() {
        pushHistory();
        layers.clear();
        selected = null;
        notifyLayerChanged();
        invalidate();
    }

    public void setColorMatrix(ColorMatrix cm) {
        colorMatrix.set(cm);
        colorFilter = new ColorMatrixColorFilter(colorMatrix);
        invalidate();
    }

    public void setMode(Mode m) {
        mode = m;
        if (m != Mode.CROP) cropVisible = false;
        if (m == Mode.CROP && base != null) {
            resetCropToCenter();
            cropVisible = true;
        }
        if (m != Mode.DRAW && m != Mode.MOSAIC) drawing = false;
        if (m != Mode.TEXT) dragging = null;
        invalidate();
    }

    public Mode getMode() {
        return mode;
    }

    public void setDrawColor(int color) {
        drawColor = color;
    }

    public void setDrawWidthDp(float dp) {
        drawWidthDp = dp;
    }

    public void setMosaicBlockDp(int dp) {
        mosaicBlockDp = Math.max(4, dp);
        pixelatedCache = null;
        blurredCache = null;
        invalidate();
    }

    public void setBorder(int color, float widthDp) {
        borderColor = color;
        borderWidthDp = widthDp;
        invalidate();
    }

    public int getBorderColor() {
        return borderColor;
    }

    public void setShapeType(int type) {
        shapeType = type;
        mode = Mode.SHAPE;
        invalidate();
    }

    public int getShapeType() {
        return shapeType;
    }

    // ============ 微调旋转 / 原图对比 ============

    public void setFineRotation(float degrees) {
        fineRotation = degrees;
        recompute();
        invalidate();
    }

    public void commitFineRotation() {
        if (base == null || Math.abs(fineRotation) < 0.05f) {
            fineRotation = 0f;
            invalidate();
            return;
        }
        pushHistory();
        int w = base.getWidth();
        int h = base.getHeight();
        double rad = Math.toRadians(fineRotation);
        float c = (float) Math.abs(Math.cos(rad));
        float sn = (float) Math.abs(Math.sin(rad));
        int nw = Math.max(1, (int) Math.ceil(w * c + h * sn));
        int nh = Math.max(1, (int) Math.ceil(w * sn + h * c));
        Matrix m = new Matrix();
        m.postTranslate(nw / 2f, nh / 2f);
        m.postRotate(fineRotation);
        m.postTranslate(-w / 2f, -h / 2f);
        Bitmap rotated = Bitmap.createBitmap(nw, nh, Bitmap.Config.ARGB_8888);
        Canvas c2 = new Canvas(rotated);
        c2.drawBitmap(base, m, new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG));
        base = rotated;
        for (Layer layer : layers) layer.matrix.postConcat(m);
        fineRotation = 0f;
        afterGeometryChange();
    }

    /** 渐变蒙版：单侧压暗/压亮，用来压天空、突出主体。 */
    public void setGradientMask(int direction, float strength) {
        gradDir = direction;
        gradStrength = Math.max(0f, Math.min(1f, strength));
        invalidate();
    }

    public int getLayerCount() {
        return layers == null ? 0 : layers.size();
    }

    public float getBorderWidth() {
        return borderWidthDp;
    }

    public int getGradientDirection() {
        return gradDir;
    }

    public float getGradientStrength() {
        return gradStrength;
    }

    /** 马赛克样式：0 像素块 / 1 磨砂模糊 / 2 色块遮挡；blockDp 颗粒，widthDp 笔刷粗细。 */
    public void setMosaicStyle(int style, int blockDp, int widthDp) {
        mosaicStyle = Math.max(0, Math.min(2, style));
        mosaicBlockDp = Math.max(4, blockDp);
        mosaicWidthDp = Math.max(6, widthDp);
        pixelatedCache = null;
        blurredCache = null;
        invalidate();
    }

    /** 给界面做滤镜缩略图用的小样，避免每个 chip 各自再解码一次大图。 */
    public Bitmap baseThumbnail(int maxSide) {
        if (base == null) return null;
        int w = base.getWidth();
        int h = base.getHeight();
        float f = Math.min(1f, maxSide / (float) Math.max(w, h));
        int tw = Math.max(1, Math.round(w * f));
        int th = Math.max(1, Math.round(h * f));
        return Bitmap.createScaledBitmap(base, tw, th, true);
    }

    public int getMosaicStyle() {
        return mosaicStyle;
    }

    public void setVignette(float strength) {
        vignette = Math.max(0f, Math.min(1f, strength));
        invalidate();
    }

    public float getVignette() {
        return vignette;
    }

    /** 单个水印放在哪（相对坐标 0~1）。 */
    public void setWatermarkAnchor(float fx, float fy) {
        wmFX = Math.max(0f, Math.min(1f, fx));
        wmFY = Math.max(0f, Math.min(1f, fy));
        invalidate();
    }

    public float[] getWatermarkAnchor() {
        return new float[]{wmFX, wmFY};
    }

    /** 单个 / 铺满 两种模式。 */
    public void setWatermarkTiled(boolean tiled) {
        wmTiled = tiled;
        invalidate();
    }

    public boolean isWatermarkTiled() {
        return wmTiled;
    }

    /** 字号（占图宽比例）、颜色、透明度、旋转。 */
    public void setWatermarkStyle(float sizeRatio, int color, float alpha, float rotationDeg) {
        wmSizeRatio = Math.max(0.015f, Math.min(0.35f, sizeRatio));
        wmColor = color;
        tileAlpha = Math.max(0.05f, Math.min(1f, alpha));
        wmRotation = rotationDeg;
        invalidate();
    }

    public float getWatermarkSizeRatio() {
        return wmSizeRatio;
    }

    public int getWatermarkColor() {
        return wmColor;
    }

    public float getWatermarkAlpha() {
        return tileAlpha;
    }

    public void setTileWatermark(String text, float alpha) {
        tileWatermark = (text == null || text.trim().isEmpty()) ? null : text.trim();
        tileAlpha = Math.max(0.05f, Math.min(0.9f, alpha));
        invalidate();
    }

    public String getTileWatermark() {
        return tileWatermark;
    }

    public void setShowOriginal(boolean show) {
        showOriginal = show;
        invalidate();
    }

    public boolean isShowingOriginal() {
        return showOriginal;
    }

    // ============ 图层 API ============

    public List<Layer> getLayers() {
        return layers;
    }

    public Layer getSelected() {
        return selected;
    }

    private void notifyLayerChanged() {
        if (onLayerChanged != null) onLayerChanged.run();
    }

    public void selectLayer(int index) {
        if (index < 0 || index >= layers.size()) {
            selected = null;
        } else {
            selected = layers.get(index);
        }
        notifyLayerChanged();
        invalidate();
    }

    public int selectedIndex() {
        return selected == null ? -1 : layers.indexOf(selected);
    }

    // ============ 编组 / 多选 ============

    private int nextGroupId = 1;

    public int getSelectedGroupId() {
        return selected == null ? 0 : selected.groupId;
    }

    /** 把当前选中的图层单独编成一组，返回组号；没选中返回 0。 */
    public int groupSelected() {
        if (selected == null) return 0;
        pushHistory();
        int gid = nextGroupId++;
        selected.groupId = gid;
        notifyLayerChanged();
        invalidate();
        return gid;
    }

    /** 把选中的多个图层编成同一组（给定下标集合）。 */
    public int groupIndexes(java.util.List<Integer> ids) {
        if (ids == null || ids.isEmpty()) return 0;
        pushHistory();
        int gid = nextGroupId++;
        for (int i : ids) if (i >= 0 && i < layers.size()) layers.get(i).groupId = gid;
        notifyLayerChanged();
        invalidate();
        return gid;
    }

    public boolean ungroupSelected() {
        if (selected == null || selected.groupId == 0) return false;
        pushHistory();
        int gid = selected.groupId;
        for (Layer l : layers) if (l.groupId == gid) l.groupId = 0;
        notifyLayerChanged();
        invalidate();
        return true;
    }

    /** 选中图层所在整组一起删除。 */
    public void deleteSelectedWithGroup() {
        if (selected == null) return;
        pushHistory();
        if (selected.groupId == 0) {
            layers.remove(selected);
        } else {
            int gid = selected.groupId;
            for (int i = layers.size() - 1; i >= 0; i--) {
                if (layers.get(i).groupId == gid) layers.remove(i);
            }
        }
        selected = null;
        notifyLayerChanged();
        invalidate();
    }

    public void deleteIndexes(java.util.List<Integer> ids) {
        if (ids == null || ids.isEmpty()) return;
        pushHistory();
        java.util.List<Layer> targets = new ArrayList<>();
        for (int i : ids) if (i >= 0 && i < layers.size()) targets.add(layers.get(i));
        layers.removeAll(targets);
        selected = null;
        notifyLayerChanged();
        invalidate();
    }

    public void deleteSelected() {
        if (selected == null) return;
        pushHistory();
        layers.remove(selected);
        selected = null;
        notifyLayerChanged();
        invalidate();
    }

    public void moveSelected(boolean up) {
        if (selected == null || selected.type == LayerType.MOSAIC) return;
        int i = layers.indexOf(selected);
        int target = up ? Math.min(layers.size() - 1, i + 1) : Math.max(0, i - 1);
        if (target == i) return;
        pushHistory();
        layers.remove(i);
        layers.add(target, selected);
        notifyLayerChanged();
        invalidate();
    }

    public void setSelectedAlpha(float alpha) {
        if (selected == null) return;
        selected.alpha = Math.max(0f, Math.min(1f, alpha));
        invalidate();
    }

    public void setSelectedBlend(int blend) {
        if (selected == null) return;
        pushHistory();
        selected.blend = blend % 4;
        invalidate();
    }

    public int getSelectedBlend() {
        return selected == null ? 0 : selected.blend;
    }

    public boolean undoStroke() {
        if (layers.isEmpty()) return false;
        pushHistory();
        Layer last = layers.remove(layers.size() - 1);
        if (last == selected) selected = null;
        notifyLayerChanged();
        invalidate();
        return true;
    }

    public int overlayCount() {
        return layers.size();
    }

    // ============ 撤销 / 重做 ============

    public void pushHistory() {
        if (base == null) return;
        List<Layer> copy = new ArrayList<>();
        for (Layer l : layers) copy.add(l.copy());
        undoStack.add(new Object[]{copy, base, layers.indexOf(selected), borderColor, borderWidthDp});
        trimHistory();
        redoStack.clear();
    }

    /**
     * 历史里的每一步都引用当时的底图。裁剪 / 旋转 / 翻转每次都会生成一张新底图，
     * 如果 20 步全是大图快照，光历史就能吃掉几百 MB。这里按"历史总字节 ≤ 堆的 1/4"来裁剪，
     * 只有确认没有任何快照和当前底图再引用它时，才 recycle 那张旧图。
     */
    private void trimHistory() {
        while (undoStack.size() > HISTORY_LIMIT) undoStack.remove(0);
        long budget = Math.max(24L * 1024 * 1024, Runtime.getRuntime().maxMemory() / 4);
        long total = historyBytes();
        while (undoStack.size() > 1 && total > budget) {
            Object[] evicted = undoStack.remove(0);
            Bitmap old = (Bitmap) evicted[1];
            if (isBaseReferenced(old)) continue; // 还被别的快照引用，留着
            total -= bytesOf(old);
            if (old != null && !old.isRecycled() && old != base) {
                try {
                    old.recycle();
                } catch (Exception ignored) {
                }
            }
        }
    }

    private long historyBytes() {
        java.util.HashSet<Bitmap> seen = new java.util.HashSet<>();
        long sum = 0;
        for (Object[] snap : undoStack) {
            Bitmap b = (Bitmap) snap[1];
            if (b != null && seen.add(b)) sum += bytesOf(b);
        }
        return sum;
    }

    private long bytesOf(Bitmap b) {
        if (b == null || b.isRecycled()) return 0;
        try {
            return b.getByteCount();
        } catch (Exception e) {
            return (long) b.getWidth() * b.getHeight() * 4L;
        }
    }

    private boolean isBaseReferenced(Bitmap b) {
        if (b == null) return false;
        if (b == base) return true;
        for (Object[] snap : undoStack) {
            if (snap[1] == b) return true;
        }
        for (Object[] snap : redoStack) {
            if (snap[1] == b) return true;
        }
        return false;
    }

    @SuppressWarnings("unchecked")
    private void restore(Object[] snap) {
        layers.clear();
        layers.addAll((List<Layer>) snap[0]);
        base = (Bitmap) snap[1];
        int selIdx = (Integer) snap[2];   // 旧快照存的是对象引用，这里兼容一下
        selected = (selIdx >= 0 && selIdx < layers.size()) ? layers.get(selIdx) : null;
        if (selected == null && snap[2] instanceof Layer) {
            int i = layers.indexOf(snap[2]);
            selected = i >= 0 ? layers.get(i) : null;
        }
        borderColor = (Integer) snap[3];
        borderWidthDp = (Float) snap[4];
        pixelatedCache = null;
        blurredCache = null;
        recompute();
        notifyLayerChanged();
        invalidate();
    }

    private Object[] snapshotNow() {
        List<Layer> copy = new ArrayList<>();
        for (Layer l : layers) copy.add(l.copy());
        return new Object[]{copy, base, layers.indexOf(selected), borderColor, borderWidthDp};
    }

    public boolean undo() {
        if (undoStack.isEmpty()) return false;
        redoStack.add(snapshotNow());
        Object[] snap = undoStack.remove(undoStack.size() - 1);
        restore(snap);
        return true;
    }

    public boolean redo() {
        if (redoStack.isEmpty()) return false;
        List<Layer> copy = new ArrayList<>();
        for (Layer l : layers) copy.add(l.copy());
        undoStack.add(new Object[]{copy, base, layers.indexOf(selected), borderColor, borderWidthDp});
        restore(redoStack.remove(redoStack.size() - 1));
        return true;
    }

    public boolean canUndo() {
        return !undoStack.isEmpty();
    }

    public boolean canRedo() {
        return !redoStack.isEmpty();
    }

    // ============ 文字 ============

    private Typeface typefaceOf(Layer l) {
        switch (l.typeface) {
            case 1:
                return Typeface.SERIF;
            case 2:
                return Typeface.MONOSPACE;
            default:
                return Typeface.DEFAULT;
        }
    }

    private Paint.Align alignOf(Layer l) {
        return l.align == 0 ? Paint.Align.LEFT : (l.align == 2 ? Paint.Align.RIGHT : Paint.Align.CENTER);
    }

    public Layer addText(String text) {
        if (base == null || text == null || text.trim().isEmpty()) return null;
        pushHistory();
        Layer l = new Layer();
        l.type = LayerType.TEXT;
        l.text = text;
        l.textBgColor = textBgDefault;
        l.textBgPad = textBgPadDefault;
        l.textSize = base.getWidth() / 14f;
        l.matrix.postTranslate(base.getWidth() / 2f, base.getHeight() / 2f);
        layers.add(l);
        selected = l;
        mode = Mode.TEXT;
        notifyLayerChanged();
        invalidate();
        return l;
    }

    public void setTextColor(int color) {
        Layer l = textLayer();
        if (l == null) return;
        l.textColor = color;
        invalidate();
    }

    public void setTextSizeDp(float dp) {
        Layer l = textLayer();
        if (l == null) return;
        l.textSize = Math.max(8f, dp * density);
        invalidate();
    }

    public void setTextTypeface(int index) {
        Layer l = textLayer();
        if (l == null) return;
        l.typeface = index % 3;
        invalidate();
    }

    public void setTextAlign(int align) {
        Layer l = textLayer();
        if (l == null) return;
        l.align = align % 3;
        invalidate();
    }

    public void setTextStroke(float widthDp, int color) {
        Layer l = textLayer();
        if (l == null) return;
        l.strokeWidth = widthDp * density;
        l.strokeColor = color;
        invalidate();
    }

    /** 文字底色（半透明圆角底板），color=0 表示去掉。 */
    public void setTextBg(int color, float padDp) {
        textBgDefault = color;
        textBgPadDefault = padDp * density;
        Layer l = textLayer();
        if (l != null) {
            l.textBgColor = color;
            l.textBgPad = padDp * density;
        }
        invalidate();
    }

    public void setTextShadow(boolean on) {
        Layer l = textLayer();
        if (l == null) return;
        l.shadow = on;
        invalidate();
    }

    private Layer textLayer() {
        if (selected != null && selected.type == LayerType.TEXT) return selected;
        for (int i = layers.size() - 1; i >= 0; i--) {
            if (layers.get(i).type == LayerType.TEXT) return layers.get(i);
        }
        return null;
    }

    public Layer addSticker(Bitmap bmp) {
        if (bmp != null) bmp.setDensity(Bitmap.DENSITY_NONE);   // 防止密度二次缩放导致画出来比框大
        if (base == null || bmp == null) return null;
        pushHistory();
        Layer l = new Layer();
        l.type = LayerType.STICKER;
        l.sticker = bmp;
        l.stickerW = bmp.getWidth();
        l.stickerH = bmp.getHeight();
        float targetW = base.getWidth() * 0.4f;
        float s = targetW / l.stickerW;
        l.matrix.postScale(s, s);
        l.matrix.postTranslate(base.getWidth() / 2f, base.getHeight() / 2f);
        layers.add(l);
        selected = l;
        notifyLayerChanged();
        invalidate();
        return l;
    }

    // ============ 相框模板 ============

    /**
     * 直接把相框"烘"进底图：外扩边距、填底色，必要时加底边（拍立得）或圆角。
     * style: 0 无 1 拍立得白框 2 圆角 3 胶片黑边 4 细白框
     */
    public void applyFrame(int style, int color) {
        if (base == null) return;
        pressFrame(style, color);
    }

    private void pressFrame(int style, int color) {
        if (style == 0) return;
        pushHistory();
        int w = base.getWidth();
        int h = base.getHeight();
        int pad = Math.round(Math.min(w, h) * 0.035f);
        int extraTop = pad, extraBottom = pad, extraLeft = pad, extraRight = pad;
        if (style == 1) {
            extraTop = pad;
            extraBottom = pad * 4;
            extraLeft = pad;
            extraRight = pad;
        } else if (style == 4) {
            pad = Math.round(Math.min(w, h) * 0.012f);
            extraTop = extraBottom = extraLeft = extraRight = pad;
        }
        int nw = w + extraLeft + extraRight;
        int nh = h + extraTop + extraBottom;
        Bitmap out = Bitmap.createBitmap(nw, nh, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(out);
        c.drawColor(color);
        Paint p = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG);
        c.drawBitmap(base, extraLeft, extraTop, p);
        base = out;
        Matrix shift = new Matrix();
        shift.postTranslate(extraLeft, extraTop);
        for (Layer layer : layers) layer.matrix.postConcat(shift);
        fineRotation = 0f;
        afterGeometryChange();
    }

    // ============ 裁剪 ============

    public void resetCropToCenter() {
        if (base == null) return;
        float w = base.getWidth();
        float h = base.getHeight();
        float insetW = w * 0.86f;
        float insetH = h * 0.86f;
        if (cropAspect > 0) {
            if (insetW / insetH > cropAspect) {
                insetW = insetH * cropAspect;
            } else {
                insetH = insetW / cropAspect;
            }
        }
        cropRect.set((w - insetW) / 2f, (h - insetH) / 2f, (w + insetW) / 2f, (h + insetH) / 2f);
    }

    public void setCropAspect(float aspect) {
        cropAspect = aspect;
        if (cropVisible) {
            applyAspectToCrop();
            invalidate();
        }
    }

    private void applyAspectToCrop() {
        if (cropAspect <= 0f) return;
        float cx = cropRect.centerX();
        float cy = cropRect.centerY();
        float w = cropRect.width();
        float h = w / cropAspect;
        if (h > base.getHeight()) {
            h = base.getHeight();
            w = h * cropAspect;
        }
        if (w > base.getWidth()) {
            w = base.getWidth();
            h = w / cropAspect;
        }
        cropRect.set(cx - w / 2f, cy - h / 2f, cx + w / 2f, cy + h / 2f);
        clampCrop();
    }

    public void applyCrop() {
        if (base == null || !cropVisible) return;
        clampCrop();
        int l = Math.max(0, (int) cropRect.left);
        int t = Math.max(0, (int) cropRect.top);
        int r = Math.min(base.getWidth(), (int) cropRect.right);
        int b = Math.min(base.getHeight(), (int) cropRect.bottom);
        int w = r - l;
        int h = b - t;
        if (w < 16 || h < 16) return;
        pushHistory();
        base = Bitmap.createBitmap(base, l, t, w, h);
        for (Layer layer : layers) {
            layer.matrix.postTranslate(-l, -t);
        }
        cropVisible = false;
        cropRect.set(0, 0, (float) w, (float) h);
        pixelatedCache = null;
        blurredCache = null;
        recompute();
        invalidate();
    }

    public void cancelCrop() {
        cropVisible = false;
        mode = Mode.NONE;
        invalidate();
    }

    // ============ 旋转 / 翻转 ============

    public void rotate90(boolean clockwise) {
        if (base == null) return;
        pushHistory();
        int w = base.getWidth();
        int h = base.getHeight();
        Matrix bm = new Matrix();
        bm.setRotate(clockwise ? 90f : 270f);
        if (clockwise) bm.postTranslate(h, 0f);
        else bm.postTranslate(0f, w);
        base = Bitmap.createBitmap(base, 0, 0, w, h, bm, true);
        for (Layer layer : layers) layer.matrix.postConcat(bm);
        afterGeometryChange();
    }

    public void flip(boolean horizontal) {
        if (base == null) return;
        pushHistory();
        int w = base.getWidth();
        int h = base.getHeight();
        Matrix bm = new Matrix();
        if (horizontal) {
            bm.setScale(-1f, 1f);
            bm.postTranslate(w, 0f);
        } else {
            bm.setScale(1f, -1f);
            bm.postTranslate(0f, h);
        }
        base = Bitmap.createBitmap(base, 0, 0, w, h, bm, true);
        for (Layer layer : layers) layer.matrix.postConcat(bm);
        afterGeometryChange();
    }

    private void afterGeometryChange() {
        cropVisible = false;
        mode = Mode.NONE;
        pixelatedCache = null;
        blurredCache = null;
        recompute();
        notifyLayerChanged();
        invalidate();
    }

    // ============ 渲染 ============

    private void recompute() {
        if (base == null) return;
        int vw = getWidth();
        int vh = getHeight();
        if (vw == 0 || vh == 0) return;
        float s = Math.min(vw / (float) base.getWidth(), vh / (float) base.getHeight());
        scale = s;
        offX = (vw - base.getWidth() * s) / 2f;
        offY = (vh - base.getHeight() * s) / 2f;
        toView.setScale(s, s);
        toView.postTranslate(offX, offY);
        viewMat.set(toView);
        if (Math.abs(fineRotation) > 0.05f) {
            float cx = offX + base.getWidth() * s / 2f;
            float cy = offY + base.getHeight() * s / 2f;
            viewMat.postRotate(fineRotation, cx, cy);
        }
        // 画面缩放/平移叠在最外层：它只影响"看"，不影响图层坐标，
        // 因为 toBitmap 是 viewMat 的逆矩阵，绘制和命中都会自动跟着换算
        if (Math.abs(userZoom - 1f) > 0.001f || Math.abs(userPanX) > 0.5f || Math.abs(userPanY) > 0.5f) {
            // 直接在数值上做「绕视图中心缩放 + 平移」，避开 Matrix 拼接方向的歧义
            float[] v = new float[9];
            viewMat.getValues(v);
            float z = userZoom;
            float ntx = z * v[2] + (1f - z) * vw / 2f + userPanX;
            float nty = z * v[5] + (1f - z) * vh / 2f + userPanY;
            viewMat.setValues(new float[]{
                    z * v[0], z * v[1], ntx,
                    z * v[3], z * v[4], nty,
                    0f, 0f, 1f});
        }
        viewMat.invert(toBitmap);
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        recompute();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (base == null) return;

        float cx = offX + base.getWidth() * scale / 2f;
        float cy = offY + base.getHeight() * scale / 2f;

        canvas.save();

        bitmapPaint.setColorFilter(colorFilter);
        Bitmap drawn = gestureActive && gestureBase != null && !gestureBase.isRecycled()
                ? gestureBase : base;
        if (drawn == base) {
            canvas.drawBitmap(base, viewMat, bitmapPaint);
        } else {
            // 预览图比原图小，先按比例放大回原图坐标系再套 viewMat，位置完全一致
            canvas.save();
            canvas.concat(viewMat);
            float k = base.getWidth() / (float) drawn.getWidth();
            canvas.scale(k, k);
            canvas.drawBitmap(drawn, 0f, 0f, bitmapPaint);
            canvas.restore();
        }

        if (!showOriginal) {
            for (Layer layer : layers) drawLayer(canvas, layer, viewMat, scale);

            if (borderWidthDp > 0f && borderColor != 0) {
                borderPaint.setColor(borderColor);
                borderPaint.setStyle(Paint.Style.STROKE);
                borderPaint.setStrokeWidth(borderWidthDp * density);
                canvas.save();
                canvas.concat(viewMat);
                float half = borderWidthDp * density / 2f;
                canvas.drawRect(half, half, base.getWidth() - half, base.getHeight() - half, borderPaint);
                canvas.restore();
            }

            drawFinishing(canvas, viewMat);
            if (shaping) drawShapePreview(canvas);
            if (selected != null && selected.type != LayerType.MOSAIC && mode != Mode.CROP) {
                drawSelection(canvas, selected);
            }
        }
        canvas.restore();

        if (showOriginal) {
            uiPaint.setStyle(Paint.Style.FILL);
            uiPaint.setColor(getContext().getColor(R.color.accent));
            uiPaint.setTextSize(12f * density);
            canvas.drawText("原图", 12f * density, 22f * density, uiPaint);
        }

        if (cropVisible) drawCropOverlay(canvas);
    }

    /** 收尾效果：暗角 + 平铺水印，预览与导出共用。 */
    private void drawFinishing(Canvas canvas, Matrix parent) {
        if (vignette <= 0.01f && tileWatermark == null && gradStrength <= 0.01f) return;
        canvas.save();
        canvas.concat(parent);
        float w = base.getWidth();
        float h = base.getHeight();

        if (vignette > 0.01f) {
            Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            android.graphics.RadialGradient g = new android.graphics.RadialGradient(
                    w / 2f, h / 2f, Math.max(w, h) * 0.62f,
                    new int[]{0x00000000, 0x00000000, ((int) (0xCC * vignette) << 24)},
                    new float[]{0f, 0.55f, 1f},
                    android.graphics.Shader.TileMode.CLAMP);
            p.setShader(g);
            canvas.drawRect(0, 0, w, h, p);
        }

        if (gradStrength > 0.01f && gradDir != 0) {
            Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            int a = (int) (0xE6 * gradStrength);
            android.graphics.LinearGradient lg;
            switch (gradDir) {
                case 1:
                    lg = new android.graphics.LinearGradient(0, 0, 0, h * 0.62f,
                            new int[]{a << 24, 0x00000000},
                            new float[]{0f, 1f}, android.graphics.Shader.TileMode.CLAMP);
                    break;
                case 2:
                    lg = new android.graphics.LinearGradient(0, h, 0, h * 0.38f,
                            new int[]{a << 24, 0x00000000},
                            new float[]{0f, 1f}, android.graphics.Shader.TileMode.CLAMP);
                    break;
                case 3:
                    lg = new android.graphics.LinearGradient(0, 0, w * 0.62f, 0,
                            new int[]{a << 24, 0x00000000},
                            new float[]{0f, 1f}, android.graphics.Shader.TileMode.CLAMP);
                    break;
                default:
                    lg = new android.graphics.LinearGradient(w, h, w * 0.35f, h * 0.35f,
                            new int[]{a << 24, 0x00000000},
                            new float[]{0f, 1f}, android.graphics.Shader.TileMode.CLAMP);
                    break;
            }
            p.setShader(lg);
            canvas.drawRect(0, 0, w, h, p);
        }

        if (tileWatermark != null) {
            Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            p.setColor(wmColor);
            p.setAlpha((int) (255 * tileAlpha));
            p.setTextSize(Math.max(10f, w * wmSizeRatio));
            p.setShadowLayer(w * 0.004f, 0f, w * 0.003f, 0x66000000);
            if (!wmTiled) {
                p.setTextAlign(Paint.Align.CENTER);
                canvas.save();
                canvas.rotate(wmRotation, w * wmFX, h * wmFY);
                Paint.FontMetrics fm = p.getFontMetrics();
                float baseline = h * wmFY - (fm.ascent + fm.descent) / 2f;
                canvas.drawText(tileWatermark, w * wmFX, baseline, p);
                canvas.restore();
            } else {
                p.setTextAlign(Paint.Align.LEFT);
                p.setShadowLayer(0f, 0f, 0f, 0);
                float tw = p.measureText(tileWatermark);
                float stepX = Math.max(tw * 1.5f, w / 3.2f);
                float stepY = p.getTextSize() * 2.4f;
                canvas.save();
                canvas.rotate(wmRotation == 0f ? -24f : wmRotation, w / 2f, h / 2f);
                for (float y = 0f; y < h + h * 0.36f; y += stepY) {
                    for (float x = -w * 0.2f; x < w * 1.2f; x += stepX) {
                        canvas.drawText(tileWatermark, x, y, p);
                    }
                }
                canvas.restore();
            }
        }
        canvas.restore();
    }

    private RectF localBounds(Layer l) {
        RectF r = new RectF();
        if (l.type == LayerType.TEXT) {
            textPaint.setTextSize(l.textSize);
            textPaint.setTypeface(typefaceOf(l));
            textPaint.setTextAlign(alignOf(l));
            float w = textPaint.measureText(l.text == null ? "" : l.text);
            Paint.FontMetrics fm = textPaint.getFontMetrics();
            float left = l.align == 0 ? 0f : (l.align == 2 ? -w : -w / 2f);
            float pad = l.strokeWidth > 0f ? l.strokeWidth : 0f;
            r.set(left - pad, fm.ascent - pad, left + w + pad, fm.descent + pad);
        } else if (l.type == LayerType.STICKER) {
            r.set(-l.stickerW / 2f, -l.stickerH / 2f, l.stickerW / 2f, l.stickerH / 2f);
        } else if (l.type == LayerType.SHAPE) {
            r.set(Math.min(l.x1, l.x2), Math.min(l.y1, l.y2),
                    Math.max(l.x1, l.x2), Math.max(l.y1, l.y2));
            r.inset(-l.width, -l.width);
        } else if (l.path != null) {
            l.path.computeBounds(r, true);
            r.inset(-l.width / 2f, -l.width / 2f);
        }
        return r;
    }

    // 复用同一批 Xfermode 对象：涂抹时每帧都会调用 drawLayer，之前每次 new 会让 GC 频繁工作
    private static final PorterDuffXfermode XFER_MULTIPLY =
            new PorterDuffXfermode(PorterDuff.Mode.MULTIPLY);
    private static final PorterDuffXfermode XFER_SCREEN =
            new PorterDuffXfermode(PorterDuff.Mode.SCREEN);
    private static final PorterDuffXfermode XFER_OVERLAY =
            new PorterDuffXfermode(PorterDuff.Mode.OVERLAY);

    private PorterDuffXfermode xferOf(int blend) {
        switch (blend) {
            case 1:
                return XFER_MULTIPLY;
            case 2:
                return XFER_SCREEN;
            case 3:
                return XFER_OVERLAY;
            default:
                return null;
        }
    }

    /** 带蒙版的图层：先整体画进一个离屏层，再用蒙版把层外的部分擦掉。 */
    private void drawLayer(Canvas canvas, Layer l, Matrix parent, float sc) {
        if (l.maskType == 0) {
            drawLayerContent(canvas, l, parent, sc);
            return;
        }
        RectF local = localBounds(l);
        Matrix vm = new Matrix(parent);
        vm.preConcat(l.matrix);
        RectF vb = new RectF(local);
        vm.mapRect(vb);
        vb.inset(-3f, -3f);
        int layerId = canvas.saveLayer(vb, null);
        drawLayerContent(canvas, l, parent, sc);
        RectF mr = new RectF(
                local.left + local.width() * l.maskL, local.top + local.height() * l.maskT,
                local.left + local.width() * l.maskR, local.top + local.height() * l.maskB);
        RectF vr = new RectF(mr);
        vm.mapRect(vr);

        // DST_IN 只作用于"画到的像素"，所以先在一张遮罩位图上生成完整覆盖（形状外为透明），
        // 再整张贴上去，形状外的内容才会被真正擦掉
        int mw = Math.max(1, (int) Math.ceil(vb.width()));
        int mh = Math.max(1, (int) Math.ceil(vb.height()));
        Bitmap mask = maskScratch;
        if (mask == null || mask.isRecycled() || mask.getWidth() != mw || mask.getHeight() != mh) {
            if (mask != null && !mask.isRecycled()) mask.recycle();
            mask = Bitmap.createBitmap(mw, mh, Bitmap.Config.ARGB_8888);
            maskScratch = mask;
        } else {
            mask.eraseColor(0);
        }
        Canvas mc = new Canvas(mask);
        mc.translate(-vb.left, -vb.top);
        Paint mp = new Paint(Paint.ANTI_ALIAS_FLAG);
        if (l.maskType == 3) {
            float f = Math.max(0.02f, Math.min(0.9f, l.maskFeather));
            android.graphics.LinearGradient lg = l.maskDir == 0
                    ? new android.graphics.LinearGradient(0f, vr.top, 0f, vr.bottom,
                        new int[]{0xFFFFFFFF, 0xFFFFFFFF, 0x00FFFFFF},
                        new float[]{0f, Math.max(0.01f, 1f - f), 1f},
                        android.graphics.Shader.TileMode.CLAMP)
                    : new android.graphics.LinearGradient(vr.left, 0f, vr.right, 0f,
                        new int[]{0xFFFFFFFF, 0xFFFFFFFF, 0x00FFFFFF},
                        new float[]{0f, Math.max(0.01f, 1f - f), 1f},
                        android.graphics.Shader.TileMode.CLAMP);
            mp.setShader(lg);
            mc.drawRect(vb, mp);
        } else {
            mp.setColor(0xFFFFFFFF);
            Path p = new Path();
            if (l.maskType == 2) p.addOval(vr, Path.Direction.CW);
            else p.addRect(vr, Path.Direction.CW);
            mc.drawPath(p, mp);
        }
        Paint apply = new Paint(Paint.ANTI_ALIAS_FLAG);
        apply.setXfermode(new android.graphics.PorterDuffXfermode(
                android.graphics.PorterDuff.Mode.DST_IN));
        canvas.drawBitmap(mask, vb.left, vb.top, apply);
        apply.setXfermode(null);
        canvas.restoreToCount(layerId);
    }

    private void drawLayerContent(Canvas canvas, Layer l, Matrix parent, float sc) {
        int alpha = Math.round(255 * Math.max(0f, Math.min(1f, l.alpha)));
        PorterDuffXfermode xfer = xferOf(l.blend);
        switch (l.type) {
            case TEXT: {
                if (l.textBgColor != 0) {
                    textPaint.setTextSize(l.textSize);
                    textPaint.setTypeface(typefaceOf(l));
                    textPaint.setTextAlign(alignOf(l));
                    String t = l.text == null ? "" : l.text;
                    float tw = textPaint.measureText(t);
                    Paint.FontMetrics fm = textPaint.getFontMetrics();
                    float left = alignOf(l) == Paint.Align.LEFT ? 0f
                            : (alignOf(l) == Paint.Align.CENTER ? -tw / 2f : -tw);
                    float right = left + tw;
                    float pad = l.textBgPad;
                    Paint bg = new Paint(Paint.ANTI_ALIAS_FLAG);
                    bg.setColor(l.textBgColor);
                    bg.setAlpha(Math.round(Color.alpha(l.textBgColor)
                            * Math.max(0f, Math.min(1f, l.alpha))));
                    canvas.save();
                    canvas.concat(parent);
                    canvas.concat(l.matrix);
                    canvas.drawRoundRect(left - pad, fm.ascent - pad,
                            right + pad, fm.descent + pad, pad, pad, bg);
                    canvas.restore();
                }
                textPaint.setTextSize(l.textSize);
                textPaint.setTypeface(typefaceOf(l));
                textPaint.setTextAlign(alignOf(l));
                textPaint.setShadowLayer(l.shadow ? 2f : 0f, 1f, 1f, 0x66000000);
                canvas.save();
                canvas.concat(parent);
                canvas.concat(l.matrix);
                if (l.strokeWidth > 0f) {
                    textPaint.setStyle(Paint.Style.STROKE);
                    textPaint.setStrokeWidth(l.strokeWidth);
                    textPaint.setColor(l.strokeColor);
                    textPaint.setAlpha(alpha);
                    textPaint.setXfermode(xfer);
                    canvas.drawText(l.text, 0f, 0f, textPaint);
                    textPaint.setXfermode(null);
                }
                textPaint.setStyle(Paint.Style.FILL);
                textPaint.setColor(l.textColor);
                textPaint.setAlpha(alpha);
                textPaint.setXfermode(xfer);
                canvas.drawText(l.text, 0f, 0f, textPaint);
                textPaint.setXfermode(null);
                canvas.restore();
                break;
            }
            case STICKER: {
                canvas.save();
                canvas.concat(parent);
                canvas.concat(l.matrix);
                bitmapPaint.setColorFilter(null);
                bitmapPaint.setAlpha(alpha);
                bitmapPaint.setXfermode(xfer);
                canvas.drawBitmap(l.sticker, -l.stickerW / 2f, -l.stickerH / 2f, bitmapPaint);
                bitmapPaint.setXfermode(null);
                bitmapPaint.setAlpha(255);
                bitmapPaint.setColorFilter(colorFilter);
                canvas.restore();
                break;
            }
            case STROKE: {
                strokePaint.setColor(l.color);
                strokePaint.setAlpha(alpha);
                strokePaint.setStrokeWidth(l.width);
                strokePaint.setXfermode(xfer);
                canvas.save();
                canvas.concat(parent);
                canvas.concat(l.matrix);
                canvas.drawPath(l.path, strokePaint);
                canvas.restore();
                strokePaint.setXfermode(null);
                break;
            }
            case SHAPE: {
                shapePaint.setColor(l.color);
                shapePaint.setAlpha(alpha);
                shapePaint.setStrokeWidth(l.width);
                shapePaint.setXfermode(xfer);
                canvas.save();
                canvas.concat(parent);
                canvas.concat(l.matrix);
                drawShape(canvas, l.shapeType, l.x1, l.y1, l.x2, l.y2, l.width);
                canvas.restore();
                shapePaint.setXfermode(null);
                break;
            }
            case MOSAIC: {
                canvas.save();
                canvas.concat(parent);
                canvas.concat(l.matrix);

                // 笔刷式打码：把笔迹当成一支圆头笔，落笔即上代价，而不是先圈范围
                Paint brush = new Paint(Paint.ANTI_ALIAS_FLAG);
                brush.setStyle(Paint.Style.STROKE);
                brush.setStrokeWidth(Math.max(2f, l.width));
                brush.setStrokeCap(Paint.Cap.ROUND);
                brush.setStrokeJoin(Paint.Join.ROUND);

                brush.setAlpha(alpha);
                if (l.mosaicStyle == 2) {
                    brush.setColor(0xFF15171C);
                    canvas.drawPath(l.path, brush);
                } else {
                    Bitmap src = (l.mosaicStyle == 1) ? blurred() : pixelated();
                    if (src != null) {
                        // 把「打码后的整张图」当成笔芯的图案，沿笔迹描一条圆头粗线：
                        // 落笔就是马赛克，拖到哪儿码到哪儿，颗粒和底图坐标严格对齐
                        brush.setShader(new android.graphics.BitmapShader(
                                src, android.graphics.Shader.TileMode.CLAMP,
                                android.graphics.Shader.TileMode.CLAMP));
                        canvas.drawPath(l.path, brush);
                        brush.setShader(null);
                    }
                }
                canvas.restore();
                break;
            }
        }
    }

    private void drawShape(Canvas canvas, int type, float x1, float y1, float x2, float y2, float width) {
        float left = Math.min(x1, x2);
        float top = Math.min(y1, y2);
        float right = Math.max(x1, x2);
        float bottom = Math.max(y1, y2);
        switch (type) {
            case 0:
                canvas.drawRect(new RectF(left, top, right, bottom), shapePaint);
                break;
            case 1:
                canvas.drawOval(new RectF(left, top, right, bottom), shapePaint);
                break;
            case 2:
                canvas.drawLine(x1, y1, x2, y2, shapePaint);
                break;
            case 3: {
                canvas.drawLine(x1, y1, x2, y2, shapePaint);
                double ang = Math.atan2(y2 - y1, x2 - x1);
                float head = Math.max(width * 4f, 18f) + width;
                float spread = (float) Math.toRadians(26);
                float ax = x2 - head * (float) Math.cos(ang - spread);
                float ay = y2 - head * (float) Math.sin(ang - spread);
                float bx = x2 - head * (float) Math.cos(ang + spread);
                float by = y2 - head * (float) Math.sin(ang + spread);
                Path p = new Path();
                p.moveTo(ax, ay);
                p.lineTo(x2, y2);
                p.lineTo(bx, by);
                Paint fill = new Paint(shapePaint);
                fill.setStyle(Paint.Style.FILL);
                fill.setStrokeWidth(0f);
                Path closed = new Path();
                closed.moveTo(x2, y2);
                closed.lineTo(ax, ay);
                closed.lineTo(bx, by);
                closed.close();
                canvas.drawPath(closed, fill);
                break;
            }
            default:
                break;
        }
    }

    /** 测试用：马赛克像素块底图 */
    public Bitmap pixelatedForTest() { return pixelated(); }

    private void drawShapePreview(Canvas canvas) {
        shapePaint.setColor(drawColor);
        shapePaint.setAlpha(220);
        shapePaint.setStrokeWidth(drawWidthDp * density / Math.max(scale, 0.0001f));
        shapePaint.setXfermode(null);
        canvas.save();
        canvas.concat(toView);
        drawShape(canvas, shapeType, shapeX1, shapeY1, shapeX2, shapeY2,
                drawWidthDp * density / Math.max(scale, 0.0001f));
        canvas.restore();
    }

    private Bitmap pixelated() {
        if (base == null) return null;
        if (pixelatedCache != null) return pixelatedCache;
        try {
            int block = Math.max(4, (int) (mosaicBlockDp * density));
            int sw = Math.max(1, base.getWidth() / block);
            int sh = Math.max(1, base.getHeight() / block);
            Bitmap small = Bitmap.createScaledBitmap(base, sw, sh, true);
            Bitmap full = Bitmap.createBitmap(base.getWidth(), base.getHeight(), Bitmap.Config.ARGB_8888);
            Canvas c = new Canvas(full);
            Paint p = new Paint();
            p.setFilterBitmap(false);
            p.setFlags(Paint.DITHER_FLAG);
            c.drawBitmap(small, null, new RectF(0, 0, base.getWidth(), base.getHeight()), p);
            if (small != base) small.recycle();
            pixelatedCache = full;
            return full;
        } catch (Throwable t) {
            return null;
        }
    }

    /** 磨砂模糊：先缩小再双线性放大，比逐像素高斯便宜且效果柔和。 */
    private Bitmap blurred() {
        if (base == null) return null;
        if (blurredCache != null) return blurredCache;
        try {
            int factor = Math.max(8, mosaicBlockDp * 2);
            int sw = Math.max(1, base.getWidth() / factor);
            int sh = Math.max(1, base.getHeight() / factor);
            Bitmap small = Bitmap.createScaledBitmap(base, sw, sh, true);
            Bitmap full = Bitmap.createBitmap(base.getWidth(), base.getHeight(), Bitmap.Config.ARGB_8888);
            Canvas c = new Canvas(full);
            Paint p = new Paint(Paint.FILTER_BITMAP_FLAG);
            c.drawBitmap(small, null, new RectF(0, 0, base.getWidth(), base.getHeight()), p);
            if (small != base) small.recycle();
            blurredCache = full;
            return full;
        } catch (Throwable t) {
            return null;
        }
    }

    private boolean insideSelection(float x, float y, float pad) {
        if (selected == null) return false;
        RectF local = localBounds(selected);
        Matrix m = new Matrix(viewMat);
        m.preConcat(selected.matrix);
        RectF vr = new RectF(local);
        m.mapRect(vr);
        vr.inset(-pad, -pad);
        return vr.contains(x, y);
    }

    /** 测试用：选中框在视图坐标里的矩形。 */
    public RectF selectionRectForTest() {
        if (selected == null) return null;
        RectF local = localBounds(selected);
        Matrix m = new Matrix(viewMat);
        m.preConcat(selected.matrix);
        RectF r = new RectF(local);
        m.mapRect(r);
        return r;
    }

    private void drawSelection(Canvas canvas, Layer l) {
        RectF local = localBounds(l);
        Matrix m = new Matrix(viewMat);
        m.preConcat(l.matrix);   // postConcat 是 M'=参数×M，会反过来，必须用 preConcat
        RectF vr = new RectF(local);
        m.mapRect(vr);
        vr.inset(-6f * density, -6f * density);
        uiPaint.setStyle(Paint.Style.STROKE);
        uiPaint.setStrokeWidth(1.5f * density);
        uiPaint.setColor(getContext().getColor(R.color.accent));
        uiPaint.setPathEffect(new DashPathEffect(new float[]{6f * density, 4f * density}, 0f));
        canvas.drawRect(vr, uiPaint);
        uiPaint.setPathEffect(null);
    }

    private RectF cropInView() {
        RectF r = new RectF(cropRect);
        toView.mapRect(r);
        return r;
    }

    private void drawCropOverlay(Canvas canvas) {
        RectF vr = cropInView();
        uiPaint.setPathEffect(null);
        uiPaint.setStyle(Paint.Style.FILL);
        uiPaint.setColor(0xB3000000);
        int vw = getWidth();
        int vh = getHeight();
        canvas.drawRect(0, 0, vw, vr.top, uiPaint);
        canvas.drawRect(0, vr.bottom, vw, vh, uiPaint);
        canvas.drawRect(0, vr.top, vr.left, vr.bottom, uiPaint);
        canvas.drawRect(vr.right, vr.top, vw, vr.bottom, uiPaint);

        uiPaint.setStyle(Paint.Style.STROKE);
        uiPaint.setStrokeWidth(1.5f * density);
        uiPaint.setColor(0xFFFFFFFF);
        canvas.drawRect(vr, uiPaint);

        uiPaint.setStrokeWidth(0.8f * density);
        uiPaint.setColor(0x66FFFFFF);
        for (int i = 1; i < 3; i++) {
            float x = vr.left + vr.width() * i / 3f;
            float y = vr.top + vr.height() * i / 3f;
            canvas.drawLine(x, vr.top, x, vr.bottom, uiPaint);
            canvas.drawLine(vr.left, y, vr.right, y, uiPaint);
        }

        uiPaint.setStyle(Paint.Style.FILL);
        uiPaint.setColor(getContext().getColor(R.color.accent));
        float r = 7f * density;
        canvas.drawCircle(vr.left, vr.top, r, uiPaint);
        canvas.drawCircle(vr.right, vr.top, r, uiPaint);
        canvas.drawCircle(vr.left, vr.bottom, r, uiPaint);
        canvas.drawCircle(vr.right, vr.bottom, r, uiPaint);
    }

    // ============ 手势 ============

    private float[] toBitmapPoint(float x, float y) {
        float[] pt = new float[]{x, y};
        toBitmap.mapPoints(pt);
        return pt;
    }

    private final Matrix hitTmp = new Matrix();
    private final Matrix hitInv = new Matrix();

    /** 供测试/无障碍使用：屏幕坐标命中的图层。 */
    public Layer layerAt(float x, float y) {
        return hitLayer(x, y);
    }

    private Layer hitLayer(float x, float y) {
        for (int i = layers.size() - 1; i >= 0; i--) {
            Layer l = layers.get(i);
            if (l.type == LayerType.MOSAIC) continue;   // 马赛克钉在底图上，不允许拖走
            hitTmp.set(viewMat);
            hitTmp.preConcat(l.matrix);
            if (!hitTmp.invert(hitInv)) continue;
            float[] local = new float[]{x, y};
            hitInv.mapPoints(local);
            RectF bounds = localBounds(l);
            float slop = 14f * density;
            if (l.type == LayerType.TEXT) slop += Math.max(0f, l.strokeWidth);
            bounds.inset(-slop, -slop);
            if (bounds.contains(local[0], local[1])) {
                return l;
            }
        }
        return null;
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (base == null) return false;
        if (viewZoomMode) return handleViewZoomTouch(e);

        // 手势仲裁：按下第一根手指时就锁定目标（画布 or 图层），整段手势期间不再改判。
        // 之前每帧都用 pointer0 重新 hit test，一根手指压在图层、另一根压在空白时会来回切换，
        // 表现为"时而缩放画布、时而缩放图层"。
        if (e.getActionMasked() == MotionEvent.ACTION_DOWN) {
            gestureOnCanvas = hitLayer(e.getX(), e.getY()) == null;
        }
        if (e.getPointerCount() >= 2) {
            // 第二根手指落下时再校正一次：第一根在空白、第二根明确落在图层上，
            // 说明用户其实想缩放这个图层，这时把锁定目标改判成图层（只改判一次）。
            if (e.getActionMasked() == MotionEvent.ACTION_POINTER_DOWN && gestureOnCanvas
                    && !viewZoomMode) {
                Layer l = hitLayer(e.getX(1), e.getY(1));
                if (l != null) {
                    gestureOnCanvas = false;
                    selected = l;
                    dragging = l;
                }
            }
            if (viewZoomMode || gestureOnCanvas) {
                return handleViewZoomTouch(e);
            }
            if (dragging == null) {
                Layer l = hitLayer(e.getX(0), e.getY(0));
                if (l == null) l = selected;
                if (l != null) {
                    selected = l;
                    dragging = l;
                }
            }
            startGesture();
            handlePinch(e);
            return true;
        }

        float x = e.getX();
        float y = e.getY();

        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                startGesture();
                if (mode == Mode.CROP && cropVisible) {
                    cropHandle = hitCropHandle(x, y);
                    lastDx = x;
                    lastDy = y;
                    return cropHandle >= 0;
                } else if (mode == Mode.DRAW || mode == Mode.MOSAIC) {
                    startStroke(x, y, mode == Mode.MOSAIC);
                    return true;
                } else if (mode == Mode.WATERMARK) {
                    float[] pt = toBitmapPoint(x, y);
                    setWatermarkAnchor(pt[0] / base.getWidth(), pt[1] / base.getHeight());
                    return true;
                } else if (mode == Mode.SHAPE) {
                    float[] pt = toBitmapPoint(x, y);
                    shapeX1 = shapeX2 = pt[0];
                    shapeY1 = shapeY2 = pt[1];
                    shaping = true;
                    invalidate();
                    return true;
                } else {
                    Layer l = hitLayer(x, y);
                    if (l == null && selected != null && selected.type != LayerType.MOSAIC
                            && insideSelection(x, y, 20f * density)) {
                        l = selected;   // 点在自己选中框附近，也当作拖这个图层
                    }
                    if (l != null) {
                        selected = l;
                        dragging = l;
                        dragStartMatrix.set(l.matrix);
                        groupDragStart.clear();
                        if (l.groupId != 0) {
                            for (Layer g : layers) {
                                if (g.groupId == l.groupId) groupDragStart.put(g, new Matrix(g.matrix));
                            }
                        }
                        groupStart.clear();
                        groupMembers.clear();
                        if (l.groupId != 0) {
                            for (Layer g : layers) {
                                if (g.groupId == l.groupId) {
                                    groupMembers.add(g);
                                    groupStart.add(new Matrix(g.matrix));
                                }
                            }
                        }
                        float[] bp = toBitmapPoint(x, y);
                        dragStartX = bp[0];
                        dragStartY = bp[1];
                        lastDx = x;
                        lastDy = y;
                        notifyLayerChanged();
                        invalidate();
                        return true;
                    }
                    if (selected != null) {
                        selected = null;
                        notifyLayerChanged();
                        invalidate();
                    }
                    return false;
                }

            case MotionEvent.ACTION_MOVE:
                if (mode == Mode.WATERMARK) {
                    float[] pt = toBitmapPoint(x, y);
                    setWatermarkAnchor(pt[0] / base.getWidth(), pt[1] / base.getHeight());
                    return true;
                } else if (mode == Mode.CROP && cropHandle >= 0) {
                    moveCrop(cropHandle, x - lastDx, y - lastDy);
                    lastDx = x;
                    lastDy = y;
                    invalidate();
                    return true;
                } else if (shaping) {
                    float[] pt = toBitmapPoint(x, y);
                    shapeX2 = pt[0];
                    shapeY2 = pt[1];
                    invalidate();
                    return true;
                } else if (drawing) {
                    float[] pt = toBitmapPoint(x, y);
                    Layer s = layers.get(layers.size() - 1);
                    s.path.lineTo(pt[0], pt[1]);
                    s.fillDirty = true;
                    invalidate();
                    return true;
                } else if (dragging != null) {
                    float[] p1 = toBitmapPoint(x, y);
                    if (!groupMembers.isEmpty()) {
                        float ddx = p1[0] - dragStartX;
                        float ddy = p1[1] - dragStartY;
                        for (int gi = 0; gi < groupMembers.size(); gi++) {
                            Layer g = groupMembers.get(gi);
                            g.matrix.set(groupStart.get(gi));
                            g.matrix.postTranslate(ddx, ddy);
                        }
                    } else {
                        dragging.matrix.set(dragStartMatrix);
                        dragging.matrix.postTranslate(p1[0] - dragStartX, p1[1] - dragStartY);
                    }
                    lastDx = x;
                    lastDy = y;
                    invalidate();
                    return true;
                }
                return false;

            case MotionEvent.ACTION_POINTER_DOWN:
                startPinch(e);
                return true;

            case MotionEvent.ACTION_POINTER_UP:
                pinching = false;
                return true;

            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                gestureOnCanvas = false;
                if (shaping) {
                    shaping = false;
                    float dx = Math.abs(shapeX2 - shapeX1);
                    float dy = Math.abs(shapeY2 - shapeY1);
                    if (dx > 12f || dy > 12f) {
                        pushHistory();
                        Layer l = new Layer();
                        l.type = LayerType.SHAPE;
                        l.shapeType = shapeType;
                        l.x1 = shapeX1;
                        l.y1 = shapeY1;
                        l.x2 = shapeX2;
                        l.y2 = shapeY2;
                        l.color = drawColor;
                        l.width = drawWidthDp * density / Math.max(scale, 0.0001f);
                        layers.add(l);
                        selected = l;
                        notifyLayerChanged();
                    }
                    invalidate();
                }
                cropHandle = -1;
                drawing = false;
                dragging = null;
                groupDragStart.clear();
                groupMembers.clear();
                groupStart.clear();
                pinching = false;
                endGesture();
                return true;
        }
        return false;
    }

    private void startGesture() {
        if (!gestureActive) {
            gestureActive = true;
            invalidate();
        }
    }

    private void endGesture() {
        if (gestureActive) {
            gestureActive = false;
            invalidate(); // 松手补一帧全清晰原图
        }
    }

    private void startStroke(float x, float y, boolean mosaic) {
        if (mosaic) pixelated();
        pushHistory();
        drawing = true;
        Layer l = new Layer();
        l.type = mosaic ? LayerType.MOSAIC : LayerType.STROKE;
        l.path = new Path();
        l.color = drawColor;
        l.width = (mosaic ? mosaicWidthDp : drawWidthDp) * density / Math.max(scale, 0.0001f);
        l.block = mosaicBlockDp;
        l.mosaicStyle = mosaicStyle;
        float[] pt = toBitmapPoint(x, y);
        l.path.moveTo(pt[0], pt[1]);
        l.path.lineTo(pt[0] + 0.05f, pt[1]);
        layers.add(l);
        selected = null;
        invalidate();
    }

    // ============ 蒙版 ============

    public int getSelectedMaskType() {
        return selected == null ? 0 : selected.maskType;
    }

    public void setSelectedMaskType(int type) {
        if (selected == null) return;
        pushHistory();
        selected.maskType = Math.max(0, Math.min(3, type));
        if (selected.maskType != 0) {
            // 默认蒙版留 8% 边，避免一开就贴死边缘
            selected.maskL = 0.08f; selected.maskT = 0.08f;
            selected.maskR = 0.92f; selected.maskB = 0.92f;
        }
        notifyLayerChanged();
        invalidate();
    }

    public void setSelectedMaskDir(int dir) {
        if (selected == null) return;
        selected.maskDir = dir == 0 ? 0 : 1;
        invalidate();
    }

    public void setSelectedMaskFeather(float f) {
        if (selected == null) return;
        selected.maskFeather = Math.max(0.02f, Math.min(0.9f, f));
        invalidate();
    }

    /** 蒙版内缩（0 = 铺满，0.5 = 只剩中间一半），给方形/圆形蒙版用。 */
    public void setSelectedMaskInset(float inset) {
        if (selected == null) return;
        inset = Math.max(0f, Math.min(0.45f, inset));
        selected.maskL = inset;
        selected.maskT = inset;
        selected.maskR = 1f - inset;
        selected.maskB = 1f - inset;
        invalidate();
    }

    /** 测试用：当前视图矩阵 */
    public float[] viewMatForTest() {
        float[] v = new float[9];
        viewMat.getValues(v);
        return v;
    }

    // ============ 画面缩放 / 平移 ============

    public void setViewZoomMode(boolean on) {
        viewZoomMode = on;
        if (!on) {
            userZoom = 1f;
            userPanX = 0f;
            userPanY = 0f;
            recompute();
            invalidate();
        }
    }

    public boolean isViewZoomMode() {
        return viewZoomMode;
    }

    public float getViewZoom() {
        return userZoom;
    }

    public void resetViewZoom() {
        userZoom = 1f;
        userPanX = 0f;
        userPanY = 0f;
        recompute();
        invalidate();
    }

    /** 以某个屏幕点为焦点缩放画面，范围 1x~6x。 */
    public void zoomViewAt(float factor, float fx, float fy) {
        float target = Math.max(1f, Math.min(6f, userZoom * factor));
        setViewZoomAbsolute(target, fx, fy);
    }

    private void unusedZoomAt(float factor, float fx, float fy) {
        float target = Math.max(1f, Math.min(6f, userZoom * factor));
        float applied = target / userZoom;
        userZoom = target;
        userPanX = fx + (userPanX - fx) * applied;
        userPanY = fy + (userPanY - fy) * applied;
        if (userZoom <= 1.0001f) {
            userPanX = 0f;
            userPanY = 0f;
            userZoom = 1f;
        }
        recompute();
        invalidate();
    }

    public void panView(float dx, float dy) {
        if (userZoom <= 1.0001f) return;
        userPanX += dx;
        userPanY += dy;
        recompute();
        invalidate();
    }

    // ============ 选中图层的显式尺寸 / 旋转（滑杆用） ============

    public boolean hasSelectedSticker() {
        return selected != null && selected.type == LayerType.STICKER && base != null;
    }

    /** 选中贴纸当前占底图宽度的比例（0.05~2.0）；没有选中贴纸返回 -1。 */
    public float getSelectedStickerWidthRatio() {
        if (!hasSelectedSticker()) return -1f;
        float[] v = new float[9];
        selected.matrix.getValues(v);
        float sx = (float) Math.hypot(v[0], v[1]);
        return sx * selected.stickerW / Math.max(1f, base.getWidth());
    }

    public void setSelectedStickerWidthRatio(float ratio) {
        if (!hasSelectedSticker()) return;
        ratio = Math.max(0.03f, Math.min(2.5f, ratio));
        float target = ratio * base.getWidth() / Math.max(1f, selected.stickerW);
        applyScaleRotation(target, null);
    }

    public float getSelectedRotationDeg() {
        if (selected == null) return 0f;
        float[] v = new float[9];
        selected.matrix.getValues(v);
        return (float) Math.toDegrees(Math.atan2(v[1], v[0]));
    }

    public void setSelectedRotationDeg(float deg) {
        if (selected == null) return;
        applyScaleRotation(null, deg);
    }

    /** 只换缩放/旋转，平移点保持不动，避免调滑杆时图层跑位。 */
    private void applyScaleRotation(Float scale, Float rotationDeg) {
        if (selected == null) return;
        float[] v = new float[9];
        selected.matrix.getValues(v);
        float curSx = (float) Math.hypot(v[0], v[1]);
        float curRot = (float) Math.toDegrees(Math.atan2(v[1], v[0]));
        float s = scale == null ? curSx : scale;
        float rot = rotationDeg == null ? curRot : rotationDeg;
        float tx = v[2];
        float ty = v[5];
        Matrix m = new Matrix();
        m.setRotate(rot);          // R
        m.postScale(s, s);         // S*R   （postScale 是 参数×M）
        m.postTranslate(tx, ty);   // T*S*R
        selected.matrix.set(m);
        invalidate();
        notifyLayerChanged();
    }

    /** 画面缩放模式：单指平移、双指缩放，不碰任何图层。 */
    private boolean handleViewZoomTouch(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                lastDx = e.getX();
                lastDy = e.getY();
                return true;
            case MotionEvent.ACTION_POINTER_DOWN:
                if (e.getPointerCount() >= 2) {
                    zoomStartDist = (float) Math.hypot(e.getX(1) - e.getX(0), e.getY(1) - e.getY(0));
                    zoomStartZoom = userZoom;
                    zoomFocusX = (e.getX(0) + e.getX(1)) / 2f;
                    zoomFocusY = (e.getY(0) + e.getY(1)) / 2f;
                }
                return true;
            case MotionEvent.ACTION_MOVE:
                if (e.getPointerCount() >= 2 && zoomStartDist > 1f) {
                    float dist = (float) Math.hypot(e.getX(1) - e.getX(0), e.getY(1) - e.getY(0));
                    float factor = dist / zoomStartDist;
                    setViewZoomAbsolute(zoomStartZoom * factor, zoomFocusX, zoomFocusY);
                    lastDx = (e.getX(0) + e.getX(1)) / 2f;
                    lastDy = (e.getY(0) + e.getY(1)) / 2f;
                } else {
                    panView(e.getX() - lastDx, e.getY() - lastDy);
                    lastDx = e.getX();
                    lastDy = e.getY();
                }
                return true;
            case MotionEvent.ACTION_POINTER_UP:
                if (e.getPointerCount() - 1 <= 1) {
                    int idx = e.getActionIndex();
                    lastDx = e.getX(idx == 0 ? 1 : 0);
                    lastDy = e.getY(idx == 0 ? 1 : 0);
                }
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                zoomStartDist = 0f;
                return true;
        }
        return true;
    }

    /** 直接给一个绝对缩放值（双指时用，避免累计误差）。 */
    public void setViewZoomAbsolute(float targetZoom, float fx, float fy) {
        float target = Math.max(1f, Math.min(6f, targetZoom));
        float k = target / userZoom;
        float cx = getWidth() / 2f;
        float cy = getHeight() / 2f;
        // 让手指下方的那个点保持不动：p1 = k·p0 + (f - c)(1 - k)
        userPanX = k * userPanX + (fx - cx) * (1f - k);
        userPanY = k * userPanY + (fy - cy) * (1f - k);
        userZoom = target;
        if (userZoom <= 1.0001f) {
            userPanX = 0f;
            userPanY = 0f;
            userZoom = 1f;
        }
        recompute();
        invalidate();
    }

    private void startPinch(MotionEvent e) {
        if (e.getPointerCount() < 2) return;
        Layer target = selected;
        if (target != null && target.type == LayerType.MOSAIC) target = null;  // 马赛克不可缩放/移动
        if (target == null) {
            float x = (e.getX(0) + e.getX(1)) / 2f;
            float y = (e.getY(0) + e.getY(1)) / 2f;
            target = hitLayer(x, y);
            if (target == null) return;
            selected = target;
        }
        gestureBaseMatrix.set(target.matrix);
        dragging = target;
        pinching = true;
        pinchHistoryPushed = false;
        float dx = e.getX(1) - e.getX(0);
        float dy = e.getY(1) - e.getY(0);
        gestureStartDist = (float) Math.hypot(dx, dy);
        gestureStartAngle = (float) Math.toDegrees(Math.atan2(dy, dx));
        float[] c = toBitmapPoint((e.getX(0) + e.getX(1)) / 2f, (e.getY(0) + e.getY(1)) / 2f);
        gestureCx = c[0];
        gestureCy = c[1];
        invalidate();
    }

    private void handlePinch(MotionEvent e) {
        if (!pinching) startPinch(e);
        if (dragging == null) return;
        float dx = e.getX(1) - e.getX(0);
        float dy = e.getY(1) - e.getY(0);
        float dist = (float) Math.hypot(dx, dy);
        float angle = (float) Math.toDegrees(Math.atan2(dy, dx));
        float factor = gestureStartDist > 1f ? dist / gestureStartDist : 1f;
        float rotate = angle - gestureStartAngle;
        if (factor < 0.2f) factor = 0.2f;
        if (factor > 8f) factor = 8f;
        // 第一次产生真实变化时才入栈
        if (!pinchHistoryPushed && (Math.abs(factor - 1f) > 0.02f || Math.abs(rotate) > 1f)) {
            pushHistory();
            pinchHistoryPushed = true;
        }

        Matrix m = new Matrix(gestureBaseMatrix);
        m.postScale(factor, factor, gestureCx, gestureCy);
        m.postRotate(rotate, gestureCx, gestureCy);
        // 限制图层总缩放 2%~1600%，避免被无限放大后 GPU 采样花屏/爆显存
        float[] vals = new float[9];
        m.getValues(vals);
        float curScale = (float) Math.hypot(vals[0], vals[1]);
        if (curScale > 16f || curScale < 0.02f) {
            float fix = (curScale > 16f ? 16f : 0.02f) / Math.max(0.0001f, curScale);
            m.postScale(fix, fix, gestureCx, gestureCy);
        }
        float[] c1 = toBitmapPoint((e.getX(0) + e.getX(1)) / 2f, (e.getY(0) + e.getY(1)) / 2f);
        m.postTranslate(c1[0] - gestureCx, c1[1] - gestureCy);
        dragging.matrix.set(m);
        invalidate();
    }

    private int hitCropHandle(float x, float y) {
        RectF vr = cropInView();
        float slop = 26f * density;
        float[][] corners = {
                {vr.left, vr.top}, {vr.right, vr.top},
                {vr.left, vr.bottom}, {vr.right, vr.bottom}
        };
        for (int i = 0; i < 4; i++) {
            if (Math.hypot(x - corners[i][0], y - corners[i][1]) < slop) return i;
        }
        if (vr.contains(x, y)) return 4;
        return -1;
    }

    private void moveCrop(int handle, float dxv, float dyv) {
        float dx = dxv / scale;
        float dy = dyv / scale;
        if (handle == 4) {
            cropRect.offset(dx, dy);
            clampCrop();
            return;
        }
        float ax = (handle == 0 || handle == 2) ? cropRect.right : cropRect.left;
        float ay = (handle == 0 || handle == 1) ? cropRect.bottom : cropRect.top;
        float nx = (handle == 0 || handle == 2) ? cropRect.left + dx : cropRect.right + dx;
        float ny = (handle == 0 || handle == 1) ? cropRect.top + dy : cropRect.bottom + dy;

        float w = Math.abs(nx - ax);
        float h = Math.abs(ny - ay);
        if (cropAspect > 0f) {
            if (w / Math.max(h, 1f) > cropAspect) h = w / cropAspect;
            else w = h * cropAspect;
        }
        w = Math.max(w, 60f);
        h = Math.max(h, 60f);
        w = Math.min(w, base.getWidth());
        h = Math.min(h, base.getHeight());

        float left = nx < ax ? ax - w : ax;
        float top = ny < ay ? ay - h : ay;
        cropRect.set(left, top, left + w, top + h);
        clampCrop();
    }

    private void clampCrop() {
        float w = Math.min(cropRect.width(), base.getWidth());
        float h = Math.min(cropRect.height(), base.getHeight());
        if (cropRect.left < 0) {
            cropRect.left = 0;
            cropRect.right = w;
        }
        if (cropRect.top < 0) {
            cropRect.top = 0;
            cropRect.bottom = h;
        }
        if (cropRect.right > base.getWidth()) {
            cropRect.right = base.getWidth();
            cropRect.left = base.getWidth() - w;
        }
        if (cropRect.bottom > base.getHeight()) {
            cropRect.bottom = base.getHeight();
            cropRect.top = base.getHeight() - h;
        }
        if (cropRect.width() < 40f) cropRect.right = cropRect.left + 40f;
        if (cropRect.height() < 40f) cropRect.bottom = cropRect.top + 40f;
    }

    // ============ 导出 ============

    /** 渲染"除文字/贴纸之外"的画面：涂鸦/马赛克/形状会被烘进底图，文字与贴纸留给草稿单独存。 */
    public Bitmap renderExcludingTextSticker() {
        if (base == null) return null;
        renderFilter = l -> l.type != LayerType.TEXT && l.type != LayerType.STICKER;
        try {
            return renderInternal();
        } catch (Throwable t) {
            ExportDiag.warn("draft_render_base", t);
            return null;
        } finally {
            renderFilter = null;
        }
    }

    /** 取出需要单独持久化的图层（文字/贴纸）。 */
    public List<Layer> textAndStickerLayers() {
        List<Layer> out = new ArrayList<>();
        for (Layer l : layers) {
            if (l.type == LayerType.TEXT || l.type == LayerType.STICKER) out.add(l);
        }
        return out;
    }

    /** 恢复草稿时把图层原样放回去。 */
    public void addRestoredLayer(Layer l) {
        if (l == null) return;
        layers.add(l);
        notifyLayerChanged();
        invalidate();
    }

    public Bitmap render() {
        if (base == null) return null;
        try {
            return renderInternal();
        } catch (OutOfMemoryError e) {
            System.gc();
            pixelatedCache = null;
            blurredCache = null;
            try {
                return renderInternal();
            } catch (OutOfMemoryError e2) {
                return null;
            }
        }
    }

    /** 草稿/分层导出用：临时只画指定类型的图层。 */
    private java.util.function.Predicate<Layer> renderFilter;

    private Bitmap renderInternal() {

        if (Math.abs(fineRotation) > 0.05f) {
            int w = base.getWidth();
            int h = base.getHeight();
            double rad = Math.toRadians(fineRotation);
            float c = (float) Math.abs(Math.cos(rad));
            float sn = (float) Math.abs(Math.sin(rad));
            int nw = Math.max(1, (int) Math.ceil(w * c + h * sn));
            int nh = Math.max(1, (int) Math.ceil(w * sn + h * c));
            Matrix m = new Matrix();
            m.postTranslate(nw / 2f, nh / 2f);
            m.postRotate(fineRotation);
            m.postTranslate(-w / 2f, -h / 2f);
            Bitmap out = Bitmap.createBitmap(nw, nh, Bitmap.Config.ARGB_8888);
            Canvas c2 = new Canvas(out);
            drawContent(c2, m);
            return out;
        }

        Bitmap out = Bitmap.createBitmap(base.getWidth(), base.getHeight(), Bitmap.Config.ARGB_8888);
        drawContent(new Canvas(out));
        return out;
    }

    private void drawContent(Canvas c) {
        drawContent(c, new Matrix());
    }

    private void drawContent(Canvas c, Matrix pre) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        p.setColorFilter(colorFilter);
        c.drawBitmap(base, pre, p);

        Matrix parent = new Matrix(pre);
        for (Layer layer : layers) {
            if (renderFilter != null && !renderFilter.test(layer)) continue;
            drawLayer(c, layer, parent, 1f);
        }

        if (borderWidthDp > 0f && borderColor != 0) {
            borderPaint.setColor(borderColor);
            borderPaint.setStyle(Paint.Style.STROKE);
            borderPaint.setStrokeWidth(borderWidthDp * density);
            float half = borderWidthDp * density / 2f;
            c.save();
            c.concat(pre);
            c.drawRect(half, half, base.getWidth() - half, base.getHeight() - half, borderPaint);
            c.restore();
        }

        drawFinishing(c, pre);
    }
}
