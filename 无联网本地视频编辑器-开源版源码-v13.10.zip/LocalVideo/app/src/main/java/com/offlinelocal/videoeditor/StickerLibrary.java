package com.offlinelocal.videoeditor;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;

/**
 * 内置贴纸：全部用矢量路径现画，不依赖 emoji 字体，
 * 因此任何设备、任何语言环境都能正常显示（也不会因为缺字变成空白）。
 */
public class StickerLibrary {

    /** 贴纸总数：前 12 个沿用原矢量画法，13 之后是表情/手势/物件。 */
    public static final int COUNT = 63;

    public static final String[] NAMES = {
            "星星", "爱心", "对勾", "叉号", "圆环", "三角", "箭头", "方框" ,
            "感叹", "靶心", "闪电", "笑脸", "微笑", "大笑", "狂笑", "眨眼" ,
            "爱心眼", "星星眼", "感动哭", "大哭", "委屈", "生气", "爆怒", "惊讶" ,
            "震惊", "疑惑", "无语", "困倦", "睡着", "得意", "坏笑", "噤声" ,
            "点赞", "比心", "鼓掌", "挥手", "托腮人物", "指一指", "握拳", "击掌" ,
            "比耶", "OK", "祈祷", "摊手", "抱拳", "捂脸", "加油", "拉勾" ,
            "托腮手", "火焰", "彩虹", "音符", "咖啡", "礼物", "皇冠", "灯泡" ,
            "炸弹", "泪滴", "心碎", "双心", "汗滴", "云朵", "月牙"
    };

    static final String[] FILES = {
            "st_01_star.png", "st_02_heart.png", "st_03_check.png", "st_04_cross.png", "st_05_ring.png",
            "st_06_triangle.png", "st_07_arrow.png", "st_08_square.png", "st_09_exclaim.png", "st_10_target.png",
            "st_11_bolt.png", "st_12_smile.png", "st_13_soft_smile.png", "st_14_laugh.png", "st_15_rofl.png",
            "st_16_wink.png", "st_17_heart_eyes.png", "st_18_star_eyes.png", "st_19_touched.png", "st_20_cry.png",
            "st_21_sad.png", "st_22_angry.png", "st_23_rage.png", "st_24_surprised.png", "st_25_shocked.png",
            "st_26_confused.png", "st_27_speechless.png", "st_28_sleepy.png", "st_29_asleep.png", "st_30_smug.png",
            "st_31_smirk.png", "st_32_hush.png", "st_33_thumbsup.png", "st_34_finger_heart.png", "st_35_clap.png",
            "st_36_wave.png", "st_37_chin_person.png", "st_38_point.png", "st_39_fist.png", "st_40_highfive.png",
            "st_41_victory.png", "st_42_ok.png", "st_43_pray.png", "st_44_shrug.png", "st_45_salute.png",
            "st_46_facepalm.png", "st_47_fighting.png", "st_48_pinky.png", "st_49_chin_hand.png", "st_50_fire.png",
            "st_51_rainbow.png", "st_52_note.png", "st_53_coffee.png", "st_54_gift.png", "st_55_crown.png",
            "st_56_bulb.png", "st_57_bomb.png", "st_58_teardrop.png", "st_59_heart_broken.png", "st_60_hearts.png",
            "st_61_sweat.png", "st_62_cloud.png", "st_63_moon.png"
    };

    /** 分类：名字与起始下标（基础 0-11 / 情绪 12-30 / 手势 31-48 / 物件 49-62）。 */
    public static final String[] CATEGORIES = {"基础", "情绪", "手势", "物件"};
    public static final int[] CATEGORY_START = {0, 12, 31, 49};

    private static final android.util.LruCache<String, Bitmap> THUMBS =
            new android.util.LruCache<String, Bitmap>(32) {
                @Override
                protected int sizeOf(String key, Bitmap value) {
                    return Math.max(1, value.getByteCount() / 1024);
                }
            };


    private static final int[] COLORS = {
            0xFFF5A623, 0xFFFF5A5A, 0xFF3DDC97, 0xFFFF5A5A,
            0xFF4D9BFF, 0xFFF5A623, 0xFF3DDC97, 0xFF4D9BFF,
            0xFFFF5A5A, 0xFFFF5A5A, 0xFFF5A623, 0xFFF5A623
    };

    private static final String RECENT_PREF = "freecut_sticker_recent";

    /** 最近用过的贴纸（最多 12 个，新的排前面）。 */
    public static java.util.List<Integer> recent(Context ctx) {
        java.util.List<Integer> out = new java.util.ArrayList<>();
        String raw = ctx.getSharedPreferences(RECENT_PREF, Context.MODE_PRIVATE)
                .getString("ids", "");
        for (String part : raw.split(",")) {
            try {
                int v = Integer.parseInt(part.trim());
                if (v >= 0 && v < COUNT && !out.contains(v)) out.add(v);
            } catch (Exception ignored) {
            }
            if (out.size() >= 12) break;
        }
        return out;
    }

    public static void pushRecent(Context ctx, int index) {
        java.util.List<Integer> list = recent(ctx);
        list.remove(Integer.valueOf(index));
        list.add(0, index);
        while (list.size() > 12) list.remove(list.size() - 1);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < list.size(); i++) {
            if (i > 0) sb.append(',');
            sb.append(list.get(i));
        }
        ctx.getSharedPreferences(RECENT_PREF, Context.MODE_PRIVATE)
                .edit().putString("ids", sb.toString()).apply();
    }

    /** 取一张贴纸位图：优先 assets/stickers 下的透明 PNG，没有就回落到原有矢量画法。 */
    public static Bitmap make(Context ctx, int index, int sizePx) {
        int i = Math.max(0, Math.min(COUNT - 1, index));
        Bitmap src = null;
        try (java.io.InputStream in = ctx.getAssets().open("stickers/" + FILES[i])) {
            src = android.graphics.BitmapFactory.decodeStream(in);
        } catch (Throwable ignored) {
        }
        if (src != null) {
            // assets 解码出来的 PNG 会带 density（常见 160dpi），高密度屏上 drawBitmap 会按密度比
            // 再放大一次：贴纸画出来比选中框大、还偏位。统一清成 DENSITY_NONE，按像素 1:1 画。
            src.setDensity(Bitmap.DENSITY_NONE);
            if (src.getWidth() == sizePx && src.getHeight() == sizePx) return src;
            Bitmap out = Bitmap.createScaledBitmap(src, sizePx, sizePx, true);
            out.setDensity(Bitmap.DENSITY_NONE);
            if (out != src) src.recycle();
            return out;
        }
        return makeVector(ctx, index, sizePx);
    }

    /** 面板缩略图：解码时就按 inSampleSize 降采样，63 张不会一起把内存吃满。 */
    public static Bitmap thumb(Context ctx, int index, int px) {
        int i = Math.max(0, Math.min(COUNT - 1, index));
        String key = i + "@" + px;
        Bitmap cached = THUMBS.get(key);
        if (cached != null) return cached;
        Bitmap bmp = null;
        try (java.io.InputStream in = ctx.getAssets().open("stickers/" + FILES[i])) {
            android.graphics.BitmapFactory.Options o = new android.graphics.BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            android.graphics.BitmapFactory.decodeStream(in, null, o);
            int sample = 1;
            while (Math.max(o.outWidth, o.outHeight) / sample > px * 2) sample *= 2;
            try (java.io.InputStream in2 = ctx.getAssets().open("stickers/" + FILES[i])) {
                android.graphics.BitmapFactory.Options o2 = new android.graphics.BitmapFactory.Options();
                o2.inSampleSize = sample;
                bmp = android.graphics.BitmapFactory.decodeStream(in2, null, o2);
            }
        } catch (Throwable ignored) {
        }
        if (bmp == null) return null;
        bmp.setDensity(Bitmap.DENSITY_NONE);
        Bitmap out = Bitmap.createScaledBitmap(bmp, px, px, true);
        out.setDensity(Bitmap.DENSITY_NONE);
        if (out != bmp) bmp.recycle();
        THUMBS.put(key, out);
        return out;
    }

    private static Bitmap makeVector(Context ctx, int index, int sizePx) {
        int i = Math.max(0, index) % 12;
        Bitmap bmp = Bitmap.createBitmap(sizePx, sizePx, Bitmap.Config.ARGB_8888);
        bmp.setDensity(Bitmap.DENSITY_NONE);
        Canvas c = new Canvas(bmp);
        Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        fill.setColor(COLORS[i]);
        fill.setStyle(Paint.Style.FILL);
        Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
        stroke.setColor(COLORS[i]);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(sizePx * 0.09f);
        stroke.setStrokeCap(Paint.Cap.ROUND);

        float s = sizePx;
        float cx = s / 2f, cy = s / 2f;

        switch (i) {
            case 0: star(c, fill, cx, cy, s * 0.44f, s * 0.19f); break;
            case 1: heart(c, fill, cx, cy, s * 0.42f); break;
            case 2: check(c, stroke, cx, cy, s); break;
            case 3: cross(c, stroke, cx, cy, s); break;
            case 4: c.drawCircle(cx, cy, s * 0.34f, stroke); break;
            case 5: triangle(c, fill, cx, cy, s * 0.42f); break;
            case 6: arrow(c, fill, stroke, cx, cy, s); break;
            case 7: c.drawRect(new RectF(s * 0.16f, s * 0.16f, s * 0.84f, s * 0.84f), stroke); break;
            case 8: bang(c, fill, cx, cy, s); break;
            case 9: target(c, fill, stroke, cx, cy, s); break;
            case 10: bolt(c, fill, cx, cy, s); break;
            default: smile(c, fill, stroke, cx, cy, s); break;
        }
        return bmp;
    }

    private static void star(Canvas c, Paint p, float cx, float cy, float outer, float inner) {
        Path path = new Path();
        for (int i = 0; i < 10; i++) {
            float r = (i % 2 == 0) ? outer : inner;
            double ang = -Math.PI / 2 + i * Math.PI / 5;
            float x = cx + r * (float) Math.cos(ang);
            float y = cy + r * (float) Math.sin(ang);
            if (i == 0) path.moveTo(x, y);
            else path.lineTo(x, y);
        }
        path.close();
        c.drawPath(path, p);
    }

    private static void heart(Canvas c, Paint p, float cx, float cy, float r) {
        Path path = new Path();
        path.moveTo(cx, cy + r * 0.72f);
        path.cubicTo(cx - r * 1.3f, cy - r * 0.2f, cx - r * 0.48f, cy - r, cx, cy - r * 0.42f);
        path.cubicTo(cx + r * 0.48f, cy - r, cx + r * 1.3f, cy - r * 0.2f, cx, cy + r * 0.72f);
        path.close();
        c.drawPath(path, p);
    }

    private static void check(Canvas c, Paint p, float cx, float cy, float s) {
        c.drawLine(cx - s * 0.28f, cy + s * 0.02f, cx - s * 0.05f, cy + s * 0.25f, p);
        c.drawLine(cx - s * 0.05f, cy + s * 0.25f, cx + s * 0.32f, cy - s * 0.24f, p);
    }

    private static void cross(Canvas c, Paint p, float cx, float cy, float s) {
        c.drawLine(cx - s * 0.26f, cy - s * 0.26f, cx + s * 0.26f, cy + s * 0.26f, p);
        c.drawLine(cx + s * 0.26f, cy - s * 0.26f, cx - s * 0.26f, cy + s * 0.26f, p);
    }

    private static void triangle(Canvas c, Paint p, float cx, float cy, float r) {
        Path path = new Path();
        path.moveTo(cx, cy - r);
        path.lineTo(cx + r * 0.92f, cy + r * 0.72f);
        path.lineTo(cx - r * 0.92f, cy + r * 0.72f);
        path.close();
        c.drawPath(path, p);
    }

    private static void arrow(Canvas c, Paint p, Paint stroke, float cx, float cy, float s) {
        stroke.setStrokeWidth(s * 0.11f);
        c.drawLine(cx - s * 0.38f, cy, cx + s * 0.34f, cy, stroke);
        Path head = new Path();
        head.moveTo(cx + s * 0.4f, cy);
        head.lineTo(cx + s * 0.16f, cy - s * 0.2f);
        head.lineTo(cx + s * 0.16f, cy + s * 0.2f);
        head.close();
        c.drawPath(head, p);
    }

    private static void bang(Canvas c, Paint p, float cx, float cy, float s) {
        Path bar = new Path();
        bar.addRoundRect(new RectF(cx - s * 0.08f, cy - s * 0.38f, cx + s * 0.08f, cy + s * 0.12f),
                s * 0.08f, s * 0.08f, Path.Direction.CW);
        c.drawPath(bar, p);
        c.drawCircle(cx, cy + s * 0.3f, s * 0.075f, p);
    }

    private static void target(Canvas c, Paint p, Paint stroke, float cx, float cy, float s) {
        c.drawCircle(cx, cy, s * 0.36f, stroke);
        c.drawCircle(cx, cy, s * 0.2f, stroke);
        c.drawCircle(cx, cy, s * 0.07f, p);
    }

    private static void bolt(Canvas c, Paint p, float cx, float cy, float s) {
        Path path = new Path();
        path.moveTo(cx + s * 0.1f, cy - s * 0.4f);
        path.lineTo(cx - s * 0.26f, cy + s * 0.06f);
        path.lineTo(cx - s * 0.02f, cy + s * 0.06f);
        path.lineTo(cx - s * 0.1f, cy + s * 0.4f);
        path.lineTo(cx + s * 0.26f, cy - s * 0.06f);
        path.lineTo(cx + s * 0.02f, cy - s * 0.06f);
        path.close();
        c.drawPath(path, p);
    }

    private static void smile(Canvas c, Paint p, Paint stroke, float cx, float cy, float s) {
        stroke.setStrokeWidth(s * 0.07f);
        c.drawCircle(cx, cy, s * 0.36f, stroke);
        c.drawCircle(cx - s * 0.12f, cy - s * 0.1f, s * 0.045f, p);
        c.drawCircle(cx + s * 0.12f, cy - s * 0.1f, s * 0.045f, p);
        RectF arc = new RectF(cx - s * 0.18f, cy - s * 0.18f, cx + s * 0.18f, cy + s * 0.2f);
        c.drawArc(arc, 20f, 140f, false, stroke);
    }

    /** 供界面用的小图标（列表里显示）。 */
    public static Bitmap icon(Context ctx, int index, int sizePx) {
        return make(ctx, index, sizePx);
    }
}
