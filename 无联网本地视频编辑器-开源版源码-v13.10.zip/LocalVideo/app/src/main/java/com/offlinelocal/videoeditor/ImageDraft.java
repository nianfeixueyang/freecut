package com.offlinelocal.videoeditor;

import android.content.Context;
import android.graphics.Bitmap;
import android.net.Uri;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;

/**
 * 图片编辑器自动草稿（图层级）。
 *
 * 底图只烘涂鸦/马赛克/形状；文字与贴纸写进 draft.json，恢复后仍可拖动、改字、缩放。
 */
public final class ImageDraft {

    private static final String PNG = "draft.png";
    private static final String META = "draft.json";

    private ImageDraft() {
    }

    private static File dir(Context c) {
        File d = new File(c.getFilesDir(), "imgdraft");
        if (!d.isDirectory() && !d.mkdirs()) ExportDiag.warn("draft_dir", null);
        return d;
    }

    public static void saveLayered(Context c, Uri src, Bitmap flat, List<EditImageView.Layer> keep) {
        if (flat == null || flat.isRecycled()) return;
        FileOutputStream out = null;
        try {
            File d = dir(c);
            File png = new File(d, PNG);
            File tmp = new File(d, "draft.tmp.png");
            out = new FileOutputStream(tmp);
            flat.compress(Bitmap.CompressFormat.PNG, 90, out);
            out.close();
            out = null;
            if (png.exists()) png.delete();
            if (!tmp.renameTo(png)) {
                tmp.delete();
                return;
            }
            JSONObject meta = new JSONObject();
            meta.put("uri", src == null ? "" : src.toString());
            meta.put("time", System.currentTimeMillis());
            meta.put("w", flat.getWidth());
            meta.put("h", flat.getHeight());
            meta.put("v", 2);
            JSONArray arr = new JSONArray();
            if (keep != null) {
                for (int i = 0; i < keep.size(); i++) {
                    EditImageView.Layer l = keep.get(i);
                    JSONObject o = new JSONObject();
                    o.put("type", l.type == EditImageView.LayerType.TEXT ? "text" : "sticker");
                    float[] m = new float[9];
                    l.matrix.getValues(m);
                    JSONArray ma = new JSONArray();
                    for (float f : m) ma.put(f);
                    o.put("m", ma);
                    o.put("alpha", l.alpha);
                    o.put("blend", l.blend);
                    o.put("group", l.groupId);
                    o.put("maskType", l.maskType);
                    o.put("maskL", l.maskL);
                    o.put("maskT", l.maskT);
                    o.put("maskR", l.maskR);
                    o.put("maskB", l.maskB);
                    o.put("maskDir", l.maskDir);
                    o.put("maskFeather", l.maskFeather);
                    if (l.type == EditImageView.LayerType.TEXT) {
                        o.put("text", l.text == null ? "" : l.text);
                        o.put("textSize", l.textSize);
                        o.put("textColor", l.textColor);
                        o.put("align", l.align);
                        o.put("typeface", l.typeface);
                        o.put("strokeWidth", l.strokeWidth);
                        o.put("strokeColor", l.strokeColor);
                        o.put("shadow", l.shadow);
                        o.put("textBgColor", l.textBgColor);
                        o.put("textBgPad", l.textBgPad);
                    } else {
                        o.put("w", l.stickerW);
                        o.put("h", l.stickerH);
                        if (l.sticker != null && !l.sticker.isRecycled()) {
                            String name = "layer_" + i + ".png";
                            FileOutputStream fo = new FileOutputStream(new File(d, name));
                            l.sticker.compress(Bitmap.CompressFormat.PNG, 90, fo);
                            fo.close();
                            o.put("file", name);
                        }
                    }
                    arr.put(o);
                }
            }
            meta.put("layers", arr);
            Files.write(new File(d, META).toPath(),
                    meta.toString().getBytes(StandardCharsets.UTF_8));

            // 清掉这一轮没用到的旧贴纸碎片
            File[] olds = d.listFiles();
            if (olds != null) {
                for (File f : olds) {
                    String n = f.getName();
                    if (!n.startsWith("layer_") || !n.endsWith(".png")) continue;
                    boolean used = false;
                    for (int k = 0; k < arr.length(); k++) {
                        JSONObject lo = arr.optJSONObject(k);
                        if (lo != null && n.equals(lo.optString("file", ""))) {
                            used = true;
                            break;
                        }
                    }
                    if (!used) f.delete();
                }
            }
        } catch (Throwable t) {
            ExportDiag.warn("draft_save", t);
        } finally {
            try {
                if (out != null) out.close();
            } catch (Throwable ignore) {
            }
        }
    }

    public static boolean has(Context c, Uri src) {
        try {
            File d = dir(c);
            if (!new File(d, PNG).isFile()) return false;
            File meta = new File(d, META);
            if (!meta.isFile()) return false;
            String json = new String(Files.readAllBytes(meta.toPath()), StandardCharsets.UTF_8);
            JSONObject o = new JSONObject(json);
            String saved = o.optString("uri", "");
            return src == null || saved.isEmpty() || saved.equals(src.toString());
        } catch (Throwable t) {
            ExportDiag.warn("draft_has", t);
            return false;
        }
    }

    public static Bitmap load(Context c) {
        try {
            File png = new File(dir(c), PNG);
            if (!png.isFile()) return null;
            return android.graphics.BitmapFactory.decodeFile(png.getAbsolutePath());
        } catch (Throwable t) {
            ExportDiag.warn("draft_load", t);
            return null;
        }
    }

    /** 读出草稿里的文字/贴纸图层；贴纸位图从私有目录读取。 */
    public static List<EditImageView.Layer> loadLayers(Context c) {
        List<EditImageView.Layer> out = new ArrayList<>();
        try {
            File d = dir(c);
            File meta = new File(d, META);
            if (!meta.isFile()) return out;
            String json = new String(Files.readAllBytes(meta.toPath()), StandardCharsets.UTF_8);
            JSONObject o = new JSONObject(json);
            JSONArray arr = o.optJSONArray("layers");
            if (arr == null) return out;
            for (int i = 0; i < arr.length(); i++) {
                JSONObject lo = arr.getJSONObject(i);
                EditImageView.Layer l = new EditImageView.Layer();
                String t = lo.optString("type", "text");
                l.type = "sticker".equals(t)
                        ? EditImageView.LayerType.STICKER : EditImageView.LayerType.TEXT;
                JSONArray ma = lo.optJSONArray("m");
                if (ma != null && ma.length() == 9) {
                    float[] m = new float[9];
                    for (int k = 0; k < 9; k++) m[k] = (float) ma.getDouble(k);
                    l.matrix.setValues(m);
                }
                l.alpha = (float) lo.optDouble("alpha", 1.0);
                l.blend = lo.optInt("blend", 0);
                l.groupId = lo.optInt("group", 0);
                l.maskType = lo.optInt("maskType", 0);
                l.maskL = (float) lo.optDouble("maskL", 0.08);
                l.maskT = (float) lo.optDouble("maskT", 0.08);
                l.maskR = (float) lo.optDouble("maskR", 0.92);
                l.maskB = (float) lo.optDouble("maskB", 0.92);
                l.maskDir = lo.optInt("maskDir", 0);
                l.maskFeather = (float) lo.optDouble("maskFeather", 0.25);
                if (l.type == EditImageView.LayerType.TEXT) {
                    l.text = lo.optString("text", "");
                    l.textSize = (float) lo.optDouble("textSize", 60);
                    l.textColor = lo.optInt("textColor", 0xFFFFFFFF);
                    l.align = lo.optInt("align", 1);
                    l.typeface = lo.optInt("typeface", 0);
                    l.strokeWidth = (float) lo.optDouble("strokeWidth", 0);
                    l.strokeColor = lo.optInt("strokeColor", 0xFF000000);
                    l.shadow = lo.optBoolean("shadow", true);
                    l.textBgColor = lo.optInt("textBgColor", 0);
                    l.textBgPad = (float) lo.optDouble("textBgPad", 8);
                } else {
                    l.stickerW = (float) lo.optDouble("w", 100);
                    l.stickerH = (float) lo.optDouble("h", 100);
                    String name = lo.optString("file", "");
                    if (!name.isEmpty()) {
                        File f = new File(d, name);
                        if (f.isFile()) l.sticker = android.graphics.BitmapFactory
                                .decodeFile(f.getAbsolutePath());
                    }
                }
                out.add(l);
            }
        } catch (Throwable t) {
            ExportDiag.warn("draft_layers", t);
        }
        return out;
    }

    /** 草稿只留最近 7 天，避免反复编辑在私有目录里越堆越多。 */
    public static void prune(Context c) {
        try {
            File png = new File(dir(c), PNG);
            if (png.isFile()
                    && System.currentTimeMillis() - png.lastModified() > 7L * 24 * 3600 * 1000) {
                clear(c);
            }
        } catch (Throwable t) {
            ExportDiag.warn("draft_prune", t);
        }
    }

    public static void clear(Context c) {
        try {
            File d = dir(c);
            File[] fs = d.listFiles();
            if (fs != null) for (File f : fs) f.delete();
        } catch (Throwable t) {
            ExportDiag.warn("draft_clear", t);
        }
    }
}
