package com.offlinelocal.videoeditor;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/**
 * 统一的底部面板（bottom sheet）。所有工具参数面板都走这里：
 * 圆角深色卡片、分组标题、可横向滚动的选择芯片、明确选中态。
 * 比系统 AlertDialog 的单选列表更接近成熟剪辑软件的观感。
 */
public final class SheetUi {

    public static final int BG = 0xFF15181D;
    public static final int CARD = 0xFF1D222A;
    public static final int CARD_SEL = 0xFF274036;
    public static final int TEXT = 0xFFEDEFF2;
    public static final int MUTED = 0xFF98A0AA;
    public static final int ACCENT = 0xFF37C88F;

    private SheetUi() {
    }

    /** 底部面板：dialog + 可追加内容的 body。 */
    public static final class Panel {
        public final Dialog dialog;
        public final LinearLayout body;

        Panel(Dialog d, LinearLayout body) {
            this.dialog = d;
            this.body = body;
        }

        public void show() {
            showCentered(dialog);
        }

        public void dismiss() {
            dialog.dismiss();
        }
    }

    public static Panel panel(Activity act, String title) {
        Dialog d = new Dialog(act);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout root = new LinearLayout(act);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackground(round(BG, 0, 20, 20, 0));
        root.setPadding(dp(act, 18), dp(act, 16), dp(act, 18), dp(act, 12));
        d.setContentView(root);

        LinearLayout head = new LinearLayout(act);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        TextView t = new TextView(act);
        t.setText(title);
        t.setTextColor(TEXT);
        t.setTextSize(17);
        t.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        head.addView(t, new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        TextView close = new TextView(act);
        close.setText("关闭");
        close.setTextColor(MUTED);
        close.setTextSize(13);
        close.setPadding(dp(act, 10), dp(act, 6), dp(act, 4), dp(act, 6));
        close.setOnClickListener(v -> d.dismiss());
        head.addView(close);
        root.addView(head, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));
        LinearLayout body = new LinearLayout(act);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(0, dp(act, 8), 0, 0);
        root.addView(body);
        return new Panel(d, body);
    }

    public static void showCentered(Dialog d) {
        Window w = d.getWindow();
        if (w == null) return;
        w.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
        w.setLayout(WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.WRAP_CONTENT);
        w.setGravity(Gravity.BOTTOM);
        w.getAttributes().windowAnimations = android.R.style.Animation_Dialog;
        d.show();
        Window win = d.getWindow();
        if (win != null) {
            win.setLayout(WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.WRAP_CONTENT);
            win.setGravity(Gravity.BOTTOM);
        }
    }

    public static void section(Context c, LinearLayout parent, String label) {
        TextView t = new TextView(c);
        t.setText(label);
        t.setTextColor(MUTED);
        t.setTextSize(12);
        t.setPadding(0, dp(c, 12), 0, dp(c, 6));
        parent.addView(t);
    }

    /** 横向可滚动的芯片行，返回用于刷新选中态的 View 数组。 */
    public static TextView[] chips(Context c, LinearLayout parent,
                                   String[] labels, int selected,
                                   java.util.function.IntConsumer onClick) {
        HorizontalScrollView hs = new HorizontalScrollView(c);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout row = new LinearLayout(c);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(0, dp(c, 2), 0, dp(c, 2));
        hs.addView(row);
        TextView[] out = new TextView[labels.length];
        for (int i = 0; i < labels.length; i++) {
            final int idx = i;
            TextView chip = new TextView(c);
            chip.setText(labels[i]);
            chip.setTextSize(14);
            chip.setGravity(Gravity.CENTER);
            chip.setPadding(dp(c, 14), dp(c, 9), dp(c, 14), dp(c, 9));
            chip.setTextColor(i == selected ? ACCENT : TEXT);
            chip.setBackground(round(i == selected ? CARD_SEL : CARD, 1,
                    18, 18, i == selected ? ACCENT : 0xFF303741));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT);
            lp.rightMargin = dp(c, 8);
            row.addView(chip, lp);
            chip.setOnClickListener(v -> {
                for (int k = 0; k < out.length; k++) {
                    out[k].setTextColor(k == idx ? ACCENT : TEXT);
                    out[k].setBackground(round(k == idx ? CARD_SEL : CARD, 1,
                            18, 18, k == idx ? ACCENT : 0xFF303741));
                }
                onClick.accept(idx);
            });
            out[i] = chip;
        }
        parent.addView(hs, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));
        return out;
    }

    /** 单选列表面板：每行 48dp，选中行高亮 + 勾。 */
    public static Panel list(Activity act, String title, String[] items, int checked,
                             java.util.function.IntConsumer onPick) {
        Panel p = panel(act, title);
        ScrollView sv = new ScrollView(act);
        sv.setVerticalScrollBarEnabled(false);
        LinearLayout col = new LinearLayout(act);
        col.setOrientation(LinearLayout.VERTICAL);
        for (int i = 0; i < items.length; i++) {
            final int idx = i;
            LinearLayout row = new LinearLayout(act);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(act, 4), 0, dp(act, 6), 0);
            row.setBackground(round(i == checked ? CARD_SEL : 0x00000000, 0, 12, 12, 0));
            TextView label = new TextView(act);
            label.setText(items[i]);
            label.setTextSize(15);
            label.setTextColor(i == checked ? ACCENT : TEXT);
            label.setSingleLine(false);
            row.addView(label, new LinearLayout.LayoutParams(0,
                    LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
            if (i == checked) {
                TextView ok = new TextView(act);
                ok.setText("✓");
                ok.setTextColor(ACCENT);
                ok.setTextSize(16);
                row.addView(ok);
            }
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, dp(act, 48));
            lp.bottomMargin = dp(act, 2);
            col.addView(row, lp);
            row.setOnClickListener(v -> {
                p.dismiss();
                onPick.accept(idx);
            });
        }
        sv.addView(col);
        p.body.addView(sv, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        int max = (int) (act.getResources().getDisplayMetrics().heightPixels * 0.62f);
        p.body.getLayoutParams();
        sv.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, Math.min(max, dp(act, 48) * items.length + dp(act, 16))));
        return p;
    }

    /** 一行滑杆：标签 + 当前值 + SeekBar。 */
    public static android.widget.SeekBar slider(Context c, LinearLayout parent, String label,
                                                int min, int max, int value,
                                                java.util.function.IntConsumer onChange) {
        LinearLayout head = new LinearLayout(c);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.setPadding(0, dp(c, 10), 0, 0);
        TextView name = new TextView(c);
        name.setText(label);
        name.setTextColor(TEXT);
        name.setTextSize(14);
        head.addView(name, new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        TextView val = new TextView(c);
        val.setText(String.valueOf(value));
        val.setTextColor(ACCENT);
        val.setTextSize(14);
        head.addView(val);
        parent.addView(head, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));
        android.widget.SeekBar sb = new android.widget.SeekBar(c);
        sb.setMax(max - min);
        sb.setProgress(value - min);
        sb.getProgressDrawable().setColorFilter(ACCENT,
                android.graphics.PorterDuff.Mode.SRC_IN);
        sb.getThumb().setColorFilter(ACCENT, android.graphics.PorterDuff.Mode.SRC_IN);
        sb.setPadding(0, dp(c, 4), 0, dp(c, 2));
        sb.setOnSeekBarChangeListener(new android.widget.SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(android.widget.SeekBar s, int progress, boolean fromUser) {
                int v = min + progress;
                val.setText(String.valueOf(v));
                if (fromUser) onChange.accept(v);
            }

            @Override
            public void onStartTrackingTouch(android.widget.SeekBar s) {
            }

            @Override
            public void onStopTrackingTouch(android.widget.SeekBar s) {
            }
        });
        parent.addView(sb, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));
        return sb;
    }

    public static TextView primaryButton(Activity a, LinearLayout parent, String label,
                                         Runnable onClick) {
        TextView b = new TextView(a);
        b.setText(label);
        b.setTextSize(15);
        b.setGravity(Gravity.CENTER);
        b.setTextColor(0xFF0C1A14);
        b.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        b.setBackground(round(ACCENT, 0, 22, 22, 0));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(a, 46));
        lp.topMargin = dp(a, 14);
        parent.addView(b, lp);
        b.setOnClickListener(v -> onClick.run());
        return b;
    }

    public static void hint(Context c, LinearLayout parent, String text) {
        TextView t = new TextView(c);
        t.setText(text);
        t.setTextColor(MUTED);
        t.setTextSize(12);
        t.setLineSpacing(dp(c, 2), 1f);
        t.setPadding(0, dp(c, 12), 0, 0);
        parent.addView(t);
    }

    public static GradientDrawable round(int fill, int strokeWidthDp, int rTop, int rBottom,
                                         int strokeColor) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        float[] r = {
                dpRaw(rTop), dpRaw(rTop),
                dpRaw(rTop), dpRaw(rTop),
                dpRaw(rBottom), dpRaw(rBottom),
                dpRaw(rBottom), dpRaw(rBottom)
        };
        g.setCornerRadii(r);
        if (strokeColor != 0) g.setStroke(strokeWidthDp, strokeColor);
        return g;
    }

    private static int dp(Context c, int v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v,
                c.getResources().getDisplayMetrics());
    }

    private static float dpRaw(int v) {
        return v * 3f;
    }
}
