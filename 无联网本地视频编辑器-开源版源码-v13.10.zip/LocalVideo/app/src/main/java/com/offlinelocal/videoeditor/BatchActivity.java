package com.offlinelocal.videoeditor;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Paint;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import android.app.AlertDialog;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import java.util.ArrayList;
import java.util.List;

/** 批量处理：多选图片 → 统一滤镜/调整/边框 → 逐张导出。 */
public class BatchActivity extends AppCompatActivity {

    private static final int REQ_WRITE = 202;

    private ImageView preview;
    private ProgressBar progress;
    private TextView tvStatus, tvTitle;
    private LinearLayout rowFilters, rowBorderColors, rowPresets;

    private final List<Uri> uris = new ArrayList<>();
    private final List<TextView> filterChips = new ArrayList<>();
    private final List<TextView> borderChips = new ArrayList<>();

    private int filterIndex = 0;
    private float brightness = 0, contrast = 0, saturation = 0, temperature = 0;
    private int borderColor = 0;
    private float borderWidthDp = 0f;
    private String watermark = null;

    private Bitmap firstBitmap;
    private boolean running = false;

    public static Intent buildIntent(Context ctx, ArrayList<Uri> list) {
        Intent i = new Intent(ctx, BatchActivity.class);
        i.putParcelableArrayListExtra("uris", list);
        return i;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_batch);

        preview = findViewById(R.id.preview);
        progress = findViewById(R.id.progress);
        tvStatus = findViewById(R.id.tvStatus);
        tvTitle = findViewById(R.id.tvTitle);
        rowFilters = findViewById(R.id.rowFilters);
        rowBorderColors = findViewById(R.id.rowBorderColors);
        rowPresets = findViewById(R.id.rowPresets);

        findViewById(R.id.btnBack).setOnClickListener(v -> {
            if (running) {
                toast("正在处理中，请稍候");
                return;
            }
            finish();
        });
        findViewById(R.id.btnRun).setOnClickListener(v -> runBatch());
        findViewById(R.id.btnWatermark).setOnClickListener(v -> askWatermark());

        ArrayList<Uri> list = getIntent().getParcelableArrayListExtra("uris");
        if (list == null || list.isEmpty()) {
            toast("没有收到图片");
            finish();
            return;
        }
        uris.addAll(list);
        tvTitle.setText("批量处理 " + uris.size() + " 张");
        tvStatus.setText(uris.size() + " 张图片 · 预览为第 1 张");

        buildFilters();
        buildPresets();
        buildBorderColors();
        setupAdjust();
        loadPreview();
    }

    private void buildFilters() {
        for (int i = 0; i < Filters.ALL.length; i++) {
            final int idx = i;
            TextView tv = chip(Filters.ALL[i].name, i == 0);
            tv.setOnClickListener(v -> {
                filterIndex = idx;
                for (int k = 0; k < filterChips.size(); k++) style(filterChips.get(k), k == filterIndex);
                applyPreview();
            });
            rowFilters.addView(tv);
            filterChips.add(tv);
        }
    }

    /** 我的预设：一次套用到这一批所有图（滤镜 + 调色 + 暗角）。 */
    private void buildPresets() {
        if (rowPresets == null) return;
        List<PresetStore.Preset> presets = PresetStore.all(this);
        if (presets.isEmpty()) {
            rowPresets.setVisibility(android.view.View.GONE);
            return;
        }
        TextView label = chip("预设", false);
        label.setClickable(false);
        rowPresets.addView(label);
        for (PresetStore.Preset p : presets) {
            TextView tv = chip(p.name, false);
            tv.setOnClickListener(v -> applyPreset(p));
            rowPresets.addView(tv);
        }
    }

    private void applyPreset(PresetStore.Preset p) {
        filterIndex = Math.max(0, Math.min(Filters.ALL.length - 1, p.filterIndex));
        brightness = p.brightness;
        contrast = p.contrast;
        saturation = p.saturation;
        temperature = p.temperature;
        for (int k = 0; k < filterChips.size(); k++) style(filterChips.get(k), k == filterIndex);
        SeekBar b = findViewById(R.id.seekBrightness);
        SeekBar c = findViewById(R.id.seekContrast);
        SeekBar s = findViewById(R.id.seekSaturation);
        SeekBar t = findViewById(R.id.seekTemperature);
        b.setProgress((int) (100 + brightness * 100));
        c.setProgress((int) (100 + contrast * 100));
        s.setProgress((int) (100 + saturation * 100));
        t.setProgress((int) (100 + temperature * 100));
        applyPreview();
        toast("已套用预设「" + p.name + "」到 " + uris.size() + " 张");
    }

    private void buildBorderColors() {
        int[] colors = {0, Color.WHITE, Color.BLACK, 0xFFF2E3C6};
        String[] labels = {"无边框", "白边", "黑边", "米金边"};
        for (int i = 0; i < colors.length; i++) {
            final int idx = i;
            TextView tv = chip(labels[i], i == 0);
            tv.setOnClickListener(v -> {
                for (int k = 0; k < borderChips.size(); k++) style(borderChips.get(k), k == idx);
                borderColor = colors[idx];
                borderWidthDp = idx == 0 ? 0f : Math.max(4f, borderWidthDp);
                applyPreview();
            });
            rowBorderColors.addView(tv);
            borderChips.add(tv);
        }
    }

    private void setupAdjust() {
        SeekBar b = findViewById(R.id.seekBrightness);
        SeekBar c = findViewById(R.id.seekContrast);
        SeekBar s = findViewById(R.id.seekSaturation);
        SeekBar t = findViewById(R.id.seekTemperature);
        SeekBar.OnSeekBarChangeListener l = new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar sb, int p, boolean fromUser) {
                brightness = (b.getProgress() - 100) / 100f;
                contrast = (c.getProgress() - 100) / 100f;
                saturation = (s.getProgress() - 100) / 100f;
                temperature = (t.getProgress() - 100) / 100f;
                applyPreview();
            }

            @Override public void onStartTrackingTouch(SeekBar sb) {}
            @Override public void onStopTrackingTouch(SeekBar sb) {}
        };
        b.setOnSeekBarChangeListener(l);
        c.setOnSeekBarChangeListener(l);
        s.setOnSeekBarChangeListener(l);
        t.setOnSeekBarChangeListener(l);
    }

    private TextView chip(String label, boolean selected) {
        TextView tv = new TextView(this);
        tv.setText(label);
        tv.setTextSize(12);
        tv.setGravity(Gravity.CENTER);
        tv.setPadding(dp(12), 0, dp(12), 0);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, dp(32));
        lp.rightMargin = dp(8);
        lp.gravity = Gravity.CENTER_VERTICAL;
        tv.setLayoutParams(lp);
        tv.setClickable(true);
        tv.setFocusable(true);
        style(tv, selected);
        return tv;
    }

    private void style(TextView tv, boolean selected) {
        tv.setBackgroundResource(selected ? R.drawable.bg_chip_selected : R.drawable.bg_chip);
        tv.setTextColor(selected ? getColor(R.color.on_accent) : getColor(R.color.text_1));
        tv.getPaint().setFakeBoldText(selected);
    }

    private int dp(float v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    private ColorMatrix matrix() {
        return Filters.imageMatrix(Filters.ALL[filterIndex],
                brightness, contrast, saturation, temperature);
    }

    private void loadPreview() {
        progress.setVisibility(View.VISIBLE);
        Work.run(this, () -> {
            try {
                Bitmap bmp = BitmapUtils.load(this, uris.get(0), 1440);
                runOnUiThread(() -> {
                    firstBitmap = bmp;
                    preview.setImageBitmap(bmp);
                    progress.setVisibility(View.GONE);
                    applyPreview();
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    progress.setVisibility(View.GONE);
                    toast("预览加载失败：" + e.getMessage());
                });
            }
        });
    }

    private void applyPreview() {
        if (firstBitmap == null) return;
        preview.setColorFilter(new ColorMatrixColorFilter(matrix()));
    }

    private void askWatermark() {
        android.widget.EditText input = new android.widget.EditText(this);
        input.setHint("留空则不加文字水印");
        input.setText(watermark == null ? "" : watermark);
        input.setTextColor(0xFFFFFFFF);
        input.setHintTextColor(0x88FFFFFF);
        android.widget.FrameLayout wrap = new android.widget.FrameLayout(this);
        int pad = dp(16);
        wrap.setPadding(pad, dp(8), pad, 0);
        wrap.addView(input);
        new AlertDialog.Builder(this)
                .setTitle("统一水印")
                .setMessage("会加在每张图右下角")
                .setView(wrap)
                .setNegativeButton("取消", null)
                .setPositiveButton("确定", (d, w) -> {
                    String t = input.getText().toString().trim();
                    watermark = t.isEmpty() ? null : t;
                    tvStatus.setText(uris.size() + " 张图片 · 水印：" + (watermark == null ? "无" : watermark));
                    applyPreview();
                })
                .show();
    }

    private void runBatch() {
        if (running) return;
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P
                && ContextCompat.checkSelfPermission(this, android.Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{android.Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQ_WRITE);
            return;
        }
        running = true;
        progress.setVisibility(View.VISIBLE);
        final ColorMatrix cm = matrix();
        final int color = borderColor;
        final float borderW = borderWidthDp;
        Work.run(this, () -> {
            int ok = 0, fail = 0;
            for (int i = 0; i < uris.size(); i++) {
                final int index = i;
                runOnUiThread(() -> tvStatus.setText("正在处理 " + (index + 1) + "/" + uris.size()));
                try {
                    Bitmap src = BitmapUtils.load(this, uris.get(i), 2048);
                    Bitmap out = compose(src, cm, color, borderW);
                    BitmapUtils.saveImage(this, out, "FC_batch_" + System.currentTimeMillis() + "_" + i + ".jpg");
                    // 连续处理 50 张时，不回收会一路把堆顶爆
                    if (out != src && !out.isRecycled()) out.recycle();
                    if (!src.isRecycled()) src.recycle();
                    ok++;
                } catch (Exception e) {
                    fail++;
                }
            }
            final int okCount = ok, failCount = fail;
            if (okCount > 0) HistoryStore.add(BatchActivity.this, "batch", okCount + " 张批量导出", null);
            runOnUiThread(() -> {
                running = false;
                progress.setVisibility(View.GONE);
                tvStatus.setText("完成：成功 " + okCount + " 张" + (failCount > 0 ? "，失败 " + failCount + " 张" : ""));
                toast("已保存到相册 Pictures/LocalVideo");
            });
        });
    }

    private Bitmap compose(Bitmap src, ColorMatrix cm, int borderColor, float borderDp) {
        Bitmap out = Bitmap.createBitmap(src.getWidth(), src.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(out);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        p.setColorFilter(new ColorMatrixColorFilter(cm));
        c.drawBitmap(src, 0f, 0f, p);
        if (watermark != null && !watermark.isEmpty()) {
            Paint wp = new Paint(Paint.ANTI_ALIAS_FLAG);
            wp.setColor(0xFFFFFFFF);
            wp.setTextSize(Math.max(18f, src.getWidth() / 22f));
            wp.setShadowLayer(4f, 1f, 1f, 0x99000000);
            wp.setTextAlign(Paint.Align.RIGHT);
            float margin = src.getWidth() / 40f;
            c.drawText(watermark, src.getWidth() - margin,
                    src.getHeight() - margin, wp);
        }
        if (borderColor != 0 && borderDp > 0f) {
            Paint bp = new Paint(Paint.ANTI_ALIAS_FLAG);
            bp.setColor(borderColor);
            bp.setStyle(Paint.Style.STROKE);
            bp.setStrokeWidth(borderDp * getResources().getDisplayMetrics().density);
            float half = borderDp * getResources().getDisplayMetrics().density / 2f;
            c.drawRect(half, half, src.getWidth() - half, src.getHeight() - half, bp);
        }
        return out;
    }

    @Override
    public void onRequestPermissionsResult(int code, @NonNull String[] p, @NonNull int[] r) {
        super.onRequestPermissionsResult(code, p, r);
        if (code == REQ_WRITE) {
            if (r.length > 0 && r[0] == PackageManager.PERMISSION_GRANTED) runBatch();
            else toast("需要存储权限才能保存");
        }
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onDestroy() {
        Work.cancelOwner(this);
        super.onDestroy();
    }
}
