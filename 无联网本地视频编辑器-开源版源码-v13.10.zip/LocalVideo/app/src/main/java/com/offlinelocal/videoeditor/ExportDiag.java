package com.offlinelocal.videoeditor;

import android.util.Log;

/**
 * 统一诊断日志：导出/混音里以前大量 catch (Throwable ignored)，失败后无从查起。
 * 这里统一一个 tag，写进 logcat，并保留最近 40 条供"导出记录"面板展示。
 */
public final class ExportDiag {

    private static final String TAG = "LocalVideoExport";
    private static final java.util.ArrayDeque<String> RING = new java.util.ArrayDeque<>();
    private static final int MAX = 40;

    private ExportDiag() {
    }

    public static void warn(String stage, Throwable t) {
        String msg = stage + ": " + (t == null ? "null" : (t.getClass().getSimpleName()
                + " " + t.getMessage()));
        Log.w(TAG, msg, t);
        synchronized (RING) {
            RING.addLast(msg);
            while (RING.size() > MAX) RING.removeFirst();
        }
    }

    public static void info(String msg) {
        Log.i(TAG, msg);
        synchronized (RING) {
            RING.addLast(msg);
            while (RING.size() > MAX) RING.removeFirst();
        }
    }

    public static String dump() {
        synchronized (RING) {
            StringBuilder sb = new StringBuilder();
            for (String s : RING) sb.append(s).append('\n');
            return sb.toString();
        }
    }
}
