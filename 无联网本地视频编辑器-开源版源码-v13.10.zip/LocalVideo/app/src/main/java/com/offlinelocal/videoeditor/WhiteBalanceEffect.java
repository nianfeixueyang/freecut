package com.offlinelocal.videoeditor;

import androidx.media3.effect.RgbMatrix;

/**
 * 色温 / 色调：线性通道增益。
 * warmth > 0 偏暖（抬红、压蓝），tint > 0 偏洋红（抬红蓝、压绿）。
 */
public class WhiteBalanceEffect implements RgbMatrix {

    private final float warmth;
    private final float tint;

    public WhiteBalanceEffect(float warmth) {
        this(warmth, 0f);
    }

    public WhiteBalanceEffect(float warmth, float tint) {
        this.warmth = warmth;
        this.tint = tint;
    }

    @Override
    public float[] getMatrix(long presentationTimeUs, boolean useHdr) {
        float r = 1f + warmth * 0.18f + tint * 0.10f;
        float g = 1f - tint * 0.12f;
        float b = 1f - warmth * 0.18f + tint * 0.10f;
        r = Math.max(0.6f, Math.min(1.5f, r));
        g = Math.max(0.6f, Math.min(1.5f, g));
        b = Math.max(0.6f, Math.min(1.5f, b));
        return new float[]{
                r, 0f, 0f, 0f,
                0f, g, 0f, 0f,
                0f, 0f, b, 0f,
                0f, 0f, 0f, 1f
        };
    }

    @Override
    public boolean isNoOp(int inputWidth, int inputHeight) {
        return warmth == 0f && tint == 0f;
    }
}
