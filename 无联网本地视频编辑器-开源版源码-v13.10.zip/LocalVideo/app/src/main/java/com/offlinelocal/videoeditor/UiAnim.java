package com.offlinelocal.videoeditor;

import android.view.MotionEvent;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;

/**
 * 统一的界面动效小工具。
 * 原则：只做 transform / alpha，不碰业务视图布局，任何机型都不会因为动画出错。
 */
public class UiAnim {

    /** 面板从底部滑入 / 滑出（时长很短，避免拖慢操作）。 */
    public static void panel(final View v, boolean show) {
        if (v == null) return;
        float dy = v.getResources().getDisplayMetrics().density * 14f;
        if (show) {
            if (v.getVisibility() == View.VISIBLE) return;
            v.animate().cancel();
            v.setVisibility(View.VISIBLE);
            v.setAlpha(0f);
            v.setTranslationY(dy);
            v.animate().alpha(1f).translationY(0f)
                    .setDuration(180)
                    .setInterpolator(new DecelerateInterpolator())
                    .start();
        } else {
            if (v.getVisibility() != View.VISIBLE) return;
            v.animate().cancel();
            v.animate().alpha(0f).translationY(dy)
                    .setDuration(140)
                    .setInterpolator(new DecelerateInterpolator())
                    .withEndAction(() -> {
                        v.setVisibility(View.GONE);
                        v.setAlpha(1f);
                        v.setTranslationY(0f);
                    })
                    .start();
        }
    }

    /** 遮罩淡入 / 淡出（导出进度用）。 */
    public static void fade(final View v, boolean show) {
        if (v == null) return;
        if (show) {
            if (v.getVisibility() == View.VISIBLE) return;
            v.animate().cancel();
            v.setVisibility(View.VISIBLE);
            v.setAlpha(0f);
            v.animate().alpha(1f).setDuration(160).start();
        } else {
            if (v.getVisibility() != View.VISIBLE) return;
            v.animate().cancel();
            v.animate().alpha(0f).setDuration(140).withEndAction(() -> {
                v.setVisibility(View.GONE);
                v.setAlpha(1f);
            });
        }
    }

    /** 按下去轻微缩小 + 回弹，给所有卡片 / 按钮一点实体感。 */
    public static void press(View v, final float scale) {
        if (v == null) return;
        v.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        view.animate().scaleX(scale).scaleY(scale)
                                .setDuration(90)
                                .setInterpolator(new DecelerateInterpolator())
                                .start();
                        break;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        view.animate().scaleX(1f).scaleY(1f)
                                .setDuration(170)
                                .setInterpolator(new OvershootInterpolator(1.2f))
                                .start();
                        break;
                    default:
                        break;
                }
                // 返回 false：不吞事件，点击/长按照常生效
                return false;
            }
        });
    }

    /** 出现时轻微放大，用于选中的工具 chip 或弹层。 */
    public static void pop(View v) {
        if (v == null) return;
        v.animate().cancel();
        v.setScaleX(0.92f);
        v.setScaleY(0.92f);
        v.setAlpha(0.6f);
        v.animate().scaleX(1f).scaleY(1f).alpha(1f)
                .setDuration(160)
                .setInterpolator(new OvershootInterpolator(1.4f))
                .start();
    }
}
