package com.offlinelocal.videoeditor;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.io.File;
import java.io.FileOutputStream;

/** 签名档：手写一次，存成透明 PNG，之后可复用为贴纸。 */
public class SignatureActivity extends AppCompatActivity {

    private SignatureView board;
    private View progress;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signature);
        board = findViewById(R.id.board);
        progress = findViewById(R.id.progress);

        findViewById(R.id.btnBack).setOnClickListener(v -> finish());
        findViewById(R.id.btnUndo).setOnClickListener(v -> board.undo());
        findViewById(R.id.btnClear).setOnClickListener(v -> board.clear());
        findViewById(R.id.btnDone).setOnClickListener(v -> finishWithResult());

        int[] colors = {0xFF111111, 0xFF1A73E8, 0xFFD32F2F};
        int[] ids = {R.id.colorBlack, R.id.colorBlue, R.id.colorRed};
        for (int i = 0; i < ids.length; i++) {
            final int col = colors[i];
            findViewById(ids[i]).setOnClickListener(v -> board.setPenColor(col));
        }
        findViewById(R.id.widthThin).setOnClickListener(v -> board.setPenWidth(4f));
        findViewById(R.id.widthNormal).setOnClickListener(v -> board.setPenWidth(7f));
        findViewById(R.id.widthThick).setOnClickListener(v -> board.setPenWidth(11f));
    }

    private void finishWithResult() {
        if (board.isEmpty()) {
            ((TextView) findViewById(R.id.tvSignatureHint)).setText("先签上你的名字");
            return;
        }
        progress.setVisibility(View.VISIBLE);
        Bitmap bmp = board.export();
        if (bmp == null) {
            progress.setVisibility(View.GONE);
            return;
        }
        try {
            File dir = new File(getFilesDir(), "signatures");
            if (!dir.exists()) dir.mkdirs();
            File file = new File(dir, "sign_" + System.currentTimeMillis() + ".png");
            try (FileOutputStream out = new FileOutputStream(file)) {
                bmp.compress(Bitmap.CompressFormat.PNG, 100, out);
            }
            Intent data = new Intent();
            data.putExtra("path", file.getAbsolutePath());
            setResult(RESULT_OK, data);
            finish();
        } catch (Exception e) {
            progress.setVisibility(View.GONE);
            ((TextView) findViewById(R.id.tvSignatureHint)).setText("保存失败：" + e.getMessage());
        }
    }
}
