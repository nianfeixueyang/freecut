package com.offlinelocal.videoeditor;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;
import java.util.List;

/**
 * 多轨时间线（第一期）：把原来"只有一条绿条"的可视化升级成真正的轨道视图。
 *
 * 轨道：
 *  0 主轨   —— 每段视频按实际时长比例排开，点击可跳到该段
 *  1 字幕轨 —— 每条字幕 cue 是一个块，拖动边缘可改起止（直接作用于导出）
 *  2 音频轨 —— 配乐/配音是否挂载
 *
 * 播放头竖直画在当前位置上；拖动空白处即为定位。
 */
public class TimelineView extends View {

    private static final int BG = 0xFF17191B;
    private static final int TRACK_BG = 0xFF202325;
    private static final int CLIP = 0xFF37C88F;
    private static final int CLIP_ALT = 0xFF2C9C70;
    private static final int CUE = 0xFF4A8FE0;
    private static final int AUDIO = 0xFFB9852C;
    private static final int PLAYHEAD = 0xFF37C88F;
    private static final int TEXT = 0xFFB9BEC2;

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF tmp = new RectF();

    private long[] clipStarts = new long[0];
    private long[] clipEnds = new long[0];
    private final List<long[]> cueRanges = new ArrayList<>();
    private long totalMs = 1;
    private long posMs;
    private boolean hasMusic;
    private boolean hasVoice;

    private int dragCue = -1;
    private int dragMode; // 0 移动 1 改起点 2 改终点
    private float dragOffset;

    public interface Listener {
        void onSeek(long ms);

        void onCueRangeChanged(int index, long startMs, long endMs);

        void onClipTap(int index);
    }

    private Listener listener;

    public TimelineView(Context c) {
        this(c, null);
    }

    public TimelineView(Context c, AttributeSet a) {
        super(c, a);
        textPaint.setColor(TEXT);
        textPaint.setTextSize(11 * getResources().getDisplayMetrics().scaledDensity);
        setBackgroundColor(BG);
    }

    public void setListener(Listener l) {
        this.listener = l;
    }

    public void setData(long[] starts, long[] ends, List<long[]> cues, long totalMs, long posMs,
                        boolean hasMusic, boolean hasVoice) {
        clipStarts = starts == null ? new long[0] : starts;
        clipEnds = ends == null ? new long[0] : ends;
        long acc = clipEnds.length > 0 ? clipEnds[clipEnds.length - 1] : 0;
        this.totalMs = Math.max(1, totalMs > 0 ? totalMs : acc);
        cueRanges.clear();
        if (cues != null) for (long[] r : cues) cueRanges.add(new long[]{r[0], r[1]});
        this.posMs = posMs;
        this.hasMusic = hasMusic;
        this.hasVoice = hasVoice;
        invalidate();
    }

    private float trackTop(int row) {
        float h = getHeight();
        float usable = h - 4f;
        return 4f + row * (usable / 3f);
    }

    private float trackHeight() {
        return (getHeight() - 4f) / 3f - 3f;
    }

    private float xOf(long ms) {
        return 4f + (getWidth() - 8f) * (ms / (float) totalMs);
    }

    private long msOf(float x) {
        float k = (x - 4f) / Math.max(1f, getWidth() - 8f);
        return (long) Math.max(0, Math.min(totalMs, k * totalMs));
    }

    @Override
    protected void onDraw(Canvas cv) {
        float th = trackHeight();
        for (int row = 0; row < 3; row++) {
            tmp.set(4f, trackTop(row), getWidth() - 4f, trackTop(row) + th);
            paint.setColor(TRACK_BG);
            cv.drawRoundRect(tmp, 6f, 6f, paint);
        }
        // 主轨
        float top = trackTop(0);
        for (int i = 0; i < clipStarts.length; i++) {
            tmp.set(xOf(clipStarts[i]) + 1f, top, xOf(clipEnds[i]) - 1f, top + th);
            if (tmp.width() < 3f) tmp.right = tmp.left + 3f;
            paint.setColor(i % 2 == 0 ? CLIP : CLIP_ALT);
            cv.drawRoundRect(tmp, 5f, 5f, paint);
        }
        // 字幕轨
        top = trackTop(1);
        for (int i = 0; i < cueRanges.size(); i++) {
            long[] r = cueRanges.get(i);
            tmp.set(xOf(r[0]), top + 3f, xOf(r[1]), top + th - 3f);
            if (tmp.width() < 4f) tmp.right = tmp.left + 4f;
            paint.setColor(CUE);
            cv.drawRoundRect(tmp, 4f, 4f, paint);
            if (tmp.width() > 34f) {
                paint.setColor(0xFFFFFFFF);
                cv.drawText("字", tmp.left + 4f, tmp.centerY() + 4f, textPaint);
            }
        }
        // 音频轨
        top = trackTop(2);
        if (hasMusic) {
            tmp.set(6f, top + 3f, getWidth() - 6f, top + th - 3f);
            paint.setColor(AUDIO);
            cv.drawRoundRect(tmp, 4f, 4f, paint);
            paint.setColor(0xFFFFFFFF);
            cv.drawText("配乐", 10f, tmp.centerY() + 4f, textPaint);
        }
        if (hasVoice) {
            tmp.set(6f, top + th * 0.55f, getWidth() - 6f, top + th - 3f);
            paint.setColor(0xFF8C5BD8);
            cv.drawRoundRect(tmp, 4f, 4f, paint);
            paint.setColor(0xFFFFFFFF);
            cv.drawText("配音", 10f, tmp.centerY() + 8f, textPaint);
        }
        // 播放头
        float x = xOf(posMs);
        paint.setColor(PLAYHEAD);
        paint.setStrokeWidth(2f);
        cv.drawLine(x, 2f, x, getHeight() - 2f, paint);
        cv.drawCircle(x, 4f, 4f, paint);
    }

    private int cueAt(float x, float y) {
        float top = trackTop(1);
        float th = trackHeight();
        if (y < top || y > top + th) return -1;
        for (int i = 0; i < cueRanges.size(); i++) {
            long[] r = cueRanges.get(i);
            float l = xOf(r[0]), rr = xOf(r[1]);
            if (x >= l - 8f && x <= rr + 8f) return i;
        }
        return -1;
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN: {
                int idx = cueAt(e.getX(), e.getY());
                if (idx >= 0) {
                    dragCue = idx;
                    float l = xOf(cueRanges.get(idx)[0]);
                    float rr = xOf(cueRanges.get(idx)[1]);
                    float edge = 12f;
                    if (Math.abs(e.getX() - l) < edge) dragMode = 1;
                    else if (Math.abs(e.getX() - rr) < edge) dragMode = 2;
                    else {
                        dragMode = 0;
                        dragOffset = e.getX() - l;
                    }
                    return true;
                }
                long ms = msOf(e.getX());
                if (listener != null) listener.onSeek(ms);
                // 主轨点击：跳到对应段
                for (int i = 0; i < clipStarts.length; i++) {
                    if (e.getY() < trackTop(1) && ms >= clipStarts[i] && ms < clipEnds[i]) {
                        if (listener != null) listener.onClipTap(i);
                        break;
                    }
                }
                return true;
            }
            case MotionEvent.ACTION_MOVE: {
                if (dragCue >= 0 && listener != null) {
                    long[] r = cueRanges.get(dragCue);
                    long ms = msOf(e.getX());
                    long min = 150;
                    if (dragMode == 1) {
                        long s = Math.max(0, Math.min(r[1] - min, ms));
                        listener.onCueRangeChanged(dragCue, s, r[1]);
                    } else if (dragMode == 2) {
                        long en = Math.min(totalMs, Math.max(r[0] + min, ms));
                        listener.onCueRangeChanged(dragCue, r[0], en);
                    } else {
                        long dur = r[1] - r[0];
                        long s = Math.max(0, Math.min(totalMs - dur, msOf(e.getX() - dragOffset)));
                        listener.onCueRangeChanged(dragCue, s, s + dur);
                    }
                    return true;
                }
                if (listener != null) listener.onSeek(msOf(e.getX()));
                return true;
            }
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                dragCue = -1;
                dragMode = 0;
                return true;
        }
        return super.onTouchEvent(e);
    }
}
