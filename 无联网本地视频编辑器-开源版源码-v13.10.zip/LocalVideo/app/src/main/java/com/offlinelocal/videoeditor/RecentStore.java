package com.offlinelocal.videoeditor;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/** 「最近打开」：首页显示最近处理过的素材，省一次找文件。 */
public class RecentStore {

    public static class Item {
        public String uri;
        public String name;
        public String kind; // image / video
    }

    private static final String PREF = "freecut_recent";
    private static final String KEY = "list";

    public static List<Item> all(Context ctx) {
        List<Item> out = new ArrayList<>();
        String raw = prefs(ctx).getString(KEY, "[]");
        try {
            JSONArray arr = new JSONArray(raw);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                Item it = new Item();
                it.uri = o.optString("uri", "");
                it.name = o.optString("name", "");
                it.kind = o.optString("kind", "image");
                if (!it.uri.isEmpty()) out.add(it);
            }
        } catch (Throwable ignored) {
            ExportDiag.warn("recent_store", ignored);
        }
        return out;
    }

    public static void touch(Context ctx, String uri, String name, String kind) {
        List<Item> list = all(ctx);
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).uri.equals(uri)) {
                list.remove(i);
                break;
            }
        }
        Item it = new Item();
        it.uri = uri;
        it.name = name;
        it.kind = kind;
        list.add(0, it);
        while (list.size() > 8) list.remove(list.size() - 1);
        JSONArray arr = new JSONArray();
        for (Item x : list) {
            JSONObject o = new JSONObject();
            try {
                o.put("uri", x.uri);
                o.put("name", x.name);
                o.put("kind", x.kind);
            } catch (Throwable ignored) {
            ExportDiag.warn("recent_store", ignored);
            }
            arr.put(o);
        }
        prefs(ctx).edit().putString(KEY, arr.toString()).apply();
    }

    /** 失效的最近项要能踢掉，否则用户每次点都白点一下。 */
    public static void remove(Context ctx, String uri) {
        List<Item> list = all(ctx);
        boolean changed = false;
        for (int i = list.size() - 1; i >= 0; i--) {
            if (list.get(i).uri.equals(uri)) {
                list.remove(i);
                changed = true;
                break;
            }
        }
        if (!changed) return;
        JSONArray arr = new JSONArray();
        for (Item x : list) {
            JSONObject o = new JSONObject();
            try {
                o.put("uri", x.uri);
                o.put("name", x.name);
                o.put("kind", x.kind);
            } catch (Throwable ignored) {
            ExportDiag.warn("recent_store", ignored);
            }
            arr.put(o);
        }
        prefs(ctx).edit().putString(KEY, arr.toString()).apply();
    }

    private static SharedPreferences prefs(Context ctx) {
        return ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE);
    }
}
