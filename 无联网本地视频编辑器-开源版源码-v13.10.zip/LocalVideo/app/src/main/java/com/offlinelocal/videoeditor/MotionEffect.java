package com.offlinelocal.videoeditor;

import android.graphics.Matrix;

import androidx.media3.effect.MatrixTransformation;

/**
 * 时间驱动的运镜（Ken Burns）：在 NDC 空间里按进度缩放/平移。
 * Media3 的 ScaleAndRotateTransformation 是静态的，只有自定义 MatrixTransformation 才能随帧变化。
 */
public class MotionEffect implements MatrixTransformation {

    public static final int PUSH_IN = 1;     // 缓慢推近
    public static final int PULL_OUT = 2;    // 缓慢拉远
    public static final int PAN_LEFT = 3;    // 左 → 右
    public static final int PAN_UP = 4;      // 下 → 上

    private final int mode;
    private final long durationUs;

    public MotionEffect(int mode, long durationMs) {
        this.mode = mode;
        this.durationUs = Math.max(1, durationMs) * 1000L;
    }

    @Override
    public Matrix getMatrix(long presentationTimeUs) {
        float t = Math.max(0f, Math.min(1f, presentationTimeUs / (float) durationUs));
        Matrix m = new Matrix();
        switch (mode) {
            case PUSH_IN: {
                float s = 1f + 0.14f * t;
                m.postScale(s, s);
                break;
            }
            case PULL_OUT: {
                float s = 1.14f - 0.14f * t;
                m.postScale(s, s);
                break;
            }
            case PAN_LEFT: {
                m.postScale(1.12f, 1.12f);
                m.postTranslate(-0.12f * (t - 0.5f) * 2f, 0f);
                break;
            }
            case PAN_UP:
            default: {
                m.postScale(1.12f, 1.12f);
                m.postTranslate(0f, -0.10f * (t - 0.5f) * 2f);
                break;
            }
        }
        return m;
    }

    @Override
    public boolean isNoOp(int inputWidth, int inputHeight) {
        return false;
    }
}
