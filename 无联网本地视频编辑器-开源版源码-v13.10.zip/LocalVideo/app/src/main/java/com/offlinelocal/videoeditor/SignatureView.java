package com.offlinelocal.videoeditor;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;
import java.util.List;

/** 手写签名板：多笔绘制，可撤销，导出为透明底 PNG。 */
public class SignatureView extends View {

    private static class Stroke {
        Path path = new Path();
        float width = 6f;
    }

    private final List<Stroke> strokes = new ArrayList<>();
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private int penColor = Color.BLACK;
    private float penWidth = 6f;

    public SignatureView(Context c) {
        super(c);
        init();
    }

    public SignatureView(Context c, AttributeSet a) {
        super(c, a);
        init();
    }

    private void init() {
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setStrokeJoin(Paint.Join.ROUND);
        setLayerType(LAYER_TYPE_SOFTWARE, null);
    }

    public void setPenColor(int color) {
        penColor = color;
        invalidate();
    }

    public void setPenWidth(float w) {
        penWidth = Math.max(2f, w);
        invalidate();
    }

    public void undo() {
        if (!strokes.isEmpty()) strokes.remove(strokes.size() - 1);
        invalidate();
    }

    public void clear() {
        strokes.clear();
        invalidate();
    }

    public boolean isEmpty() {
        return strokes.isEmpty();
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN: {
                Stroke s = new Stroke();
                s.width = penWidth;
                s.path.moveTo(e.getX(), e.getY());
                s.path.lineTo(e.getX() + 0.1f, e.getY() + 0.1f);
                strokes.add(s);
                invalidate();
                return true;
            }
            case MotionEvent.ACTION_MOVE: {
                if (!strokes.isEmpty()) {
                    strokes.get(strokes.size() - 1).path.lineTo(e.getX(), e.getY());
                    invalidate();
                }
                return true;
            }
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                invalidate();
                return true;
            default:
                return super.onTouchEvent(e);
        }
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        drawStrokes(canvas, 1f, 1f);
    }

    private void drawStrokes(Canvas canvas, float sx, float sy) {
        paint.setColor(penColor);
        for (Stroke s : strokes) {
            paint.setStrokeWidth(s.width * sx);
            canvas.drawPath(s.path, paint);
        }
    }

    /** 导出透明底签名图（按内容自动裁掉四周空白）。 */
    public Bitmap export() {
        int w = getWidth();
        int h = getHeight();
        if (w <= 0 || h <= 0) return null;
        Bitmap raw = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(raw);
        drawStrokes(c, 1f, 1f);
        return trim(raw);
    }

    private Bitmap trim(Bitmap src) {
        int w = src.getWidth();
        int h = src.getHeight();
        int minX = w, minY = h, maxX = -1, maxY = -1;
        int[] row = new int[w];
        for (int y = 0; y < h; y++) {
            src.getPixels(row, 0, w, 0, y, w, 1);
            for (int x = 0; x < w; x++) {
                if ((row[x] >>> 24) > 8) {
                    if (x < minX) minX = x;
                    if (x > maxX) maxX = x;
                    if (y < minY) minY = y;
                    maxY = y;
                }
            }
        }
        if (maxX < 0) return src;
        int pad = 6;
        minX = Math.max(0, minX - pad);
        minY = Math.max(0, minY - pad);
        maxX = Math.min(w - 1, maxX + pad);
        maxY = Math.min(h - 1, maxY + pad);
        return Bitmap.createBitmap(src, minX, minY, maxX - minX + 1, maxY - minY + 1);
    }
}
