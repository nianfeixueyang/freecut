package com.offlinelocal.videoeditor;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * 导出诊断日志：每次导出记一条（参数组合 + 结果 + 错误码 + 降级阶段），
 * 只写本地、最多 60 条，用户报"导出失败"时能直接看出是哪一档炸的。
 */
public class ExportLog {

    private static final String FILE = "export_log.json";
    private static final int LIMIT = 60;

    public static class Entry {
        public long time;
        public boolean ok;
        public String code = "";
        public int stage;
        public int clips;
        public boolean subtitles;
        public boolean music;
        public boolean hevc;
        public String note = "";
        public long durationMs;

        public String line() {
            SimpleDateFormat f = new SimpleDateFormat("MM-dd HH:mm:ss", Locale.getDefault());
            String params = clips + "段" + (subtitles ? "·字幕" : "") + (music ? "·配乐" : "")
                    + (hevc ? "·H.265" : "·H.264");
            return f.format(new Date(time)) + "  " + (ok ? "成功" : "失败")
                    + (stage > 0 ? "（降级" + stage + "档）" : "")
                    + "  " + params + (code.isEmpty() ? "" : "  " + code)
                    + (durationMs > 0 ? "  " + (durationMs / 1000) + "s" : "")
                    + (note.isEmpty() ? "" : "  " + note);
        }
    }

    private static File file(Context ctx) {
        return new File(ctx.getFilesDir(), FILE);
    }

    public static void add(Context ctx, Entry e) {
        e.time = System.currentTimeMillis();
        List<Entry> list = load(ctx);
        list.add(0, e);
        while (list.size() > LIMIT) list.remove(list.size() - 1);
        JSONArray arr = new JSONArray();
        try {
            for (Entry i : list) {
                JSONObject o = new JSONObject();
                o.put("t", i.time);
                o.put("ok", i.ok);
                o.put("c", i.code);
                o.put("s", i.stage);
                o.put("n", i.clips);
                o.put("sub", i.subtitles);
                o.put("m", i.music);
                o.put("h", i.hevc);
                o.put("note", i.note);
                o.put("d", i.durationMs);
                arr.put(o);
            }
            try (FileOutputStream fo = new FileOutputStream(file(ctx))) {
                fo.write(arr.toString().getBytes("UTF-8"));
            }
        } catch (Exception ignored) {
        }
    }

    public static List<Entry> load(Context ctx) {
        List<Entry> list = new ArrayList<>();
        File f = file(ctx);
        if (!f.exists()) return list;
        try (FileInputStream in = new FileInputStream(f)) {
            byte[] buf = new byte[(int) f.length()];
            int n = in.read(buf);
            if (n <= 0) return list;
            JSONArray arr = new JSONArray(new String(buf, 0, n, "UTF-8"));
            for (int k = 0; k < arr.length(); k++) {
                JSONObject o = arr.getJSONObject(k);
                Entry e = new Entry();
                e.time = o.optLong("t");
                e.ok = o.optBoolean("ok");
                e.code = o.optString("c", "");
                e.stage = o.optInt("s");
                e.clips = o.optInt("n");
                e.subtitles = o.optBoolean("sub");
                e.music = o.optBoolean("m");
                e.hevc = o.optBoolean("h");
                e.note = o.optString("note", "");
                e.durationMs = o.optLong("d");
                list.add(e);
            }
        } catch (Exception ignored) {
        }
        return list;
    }

    /** 汇总：成功率、失败码分布、平均耗时。用来判断某一版是变好还是变坏。 */
    public static String summary(Context ctx) {
        List<Entry> list = load(ctx);
        if (list.isEmpty()) return "还没有导出记录";
        int ok = 0, fail = 0;
        long okMs = 0;
        java.util.Map<String, Integer> codes = new java.util.TreeMap<>();
        java.util.Map<Integer, Integer> stages = new java.util.TreeMap<>();
        for (Entry e : list) {
            if (e.ok) {
                ok++;
                if (e.durationMs > 0) okMs += e.durationMs;
            } else {
                fail++;
                if (!e.code.isEmpty()) {
                    Integer c = codes.get(e.code);
                    codes.put(e.code, c == null ? 1 : c + 1);
                }
                Integer s = stages.get(e.stage);
                stages.put(e.stage, s == null ? 1 : s + 1);
            }
        }
        StringBuilder sb = new StringBuilder();
        int total = ok + fail;
        sb.append("共 ").append(total).append(" 次：成功 ").append(ok)
                .append("（").append(total == 0 ? 0 : (ok * 100 / total)).append("%）")
                .append("，失败 ").append(fail);
        if (ok > 0) sb.append("，平均耗时 ").append((okMs / ok) / 1000).append("s");
        if (!codes.isEmpty()) {
            sb.append("\n失败码：");
            int shown = 0;
            for (java.util.Map.Entry<String, Integer> en : codes.entrySet()) {
                if (shown++ >= 3) break;
                sb.append(en.getKey()).append("×").append(en.getValue()).append("  ");
            }
        }
        if (!stages.isEmpty()) {
            sb.append("\n降级分布：");
            for (java.util.Map.Entry<Integer, Integer> en : stages.entrySet()) {
                sb.append("stage").append(en.getKey()).append("×").append(en.getValue()).append("  ");
            }
        }
        return sb.toString().trim();
    }

}
