package com.offlinelocal.videoeditor;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** SRT 字幕解析与生成（离线，不依赖任何库）。 */
public class SrtUtils {

    public static List<TimedTextOverlay.Cue> parse(String raw) {
        List<TimedTextOverlay.Cue> out = new ArrayList<>();
        if (raw == null) return out;
        String[] lines = raw.replace("\r\n", "\n").replace('\r', '\n').split("\n");
        // 状态机解析：不再靠空行切块，正文里带空行也不会断
        int i = 0;
        while (i < lines.length) {
            String line = lines[i].trim();
            if (!line.contains("-->")) {
                i++;
                continue;
            }
            String[] parts = line.split("-->");
            if (parts.length < 2) {
                i++;
                continue;
            }
            long start = parseTime(parts[0].trim());
            long end = parseTime(parts[1].trim());
            i++;
            StringBuilder text = new StringBuilder();
            while (i < lines.length) {
                String next = lines[i];
                String trimmed = next.trim();
                if (trimmed.contains("-->")) break;                 // 下一条时间行
                if (trimmed.matches("\\d+")) {
                    // 序号行：后面紧跟时间行时说明上一条已结束
                    int j = i + 1;
                    while (j < lines.length && lines[j].trim().isEmpty()) j++;
                    if (j < lines.length && lines[j].contains("-->")) break;
                }
                if (trimmed.isEmpty()) {
                    // 空行保留为段落分隔，但连续空行只留一个
                    if (text.length() > 0 && !text.toString().endsWith("\n")) text.append('\n');
                } else {
                    if (text.length() > 0 && !text.toString().endsWith("\n")) text.append('\n');
                    text.append(trimmed);
                }
                i++;
            }
            String body = text.toString().trim();
            if (start < 0 || end <= start || body.isEmpty()) continue;
            out.add(new TimedTextOverlay.Cue(start, end, body));
        }
        return out;
    }

    /** 支持 00:00:01,000 或 00:00:01.000。 */
    private static long parseTime(String s) {
        try {
            String t = s.replace(',', '.');
            String[] hms = t.split(":");
            if (hms.length < 3) return -1;
            long h = Long.parseLong(hms[0].trim());
            long m = Long.parseLong(hms[1].trim());
            double sec = Double.parseDouble(hms[2].trim());
            return h * 3600000L + m * 60000L + (long) (sec * 1000);
        } catch (Exception e) {
            return -1;
        }
    }

    public static String build(List<TimedTextOverlay.Cue> cues) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < cues.size(); i++) {
            TimedTextOverlay.Cue c = cues.get(i);
            sb.append(i + 1).append('\n');
            sb.append(fmt(c.startMs)).append(" --> ").append(fmt(c.endMs)).append('\n');
            sb.append(c.text).append("\n\n");
        }
        return sb.toString();
    }

    private static String fmt(long ms) {
        long h = ms / 3600000L;
        long m = (ms / 60000L) % 60;
        long s = (ms / 1000L) % 60;
        long msec = ms % 1000;
        return String.format(Locale.US, "%02d:%02d:%02d,%03d", h, m, s, msec);
    }
}
