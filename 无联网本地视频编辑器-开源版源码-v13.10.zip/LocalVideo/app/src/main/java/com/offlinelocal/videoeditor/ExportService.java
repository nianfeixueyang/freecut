package com.offlinelocal.videoeditor;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

/**
 * 导出期间的保活服务。
 * Android 14 起后台长任务很容易被系统回收，导出视频时用 mediaProcessing 类型的前台服务
 * 挂一个进度通知，用户切到微信/桌面也不会把导出掐断。
 */
public class ExportService extends Service {

    private static final String CHANNEL_ID = "freecut_export";
    private static final int NOTIFY_ID = 2101;
    private PowerManager.WakeLock wakeLock;

    public static void start(Context ctx, String title) {
        Intent i = new Intent(ctx, ExportService.class);
        i.putExtra("title", title);
        try {
            if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i);
            else ctx.startService(i);
        } catch (Throwable ignored) {
        }
    }

    public static void update(Context ctx, int percent, String title) {
        try {
            NotificationManager nm = ctx.getSystemService(NotificationManager.class);
            if (nm != null) nm.notify(NOTIFY_ID, build(ctx, title, percent));
        } catch (Throwable t) {
            ExportDiag.warn("fgs_update", t);
        }
    }

    /** 导出结束的常驻通知（可点击打开应用，自动消失）。 */
    public static void notifyDone(Context ctx, boolean ok, String fileName) {
        try {
            NotificationManager nm = ctx.getSystemService(NotificationManager.class);
            if (nm == null) return;
            String chId = "freecut_done";
            if (Build.VERSION.SDK_INT >= 26) {
                NotificationChannel ch = new NotificationChannel(chId, "导出完成",
                        NotificationManager.IMPORTANCE_DEFAULT);
                ch.setShowBadge(true);
                nm.createNotificationChannel(ch);
            }
            Intent open = new Intent(ctx, MainActivity.class);
            open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            android.app.PendingIntent pi = android.app.PendingIntent.getActivity(
                    ctx, 0, open, android.app.PendingIntent.FLAG_IMMUTABLE);
            Notification n = new NotificationCompat.Builder(ctx, chId)
                    .setSmallIcon(R.drawable.ic_video_line)
                    .setContentTitle(ok ? "导出完成" : "导出失败")
                    .setContentText(ok ? (fileName == null ? "视频已保存到相册" : fileName)
                            : "生成失败，可在导出日志里查看原因")
                    .setAutoCancel(true)
                    .setContentIntent(pi)
                    .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                    .build();
            nm.notify(ok ? 2102 : 2103, n);
        } catch (Throwable ignored) {
        }
    }

    public static void stop(Context ctx) {
        try {
            ctx.stopService(new Intent(ctx, ExportService.class));
        } catch (Throwable ignored) {
        }
    }

    private static Notification build(Context ctx, String title, int percent) {
        NotificationCompat.Builder b = new NotificationCompat.Builder(ctx, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_video_line)
                .setContentTitle(title)
                .setContentText("已完成 " + Math.max(0, Math.min(100, percent)) + "%")
                .setProgress(100, Math.max(0, Math.min(100, percent)), false)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setPriority(NotificationCompat.PRIORITY_LOW);
        return b.build();
    }

    @Override
    public void onCreate() {
        super.onCreate();
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CHANNEL_ID, "导出进度",
                    NotificationManager.IMPORTANCE_LOW);
            ch.setShowBadge(false);
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(ch);
        }
        try {
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            if (pm != null) {
                wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "LocalVideo:export");
                wakeLock.setReferenceCounted(false);
                wakeLock.acquire(30 * 60 * 1000L);
            }
        } catch (Throwable ignored) {
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String title = intent == null ? "正在导出成片" : intent.getStringExtra("title");
        if (title == null) title = "正在导出成片";
        try {
            if (Build.VERSION.SDK_INT >= 34) {
                // compileSdk 34 没有 mediaProcessing 常量（API 35 才加）。
                // 在 34 上仍用 dataSync 保活，同时把启动异常写进诊断，便于定位前台服务被拒。
                startForeground(NOTIFY_ID, build(this, title, 0),
                        android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
            } else {
                startForeground(NOTIFY_ID, build(this, title, 0));
            }
        } catch (Throwable t) {
            ExportDiag.warn("fgs_start", t);
        }
        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy() {
        try {
            if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        } catch (Throwable ignored) {
        }
        super.onDestroy();
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
