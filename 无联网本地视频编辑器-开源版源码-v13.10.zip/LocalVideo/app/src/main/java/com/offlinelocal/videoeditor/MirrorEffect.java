package com.offlinelocal.videoeditor;

import android.graphics.Matrix;

import androidx.media3.common.util.Size;
import androidx.media3.effect.MatrixTransformation;

/**
 * 镜像效果。
 * Media3 的 ScaleAndRotateTransformation 只接受正数缩放，用它做镜像会直接抛异常导致导出失败，
 * 所以这里单独实现一个矩阵变换：绕画面中心做负向缩放即可。
 */
public class MirrorEffect implements MatrixTransformation {

    private final boolean horizontal;
    private final boolean vertical;

    public MirrorEffect(boolean horizontal, boolean vertical) {
        this.horizontal = horizontal;
        this.vertical = vertical;
    }

    @Override
    public Size configure(int inputWidth, int inputHeight) {
        return new Size(inputWidth, inputHeight);
    }

    /** Media3 的矩阵作用在归一化坐标系（中心为原点），所以直接负向缩放即翻转。 */
    @Override
    public Matrix getMatrix(long presentationTimeUs) {
        Matrix m = new Matrix();
        m.postScale(horizontal ? -1f : 1f, vertical ? -1f : 1f);
        return m;
    }
}
