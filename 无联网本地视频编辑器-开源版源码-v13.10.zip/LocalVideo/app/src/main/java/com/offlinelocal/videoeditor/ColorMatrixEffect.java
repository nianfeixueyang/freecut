package com.offlinelocal.videoeditor;

import androidx.media3.effect.RgbMatrix;

/** 把颜色矩阵交给 Media3 的 GL 管线，用于视频调色。 */
public class ColorMatrixEffect implements RgbMatrix {

    private final float[] matrix;

    public ColorMatrixEffect(float[] matrix) {
        this.matrix = matrix;
    }

    @Override
    public float[] getMatrix(long presentationTimeUs, boolean useHdr) {
        return matrix;
    }
}
