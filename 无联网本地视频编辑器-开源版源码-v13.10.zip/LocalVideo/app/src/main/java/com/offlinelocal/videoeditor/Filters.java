package com.offlinelocal.videoeditor;

import android.graphics.ColorMatrix;

/**
 * 图片与视频共用的一套滤镜预设：
 * 每个预设只用一个线性颜色参数描述（饱和度 / 对比度 / RGB 通道增益），
 * 图片端会额外叠加亮度等偏移，视频端只用线性部分（保证 GL 矩阵稳定）。
 */
public final class Filters {

    public static final class Preset {
        public final String name;
        public final float saturation;
        public final float contrast;
        public final float r;
        public final float g;
        public final float b;

        Preset(String name, float saturation, float contrast, float r, float g, float b) {
            this.name = name;
            this.saturation = saturation;
            this.contrast = contrast;
            this.r = r;
            this.g = g;
            this.b = b;
        }
    }

    public static final Preset[] ALL = new Preset[]{
            new Preset("原图", 1.00f, 1.00f, 1.00f, 1.00f, 1.00f),
            new Preset("鲜亮", 1.42f, 1.10f, 1.04f, 1.02f, 1.00f),
            new Preset("黑白", 0.00f, 1.10f, 1.00f, 1.00f, 1.00f),
            new Preset("复古", 0.38f, 0.96f, 1.18f, 0.98f, 0.80f),
            new Preset("冷调", 1.05f, 1.04f, 0.90f, 1.00f, 1.20f),
            new Preset("暖调", 1.05f, 1.00f, 1.18f, 1.04f, 0.84f),
            new Preset("胶片", 0.84f, 0.92f, 1.06f, 1.00f, 1.08f),
            new Preset("高对比", 1.10f, 1.34f, 1.00f, 1.00f, 1.00f),
            new Preset("褪色", 0.58f, 0.82f, 1.02f, 1.02f, 1.04f),
            new Preset("青橙", 1.18f, 1.06f, 1.12f, 1.00f, 1.14f),
            new Preset("薄荷", 0.92f, 1.02f, 0.96f, 1.14f, 1.02f),
            new Preset("暗夜", 0.90f, 0.88f, 0.86f, 0.90f, 1.10f),
            // v13.9 追加：老工程按下标存滤镜，新预设只能往末尾加
            new Preset("赛博", 1.35f, 1.12f, 0.92f, 0.98f, 1.22f),
            new Preset("奶白", 0.80f, 0.92f, 1.12f, 1.06f, 1.00f),
            new Preset("银盐", 0.14f, 1.18f, 1.02f, 1.02f, 1.03f),
            new Preset("森系", 0.78f, 1.02f, 0.94f, 1.12f, 0.94f),
            new Preset("落日金", 1.12f, 1.06f, 1.22f, 1.04f, 0.86f)
    };

    private Filters() {}

    private static float clamp(float v, float lo, float hi) {
        return v < lo ? lo : (v > hi ? hi : v);
    }

    private static ColorMatrix contrastMatrix(float c) {
        float offset = 128f * (1f - c);
        ColorMatrix m = new ColorMatrix(new float[]{
                c, 0, 0, 0, offset,
                0, c, 0, 0, offset,
                0, 0, c, 0, offset,
                0, 0, 0, 1, 0
        });
        return m;
    }

    private static ColorMatrix channelMatrix(float r, float g, float b, float offset) {
        return new ColorMatrix(new float[]{
                r, 0, 0, 0, offset,
                0, g, 0, 0, offset,
                0, 0, b, 0, offset,
                0, 0, 0, 1, 0
        });
    }

    /** 图片用：预设 + 亮度(-1..1) + 对比度(-1..1) + 饱和度(-1..1) + 色温(-1..1) */
    public static ColorMatrix imageMatrix(Preset p, float brightness, float contrastAdj,
                                          float satAdj, float temperature) {
        return imageMatrix(p, brightness, contrastAdj, satAdj, temperature, 0f, 0f);
    }

    /** 图片用（完整版）：额外支持 色调 hue(-1..1) 与 褪色 fade(0..1)。 */
    public static ColorMatrix imageMatrix(Preset p, float brightness, float contrastAdj,
                                          float satAdj, float temperature, float hue, float fade) {
        float sat = clamp(p.saturation * (1f + satAdj), 0f, 3f);
        float con = clamp(p.contrast * (1f + contrastAdj), 0.2f, 3f);
        float warm = clamp(temperature, -1f, 1f);
        float r = clamp(p.r * (1f + 0.18f * warm), 0f, 3f);
        float b = clamp(p.b * (1f - 0.18f * warm), 0f, 3f);

        ColorMatrix cm = new ColorMatrix();
        cm.setSaturation(sat);
        cm.postConcat(contrastMatrix(con));
        cm.postConcat(channelMatrix(r, p.g, b, 0f));
        float lift = clamp(brightness, -1f, 1f) * 90f;
        if (lift != 0f) {
            cm.postConcat(channelMatrix(1f, 1f, 1f, lift));
        }
        float h = clamp(hue, -1f, 1f);
        if (h != 0f) {
            ColorMatrix hm = new ColorMatrix();
            hm.setRotate(0, h * 90f);
            cm.postConcat(hm);
        }
        float fd = clamp(fade, 0f, 1f);
        if (fd > 0f) {
            ColorMatrix fm = new ColorMatrix();
            fm.setSaturation(1f - 0.45f * fd);
            fm.postConcat(contrastMatrix(1f - 0.35f * fd));
            fm.postConcat(channelMatrix(1f, 1f, 1f, 26f * fd));
            cm.postConcat(fm);
        }
        return cm;
    }

    /** 视频用：把线性部分转成 GL 需要的 4x4 列主序矩阵，并按 strength(0~1) 与原片插值。 */
    public static float[] videoMatrix(Preset p, float strength) {
        return blend4x4(videoMatrix(p), Math.max(0f, Math.min(1f, strength)));
    }

    /**
     * 视频预览用：把导出时那条 4x4 矩阵转成 ColorMatrix（行主序、无偏移），
     * 保证"预览看到的浓淡"和"导出成片"是同一套数学，不再两张皮。
     */
    public static ColorMatrix videoPreviewColorMatrix(Preset p, float strength) {
        float[] m = videoMatrix(p, strength);
        float[] rows = new float[20];
        for (int r = 0; r < 4; r++) {
            for (int c = 0; c < 4; c++) {
                rows[r * 5 + c] = m[c * 4 + r];
            }
            rows[r * 5 + 4] = 0f;
        }
        return new ColorMatrix(rows);
    }

    /** 4x4 列主序矩阵与单位矩阵插值，用来做"滤镜强度"。 */
    public static float[] blend4x4(float[] m, float t) {
        float[] id = new float[]{
                1f, 0f, 0f, 0f,
                0f, 1f, 0f, 0f,
                0f, 0f, 1f, 0f,
                0f, 0f, 0f, 1f};
        if (t >= 0.999f) return m;
        float[] out = new float[16];
        for (int i = 0; i < 16; i++) out[i] = id[i] * (1f - t) + m[i] * t;
        return out;
    }

    /** 视频用：把线性部分转成 GL 需要的 4x4 列主序矩阵。 */
    public static float[] videoMatrix(Preset p) {
        float[] m = new float[16];
        float sat = p.saturation;
        float con = p.contrast;
        // 饱和度矩阵
        float[] s = {
                0.213f + 0.787f * sat, 0.715f - 0.715f * sat, 0.072f - 0.072f * sat,
                0.213f - 0.213f * sat, 0.715f + 0.285f * sat, 0.072f - 0.072f * sat,
                0.213f - 0.213f * sat, 0.715f - 0.715f * sat, 0.072f + 0.928f * sat
        };
        // 先饱和度，再对比度(纯缩放)，再通道增益
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 3; col++) {
                float v = s[row * 3 + col] * con;
                if (row == 0) v *= p.r;
                if (row == 1) v *= p.g;
                if (row == 2) v *= p.b;
                m[col * 4 + row] = v;
            }
        }
        m[15] = 1f;
        return m;
    }

    /** 把滤镜矩阵与"原图（单位矩阵）"按 t(0~1) 混合，实现滤镜强度。 */
    public static ColorMatrix blendWithIdentity(ColorMatrix filter, float t) {
        t = Math.max(0f, Math.min(1f, t));
        float[] f = filter.getArray();
        float[] id = {1f, 0f, 0f, 0f, 0f,
                0f, 1f, 0f, 0f, 0f,
                0f, 0f, 1f, 0f, 0f,
                0f, 0f, 0f, 1f, 0f};
        float[] out = new float[20];
        for (int i = 0; i < 20; i++) out[i] = id[i] * (1f - t) + f[i] * t;
        return new ColorMatrix(out);
    }
}
