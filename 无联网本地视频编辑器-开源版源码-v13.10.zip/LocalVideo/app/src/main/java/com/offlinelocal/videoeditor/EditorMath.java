package com.offlinelocal.videoeditor;

/**
 * 纯计算逻辑（不依赖 Context / 播放器），方便单元测试。
 */
public class EditorMath {

    /**
     * 片段重排后，原来选中的那一段的新下标。
     *
     * @param currentIndex 重排前选中段下标
     * @param from         被移动段下标
     * @param to           移动后目标下标
     * @return 重排后应该选中的下标
     */
    public static int moveIndex(int currentIndex, int from, int to) {
        if (currentIndex == from) return to;
        if (from < currentIndex && to >= currentIndex) return currentIndex - 1;
        if (from > currentIndex && to <= currentIndex) return currentIndex + 1;
        return currentIndex;
    }

    /** 0..375 ←→ 0.25x..4x，对数刻度，1x 附近更好微调。 */
    public static int speedToProgress(float speed) {
        float s = Math.max(0.25f, Math.min(4f, speed));
        return Math.round((float) (Math.log(s / 0.25f) / Math.log(16f) * 375f));
    }

    public static float progressToSpeed(int progress) {
        float t = Math.max(0, Math.min(375, progress)) / 375f;
        float s = 0.25f * (float) Math.pow(16f, t);
        return Math.round(s * 100) / 100f;
    }
}
