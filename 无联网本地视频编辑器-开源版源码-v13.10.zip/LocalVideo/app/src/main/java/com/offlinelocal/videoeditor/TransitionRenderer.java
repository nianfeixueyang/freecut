package com.offlinelocal.videoeditor;

import android.content.Context;
import android.graphics.SurfaceTexture;
import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.media.MediaMuxer;
import android.net.Uri;
import android.opengl.EGL14;
import android.opengl.EGLExt;
import android.opengl.GLES11Ext;
import android.opengl.GLES20;
import android.opengl.Matrix;
import android.view.Surface;

import java.io.File;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.util.ArrayList;
import java.util.List;

/**
 * 双轨 GL 转场合成器。
 *
 * 两条解码器各解一路视频到独立 OES 纹理，片元着色器按进度 uProgress 做叠化/擦除/推拉/缩放，
 * 结果直接画进编码器 Surface。过渡段音频在 AudioMixer 里按区间解出 PCM 后交叉淡化，
 * 再编码 AAC 写进同一个 mp4——这样过渡期间不会出现静默空洞。
 *
 * Media3 1.4.1 的顺序播放没有重叠时间轴，真转场只能在导出前把过渡段单独渲染成小片段，
 * 再用 A(尾- fade) + 过渡片段 + B(头跳过 fade) 的方式拼起来。
 */
public final class TransitionRenderer {

    public static final int DISSOLVE = 0;
    public static final int WIPE = 1;
    public static final int PUSH = 2;
    public static final int ZOOM = 3;

    private static final int FPS = 30;
    private static final int SR = 44100;
    private static final int CH = 2;

    private TransitionRenderer() {
    }

    public static String nameOf(int type) {
        switch (type) {
            case WIPE: return "擦除";
            case PUSH: return "推拉";
            case ZOOM: return "缩放";
            default: return "叠化";
        }
    }

    /**
     * @param aEndMs   前一段的结束时间；过渡从 aEndMs - fadeMs 开始
     * @param bStartMs 后一段的起始时间
     */
    public static boolean render(Context ctx, Uri a, long aEndMs, Uri b, long bStartMs,
                                 int type, int fadeMs, int outW, int outH, File dst) {
        fadeMs = Math.max(120, Math.min(fadeMs, 1200));
        outW = Math.max(16, (outW / 16) * 16);
        outH = Math.max(16, (outH / 16) * 16);
        long aStartMs = Math.max(0, aEndMs - fadeMs);

        AacBuffer audio = null;
        try {
            int frames = (int) ((long) fadeMs * SR / 1000L);
            short[] pa = AudioMixer.pcmRange(ctx, a, aStartMs, aEndMs, frames);
            short[] pb = AudioMixer.pcmRange(ctx, b, bStartMs, bStartMs + fadeMs, frames);
            audio = encodeAac(crossfade(pa, pb, frames));
        } catch (Throwable t) {
            ExportDiag.warn("transition_audio", t);
            audio = null;
        }

        MediaCodec enc = null;
        MediaCodec decA = null;
        MediaCodec decB = null;
        MediaExtractor exA = null;
        MediaExtractor exB = null;
        GlCtx gl = null;
        Stream sa = null, sb = null;
        MediaMuxer muxer = null;
        try {
            enc = MediaCodec.createEncoderByType("video/avc");
            MediaFormat ef = MediaFormat.createVideoFormat("video/avc", outW, outH);
            ef.setInteger(MediaFormat.KEY_COLOR_FORMAT,
                    MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface);
            int bitrate = Math.max(3_000_000, Math.min(20_000_000,
                    (int) (outW * (long) outH * FPS * 0.12)));
            ef.setInteger(MediaFormat.KEY_BIT_RATE, bitrate);
            ef.setInteger(MediaFormat.KEY_FRAME_RATE, FPS);
            ef.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1);
            ef.setInteger(MediaFormat.KEY_PROFILE,
                    MediaCodecInfo.CodecProfileLevel.AVCProfileMain);
            ef.setInteger(MediaFormat.KEY_LEVEL,
                    MediaCodecInfo.CodecProfileLevel.AVCLevel41);
            try {
                enc.configure(ef, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
            } catch (Throwable profileFailed) {
                MediaFormat plain = MediaFormat.createVideoFormat("video/avc", outW, outH);
                plain.setInteger(MediaFormat.KEY_COLOR_FORMAT,
                        MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface);
                plain.setInteger(MediaFormat.KEY_BIT_RATE, bitrate);
                plain.setInteger(MediaFormat.KEY_FRAME_RATE, FPS);
                plain.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1);
                try {
                    enc.stop();
                } catch (Throwable ignore) {
                }
                try {
                    enc.release();
                } catch (Throwable ignore) {
                }
                enc = MediaCodec.createEncoderByType("video/avc");
                enc.configure(plain, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
            }
            Surface encSurface = enc.createInputSurface();
            enc.start();

            gl = new GlCtx(encSurface);
            sa = new Stream(ctx, a, aStartMs, gl.texA);
            sb = new Stream(ctx, b, bStartMs, gl.texB);
            decA = sa.codec;
            decB = sb.codec;
            exA = sa.extractor;
            exB = sb.extractor;

            muxer = new MediaMuxer(dst.getAbsolutePath(),
                    MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
            int audioTrack = -1;
            if (audio != null && audio.format != null) {
                try {
                    audioTrack = muxer.addTrack(audio.format);
                } catch (Throwable ignore) {
                    audioTrack = -1;
                }
            }

            int videoTrack = -1;
            boolean started = false;
            boolean writtenAudio = false;
            int total = Math.max(2, (int) ((long) fadeMs * FPS / 1000L));
            long frameUs = 1_000_000L / FPS;

            for (int k = 0; k < total; k++) {
                long aTarget = aStartMs * 1000L + k * frameUs;
                long bTarget = bStartMs * 1000L + k * frameUs;
                sa.advanceTo(aTarget);
                sb.advanceTo(bTarget);
                float p = total <= 1 ? 1f : k / (float) (total - 1);
                gl.draw(sa, sb, p, type, outW, outH, k * frameUs);

                MediaCodec.BufferInfo bi = new MediaCodec.BufferInfo();
                while (true) {
                    int oi = enc.dequeueOutputBuffer(bi, 0);
                    if (oi == MediaCodec.INFO_TRY_AGAIN_LATER) break;
                    if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                        if (!started) {
                            videoTrack = muxer.addTrack(enc.getOutputFormat());
                            muxer.start();
                            started = true;
                            if (audioTrack >= 0 && !writtenAudio) {
                                for (AacSample s : audio.samples) {
                                    MediaCodec.BufferInfo ai = new MediaCodec.BufferInfo();
                                    ai.offset = 0;
                                    ai.size = s.data.length;
                                    ai.presentationTimeUs = s.ptsUs;
                                    ai.flags = 0;
                                    ByteBuffer bb = ByteBuffer.wrap(s.data);
                                    try {
                                        muxer.writeSampleData(audioTrack, bb, ai);
                                    } catch (Throwable ignore) {
                                    }
                                }
                                writtenAudio = true;
                            }
                        }
                        continue;
                    }
                    if (oi < 0) continue;
                    ByteBuffer ob = enc.getOutputBuffer(oi);
                    if (ob != null && bi.size > 0
                            && (bi.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0
                            && started && videoTrack >= 0) {
                        ob.position(bi.offset);
                        ob.limit(bi.offset + bi.size);
                        muxer.writeSampleData(videoTrack, ob, bi);
                    }
                    enc.releaseOutputBuffer(oi, false);
                }
            }

            try {
                enc.signalEndOfInputStream();
            } catch (Throwable ignore) {
            }
            MediaCodec.BufferInfo eos = new MediaCodec.BufferInfo();
            long deadline = System.currentTimeMillis() + 30_000L;
            boolean done = false;
            while (!done && System.currentTimeMillis() < deadline) {
                int oi = enc.dequeueOutputBuffer(eos, 10_000);
                if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    if (!started) {
                        videoTrack = muxer.addTrack(enc.getOutputFormat());
                        muxer.start();
                        started = true;
                    }
                    continue;
                }
                if (oi < 0) continue;
                ByteBuffer ob = enc.getOutputBuffer(oi);
                if (ob != null && eos.size > 0
                        && (eos.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0
                        && started && videoTrack >= 0) {
                    ob.position(eos.offset);
                    ob.limit(eos.offset + eos.size);
                    muxer.writeSampleData(videoTrack, ob, eos);
                }
                if ((eos.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) done = true;
                enc.releaseOutputBuffer(oi, false);
            }
            return started && dst.isFile() && dst.length() > 1024;
        } catch (Throwable t) {
            ExportDiag.warn("transition_render", t);
            return false;
        } finally {
            if (sa != null) sa.close();
            if (sb != null) sb.close();
            stop(decA);
            stop(decB);
            rel(exA);
            rel(exB);
            stop(enc);
            if (gl != null) gl.release();
            if (muxer != null) {
                try {
                    muxer.stop();
                } catch (Throwable ignore) {
                }
                try {
                    muxer.release();
                } catch (Throwable ignore) {
                }
            }
        }
    }

    // ---------- 音频 ----------

    private static short[] crossfade(short[] a, short[] b, int frames) {
        short[] out = new short[frames * CH];
        for (int i = 0; i < frames; i++) {
            float p = frames <= 1 ? 1f : i / (float) (frames - 1);
            for (int c = 0; c < CH; c++) {
                int ia = i * CH + c;
                short va = (a != null && ia < a.length) ? a[ia] : 0;
                short vb = (b != null && ia < b.length) ? b[ia] : 0;
                float v = va * (1f - p) + vb * p;
                out[ia] = (short) Math.max(-32768f, Math.min(32767f, v));
            }
        }
        return out;
    }

    private static final class AacSample {
        final byte[] data;
        final long ptsUs;

        AacSample(byte[] data, long ptsUs) {
            this.data = data;
            this.ptsUs = ptsUs;
        }
    }

    private static final class AacBuffer {
        MediaFormat format;
        final List<AacSample> samples = new ArrayList<>();
    }

    private static AacBuffer encodeAac(short[] pcm) {
        if (pcm == null || pcm.length < CH) return null;
        MediaCodec enc = null;
        try {
            enc = MediaCodec.createEncoderByType("audio/mp4a-latm");
            MediaFormat f = MediaFormat.createAudioFormat("audio/mp4a-latm", SR, CH);
            f.setInteger(MediaFormat.KEY_BIT_RATE, 128000);
            f.setInteger(MediaFormat.KEY_AAC_PROFILE,
                    MediaCodecInfo.CodecProfileLevel.AACObjectLC);
            f.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384);
            enc.configure(f, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
            enc.start();

            AacBuffer out = new AacBuffer();
            byte[] all = new byte[pcm.length * 2];
            for (int i = 0; i < pcm.length; i++) {
                all[i * 2] = (byte) (pcm[i] & 0xFF);
                all[i * 2 + 1] = (byte) ((pcm[i] >> 8) & 0xFF);
            }
            int offset = 0;
            int chunk = 4096;
            boolean inDone = false;
            MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
            long pts = 0;
            long deadline = System.currentTimeMillis() + 20_000L;
            while (System.currentTimeMillis() < deadline) {
                if (!inDone) {
                    int ii = enc.dequeueInputBuffer(5_000);
                    if (ii >= 0) {
                        ByteBuffer ib = enc.getInputBuffer(ii);
                        if (offset >= all.length) {
                            enc.queueInputBuffer(ii, 0, 0, pts, MediaCodec.BUFFER_FLAG_END_OF_STREAM);
                            inDone = true;
                        } else {
                            int n = Math.min(chunk, all.length - offset);
                            ib.clear();
                            ib.put(all, offset, n);
                            enc.queueInputBuffer(ii, 0, n, pts, 0);
                            offset += n;
                            pts += (long) (n / (2 * CH)) * 1_000_000L / SR;
                        }
                    }
                }
                int oi = enc.dequeueOutputBuffer(info, 5_000);
                if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    out.format = enc.getOutputFormat();
                } else if (oi >= 0) {
                    if (info.size > 0 && (info.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0) {
                        ByteBuffer ob = enc.getOutputBuffer(oi);
                        if (ob != null) {
                            byte[] d = new byte[info.size];
                            ob.position(info.offset);
                            ob.limit(info.offset + info.size);
                            ob.get(d);
                            out.samples.add(new AacSample(d, info.presentationTimeUs));
                        }
                    }
                    boolean eos = (info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0;
                    enc.releaseOutputBuffer(oi, false);
                    if (eos) break;
                }
            }
            if (out.format == null || out.samples.isEmpty()) return null;
            return out;
        } catch (Throwable t) {
            return null;
        } finally {
            stop(enc);
        }
    }

    // ---------- 视频解码流 ----------

    private static final class Stream {
        MediaExtractor extractor;
        MediaCodec codec;
        SurfaceTexture st;
        Surface surface;
        final float[] transform = new float[16];
        final float[] rot = new float[16];
        final float[] uv = new float[16];
        final MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
        boolean inputDone = false;
        boolean hasFrame = false;

        Stream(Context ctx, Uri uri, long startMs, int texId) throws Exception {
            extractor = new MediaExtractor();
            extractor.setDataSource(ctx, uri, null);
            int idx = -1;
            MediaFormat fmt = null;
            for (int i = 0; i < extractor.getTrackCount(); i++) {
                MediaFormat f = extractor.getTrackFormat(i);
                String mime = f.getString(MediaFormat.KEY_MIME);
                if (mime != null && mime.startsWith("video/")) {
                    idx = i;
                    fmt = f;
                    break;
                }
            }
            if (idx < 0 || fmt == null) throw new IllegalStateException("没有视频轨");
            extractor.selectTrack(idx);
            if (startMs > 0) {
                extractor.seekTo(startMs * 1000L, MediaExtractor.SEEK_TO_PREVIOUS_SYNC);
            }
            int w = fmt.getInteger(MediaFormat.KEY_WIDTH);
            int h = fmt.getInteger(MediaFormat.KEY_HEIGHT);
            st = new SurfaceTexture(texId);
            st.setDefaultBufferSize(Math.max(1, w), Math.max(1, h));
            surface = new Surface(st);
            Matrix.setIdentityM(transform, 0);
            int rotation = fmt.containsKey(MediaFormat.KEY_ROTATION)
                    ? fmt.getInteger(MediaFormat.KEY_ROTATION) : 0;
            Matrix.setIdentityM(rot, 0);
            if (rotation != 0) {
                Matrix.translateM(rot, 0, 0.5f, 0.5f, 0f);
                Matrix.rotateM(rot, 0, rotation, 0f, 0f, 1f);
                Matrix.translateM(rot, 0, -0.5f, -0.5f, 0f);
            }
            String mime = fmt.getString(MediaFormat.KEY_MIME);
            codec = MediaCodec.createDecoderByType(mime);
            codec.configure(fmt, surface, null, 0);
            codec.start();
        }

        void advanceTo(long targetUs) {
            if (codec == null) return;
            for (int guard = 0; guard < 240; guard++) {
                if (!inputDone) {
                    int ii = codec.dequeueInputBuffer(6_000);
                    if (ii >= 0) {
                        ByteBuffer ib = codec.getInputBuffer(ii);
                        int size = ib == null ? -1 : extractor.readSampleData(ib, 0);
                        if (size < 0) {
                            codec.queueInputBuffer(ii, 0, 0, 0,
                                    MediaCodec.BUFFER_FLAG_END_OF_STREAM);
                            inputDone = true;
                        } else {
                            codec.queueInputBuffer(ii, 0, size, extractor.getSampleTime(), 0);
                            extractor.advance();
                        }
                    }
                }
                int oi = codec.dequeueOutputBuffer(info, 6_000);
                if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) continue;
                if (oi < 0) continue;
                boolean eos = (info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0;
                if (info.size == 0) {
                    codec.releaseOutputBuffer(oi, false);
                    if (eos) inputDone = true;
                    continue;
                }
                if (info.presentationTimeUs < targetUs - 15_000) {
                    codec.releaseOutputBuffer(oi, false);
                    if (eos) inputDone = true;
                    continue;
                }
                codec.releaseOutputBuffer(oi, true);
                st.updateTexImage();
                st.getTransformMatrix(transform);
                hasFrame = true;
                if (eos) inputDone = true;
                return;
            }
        }

        float[] uvMatrix() {
            Matrix.multiplyMM(uv, 0, rot, 0, transform, 0);
            return uv;
        }

        void close() {
            try {
                if (st != null) st.release();
            } catch (Throwable ignore) {
            }
            try {
                if (surface != null) surface.release();
            } catch (Throwable ignore) {
            }
            stop(codec);
            rel(extractor);
        }
    }

    // ---------- GL ----------

    private static final String VS =
            "attribute vec2 aPos;\n"
                    + "attribute vec2 aTex;\n"
                    + "varying vec2 vTex;\n"
                    + "uniform mat4 uMvp;\n"
                    + "void main(){ vTex=aTex; gl_Position=uMvp*vec4(aPos,0.0,1.0); }\n";

    private static final String FS =
            "#extension GL_OES_EGL_image_external : require\n"
                    + "precision mediump float;\n"
                    + "varying vec2 vTex;\n"
                    + "uniform samplerExternalOES uTexA;\n"
                    + "uniform samplerExternalOES uTexB;\n"
                    + "uniform float uProgress;\n"
                    + "uniform int uType;\n"
                    + "uniform mat4 uMatA;\n"
                    + "uniform mat4 uMatB;\n"
                    + "void main(){\n"
                    + "  vec2 uvA = (uMatA*vec4(vTex,0.0,1.0)).xy;\n"
                    + "  vec2 uvB = (uMatB*vec4(vTex,0.0,1.0)).xy;\n"
                    + "  if(uType==2){ uvA = vTex + vec2(uProgress,0.0); uvB = vTex - vec2(1.0-uProgress,0.0); }\n"
                    + "  if(uType==3){ uvA = (vTex-0.5)*(1.0+0.25*uProgress)+0.5; uvB = (vTex-0.5)*(1.25-0.25*uProgress)+0.5; }\n"
                    + "  vec4 a = texture2D(uTexA, clamp(uvA, 0.001, 0.999));\n"
                    + "  vec4 b = texture2D(uTexB, clamp(uvB, 0.001, 0.999));\n"
                    + "  if(uType==1){ float m = step(vTex.x, uProgress); gl_FragColor = mix(a,b,m); }\n"
                    + "  else if(uType==2){ float m = step(vTex.x, uProgress); gl_FragColor = m > 0.5 ? b : a; }\n"
                    + "  else { gl_FragColor = mix(a,b,uProgress); }\n"
                    + "}\n";

    private static final class GlCtx {
        final EGLDisplayHolder egl;
        final int texA, texB;
        final int program;
        final FloatBuffer quad, texCoord;
        final int aPos, aTex, uMvp, uProgress, uType, uMatA, uMatB;

        GlCtx(Surface encSurface) {
            egl = new EGLDisplayHolder(encSurface);
            int[] t = new int[2];
            GLES20.glGenTextures(2, t, 0);
            texA = t[0];
            texB = t[1];
            for (int id : t) {
                GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, id);
                GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES,
                        GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR);
                GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES,
                        GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR);
                GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES,
                        GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE);
                GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES,
                        GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE);
            }
            int vs = compile(GLES20.GL_VERTEX_SHADER, VS);
            int fs = compile(GLES20.GL_FRAGMENT_SHADER, FS);
            program = GLES20.glCreateProgram();
            GLES20.glAttachShader(program, vs);
            GLES20.glAttachShader(program, fs);
            GLES20.glLinkProgram(program);
            aPos = GLES20.glGetAttribLocation(program, "aPos");
            aTex = GLES20.glGetAttribLocation(program, "aTex");
            uMvp = GLES20.glGetUniformLocation(program, "uMvp");
            uProgress = GLES20.glGetUniformLocation(program, "uProgress");
            uType = GLES20.glGetUniformLocation(program, "uType");
            uMatA = GLES20.glGetUniformLocation(program, "uMatA");
            uMatB = GLES20.glGetUniformLocation(program, "uMatB");
            float[] q = {-1f, -1f, 1f, -1f, -1f, 1f, 1f, 1f};
            quad = buf(q);
            float[] tx = {0f, 1f, 1f, 1f, 0f, 0f, 1f, 0f};
            texCoord = buf(tx);
        }

        void draw(Stream a, Stream b, float p, int type, int w, int h, long ptsUs) {
            GLES20.glViewport(0, 0, w, h);
            GLES20.glClearColor(0f, 0f, 0f, 1f);
            GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT);
            GLES20.glUseProgram(program);
            GLES20.glUniformMatrix4fv(uMvp, 1, false, IDENTITY, 0);
            GLES20.glUniform1f(uProgress, p);
            GLES20.glUniform1i(uType, type);
            GLES20.glUniformMatrix4fv(uMatA, 1, false, a.uvMatrix(), 0);
            GLES20.glUniformMatrix4fv(uMatB, 1, false, b.uvMatrix(), 0);
            GLES20.glActiveTexture(GLES20.GL_TEXTURE0);
            GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, texA);
            GLES20.glUniform1i(GLES20.glGetUniformLocation(program, "uTexA"), 0);
            GLES20.glActiveTexture(GLES20.GL_TEXTURE1);
            GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, texB);
            GLES20.glUniform1i(GLES20.glGetUniformLocation(program, "uTexB"), 1);
            GLES20.glEnableVertexAttribArray(aPos);
            GLES20.glVertexAttribPointer(aPos, 2, GLES20.GL_FLOAT, false, 0, quad);
            GLES20.glEnableVertexAttribArray(aTex);
            GLES20.glVertexAttribPointer(aTex, 2, GLES20.GL_FLOAT, false, 0, texCoord);
            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4);
            GLES20.glDisableVertexAttribArray(aPos);
            GLES20.glDisableVertexAttribArray(aTex);
            EGLExt.eglPresentationTimeANDROID(egl.display, egl.surface, ptsUs * 1000L);
            EGL14.eglSwapBuffers(egl.display, egl.surface);
        }

        void release() {
            egl.release();
        }

        private static final float[] IDENTITY = new float[16];

        static {
            Matrix.setIdentityM(IDENTITY, 0);
        }

        private static FloatBuffer buf(float[] data) {
            FloatBuffer b = ByteBuffer.allocateDirect(data.length * 4)
                    .order(ByteOrder.nativeOrder()).asFloatBuffer();
            b.put(data).position(0);
            return b;
        }

        private static int compile(int type, String src) {
            int s = GLES20.glCreateShader(type);
            GLES20.glShaderSource(s, src);
            GLES20.glCompileShader(s);
            int[] ok = new int[1];
            GLES20.glGetShaderiv(s, GLES20.GL_COMPILE_STATUS, ok, 0);
            if (ok[0] == 0) {
                throw new IllegalStateException("转场着色器编译失败: "
                        + GLES20.glGetShaderInfoLog(s));
            }
            return s;
        }
    }

    private static final class EGLDisplayHolder {
        final android.opengl.EGLDisplay display;
        final android.opengl.EGLContext context;
        final android.opengl.EGLSurface surface;

        EGLDisplayHolder(Surface encSurface) {
            display = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY);
            int[] ver = new int[2];
            EGL14.eglInitialize(display, ver, 0, ver, 1);
            int[] attrs = {
                    EGL14.EGL_RED_SIZE, 8,
                    EGL14.EGL_GREEN_SIZE, 8,
                    EGL14.EGL_BLUE_SIZE, 8,
                    EGL14.EGL_ALPHA_SIZE, 8,
                    EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT,
                    EGL14.EGL_SURFACE_TYPE, EGL14.EGL_WINDOW_BIT,
                    EGLExt.EGL_RECORDABLE_ANDROID, 1,
                    EGL14.EGL_NONE
            };
            android.opengl.EGLConfig[] cfg = new android.opengl.EGLConfig[1];
            int[] n = new int[1];
            int[] visual = {EGL14.EGL_NONE};
            EGL14.eglChooseConfig(display, attrs, 0, cfg, 0, 1, n, 0);
            if (n[0] <= 0) throw new IllegalStateException("EGL config 不支持");
            int[] ctxAttrs = {EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE};
            context = EGL14.eglCreateContext(display, cfg[0], EGL14.EGL_NO_CONTEXT, ctxAttrs, 0);
            surface = EGL14.eglCreateWindowSurface(display, cfg[0], encSurface, visual, 0);
            if (surface == null || surface == EGL14.EGL_NO_SURFACE) {
                throw new IllegalStateException("无法创建转场 EGLSurface");
            }
            EGL14.eglMakeCurrent(display, surface, surface, context);
        }

        void release() {
            try {
                EGL14.eglMakeCurrent(display, EGL14.EGL_NO_SURFACE,
                        EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT);
                EGL14.eglDestroySurface(display, surface);
                EGL14.eglDestroyContext(display, context);
                EGL14.eglTerminate(display);
            } catch (Throwable ignore) {
            }
        }
    }

    private static void stop(MediaCodec c) {
        if (c == null) return;
        try {
            c.stop();
        } catch (Throwable ignore) {
        }
        try {
            c.release();
        } catch (Throwable ignore) {
        }
    }

    private static void rel(MediaExtractor e) {
        if (e == null) return;
        try {
            e.release();
        } catch (Throwable ignore) {
        }
    }
}
