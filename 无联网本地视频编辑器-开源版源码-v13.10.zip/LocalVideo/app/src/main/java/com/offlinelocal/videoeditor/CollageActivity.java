package com.offlinelocal.videoeditor;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import java.util.ArrayList;
import java.util.List;

/** 拼图：多选图片 → 选排版/间隙/底色 → 预览 → 保存。 */
public class CollageActivity extends AppCompatActivity {

    private static final int REQ_WRITE = 303;

    private ImageView preview;
    private ProgressBar progress;
    private TextView tvTitle, tvHint;
    private LinearLayout rowStyles, rowBg;

    private final List<Uri> uris = new ArrayList<>();
    private final List<Bitmap> bitmaps = new ArrayList<>();
    private final List<TextView> styleChips = new ArrayList<>();

    private int style = 0;
    private int gapDp = 10;
    private int bgColor = 0xFFFFFFFF;
    private Bitmap result;
    private boolean saving = false;
    /** 渲染任务序号：连点几个模式时，只有最后一次的结果会显示。 */
    private int renderToken = 0;
    /** 已解码源图里最大的宽度（原图像素，作为清晰度基准）。 */
    private int sourceMaxWidth = 0;

    public static Intent buildIntent(Context ctx, ArrayList<Uri> list) {
        Intent i = new Intent(ctx, CollageActivity.class);
        i.putParcelableArrayListExtra("uris", list);
        return i;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_collage);

        preview = findViewById(R.id.preview);
        progress = findViewById(R.id.progress);
        tvTitle = findViewById(R.id.tvTitle);
        tvHint = findViewById(R.id.tvHint);
        rowStyles = findViewById(R.id.rowStyles);
        rowBg = findViewById(R.id.rowBg);

        findViewById(R.id.btnBack).setOnClickListener(v -> finish());
        findViewById(R.id.btnSave).setOnClickListener(v -> save());

        ArrayList<Uri> list = getIntent().getParcelableArrayListExtra("uris");
        if (list == null || list.size() < 2) {
            toast("至少选两张图片");
            finish();
            return;
        }
        if (list.size() > 9) {
            uris.addAll(list.subList(0, 9));
        } else {
            uris.addAll(list);
        }
        tvTitle.setText("拼图 · " + uris.size() + " 张");

        buildStyles();
        buildBgColors();
        setupGap();
        loadImages();
    }

    private int dp(float v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    private TextView chip(String label, boolean selected) {
        TextView tv = new TextView(this);
        tv.setText(label);
        tv.setTextSize(12);
        tv.setGravity(Gravity.CENTER);
        tv.setPadding(dp(12), 0, dp(12), 0);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, dp(32));
        lp.rightMargin = dp(8);
        lp.gravity = Gravity.CENTER_VERTICAL;
        tv.setLayoutParams(lp);
        tv.setClickable(true);
        tv.setBackgroundResource(selected ? R.drawable.bg_chip_selected : R.drawable.bg_chip);
        tv.setTextColor(selected ? getColor(R.color.on_accent) : getColor(R.color.text_1));
        return tv;
    }

    private void style(TextView tv, boolean selected) {
        tv.setBackgroundResource(selected ? R.drawable.bg_chip_selected : R.drawable.bg_chip);
        tv.setTextColor(selected ? getColor(R.color.on_accent) : getColor(R.color.text_1));
    }

    private void buildStyles() {
        for (int i = 0; i < CollageEngine.STYLE_NAMES.length; i++) {
            final int idx = i;
            TextView tv = chip(CollageEngine.STYLE_NAMES[i], i == 0);
            tv.setOnClickListener(v -> {
                style = idx;
                for (int k = 0; k < styleChips.size(); k++) style(styleChips.get(k), k == style);
                render();
            });
            rowStyles.addView(tv);
            styleChips.add(tv);
        }
    }

    private void buildBgColors() {
        int[] colors = {0xFFFFFFFF, 0xFF111317, 0xFFF2E3C6, getColor(R.color.accent)};
        for (int c : colors) {
            final int color = c;
            View dot = new View(this);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(26), dp(26));
            lp.rightMargin = dp(10);
            lp.gravity = Gravity.CENTER_VERTICAL;
            dot.setLayoutParams(lp);
            dot.setBackgroundResource(R.drawable.bg_dot);
            dot.getBackground().mutate().setColorFilter(color, android.graphics.PorterDuff.Mode.SRC_IN);
            dot.setOnClickListener(v -> {
                bgColor = color;
                render();
            });
            rowBg.addView(dot);
        }
    }

    private void setupGap() {
        SeekBar seek = findViewById(R.id.seekGap);
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar sb, int p, boolean fromUser) {
                gapDp = Math.max(0, p);
            }

            @Override public void onStartTrackingTouch(SeekBar sb) {}

            @Override
            public void onStopTrackingTouch(SeekBar sb) {
                render();
            }
        });
    }

    /** 输出像素预算：拿堆的 45% 做上限，再封到 6400 万像素（再高手机扛不住）。 */
    private long pixelBudget() {
        long budget = Runtime.getRuntime().maxMemory() * 45 / 100 / 4; // ARGB 每像素 4 字节
        return Math.min(budget, 64_000_000L);
    }

    private int colsOf() {
        if (style == 0) return 3;
        if (style == 1) return 2;
        if (style == 2) return Math.min(2, uris.size());
        return 1;
    }

    /**
     * 按原图分辨率加载：先读每张图的真实尺寸，取最大宽度作为清晰度基准，
     * 再按"所有源图 + 一张输出图"的内存预算决定实际解码边长。
     * 预算够就是 1:1 原像素，不够才等比降——不再固定 720 一刀切。
     */
    private void loadImages() {
        progress.setVisibility(View.VISIBLE);
        Work.run(this, () -> {
            List<Bitmap> loaded = new ArrayList<>();
            int maxW = 0;
            for (Uri u : uris) {
                int[] size = BitmapUtils.sizeOf(this, u);
                if (size != null) maxW = Math.max(maxW, size[0]);
            }
            if (maxW <= 0) maxW = 1080;
            final int sourceW = maxW;
            // 源图整体只允许占堆的 ~35%
            long srcBudgetBytes = Runtime.getRuntime().maxMemory() * 35 / 100;
            long perBytes = Math.max(1, srcBudgetBytes / Math.max(1, uris.size()));
            int perSide = (int) Math.sqrt(perBytes / 4f);
            int decodeDim = Math.min(sourceW * 2, Math.max(720, perSide));
            int maxDim = Math.max(720, Math.min(decodeDim, BitmapUtils.safeMaxDim()));
            try {
                loaded = loadAll(maxDim);
            } catch (OutOfMemoryError oom) {
                recycleAll(loaded);
                loaded = loadAll(Math.max(720, maxDim / 2));
            }
            final List<Bitmap> okList = loaded;
            runOnUiThread(() -> {
                recycleAll(bitmaps);
                bitmaps.clear();
                bitmaps.addAll(okList);
                int realW = 0;
                for (Bitmap b : okList) realW = Math.max(realW, b.getWidth());
                sourceMaxWidth = realW;
                progress.setVisibility(View.GONE);
                if (bitmaps.isEmpty()) {
                    toast("图片加载失败");
                    finish();
                    return;
                }
                render();
            });
        });
    }

    private List<Bitmap> loadAll(int maxDim) {
        List<Bitmap> out = new ArrayList<>();
        for (Uri u : uris) {
            try {
                out.add(BitmapUtils.load(this, u, maxDim));
            } catch (Exception ignored) {
            }
        }
        return out;
    }

    private void recycleAll(List<Bitmap> list) {
        for (Bitmap b : list) {
            if (b != null && !b.isRecycled()) {
                try {
                    b.recycle();
                } catch (Exception ignored) {
                }
            }
        }
        list.clear();
    }

    private void render() {
        if (bitmaps.isEmpty()) return;
        final int token = ++renderToken;
        final int styleNow = style;
        final int gapPx = dp(gapDp);
        final int bgNow = bgColor;
        final int cols = colsOf();
        final int rows = (int) Math.ceil(bitmaps.size() / (double) cols);
        final long budget = pixelBudget();
        progress.setVisibility(View.VISIBLE);
        Work.run(this, () -> {
            Bitmap built = null;
            int outCell = sourceMaxWidth;
            try {
                if (styleNow == 4) {
                    int maxH = (int) Math.min(Integer.MAX_VALUE, budget / Math.max(1, sourceMaxWidth));
                    built = CollageEngine.stitch(bitmaps, sourceMaxWidth, maxH);
                } else {
                    // 单格尺寸 = min(原图宽, 按像素预算反推的上限)，尽量贴着原像素出图
                    long perCell = budget / Math.max(1L, (long) cols * rows);
                    int cellBudget = (int) Math.sqrt(Math.max(1, perCell));
                    outCell = Math.max(240, Math.min(sourceMaxWidth, cellBudget));
                    int totalW = cols * outCell + gapPx * (cols + 1);
                    built = CollageEngine.build(bitmaps, styleNow, gapPx, dp(6), bgNow, totalW);
                }
            } catch (OutOfMemoryError oom) {
                System.gc();
                int fallbackCell = Math.max(360, outCell / 2);
                try {
                    if (styleNow == 4) {
                        built = CollageEngine.stitch(bitmaps, Math.max(480, sourceMaxWidth / 2),
                                Math.max(4000, (int) (budget / 2 / Math.max(1, sourceMaxWidth))));
                    } else {
                        int totalW = cols * fallbackCell + gapPx * (cols + 1);
                        built = CollageEngine.build(bitmaps, styleNow, gapPx, dp(6), bgNow, totalW);
                    }
                } catch (Throwable ignored) {
                }
            }
            final Bitmap out = built;
            final int cellUsed = outCell;
            runOnUiThread(() -> {
                progress.setVisibility(View.GONE);
                if (token != renderToken) {
                    if (out != null && !out.isRecycled()) out.recycle();
                    return;
                }
                if (out == null) {
                    toast("这个尺寸拼不出来，换一档试试");
                    return;
                }
                Bitmap old = result;
                result = out;
                preview.setImageBitmap(out);
                tvTitle.setText("拼图 · " + bitmaps.size() + " 张 · " + out.getWidth() + "×" + out.getHeight());
                // 正在存盘的那张不能回收，否则保存线程会读到已回收的位图
                if (old != null && old != out && !old.isRecycled() && !saving) old.recycle();
                if (cellUsed < sourceMaxWidth) {
                    tvHint.setText("已按本机内存上限输出（单格 " + cellUsed + "px / 源图 "
                            + sourceMaxWidth + "px）");
                } else {
                    tvHint.setText("按原图分辨率输出");
                }
            });
        });
    }

    private void save() {
        if (saving) return;
        if (result == null) {
            toast("还没有拼图结果");
            return;
        }
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P
                && ContextCompat.checkSelfPermission(this, android.Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{android.Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQ_WRITE);
            return;
        }
        saving = true;
        progress.setVisibility(View.VISIBLE);
        final Bitmap out = result;
        Work.run(this, () -> {
            try {
                String name = "FC_collage_" + System.currentTimeMillis() + ".jpg";
                Uri saved = BitmapUtils.saveImage(this, out, name);
                HistoryStore.add(this, "image", name, saved);
                runOnUiThread(() -> {
                    saving = false;
                    progress.setVisibility(View.GONE);
                    new AlertDialog.Builder(this)
                            .setTitle("拼图已保存")
                            .setMessage("已写入相册 Pictures/LocalVideo\n文件：" + name)
                            .setNegativeButton("知道了", null)
                            .setPositiveButton("继续编辑", (d, w) -> {
                                if (saved != null) {
                                    startActivity(ImageEditorActivity.buildIntent(this, saved));
                                }
                            })
                            .show();
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    saving = false;
                    progress.setVisibility(View.GONE);
                    toast("保存失败：" + e.getMessage());
                });
            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int code, @NonNull String[] p, @NonNull int[] r) {
        super.onRequestPermissionsResult(code, p, r);
        if (code == REQ_WRITE) {
            if (r.length > 0 && r[0] == PackageManager.PERMISSION_GRANTED) save();
            else toast("需要存储权限才能保存");
        }
    }

    private void toast(String m) {
        Toast.makeText(this, m, Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onDestroy() {
        Work.cancelOwner(this);
        super.onDestroy();
    }
}
