package com.offlinelocal.videoeditor;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/** 「我的预设」：把滤镜 + 调整 + 暗角存成一条，下次一键套用。 */
public class PresetStore {

    public static class Preset {
        public String name;
        public int filterIndex;
        public float strength = 1f;
        public float brightness = 0f;
        public float contrast = 0f;
        public float saturation = 0f;
        public float temperature = 0f;
        public float vignette = 0f;
    }

    private static final String PREF = "freecut_presets";
    private static final String KEY = "list";

    public static List<Preset> all(Context ctx) {
        List<Preset> out = new ArrayList<>();
        String raw = prefs(ctx).getString(KEY, "[]");
        try {
            JSONArray arr = new JSONArray(raw);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                Preset p = new Preset();
                p.name = o.optString("name", "预设");
                p.filterIndex = o.optInt("filter", 0);
                p.strength = (float) o.optDouble("strength", 1);
                p.brightness = (float) o.optDouble("brightness", 0);
                p.contrast = (float) o.optDouble("contrast", 0);
                p.saturation = (float) o.optDouble("saturation", 0);
                p.temperature = (float) o.optDouble("temperature", 0);
                p.vignette = (float) o.optDouble("vignette", 0);
                out.add(p);
            }
        } catch (Exception ignored) {
        }
        return out;
    }

    public static void add(Context ctx, Preset p) {
        List<Preset> list = all(ctx);
        list.add(0, p);
        while (list.size() > 12) list.remove(list.size() - 1);
        save(ctx, list);
    }

    public static void remove(Context ctx, String name) {
        List<Preset> list = all(ctx);
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).name.equals(name)) {
                list.remove(i);
                break;
            }
        }
        save(ctx, list);
    }

    private static void save(Context ctx, List<Preset> list) {
        JSONArray arr = new JSONArray();
        for (Preset p : list) {
            JSONObject o = new JSONObject();
            try {
                o.put("name", p.name);
                o.put("filter", p.filterIndex);
                o.put("strength", p.strength);
                o.put("brightness", p.brightness);
                o.put("contrast", p.contrast);
                o.put("saturation", p.saturation);
                o.put("temperature", p.temperature);
                o.put("vignette", p.vignette);
            } catch (Exception ignored) {
            }
            arr.put(o);
        }
        prefs(ctx).edit().putString(KEY, arr.toString()).apply();
    }

    private static SharedPreferences prefs(Context ctx) {
        return ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE);
    }
}
