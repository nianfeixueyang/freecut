package com.offlinelocal.videoeditor;

import android.content.Context;
import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.media.MediaMuxer;
import android.net.Uri;

import java.io.File;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.file.Files;

/**
 * 自建配乐混音：解码原声与配乐 → 统一 44.1k 立体声 → 按各自音量相加 → AAC 编码，
 * 视频轨直接复制（不重编码）。避免 Media3 混音在低端机上直接报 "invalid error code"。
 */
public final class AudioMixer {

    private static final int SR = 44100;
    private static final int CH = 2;

    private AudioMixer() {
    }

    /**
     * @param keepOriginal 是否保留原声（mute 时传 false）
     * @param origVolume   原声音量（0~2）
     * @param musicVolume  配乐音量（0~2）
     */
    public static boolean mix(Context ctx, File video, Uri music, boolean keepOriginal,
                              float origVolume, float musicVolume,
                              Uri voice, float voiceVolume,
                              int fadeInMs, int fadeOutMs, File out, long durationMs) {
        return mix(ctx, video, music, keepOriginal, origVolume, musicVolume,
                voice, voiceVolume, fadeInMs, fadeOutMs, out, durationMs, false);
    }

    /**
     * @param duckMusic 配音出现时自动把配乐压下去（闪避），配音停下来再缓缓恢复。
     */
    public static boolean mix(Context ctx, File video, Uri music, boolean keepOriginal,
                              float origVolume, float musicVolume,
                              Uri voice, float voiceVolume,
                              int fadeInMs, int fadeOutMs, File out, long durationMs,
                              boolean duckMusic) {
        MediaExtractor vEx = null;
        MediaCodec enc = null;
        MediaMuxer muxer = null;
        try {
            vEx = new MediaExtractor();
            vEx.setDataSource(video.getAbsolutePath());
            int vTrack = -1;
            MediaFormat vf = null;
            long durationUs = durationMs > 0 ? durationMs * 1000L : 0;
            for (int i = 0; i < vEx.getTrackCount(); i++) {
                MediaFormat f = vEx.getTrackFormat(i);
                String mime = f.getString(MediaFormat.KEY_MIME);
                if (mime != null && mime.startsWith("video/") && vTrack < 0) {
                    vTrack = i;
                    vf = f;
                    if (f.containsKey(MediaFormat.KEY_DURATION)) {
                        durationUs = f.getLong(MediaFormat.KEY_DURATION);
                    }
                }
            }
            if (vTrack < 0 || vf == null) return false;

            long limitUs = durationUs > 0 ? durationUs : 10_000_000L;
            // 分块流式改造后内存与时长无关，这里不再限 20 分钟（旧上限会把长视频后半段静音）
            int totalFrames = (int) (limitUs / 1_000_000.0 * SR);
            boolean any = music != null || keepOriginal || voice != null;
            if (!any || totalFrames <= 0) return false;

            float og = keepOriginal ? origVolume : 0f;
            float mg = music == null ? 0f : musicVolume;
            float vg = voice == null ? 0f : voiceVolume;
            int fadeIn = Math.max(0, fadeInMs) * SR / 1000;
            int fadeOutLen = Math.max(0, fadeOutMs) * SR / 1000;

            enc = MediaCodec.createEncoderByType("audio/mp4a-latm");
            MediaFormat ef = MediaFormat.createAudioFormat("audio/mp4a-latm", SR, CH);
            ef.setInteger(MediaFormat.KEY_AAC_PROFILE,
                    MediaCodecInfo.CodecProfileLevel.AACObjectLC);
            ef.setInteger(MediaFormat.KEY_BIT_RATE, 128_000);
            ef.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384);
            enc.configure(ef, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
            enc.start();

            muxer = new MediaMuxer(out.getAbsolutePath(),
                    MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
            int vOut = muxer.addTrack(vf);
            final int[] aTrack = {-1};
            final boolean[] started = {false};

            // 分块流式混音：每块 4 秒，峰值内存 ≈ 块大小的 3 倍，不再随视频时长线性膨胀。
            int chunkFrames = SR * 4;
            for (int chunkStart = 0; chunkStart < totalFrames; chunkStart += chunkFrames) {
                int len = Math.min(chunkFrames, totalFrames - chunkStart);
                short[] pcm = mixChunk(ctx, video, music, voice, keepOriginal,
                        og, mg, vg, chunkStart, len, totalFrames, fadeIn, fadeOutLen, duckMusic);
                int pos = 0;
                while (pos < len) {
                    int inIdx = enc.dequeueInputBuffer(10_000);
                    if (inIdx >= 0) {
                        ByteBuffer ib = enc.getInputBuffer(inIdx);
                        int bytes = 0;
                        if (ib != null) {
                            ib.clear();
                            int room = ib.capacity() / (CH * 2);
                            int take = Math.min(room, len - pos);
                            for (int i = 0; i < take * CH; i++) {
                                ib.putShort(pcm[pos * CH + i]);
                            }
                            bytes = take * CH * 2;
                            long pts = (chunkStart + (long) pos) * 1_000_000L / SR;
                            enc.queueInputBuffer(inIdx, 0, bytes, pts, 0);
                            pos += take;
                        }
                    }
                    drainAudio(enc, muxer, aTrack, started);
                }
                drainAudio(enc, muxer, aTrack, started);
            }

            boolean eosQueued = false;
            long deadline = System.currentTimeMillis() + 60_000L;
            boolean encDone = false;
            while (!encDone && System.currentTimeMillis() < deadline) {
                if (!eosQueued) {
                    int inIdx = enc.dequeueInputBuffer(10_000);
                    if (inIdx >= 0) {
                        enc.queueInputBuffer(inIdx, 0, 0, 0,
                                MediaCodec.BUFFER_FLAG_END_OF_STREAM);
                        eosQueued = true;
                    }
                }
                encDone = drainAudio(enc, muxer, aTrack, started);
            }
            if (!started[0]) return false;

            // 视频轨原样复制
            vEx.selectTrack(vTrack);
            MediaCodec.BufferInfo vi = new MediaCodec.BufferInfo();
            int max = vf.containsKey(MediaFormat.KEY_MAX_INPUT_SIZE)
                    ? vf.getInteger(MediaFormat.KEY_MAX_INPUT_SIZE) : 512 * 1024;
            ByteBuffer buf = ByteBuffer.allocateDirect(Math.max(512 * 1024, max));
            while (true) {
                int size = vEx.readSampleData(buf, 0);
                if (size < 0) break;
                long pts = vEx.getSampleTime();
                if (durationUs > 0 && pts > durationUs) break;
                vi.offset = 0;
                vi.size = size;
                vi.presentationTimeUs = pts;
                vi.flags = vEx.getSampleFlags() == MediaExtractor.SAMPLE_FLAG_SYNC
                        ? MediaCodec.BUFFER_FLAG_KEY_FRAME : 0;
                try {
                    muxer.writeSampleData(vOut, buf, vi);
                } catch (Throwable t) {
                    ExportDiag.warn("audio_mux_video", t);
                }
                vEx.advance();
            }
            return out.isFile() && out.length() > 1024;
        } catch (Throwable t) {
            ExportDiag.warn("audio_mix_fail", t);
            return false;
        } finally {
            safeStop(enc);
            if (muxer != null) {
                try {
                    muxer.stop();
                } catch (Throwable ignore) {
                }
                try {
                    muxer.release();
                } catch (Throwable ignore) {
                }
            }
            if (vEx != null) {
                try {
                    vEx.release();
                } catch (Throwable ignore) {
                }
            }
        }
    }

    /** 解一块（约 4 秒）并叠加，返回 len 帧立体声 PCM；内存只与块大小相关。 */
    private static short[] mixChunk(Context ctx, File video, Uri music, Uri voice,
                                    boolean keepOriginal, float og, float mg, float vg,
                                    int startFrame, int len, int totalFrames,
                                    int fadeIn, int fadeOutLen, boolean duckMusic) {
        long startMs = (long) startFrame * 1000L / SR;
        long endMs = (long) (startFrame + len) * 1000L / SR + 1;
        int pad = SR / 2;
        short[] m = music == null ? null : decode(ctx, music, len + pad, startMs, endMs);
        short[] o = keepOriginal ? decode(ctx, Uri.fromFile(video), len + pad, startMs, endMs) : null;
        short[] v = voice == null ? null : decode(ctx, voice, len + pad, startMs, endMs);
        short[] out = new short[len * CH];
        float duckEnv = 0f;
        for (int i = 0; i < len; i++) {
            float env = 1f;
            int frame = startFrame + i;
            if (fadeIn > 0 && frame < fadeIn) env = frame / (float) fadeIn;
            if (fadeOutLen > 0 && frame > totalFrames - fadeOutLen) {
                env = Math.min(env, (totalFrames - frame) / (float) fadeOutLen);
            }
            if (duckMusic && v != null) {
                float level = Math.abs(v[i * CH]);
                // 瞬间压低、约 40ms 恢复：配音一开口配乐就让位，别让人声被糊住
                duckEnv = Math.max(level * vg, duckEnv * 0.997f);
            }
            float duckGain = 1f;
            if (duckMusic && v != null) {
                duckGain = 1f - 0.85f * Math.min(1f, duckEnv / 9_000f);
            }
            for (int c = 0; c < CH; c++) {
                int src = i * CH + c;
                float val = 0f;
                if (m != null && src < m.length) val += m[src] * mg * env * duckGain;
                if (o != null && src < o.length) val += o[src] * og;
                if (v != null && src < v.length) val += v[src] * vg;
                out[src] = (short) Math.max(-32768f, Math.min(32767f, val));
            }
        }
        return out;
    }

    /** 把编码器当前能出的帧写进 muxer；返回是否遇到 EOS。 */
    private static boolean drainAudio(MediaCodec enc, MediaMuxer muxer,
                                      int[] aTrack, boolean[] started) {
        MediaCodec.BufferInfo ei = new MediaCodec.BufferInfo();
        while (true) {
            int idx = enc.dequeueOutputBuffer(ei, 0);
            if (idx == MediaCodec.INFO_TRY_AGAIN_LATER) return false;
            if (idx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                aTrack[0] = muxer.addTrack(enc.getOutputFormat());
                muxer.start();
                started[0] = true;
                continue;
            }
            if (idx < 0) continue;
            ByteBuffer ob = enc.getOutputBuffer(idx);
            if (ob != null && ei.size > 0 && (ei.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0) {
                ob.position(ei.offset);
                ob.limit(ei.offset + ei.size);
                if (started[0] && aTrack[0] >= 0) {
                    try {
                        muxer.writeSampleData(aTrack[0], ob, ei);
                    } catch (Throwable t) {
                        ExportDiag.warn("audio_mux", t);
                    }
                }
            }
            boolean eos = (ei.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0;
            enc.releaseOutputBuffer(idx, false);
            if (eos) return true;
        }
    }

    private static void safeStop(MediaCodec c) {
        if (c == null) return;
        try {
            c.stop();
        } catch (Throwable ignore) {
        }
        try {
            c.release();
        } catch (Throwable ignore) {
        }
    }

    /** 解码第一条音轨为 44.1k 立体声 16bit PCM，长度上限 frames 个采样帧。 */
    /** 解一段指定时间区间的 PCM（44.1k 立体声），给转场做音频交叉淡化用。 */
    public static short[] pcmRange(Context ctx, Uri src, long startMs, long endMs, int frames) {
        return decode(ctx, src, frames, startMs, endMs);
    }

    private static short[] decode(Context ctx, Uri src, int frames) {
        return decode(ctx, src, frames, 0, 0);
    }

    private static short[] decode(Context ctx, Uri src, int frames, long startMs, long endMs) {
        MediaExtractor ex = null;
        MediaCodec dec = null;
        try {
            ex = new MediaExtractor();
            ex.setDataSource(ctx, src, null);
            int idx = -1;
            MediaFormat af = null;
            for (int i = 0; i < ex.getTrackCount(); i++) {
                MediaFormat f = ex.getTrackFormat(i);
                String mime = f.getString(MediaFormat.KEY_MIME);
                if (mime != null && mime.startsWith("audio/")) {
                    idx = i;
                    af = f;
                    break;
                }
            }
            if (idx < 0 || af == null) return null;
            ex.selectTrack(idx);
            if (startMs > 0) ex.seekTo(startMs * 1000L, MediaExtractor.SEEK_TO_PREVIOUS_SYNC);
            String mime = af.getString(MediaFormat.KEY_MIME);
            dec = MediaCodec.createDecoderByType(mime);
            dec.configure(af, null, null, 0);
            dec.start();

            int srcRate = af.containsKey(MediaFormat.KEY_SAMPLE_RATE)
                    ? af.getInteger(MediaFormat.KEY_SAMPLE_RATE) : SR;
            int srcCh = af.containsKey(MediaFormat.KEY_CHANNEL_COUNT)
                    ? af.getInteger(MediaFormat.KEY_CHANNEL_COUNT) : 1;

            // 先用较大缓冲收集 PCM，再重采样
            java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream();
            MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
            boolean inDone = false;
            int loops = 0;
            while (loops++ < 200000) {
                if (!inDone) {
                    int inIdx = dec.dequeueInputBuffer(5_000);
                    if (inIdx >= 0) {
                        ByteBuffer ib = dec.getInputBuffer(inIdx);
                        int size = ib == null ? -1 : ex.readSampleData(ib, 0);
                        long pts = ex.getSampleTime();
                        boolean stop = size < 0
                                || (endMs > 0 && pts > endMs * 1000L);
                        if (stop) {
                            dec.queueInputBuffer(inIdx, 0, 0, 0,
                                    MediaCodec.BUFFER_FLAG_END_OF_STREAM);
                            inDone = true;
                        } else {
                            dec.queueInputBuffer(inIdx, 0, size, pts, 0);
                            ex.advance();
                        }
                    }
                }
                int outIdx = dec.dequeueOutputBuffer(info, 5_000);
                if (outIdx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    MediaFormat of = dec.getOutputFormat();
                    if (of.containsKey(MediaFormat.KEY_SAMPLE_RATE)) {
                        srcRate = of.getInteger(MediaFormat.KEY_SAMPLE_RATE);
                    }
                    if (of.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) {
                        srcCh = of.getInteger(MediaFormat.KEY_CHANNEL_COUNT);
                    }
                } else if (outIdx >= 0) {
                    ByteBuffer ob = dec.getOutputBuffer(outIdx);
                    if (ob != null && info.size > 0
                            && (startMs <= 0 || info.presentationTimeUs >= startMs * 1000L)) {
                        byte[] tmp = new byte[info.size];
                        ob.position(info.offset);
                        ob.limit(info.offset + info.size);
                        ob.get(tmp);
                        bos.write(tmp);
                    }
                    dec.releaseOutputBuffer(outIdx, false);
                    if ((info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) break;
                }
            }
            byte[] pcm = bos.toByteArray();
            if (pcm.length < 4) return null;
            return resample(pcm, srcRate, srcCh, frames);
        } catch (Throwable t) {
            ExportDiag.warn("audio_decode", t);
            return null;
        } finally {
            if (dec != null) {
                try {
                    dec.stop();
                } catch (Throwable ignore) {
                }
                try {
                    dec.release();
                } catch (Throwable ignore) {
                }
            }
            if (ex != null) {
                try {
                    ex.release();
                } catch (Throwable ignore) {
                }
            }
        }
    }

    private static short[] resample(byte[] pcm, int srcRate, int srcCh, int frames) {
        if (srcRate <= 0 || srcCh <= 0) return null;
        int srcFrames = pcm.length / (srcCh * 2);
        if (srcFrames <= 0) return null;
        float step = srcRate / (float) SR;
        int outFrames = Math.min(frames, (int) (srcFrames / step) + 1);
        short[] out = new short[outFrames * CH];
        short[] src = new short[pcm.length / 2];
        ByteBuffer b = ByteBuffer.wrap(pcm).order(ByteOrder.LITTLE_ENDIAN);
        b.asShortBuffer().get(src);
        for (int i = 0; i < outFrames; i++) {
            float pos = i * step;
            int sp = (int) pos;
            float f = pos - sp;
            for (int c = 0; c < CH; c++) {
                int ch = srcCh > 1 ? c : 0;
                // Catmull-Rom：4 点三次插值，相比线性插值高频细节明显更完整，CPU 仍是很便宜的定点运算
                float p0 = sampleAt(src, srcCh, sp - 1, ch, srcFrames);
                float p1 = sampleAt(src, srcCh, sp, ch, srcFrames);
                float p2 = sampleAt(src, srcCh, sp + 1, ch, srcFrames);
                float p3 = sampleAt(src, srcCh, sp + 2, ch, srcFrames);
                float v = p1 + 0.5f * f * (p2 - p0)
                        + f * f * (p0 - 2.5f * p1 + 2f * p2 - 0.5f * p3)
                        + f * f * f * (-0.5f * p0 + 1.5f * p1 - 1.5f * p2 + 0.5f * p3);
                if (v > 32767f) v = 32767f;
                if (v < -32768f) v = -32768f;
                out[i * CH + c] = (short) v;
            }
        }
        return out;
    }

    private static float sampleAt(short[] src, int srcCh, int frame, int ch, int frames) {
        if (frame < 0) frame = 0;
        if (frame >= frames) frame = frames - 1;
        int idx = frame * srcCh + ch;
        return idx >= 0 && idx < src.length ? src[idx] : 0f;
    }
}
