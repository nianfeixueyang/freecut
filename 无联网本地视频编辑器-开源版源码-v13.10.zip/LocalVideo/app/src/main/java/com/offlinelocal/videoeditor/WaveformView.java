package com.offlinelocal.videoeditor;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.net.Uri;
import android.util.AttributeSet;
import android.view.View;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/** 音频波形：抽样读出振幅，画成柱状，方便找卡点。 */
public class WaveformView extends View {

    private final Paint barPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private int[] samples = new int[0];
    private Uri currentUri;
    private int loadingToken = 0;

    public WaveformView(Context c) {
        super(c);
        init();
    }

    public WaveformView(Context c, AttributeSet a) {
        super(c, a);
        init();
    }

    private void init() {
        barPaint.setColor(getContext().getColor(R.color.accent));
    }

    public void setSource(Uri uri) {
        if (uri == null) return;
        if (currentUri != null && currentUri.equals(uri) && samples.length > 0) return;
        currentUri = uri;
        final int token = ++loadingToken;
        samples = new int[0];
        invalidate();
        Work.run(() -> {
            int[] data = extract(uri);
            post(() -> {
                if (token != loadingToken) return;
                samples = data;
                invalidate();
            });
        });
    }

    private int[] extract(Uri uri) {
        MediaExtractor ex = new MediaExtractor();
        try {
            String scheme = uri.getScheme();
            if (scheme == null || "file".equals(scheme)) {
                ex.setDataSource(uri.getPath());
            } else {
                android.content.res.AssetFileDescriptor afd =
                        getContext().getContentResolver().openAssetFileDescriptor(uri, "r");
                if (afd == null) return new int[0];
                ex.setDataSource(afd.getFileDescriptor(), afd.getStartOffset(), afd.getLength());
            }
            int track = -1;
            int sampleRate = 44100;
            for (int i = 0; i < ex.getTrackCount(); i++) {
                MediaFormat f = ex.getTrackFormat(i);
                String mime = f.getString(MediaFormat.KEY_MIME);
                if (mime != null && mime.startsWith("audio/")) {
                    track = i;
                    if (f.containsKey(MediaFormat.KEY_SAMPLE_RATE)) {
                        sampleRate = f.getInteger(MediaFormat.KEY_SAMPLE_RATE);
                    }
                    break;
                }
            }
            if (track < 0) return new int[0];
            ex.selectTrack(track);
            int bars = 120;
            int[] out = new int[bars];
            ByteBuffer buf = ByteBuffer.allocate(64 * 1024).order(ByteOrder.nativeOrder());
            long totalUs = ex.getTrackFormat(track).containsKey(MediaFormat.KEY_DURATION)
                    ? ex.getTrackFormat(track).getLong(MediaFormat.KEY_DURATION) : 1;
            int seen = 0;
            int size = 0;
            while ((size = ex.readSampleData(buf, 0)) > 0) {
                int peak = 0;
                for (int i = 0; i + 1 < size; i += 2) {
                    short v = buf.order(ByteOrder.nativeOrder()).getShort(i);
                    int abs = v < 0 ? -v : v;
                    if (abs > peak) peak = abs;
                }
                long ts = ex.getSampleTime();
                int idx = (int) Math.min(bars - 1, Math.max(0, ts * bars / Math.max(1, totalUs)));
                if (peak > out[idx]) out[idx] = peak;
                seen++;
                ex.advance();
                if (seen > 3000) break;
                buf.clear();
            }
            return out;
        } catch (Exception e) {
            return new int[0];
        } finally {
            try {
                ex.release();
            } catch (Exception ignored) {
            }
        }
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        int w = getWidth();
        int h = getHeight();
        if (samples.length == 0) {
            barPaint.setColor(0x33FFFFFF);
            canvas.drawRect(0, h / 2f - 1, w, h / 2f + 1, barPaint);
            barPaint.setColor(getContext().getColor(R.color.accent));
            return;
        }
        float bw = (float) w / samples.length;
        for (int i = 0; i < samples.length; i++) {
            float amp = samples[i] / 32768f;
            float bh = Math.max(1.5f, amp * (h * 0.92f));
            canvas.drawRect(i * bw, (h - bh) / 2f, (i + 1) * bw * 0.85f, (h + bh) / 2f, barPaint);
        }
    }
}
