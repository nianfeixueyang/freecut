package com.offlinelocal.videoeditor;

import android.graphics.Color;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.AbsoluteSizeSpan;
import android.text.style.ForegroundColorSpan;
import android.text.style.StyleSpan;

import androidx.media3.effect.OverlaySettings;
import androidx.media3.effect.TextOverlay;

import java.util.ArrayList;
import java.util.List;

/**
 * 按时间显示的字幕叠加层。
 * Media3 1.4 的 TextOverlay 只有静态工厂，这里继承它实现 getText(timeUs)，
 * 并覆写 getOverlaySettings 把字幕放到画面下方居中。
 */
public class TimedTextOverlay extends TextOverlay {

    public static class Cue {
        public long startMs;
        public long endMs;
        public String text;

        public Cue(long startMs, long endMs, String text) {
            this.startMs = startMs;
            this.endMs = endMs;
            this.text = text;
        }
    }

    private final List<Cue> cues;
    private final float textSizePx;
    private final float anchorX;
    private final float anchorY;
    private final int textColor;
    private final OverlaySettings settings;

    public TimedTextOverlay(List<Cue> cues) {
        this(cues, 64f);
    }

    public TimedTextOverlay(List<Cue> cues, float textSizePx) {
        this(cues, textSizePx, 0f, -0.72f, Color.WHITE);
    }

    /** 位置/字号/颜色都可由用户改：位置是帧锚点 (-1~1)，默认底部居中。 */
    public TimedTextOverlay(List<Cue> cues, float textSizePx, float anchorX, float anchorY, int textColor) {
        this.cues = cues == null ? new ArrayList<>() : new ArrayList<>(cues);
        this.textSizePx = textSizePx;
        this.anchorX = anchorX;
        this.anchorY = anchorY;
        this.textColor = textColor;
        this.settings = new OverlaySettings.Builder()
                .setBackgroundFrameAnchor(anchorX, anchorY)
                .setOverlayFrameAnchor(0f, 0f)
                .setAlphaScale(1f)
                .build();
    }

    private boolean activeAt(long ms) {
        for (Cue c : cues) {
            if (ms >= c.startMs && ms < c.endMs) return true;
        }
        return false;
    }

    @Override
    public SpannableString getText(long presentationTimeUs) {
        long ms = presentationTimeUs / 1000L;
        String current = "";
        for (Cue c : cues) {
            if (ms >= c.startMs && ms < c.endMs) {
                current = c.text;
                break;
            }
        }
        if (current.isEmpty()) current = " ";
        SpannableString sp = new SpannableString(current);
        if (!current.isEmpty()) {
            sp.setSpan(new AbsoluteSizeSpan((int) textSizePx), 0, sp.length(),
                    Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            sp.setSpan(new ForegroundColorSpan(textColor), 0, sp.length(),
                    Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            sp.setSpan(new StyleSpan(android.graphics.Typeface.BOLD), 0, sp.length(),
                    Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        }
        return sp;
    }

    @Override
    public OverlaySettings getOverlaySettings(long presentationTimeUs) {
        long ms = presentationTimeUs / 1000L;
        if (!activeAt(ms)) {
            // 没有字幕的帧：用全透明，而不是丢空串（空串会生成 0 宽位图，部分 GPU 直接报帧处理失败）
            return new OverlaySettings.Builder()
                    .setBackgroundFrameAnchor(anchorX, anchorY)
                    .setOverlayFrameAnchor(0f, 0f)
                    .setAlphaScale(0f)
                    .build();
        }
        return settings;
    }

    public boolean hasCueAt(long timeMs) {
        for (Cue c : cues) {
            if (timeMs >= c.startMs && timeMs < c.endMs) return true;
        }
        return false;
    }
}
