package com.offlinelocal.videoeditor;

import androidx.media3.effect.RgbMatrix;

/**
 * 首尾黑场淡入淡出：按时间把 RGB 整体乘一个 0→1 / 1→0 的亮度系数。
 * 用于片头片尾，以及"黑场转场"的观感。
 */
public class FadeEffect implements RgbMatrix {

    private final long totalUs;
    private final long fadeUs;

    public FadeEffect(long totalDurationMs, long fadeMs) {
        this.totalUs = Math.max(1, totalDurationMs) * 1000L;
        this.fadeUs = Math.max(0, fadeMs) * 1000L;
    }

    @Override
    public float[] getMatrix(long presentationTimeUs, boolean useHdr) {
        float k = 1f;
        if (fadeUs > 0) {
            if (presentationTimeUs < fadeUs) {
                k = presentationTimeUs / (float) fadeUs;
            }
            long tailStart = totalUs - fadeUs;
            if (presentationTimeUs > tailStart) {
                k = Math.min(k, (totalUs - presentationTimeUs) / (float) fadeUs);
            }
        }
        k = Math.max(0f, Math.min(1f, k));
        // 4×4 列主序
        return new float[]{
                k, 0f, 0f, 0f,
                0f, k, 0f, 0f,
                0f, 0f, k, 0f,
                0f, 0f, 0f, 1f
        };
    }
}
