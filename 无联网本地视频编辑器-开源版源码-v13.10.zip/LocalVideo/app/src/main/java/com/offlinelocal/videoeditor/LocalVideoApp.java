package com.offlinelocal.videoeditor;

import android.app.Application;

import java.io.File;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * 全局兜底：任何未捕获异常都落盘记录，下次启动在首页提示，
 * 而不是让用户遇到一个"闪退后什么都不知道"的黑箱。
 */
public class LocalVideoApp extends Application {

    private static final String CRASH_FILE = "last_crash.txt";

    @Override
    public void onCreate() {
        super.onCreate();
        final Thread.UncaughtExceptionHandler previous =
                Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler((thread, throwable) -> {
            try {
                writeCrash(throwable);
            } catch (Exception ignored) {
            }
            if (previous != null) previous.uncaughtException(thread, throwable);
        });
    }

    private void writeCrash(Throwable t) throws java.io.IOException {
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        pw.println(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(new Date()));
        pw.println("version=" + versionName());
        pw.println("thread=" + Thread.currentThread().getName());
        try {
            pw.println("device=" + android.os.Build.MANUFACTURER + " " + android.os.Build.MODEL
                    + " / Android " + android.os.Build.VERSION.RELEASE);
        } catch (Throwable ignored) {
        }
        t.printStackTrace(pw);
        Throwable cause = t.getCause();
        while (cause != null) {
            pw.println("Caused by: " + cause);
            cause.printStackTrace(pw);
            cause = cause.getCause();
        }
        pw.flush();

        File f = crashFile(this);
        // 先把上一份归档，避免第二次崩溃把第一份盖掉（用户要排查的往往不止一条）
        if (f.exists() && f.length() > 0) {
            File hist = crashHistoryDir(this);
            hist.mkdirs();
            long ts = f.lastModified();
            File copy = new File(hist, "crash_" + ts + ".log");
            try {
                copyFile(f, copy);
            } catch (Throwable ignored) {
            }
            trimHistory(hist, 5);
        }
        // 原子写：先写 .tmp 再 rename，写到一半被杀也不会留下半个文件
        File tmp = new File(f.getAbsolutePath() + ".tmp");
        try (java.io.FileOutputStream out = new java.io.FileOutputStream(tmp)) {
            out.write(sw.toString().getBytes("UTF-8"));
            out.getFD().sync();
        }
        if (!tmp.renameTo(f)) {
            try (java.io.FileOutputStream out = new java.io.FileOutputStream(f)) {
                out.write(sw.toString().getBytes("UTF-8"));
            }
            tmp.delete();
        }
    }

    /** API 24/25 没有 java.nio.file，日志落盘一律走流。 */
    private static void copyFile(File from, File to) throws java.io.IOException {
        try (java.io.FileInputStream in = new java.io.FileInputStream(from);
             java.io.FileOutputStream out = new java.io.FileOutputStream(to)) {
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        }
    }

    private String versionName() {
        try {
            return getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
        } catch (Exception e) {
            return "unknown";
        }
    }

    private static void trimHistory(File dir, int keep) {
        File[] all = dir.listFiles((d, n) -> n.endsWith(".log"));
        if (all == null || all.length <= keep) return;
        java.util.Arrays.sort(all, (a, b) -> Long.compare(b.lastModified(), a.lastModified()));
        for (int i = keep; i < all.length; i++) all[i].delete();
    }

    public static File crashHistoryDir(android.content.Context ctx) {
        return new File(ctx.getFilesDir(), "crash_history");
    }

    /** 历史崩溃日志，按时间倒序；给"故障日志"页用。 */
    public static File[] crashHistory(android.content.Context ctx) {
        File[] all = crashHistoryDir(ctx).listFiles((d, n) -> n.endsWith(".log"));
        if (all == null) return new File[0];
        java.util.Arrays.sort(all, (a, b) -> Long.compare(b.lastModified(), a.lastModified()));
        return all;
    }

    public static File crashFile(android.content.Context ctx) {
        return new File(ctx.getFilesDir(), CRASH_FILE);
    }

    public static boolean hasCrash(android.content.Context ctx) {
        File f = crashFile(ctx);
        return f.exists() && f.length() > 0;
    }

    public static String readCrash(android.content.Context ctx, int maxChars) {
        try {
            File f = crashFile(ctx);
            if (!f.exists()) return "";
            java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream();
            try (java.io.FileInputStream in = new java.io.FileInputStream(f)) {
                byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) > 0) bos.write(buf, 0, n);
            }
            String text = new String(bos.toByteArray(), "UTF-8");
            // 日志完整保留在文件里，界面上只截前 maxChars 字，避免弹窗被几万行撑爆
            return maxChars > 0 && text.length() > maxChars ? text.substring(0, maxChars) : text;
        } catch (Exception e) {
            return "";
        }
    }

    /** 把当前崩溃日志复制成可分享的文件（cache 目录，FileProvider 可读）。 */
    public static File exportCrash(android.content.Context ctx) throws java.io.IOException {
        File src = crashFile(ctx);
        if (!src.exists()) return null;
        File dir = new File(ctx.getCacheDir(), "logs");
        dir.mkdirs();
        File out = new File(dir, "无联网本地视频编辑器-崩溃日志-"
                + new SimpleDateFormat("MMdd-HHmmss-SSS", Locale.US).format(new Date()) + ".txt");
        copyFile(src, out);
        return out;
    }

    public static void clearCrash(android.content.Context ctx) {
        crashFile(ctx).delete();
    }
}
