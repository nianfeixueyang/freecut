package com.offlinelocal.videoeditor;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Movie;
import android.graphics.Paint;
import android.graphics.RectF;
import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaFormat;
import android.media.MediaMuxer;
import android.net.Uri;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.nio.ByteBuffer;

/**
 * 动图（GIF / 动态 WebP 走 Movie 能解的那部分）转成短视频，好让"动图"直接进视频编辑器。
 *
 * 做法：Movie 逐帧画到 Bitmap，转 YUV420 喂给 MediaCodec 编 H.264，再封装成 mp4。
 * 纯离线，不依赖任何在线服务。
 */
public final class GifToVideo {

    private static final int FPS = 24;
    private static final int MAX_SIDE = 1920;

    private GifToVideo() {
    }

    /** 判断这个 Uri 是不是动图（按 mime + 后缀双保险）。 */
    public static boolean isAnimated(Context ctx, Uri uri) {
        if (uri == null) return false;
        try {
            String type = ctx.getContentResolver().getType(uri);
            if (type != null) {
                if (type.equals("image/gif") || type.contains("webp") || type.contains("apng")) {
                    return true;
                }
                if (type.startsWith("video/")) return false;
            }
            String p = uri.toString().toLowerCase();
            return p.endsWith(".gif") || p.endsWith(".webp") || p.endsWith(".apng");
        } catch (Throwable t) {
            ExportDiag.warn("gif_type", t);
            return false;
        }
    }

    /** 图片也当片段用：转成 durationMs 的静态短视频（默认 3 秒）。 */
    public static File convertStill(Context ctx, Uri src, File dir, int durationMs) {
        MediaCodec enc = null;
        MediaMuxer muxer = null;
        try {
            android.graphics.BitmapFactory.Options o = new android.graphics.BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            InputStream in = ctx.getContentResolver().openInputStream(src);
            if (in == null) return null;
            android.graphics.BitmapFactory.decodeStream(in, null, o);
            in.close();
            int w = o.outWidth, h = o.outHeight;
            if (w <= 0 || h <= 0) return null;
            int sample = 1;
            while (Math.max(w, h) / sample > MAX_SIDE) sample *= 2;
            o.inJustDecodeBounds = false;
            o.inSampleSize = sample;
            in = ctx.getContentResolver().openInputStream(src);
            if (in == null) return null;
            Bitmap bmp = android.graphics.BitmapFactory.decodeStream(in, null, o);
            in.close();
            if (bmp == null) return null;
            int outW = (bmp.getWidth() / 2) * 2;
            int outH = (bmp.getHeight() / 2) * 2;
            if (outW < 2 || outH < 2) return null;
            Bitmap scaled = Bitmap.createScaledBitmap(bmp, outW, outH, true);
            if (scaled != bmp) bmp.recycle();

            if (!dir.isDirectory() && !dir.mkdirs()) {
                scaled.recycle();
                return null;
            }
            File out = new File(dir, "still_" + System.currentTimeMillis() + ".mp4");
            MediaFormat fmt = MediaFormat.createVideoFormat("video/avc", outW, outH);
            fmt.setInteger(MediaFormat.KEY_COLOR_FORMAT,
                    MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible);
            fmt.setInteger(MediaFormat.KEY_BIT_RATE, Math.max(2_000_000, outW * outH * 3));
            fmt.setInteger(MediaFormat.KEY_FRAME_RATE, FPS);
            fmt.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1);
            enc = MediaCodec.createEncoderByType("video/avc");
            enc.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
            enc.start();
            muxer = new MediaMuxer(out.getAbsolutePath(), MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);

            byte[] yuv = new byte[outW * outH * 3 / 2];
            argbToYuv420(scaled, yuv, outW, outH);
            scaled.recycle();
            MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
            int total = Math.max(1, durationMs * FPS / 1000);
            int track = -1;
            boolean started = false;
            for (int i = 0; i < total; i++) {
                int inIdx = enc.dequeueInputBuffer(10_000);
                if (inIdx >= 0) {
                    ByteBuffer ib = enc.getInputBuffer(inIdx);
                    if (ib != null) {
                        ib.clear();
                        ib.put(yuv);
                    }
                    enc.queueInputBuffer(inIdx, 0, yuv.length, i * 1_000_000L / FPS, 0);
                }
                while (true) {
                    int idx = enc.dequeueOutputBuffer(info, 0);
                    if (idx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                        track = muxer.addTrack(enc.getOutputFormat());
                        muxer.start();
                        started = true;
                        continue;
                    }
                    if (idx < 0) break;
                    ByteBuffer ob = enc.getOutputBuffer(idx);
                    if (ob != null && info.size > 0 && track >= 0) {
                        ob.position(info.offset);
                        ob.limit(info.offset + info.size);
                        muxer.writeSampleData(track, ob, info);
                    }
                    enc.releaseOutputBuffer(idx, false);
                }
            }
            int inIdx = enc.dequeueInputBuffer(20_000);
            if (inIdx >= 0) enc.queueInputBuffer(inIdx, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM);
            for (int i = 0; i < 300 && started; i++) {
                int idx = enc.dequeueOutputBuffer(info, 5_000);
                if (idx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    track = muxer.addTrack(enc.getOutputFormat());
                    muxer.start();
                    continue;
                }
                if (idx < 0) continue;
                ByteBuffer ob = enc.getOutputBuffer(idx);
                if (ob != null && info.size > 0 && track >= 0) {
                    ob.position(info.offset);
                    ob.limit(info.offset + info.size);
                    muxer.writeSampleData(track, ob, info);
                }
                boolean eos = (info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0;
                enc.releaseOutputBuffer(idx, false);
                if (eos) break;
            }
            if (!started) {
                out.delete();
                return null;
            }
            return out;
        } catch (Throwable t) {
            ExportDiag.warn("image_to_video", t);
            return null;
        } finally {
            if (enc != null) {
                try { enc.stop(); } catch (Throwable ignore) { }
                try { enc.release(); } catch (Throwable ignore) { }
            }
            if (muxer != null) {
                try { muxer.stop(); } catch (Throwable ignore) { }
                try { muxer.release(); } catch (Throwable ignore) { }
            }
        }
    }

    /** 转换成功返回 mp4 文件，失败返回 null（调用方负责提示）。 */
    public static File convert(Context ctx, Uri src, File dir) {
        Movie movie = null;
        MediaCodec enc = null;
        MediaMuxer muxer = null;
        try {
            InputStream in = ctx.getContentResolver().openInputStream(src);
            if (in == null) return null;
            movie = Movie.decodeStream(in);
            in.close();
            if (movie == null) {
                ExportDiag.info("gif 解码失败：不是 Movie 支持的动图");
                return null;
            }
            int w = movie.width();
            int h = movie.height();
            if (w <= 0 || h <= 0) return null;
            float k = Math.min(1f, MAX_SIDE / (float) Math.max(w, h));
            int outW = Math.max(2, (int) (w * k)) / 2 * 2;
            int outH = Math.max(2, (int) (h * k)) / 2 * 2;
            int durationMs = movie.duration();
            if (durationMs <= 0) durationMs = 1000;
            durationMs = Math.min(durationMs, 30_000);

            if (!dir.isDirectory() && !dir.mkdirs()) return null;
            File out = new File(dir, "gif_" + System.currentTimeMillis() + ".mp4");

            MediaFormat fmt = MediaFormat.createVideoFormat("video/avc", outW, outH);
            fmt.setInteger(MediaFormat.KEY_COLOR_FORMAT,
                    MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible);
            fmt.setInteger(MediaFormat.KEY_BIT_RATE, Math.max(2_000_000, outW * outH * 3));
            fmt.setInteger(MediaFormat.KEY_FRAME_RATE, FPS);
            fmt.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1);
            enc = MediaCodec.createEncoderByType("video/avc");
            enc.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
            enc.start();
            muxer = new MediaMuxer(out.getAbsolutePath(), MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
            int track = -1;
            boolean muxStarted = false;

            Bitmap frame = Bitmap.createBitmap(outW, outH, Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(frame);
            Paint paint = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG);
            RectF dst = new RectF(0, 0, outW, outH);
            int totalFrames = Math.max(1, durationMs * FPS / 1000);
            byte[] yuv = new byte[outW * outH * 3 / 2];
            MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();

            for (int i = 0; i < totalFrames; i++) {
                canvas.drawColor(Color.BLACK);
                movie.setTime((int) ((i * 1000L / FPS) % Math.max(1, movie.duration())));
                int save = canvas.save();
                canvas.scale(outW / (float) w, outH / (float) h);
                movie.draw(canvas, 0, 0);
                canvas.restoreToCount(save);
                argbToYuv420(frame, yuv, outW, outH);

                boolean fed = false;
                while (!fed) {
                    int inIdx = enc.dequeueInputBuffer(10_000);
                    if (inIdx >= 0) {
                        ByteBuffer ib = enc.getInputBuffer(inIdx);
                        if (ib != null) {
                            ib.clear();
                            ib.put(yuv);
                        }
                        long pts = i * 1_000_000L / FPS;
                        enc.queueInputBuffer(inIdx, 0, yuv.length, pts, 0);
                        fed = true;
                    } else {
                        drain(enc, muxer, info, out, track, muxStarted);
                        // track 可能在 drain 中建立，重新读
                        if (track < 0 && muxStarted) track = lastTrack;
                    }
                }
                drain(enc, muxer, info, out, track, muxStarted);
                if (track < 0 && muxStarted) track = lastTrack;
            }
            // 结束流
            int inIdx = enc.dequeueInputBuffer(20_000);
            if (inIdx >= 0) {
                enc.queueInputBuffer(inIdx, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM);
            }
            for (int i = 0; i < 200; i++) {
                if (drain(enc, muxer, info, out, track, muxStarted)) break;
                if (track < 0 && muxStarted) track = lastTrack;
            }
            frame.recycle();
            if (!muxStarted) {
                out.delete();
                return null;
            }
            return out;
        } catch (Throwable t) {
            ExportDiag.warn("gif_convert", t);
            return null;
        } finally {
            if (enc != null) {
                try { enc.stop(); } catch (Throwable ignore) { }
                try { enc.release(); } catch (Throwable ignore) { }
            }
            if (muxer != null) {
                try { muxer.stop(); } catch (Throwable ignore) { }
                try { muxer.release(); } catch (Throwable ignore) { }
            }
        }
    }

    private static int lastTrack = -1;

    /** 排空编码器输出；返回是否遇到 EOS。 */
    private static boolean drain(MediaCodec enc, MediaMuxer muxer, MediaCodec.BufferInfo info,
                                 File out, int track, boolean muxStarted) {
        while (true) {
            int idx = enc.dequeueOutputBuffer(info, 0);
            if (idx == MediaCodec.INFO_TRY_AGAIN_LATER) return false;
            if (idx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                lastTrack = muxer.addTrack(enc.getOutputFormat());
                muxer.start();
                return false;
            }
            if (idx < 0) return false;
            ByteBuffer ob = enc.getOutputBuffer(idx);
            if (ob != null && info.size > 0 && lastTrack >= 0) {
                ob.position(info.offset);
                ob.limit(info.offset + info.size);
                muxer.writeSampleData(lastTrack, ob, info);
            }
            enc.releaseOutputBuffer(idx, false);
            if ((info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) return true;
        }
    }

    private static byte[] readAll(InputStream in) throws Exception {
        java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = in.read(buf)) > 0) bos.write(buf, 0, n);
        return bos.toByteArray();
    }

    /** ARGB_8888 → YUV420 planar（I420）。 */
    private static void argbToYuv420(Bitmap bmp, byte[] out, int w, int h) {
        int[] px = new int[w * h];
        bmp.getPixels(px, 0, w, 0, 0, w, h);
        int ySize = w * h;
        int uvSize = ySize / 4;
        int uOff = ySize;
        int vOff = ySize + uvSize;
        for (int j = 0; j < h; j++) {
            for (int i = 0; i < w; i++) {
                int c = px[j * w + i];
                int r = (c >> 16) & 0xFF;
                int g = (c >> 8) & 0xFF;
                int b = c & 0xFF;
                int y = ((66 * r + 129 * g + 25 * b + 128) >> 8) + 16;
                out[j * w + i] = (byte) Math.max(16, Math.min(235, y));
                if ((j & 1) == 0 && (i & 1) == 0) {
                    int u = ((-38 * r - 74 * g + 112 * b + 128) >> 8) + 128;
                    int v = ((112 * r - 94 * g - 18 * b + 128) >> 8) + 128;
                    int idx = (j / 2) * (w / 2) + (i / 2);
                    out[uOff + idx] = (byte) Math.max(16, Math.min(240, u));
                    out[vOff + idx] = (byte) Math.max(16, Math.min(240, v));
                }
            }
        }
    }
}
