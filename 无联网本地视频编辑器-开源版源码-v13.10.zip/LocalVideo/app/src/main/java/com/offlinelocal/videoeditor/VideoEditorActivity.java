package com.offlinelocal.videoeditor;

import android.app.AlertDialog;
import android.content.ClipData;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Paint;
import android.media.MediaMetadataRetriever;
import android.media.MediaRecorder;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.SpannableString;
import android.util.Pair;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Button;
import android.widget.HorizontalScrollView;
import android.graphics.Typeface;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;
import androidx.media3.common.C;
import androidx.media3.common.Effect;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.audio.AudioProcessor;
import androidx.media3.common.audio.SpeedProvider;
import androidx.media3.effect.BitmapOverlay;
import androidx.media3.effect.OverlayEffect;
import androidx.media3.effect.OverlaySettings;
import androidx.media3.effect.Presentation;
import androidx.media3.effect.TextOverlay;
import androidx.media3.effect.TextureOverlay;
import com.google.common.collect.ImmutableList;
import androidx.media3.effect.ScaleAndRotateTransformation;
import androidx.media3.exoplayer.DefaultRenderersFactory;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.transformer.Composition;
import androidx.media3.transformer.EditedMediaItem;
import androidx.media3.transformer.EditedMediaItemSequence;
import androidx.media3.transformer.Effects;
import androidx.media3.transformer.ExportException;
import androidx.media3.transformer.ExportResult;
import androidx.media3.transformer.ProgressHolder;
import androidx.media3.transformer.TransformationException;
import androidx.media3.transformer.TransformationResult;
import androidx.media3.transformer.Transformer;
import androidx.media3.ui.PlayerView;

import com.google.android.material.slider.RangeSlider;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class VideoEditorActivity extends AppCompatActivity {

    /** 工程/草稿结构版本：老工程没有这个字段，读取时按 1 处理并自动补到新版本。 */
    private static final int SCHEMA_VERSION = 4;

    private static class Clip {
        Uri uri;
        String name;
        long durationMs;
        int width;
        int height;
        long startMs;
        long endMs;
        boolean locked = false;   // 轨道锁定：锁定后不允许改裁剪区间/删除/微调
        boolean hidden = false;   // 轨道隐藏：保留在工程里，但不参与预览和导出

        long lengthMs() {
            return Math.max(0, endMs - startMs);
        }

        Clip copy() {
            Clip c = new Clip();
            c.uri = uri;
            c.name = name;
            c.durationMs = durationMs;
            c.width = width;
            c.height = height;
            c.startMs = startMs;
            c.endMs = endMs;
            c.locked = locked;
            c.hidden = hidden;
            return c;
        }
    }

    /** 一次编辑的状态快照，撤销/重做与工程存档共用这一份结构。 */
    private static class EditorState {
        List<Clip> clips = new ArrayList<>();
        int currentIndex = 0;
        float rotation = 0f;
        float zoom = 1f;
        int filterIndex = 0;
        float filterStrength = 1f;
        float speed = 1f;
        int speedCurve = 0;
        boolean mute = false;
        float volume = 1f;
        boolean fadeAudio = false;
        float aspect = 0f;
        int targetHeight = 0;
        int exportBitrateMbps = 0;
        boolean exportHevc = false;
        boolean compatExport = false;
        String voiceUri;
        float voiceVolume = 0.7f;
        int fadeInMs = 600;
        int fadeOutMs = 600;
        int motion;
        boolean fadeTransition;
        int clipTransitionMs;
        int transType;
        float[][] kfKeys;
        int keyEasing;
        float brightness;
        float contrast = 1f;
        float saturation = 1f;
        float hueDeg;
        float warmth;
        float tint;
        boolean mirrorH = false;
        boolean mirrorV = false;
        String watermarkText;
        Uri watermarkLogo;
        float wmX = 0.62f, wmY = -0.72f, wmScale = 0.5f, wmAlpha = 0.9f, wmRotation = 0f;
        int wmColor = 0xFFFFFFFF;
        String musicUri;
        float musicVolume = 0.6f;
        List<TimedTextOverlay.Cue> cues = new ArrayList<>();
        float subX = 0f, subY = -0.72f, subSize = 72f;
        float subStroke = 2.5f;
        int subBg = 0;
        int subAnim;
        String titleText = "";
        long titleMs;
        int subColor = 0xFFFFFFFF;
    }

    /** 手动字幕段落（导出时按时间叠加）。 */
    private final List<TimedTextOverlay.Cue> subtitleCues = new ArrayList<>();
    private float subX = 0f, subY = -0.72f;   // 字幕锚点 (-1~1)
    private float subSize = 72f;
    /** 字幕描边粗细（以 72px 字号为基准） */
    private float subStroke = 2.5f;
    /** 字幕底色透明度 0~255 */
    private int subBg = 0;
    /** 字幕入场动画 0 无 1 淡入 2 上滑淡入 */
    private int subAnim = 0;
    /** 片头标题卡 */
    private String titleText = "";
    private long titleMs = 0;              // 导出字号（px）
    private int subColor = 0xFFFFFFFF;
    /** 变速曲线：0=匀速，1=慢起快走，2=快起慢收，3=两头慢中间快 */
    private int speedCurve = 0;

    private boolean edited = false;
    private boolean exportedOnce = false;
    private long exportStartMs = 0L;
    private boolean leaveAfterExport = false;

    private androidx.activity.result.ActivityResultLauncher<String[]> projectImporter;

    private ExoPlayer player;
    private PlayerView playerView;
    private float previewZoom = 1f;
    private float previewPanX = 0f, previewPanY = 0f;
    private float previewLastX = 0f, previewLastY = 0f;
    private RangeSlider trimSlider;
    private TimelineView timelineMulti;
    private TextView tvTime, tvSummary, tvExportTitle, tvExportPercent;
    private ProgressBar progress, exportProgress;
    private View exportMask;
    private LinearLayout categoryRow;
    private LinearLayout toolRow;

    private final List<Clip> clips = new ArrayList<>();
    private int currentIndex = 0;

    private float rotation = 0f;
    private float zoom = 1f;
    private int filterIndex = 0;
    private float filterStrength = 1f;
    private final List<TextView> filterChips = new ArrayList<>();
    private float speed = 1f;
    private boolean mute = false;
    private float volume = 1f;
    private boolean fadeAudio = false;
    private Uri musicUri = null;
    /** 配乐音量 0~1，和原声音量分开调（原声在「音量」里） */
    private float musicVolume = 0.6f;
    private float aspect = 0f;
    private int targetHeight = 0;   // 0 = 原尺寸
    private int exportBitrateMbps = 0;   // 0 = 自动
    private boolean exportHevc = false;  // false = H.264，true = H.265
    private boolean mirrorH = false;
    private boolean mirrorV = false;


    private LinearLayout timelineRow;
    private android.util.LruCache<String, Bitmap> thumbCache;
    private final List<EditorState> undoStack = new ArrayList<>();
    private final List<EditorState> redoStack = new ArrayList<>();
    private static final int UNDO_LIMIT = 30;
    private String projectId = null;
    private String projectTitle = "未命名工程";
    private boolean fromProject = false;
    static final String EXTRA_OPEN_DRAFT = "freecut_open_draft";
    private boolean draftThumbPending = false;

    private Transformer transformer;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ProgressHolder progressHolder = new ProgressHolder();
    private boolean exporting = false;
    /**
     * 效果降级层级：0 全开 → 1 去水印字幕 → 2 去滤镜 → 3 去变速（留旋转/画幅）→ 4 原片直出。
     * 某个效果在本机吃不下去时逐级退，比一次全丢掉更容易保住画面。
     */
    private int exportStage = 0;
    private boolean previewMode = false;
    private File exportFile;
    private boolean bindingSlider = false;
    private boolean suppressPreviewOnce = false;
    private Uri lastPreparedUri = null;

    private ActivityResultLauncher<String[]> clipPicker;
    private ActivityResultLauncher<String[]> logoPicker;
    private ActivityResultLauncher<String[]> srtPicker;
    private ActivityResultLauncher<String[]> musicPicker;

    private String watermarkText = null;
    private Uri watermarkLogo = null;
    private float wmX = 0.62f, wmY = -0.72f, wmScale = 0.5f;
    private float wmAlpha = 0.9f;
    private float wmRotation = 0f;
    private int wmColor = 0xFFFFFFFF;

    /** 从首页「继续上次编辑」进来：直接载入草稿，不再弹窗询问。 */
    public static Intent buildDraftIntent(Context ctx) {
        Intent i = new Intent(ctx, VideoEditorActivity.class);
        i.putExtra(EXTRA_OPEN_DRAFT, true);
        return i;
    }

    /** 从首页「我的工程」进来：直接按工程 id 恢复。 */
    public static Intent buildProjectIntent(Context ctx, String projectId) {
        Intent i = new Intent(ctx, VideoEditorActivity.class);
        i.putExtra(ProjectStore.EXTRA_PROJECT_ID, projectId);
        return i;
    }

    public static Intent buildIntent(Context ctx, Uri uri) {
        Intent i = new Intent(ctx, VideoEditorActivity.class);
        i.setData(uri);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        return i;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video_editor);

        try {
            android.content.SharedPreferences sp =
                    getSharedPreferences(EXPORT_PREFS, MODE_PRIVATE);
            if (sp.getBoolean("pending", false)) {
                sp.edit().putBoolean("pending", false).apply();
                toast("上次导出没有完成，可重新导出；失败原因见「信息 → 最近导出」");
            }
        } catch (Throwable ignored) {
        }

        playerView = findViewById(R.id.playerView);
        setupPreviewZoom();
        trimSlider = findViewById(R.id.trimSlider);
        timelineMulti = findViewById(R.id.timelineMulti);
        if (timelineMulti != null) {
            timelineMulti.setListener(new TimelineView.Listener() {
                @Override
                public void onSeek(long ms) {
                    seekTimeline(ms);
                }

                @Override
                public void onCueRangeChanged(int index, long startMs, long endMs) {
                    if (index < 0 || index >= subtitleCues.size()) return;
                    TimedTextOverlay.Cue cue = subtitleCues.get(index);
                    cue.startMs = Math.max(0, startMs);
                    cue.endMs = Math.max(cue.startMs + 100, endMs);
                    subtitleCues.sort((a, b) -> Long.compare(a.startMs, b.startMs));
                    afterChange();
                    syncTimeline();
                    toast("字幕时间已调整");
                }

                @Override
                public void onClipTap(int index) {
                    if (index < 0 || index >= clips.size()) return;
                    currentIndex = index;
                    previewSequence();
                    syncTimeline();
                }
            });
        }
        tvTime = findViewById(R.id.tvTime);
        tvSummary = findViewById(R.id.tvSummary);
        progress = findViewById(R.id.progress);
        exportMask = findViewById(R.id.exportMask);
        exportProgress = findViewById(R.id.exportProgress);
        tvExportTitle = findViewById(R.id.tvExportTitle);
        tvExportPercent = findViewById(R.id.tvExportPercent);
        toolRow = findViewById(R.id.toolRow);
        categoryRow = findViewById(R.id.categoryRow);

        Uri sourceUri = getIntent().getData();
        String openProjectId = getIntent().getStringExtra(ProjectStore.EXTRA_PROJECT_ID);
        if (getIntent().getBooleanExtra(EXTRA_OPEN_DRAFT, false)) {
            org.json.JSONObject d = ProjectStore.loadDraftData(this);
            if (d == null || !fromJson(d)) {
                toast("草稿已经不存在了");
                finish();
                return;
            }
            projectTitle = ProjectStore.draftTitle(this);
            fromProject = true; // 不再弹草稿询问
            for (Clip c : clips) {
                try {
                    getContentResolver().takePersistableUriPermission(c.uri,
                            Intent.FLAG_GRANT_READ_URI_PERMISSION);
                } catch (Exception ignored) {
                }
            }
        } else if (openProjectId != null) {
            org.json.JSONObject data = ProjectStore.load(this, openProjectId);
            if (data == null) {
                toast("工程文件已丢失或损坏");
                finish();
                return;
            }
            projectId = openProjectId;
            String title = ProjectStore.loadTitle(this, openProjectId);
            if (title != null) projectTitle = title;
            fromProject = true;
            org.json.JSONArray arr = data.optJSONArray("clips");
            if (arr != null) {
                for (int i = 0; i < arr.length(); i++) {
                    try {
                        Uri u = Uri.parse(arr.getJSONObject(i).getString("uri"));
                        getContentResolver().takePersistableUriPermission(u,
                                Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    } catch (Exception ignored) {
                    }
                }
            }
            if (!fromJson(data)) {
                toast("工程数据读不出来");
                finish();
                return;
            }
        } else {
            if (sourceUri == null) {
                toast("没有收到视频");
                finish();
                return;
            }
            try {
                getContentResolver().takePersistableUriPermission(sourceUri,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } catch (Exception ignored) {
            }
        }

        findViewById(R.id.btnBack).setOnClickListener(v -> confirmExit());
        findViewById(R.id.btnExport).setOnClickListener(v -> {
            exportStage = 0; // 用户主动点导出：先从完整效果管线试
            runExport(false);
        });
        findViewById(R.id.btnExportCancel).setOnClickListener(v -> cancelExport());

        clipPicker = registerForActivityResult(
                new ActivityResultContracts.OpenDocument(), this::onClipPicked);
        musicPicker = registerForActivityResult(
                new ActivityResultContracts.OpenDocument(), uri -> {
                    if (uri == null) return;
                    try {
                        getContentResolver().takePersistableUriPermission(uri,
                                Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    } catch (Exception ignored) {
                    }
                    musicUri = uri;
                    afterChange();
                    toast("配乐已设置，导出时循环铺满整条视频");
                });
        srtPicker = registerForActivityResult(new ActivityResultContracts.OpenDocument(), uri -> {
            if (uri == null) return;
            try (java.io.InputStream in = getContentResolver().openInputStream(uri)) {
                if (in == null) return;
                java.io.BufferedReader r = new java.io.BufferedReader(new java.io.InputStreamReader(in));
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = r.readLine()) != null) sb.append(line).append('\n');
                List<TimedTextOverlay.Cue> parsed = SrtUtils.parse(sb.toString());
                if (parsed.isEmpty()) {
                    toast("这个文件里没解析到字幕");
                    return;
                }
                subtitleCues.clear();
                subtitleCues.addAll(parsed);
                afterChange();
                toast("已导入 " + parsed.size() + " 条字幕");
            } catch (Exception e) {
                toast("导入失败：" + e.getMessage());
            }
        });

        projectImporter = registerForActivityResult(
                new ActivityResultContracts.OpenDocument(), uri -> {
                    if (uri == null) return;
                    try (java.io.InputStream in = getContentResolver().openInputStream(uri)) {
                        if (in == null) {
                            toast("读不到这个文件");
                            return;
                        }
                        java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
                        byte[] buf = new byte[8192];
                        int n;
                        while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
                        org.json.JSONObject data =
                                new org.json.JSONObject(new String(bo.toByteArray(), "UTF-8"));
                        if (!fromJson(data)) {
                            toast("不是有效的无联网本地视频编辑器工程文件");
                            return;
                        }
                        projectId = null;
                        fromProject = false;
                        markEdited();
                        applyRestoredState();
                        loadDurations();
                        toast("工程已导入，共 " + clips.size() + " 段");
                    } catch (Exception e) {
                        toast("导入失败：" + e.getMessage());
                    }
                });

        logoPicker = registerForActivityResult(
                new ActivityResultContracts.OpenDocument(), uri -> {
                    if (uri == null) return;
                    final int takeFlags = Intent.FLAG_GRANT_READ_URI_PERMISSION;
                    try {
                        getContentResolver().takePersistableUriPermission(uri, takeFlags);
                    } catch (Exception ignored) {
                    }
                    watermarkLogo = uri;
                    watermarkText = null;
                    afterChange();
                    toast("图片水印已设置，导出时叠加到成片");
                });

        if (getIntent().getStringExtra(ProjectStore.EXTRA_PROJECT_ID) == null) {
            Clip first = new Clip();
            first.uri = sourceUri;
            first.name = "片段 1";
            clips.add(first);
        }

        timelineRow = findViewById(R.id.timelineRow);
        long cacheBytes = Math.max(8L * 1024 * 1024, Runtime.getRuntime().maxMemory() / 16);
        thumbCache = new android.util.LruCache<String, Bitmap>((int) cacheBytes) {
            @Override
            protected int sizeOf(String key, Bitmap value) {
                return Math.max(1, value.getByteCount() / 1024);
            }
        };
        buildTools();
        setupTransformPanel();
        setupFilterPanel();
        setupSpeedPanel();
        setupTimeline();
        setupPlayer();
        setupFrameButtons();
        setupSlider();
        loadDurations();
        applyRestoredState();
        Work.run(this::cleanOldExports);
        maybeOfferDraft();
    }

    @Override
    protected void onResume() {
        super.onResume();
        handler.removeCallbacks(draftTick);
        handler.postDelayed(draftTick, 10000);
    }

    @Override
    protected void onPause() {
        super.onPause();
        // 回到家/切微信后视频声音还在响，是明显的体验 bug
        if (player != null && player.isPlaying()) player.pause();
        handler.removeCallbacks(draftTick);
        try {
            autoSave();
        } catch (Exception ignored) {
        }
    }

    /** 导出目录只留最近的正式成片：预览临时文件与超过 12 小时的残留一律清掉。 */
    private void cleanOldExports() {
        try {
            File dir = new File(getExternalFilesDir(null), "export");
            File[] files = dir.listFiles();
            if (files == null) return;
            long now = System.currentTimeMillis();
            for (File f : files) {
                String n = f.getName();
                boolean preview = n.startsWith("PREVIEW_");
                boolean stale = now - f.lastModified() > 12L * 60 * 60 * 1000;
                if (preview || stale) {
                    //noinspection ResultOfMethodCallIgnored
                    f.delete();
                }
            }
        } catch (Exception ignored) {
        }
    }

    // ---------------- 时长 ----------------

    private void loadDurations() {
        Work.run(() -> {
            for (Clip c : clips) {
                if (c.durationMs == 0) {
                    c.durationMs = readDuration(c.uri);
                    if (c.durationMs <= 0) c.durationMs = 0;
                    c.startMs = 0;
                    c.endMs = c.durationMs;
                }
                if (c.width <= 0 || c.height <= 0) {
                    int[] size = readSize(c.uri);
                    c.width = size[0];
                    c.height = size[1];
                }
            }
            runOnUiThread(() -> bindCurrentClip());
        });
    }

    private int[] readSize(Uri uri) {
        MediaMetadataRetriever r = new MediaMetadataRetriever();
        try {
            r.setDataSource(this, uri);
            String w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH);
            String h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT);
            String rot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION);
            int iw = w == null ? 0 : Integer.parseInt(w);
            int ih = h == null ? 0 : Integer.parseInt(h);
            int rotation = rot == null ? 0 : Integer.parseInt(rot);
            if (rotation == 90 || rotation == 270) {
                int tmp = iw;
                iw = ih;
                ih = tmp;
            }
            return new int[]{iw, ih};
        } catch (Exception e) {
            return new int[]{0, 0};
        } finally {
            try {
                r.release();
            } catch (Exception ignored) {
            }
        }
    }

    /** 多段分辨率不一致时，用首段比例做统一画幅；单段或比例一致返回 0（不额外处理）。 */
    private float unifiedAspectOfClips() {
        if (clips.size() < 2) return 0f;
        int baseW = 0, baseH = 0;
        boolean differ = false;
        for (Clip c : clips) {
            if (c.width <= 0 || c.height <= 0) continue;
            if (baseH == 0) {
                baseW = c.width;
                baseH = c.height;
            } else if (c.width != baseW || c.height != baseH) {
                differ = true;
            }
        }
        if (!differ || baseW <= 0 || baseH <= 0) return 0f;
        return (float) baseW / (float) baseH;
    }

    /**
     * 拼接不同分辨率/不同比例的片段时，Media3 会因为尺寸不一致出问题。
     * 这里统一锚到同一高度并等比留边，画面不会变形。
     */
    private void addResolutionUnification(List<Effect> videoEffects) {
        if (clips.size() < 2) return;
        int maxH = 0, minH = Integer.MAX_VALUE;
        boolean differ = false;
        int baseW = 0, baseH = 0;
        for (Clip c : clips) {
            if (c.height <= 0) continue;
            if (baseH == 0) {
                baseW = c.width;
                baseH = c.height;
            } else if (c.height != baseH || c.width != baseW) {
                differ = true;
            }
            maxH = Math.max(maxH, c.height);
            minH = Math.min(minH, c.height);
        }
        if (!differ || maxH == 0) return;
        // Media3 1.4 的 createForHeight 没有布局参数重载，会裁切；
        // 这里改用「统一到首段比例 + 等比留边」，画面不变形也不裁内容。
        if (baseW <= 0 || baseH <= 0) return;
        float aspect = (float) baseW / (float) baseH;
        videoEffects.add(Presentation.createForAspectRatio(aspect, Presentation.LAYOUT_SCALE_TO_FIT));
    }

    private long readDuration(Uri uri) {
        MediaMetadataRetriever r = new MediaMetadataRetriever();
        try {
            r.setDataSource(this, uri);
            String d = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
            return d == null ? 0 : Long.parseLong(d);
        } catch (Exception e) {
            return 0;
        } finally {
            try {
                r.release();
            } catch (Exception ignored) {
            }
        }
    }

    private void refreshWaveformIfVisible() {
        com.offlinelocal.videoeditor.WaveformView wave = findViewById(R.id.waveform);
        if (wave != null && wave.getVisibility() == View.VISIBLE && !clips.isEmpty()) {
            wave.setSource(clips.get(currentIndex).uri);
        }
    }

    private void bindCurrentClip() {
        filterFrame = null;
        hideFilterPreview();
        Clip c = clips.get(currentIndex);
        if (c.durationMs <= 0) return;
        // 关键修复：进入编辑器时若 endMs 还没被初始化（<=startMs 或超出素材时长），
        // 先补成整段。以前这里直接拿 0 去算，最小间隔把片段强行截成 0.2~0.3 秒，
        // 表现为"刚点进去预览黑屏、本段只剩 00:00.2"。
        if (c.startMs < 0) c.startMs = 0;
        if (c.endMs <= c.startMs || c.endMs > c.durationMs + 1) {
            c.startMs = 0;
            c.endMs = c.durationMs;
        }
        bindingSlider = true;
        float dur = (float) c.durationMs;
        float range = Math.max(300f, dur);
        trimSlider.setValueFrom(0f);
        trimSlider.setValueTo(range);
        trimSlider.setMinSeparationValue(Math.min(500f, Math.max(200f, range / 2f)));
        float s = Math.max(0f, Math.min(c.startMs, range - 1f));
        float e = Math.max(s + 1f, Math.min(c.endMs, range));
        if (e - s < Math.min(500f, dur)) e = Math.min(range, s + Math.min(500f, dur));
        if (c.durationMs > 0 && c.durationMs < 500) {
            toast("这段素材只有 " + c.durationMs + "ms，片段过短，预览可能黑屏");
        }
        trimSlider.setValues(s, e);
        bindingSlider = false;
        updateTimeLabel();
        refreshToolLabels();
        updateSummary();
        refreshWaveformIfVisible();
        if (suppressPreviewOnce) {
            suppressPreviewOnce = false;
            return;
        }
        if (!bindingSlider) previewCurrentClip();
    }

    // ---------------- 预览 ----------------

    /**
     * 预览自愈：如果视频画面被压成细条（尺寸远小于预览框），把一切变换复位并重新布局。
     * 同时把框尺寸/画面尺寸写进诊断，便于下次定位。
     */
    private void selfHealPreview(String where) {
        try {
            android.widget.FrameLayout box = findViewById(R.id.previewBox);
            android.view.View surf = playerView == null ? null : playerView.getVideoSurfaceView();
            if (box == null || surf == null) return;
            int bw = box.getWidth(), bh = box.getHeight();
            int sw = surf.getWidth(), sh = surf.getHeight();
            ExportDiag.info("preview " + where + " box=" + bw + "x" + bh + " surf=" + sw + "x" + sh);
            boolean tiny = bw > 0 && bh > 0 && (sh < bh * 0.4f || sw < bw * 0.15f);
            if (tiny) {
                surf.setScaleX(1f);
                surf.setScaleY(1f);
                surf.setTranslationX(0f);
                surf.setTranslationY(0f);
                playerView.setScaleX(1f);
                playerView.setScaleY(1f);
                playerView.setTranslationX(0f);
                playerView.setTranslationY(0f);
                previewZoom = 1f;
                previewPanX = 0f;
                previewPanY = 0f;
                playerView.requestLayout();
                box.requestLayout();
                ExportDiag.info("preview 自愈：画面尺寸异常，已复位变换");
                // 再等一拍：若尺寸仍然异常，说明是画面比例测量问题，强切 ZOOM（铺满裁切）保证能看到画面
                handler.postDelayed(() -> {
                    try {
                        int sh2 = surf.getHeight(), bw2 = box.getWidth(), bh2 = box.getHeight();
                        if (bh2 > 0 && sh2 < bh2 * 0.4f) {
                            playerView.setResizeMode(
                                    androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_ZOOM);
                            playerView.requestLayout();
                            ExportDiag.info("preview 自愈：改 ZOOM 铺满");
                        }
                    } catch (Throwable t) {
                        ExportDiag.warn("preview_heal2", t);
                    }
                }, 700);
            }
        } catch (Throwable t) {
            ExportDiag.warn("preview_heal", t);
        }
    }

    private void setupPlayer() {
        // decoderFallback：某些机型缺少对应的硬解码器时自动回退软解，避免大视频直接白屏
        DefaultRenderersFactory renderers = new DefaultRenderersFactory(this)
                .setEnableDecoderFallback(true)
                .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_OFF);
        player = new ExoPlayer.Builder(this, renderers).build();
        player.setVideoScalingMode(C.VIDEO_SCALING_MODE_SCALE_TO_FIT);
        playerView.setPlayer(player);
        applyLivePreviewEffects();

        player.addListener(new androidx.media3.common.Player.Listener() {
            @Override
            public void onPlaybackStateChanged(int state) {
                if (state == androidx.media3.common.Player.STATE_READY) {
                    progress.setVisibility(View.GONE);
                    hideLoadTip();
                    Clip c = clips.get(currentIndex);
                    // 兜底：元数据读不到时长时，用播放器拿到的时长补上
                    if (c.durationMs <= 0 && player.getDuration() > 0) {
                        c.durationMs = player.getDuration();
                        c.startMs = 0;
                        c.endMs = c.durationMs;
                        bindCurrentClip();
                    }
                    warnIfLargeVideo();
                } else if (state == androidx.media3.common.Player.STATE_ENDED) {
                    if (clips.size() > 1) {
                        // 多段：播完最后一段就从头再来，整条串起来循环
                        currentIndex = 0;
                        suppressPreviewOnce = true;
                        bindCurrentClip();
                        buildTimeline();
                        player.seekTo(0);
                    } else {
                        Clip cc = clips.get(currentIndex);
                        long lenMs = cc.endMs - cc.startMs;
                        player.seekTo(cc.startMs);
                        if (lenMs < 1200) {
                            // 极短视频（含动图转出来的）循环重播会一直闪黑，停在首帧更好用
                            player.pause();
                            return;
                        }
                    }
                    player.play();
                }
            }

            @Override
            public void onVideoSizeChanged(androidx.media3.common.VideoSize size) {
                ExportDiag.info("preview video=" + size.width + "x" + size.height
                        + " par=" + size.pixelWidthHeightRatio);
                selfHealPreview("videoSize");
            }

            @Override
            public void onRenderedFirstFrame() {
                selfHealPreview("firstFrame");
            }

            @Override
            public void onMediaItemTransition(MediaItem item, int reason) {
                if (clips.size() <= 1) return;
                int idx = player.getCurrentMediaItemIndex();
                if (idx < 0 || idx >= clips.size() || idx == currentIndex) return;
                currentIndex = idx;
                suppressPreviewOnce = true;
                bindCurrentClip();
                buildTimeline();
                updateSummary();
            }

            @Override
            public void onPlayerError(androidx.media3.common.PlaybackException error) {
                progress.setVisibility(View.GONE);
                hideLoadTip();
                toast("视频打不开（" + error.getErrorCodeName() + "）：文件可能过大或格式不受支持");
            }
        });

        // 看门狗：8 秒还没就绪就提示，避免"一直转圈"
        handler.postDelayed(loadWatchdog, 8000);
    }

    private final Runnable loadWatchdog = new Runnable() {
        @Override
        public void run() {
            if (isDestroyed() || player == null) return;
            if (player.getPlaybackState() != androidx.media3.common.Player.STATE_READY) {
                progress.setVisibility(View.GONE);
                showLoadTip("视频较大，解码较慢。可以先调参数，导出时会完整处理；" +
                        "或换用 720p 压缩预设。");
            }
        }
    };

    private TextView tipView;

    private void showLoadTip(String text) {
        hideLoadTip();
        tipView = new TextView(this);
        tipView.setText(text);
        tipView.setTextSize(12);
        tipView.setTextColor(getColor(R.color.warn));
        tipView.setPadding(dp(12), dp(8), dp(12), dp(8));
        tipView.setBackgroundColor(0xCC000000);
        tipView.setOnClickListener(v -> hideLoadTip());
        ((android.widget.FrameLayout) playerView.getParent()).addView(tipView,
                new android.widget.FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                        Gravity.BOTTOM));
    }

    private void hideLoadTip() {
        if (tipView != null && tipView.getParent() != null) {
            ((android.view.ViewGroup) tipView.getParent()).removeView(tipView);
        }
        tipView = null;
    }

    private boolean largeWarned = false;

    private void warnIfLargeVideo() {
        if (largeWarned) return;
        Clip c = clips.get(currentIndex);
        int h = 0;
        MediaMetadataRetriever r = new MediaMetadataRetriever();
        try {
            r.setDataSource(this, c.uri);
            String hs = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT);
            if (hs != null) h = Integer.parseInt(hs);
        } catch (Exception ignored) {
        } finally {
            try {
                r.release();
            } catch (Exception ignored) {
            }
        }
        if (h >= 2000) {
            largeWarned = true;
            toast("这是 " + h + "p 大视频，预览会吃性能；建议用「压缩预设」导出 720p");
        }
    }

    private void previewCurrentClip() {
        if (player == null || clips.isEmpty()) return;
        final Clip c = clips.get(currentIndex);
        if (c.endMs <= 0) return;
        if (clips.size() > 1) {
            previewSequence();
            return;
        }
        sequenceSignature = null;
        // 同一段视频只改起止点时，用 seek 代替重新 prepare，避免大文件反复解码卡死
        boolean sameMedia = lastPreparedUri != null && lastPreparedUri.equals(c.uri);
        if (sameMedia) {
            player.seekTo(Math.max(0, c.startMs));
            if (player.getPlaybackState() == androidx.media3.common.Player.STATE_IDLE) player.prepare();
            return;
        }
        lastPreparedUri = c.uri;
        MediaItem item = new MediaItem.Builder()
                .setUri(c.uri)
                .setClippingConfiguration(new MediaItem.ClippingConfiguration.Builder()
                        .setStartPositionMs(c.startMs)
                        .setEndPositionMs(c.endMs)
                        .build())
                .build();
        progress.setVisibility(View.VISIBLE);
        player.setMediaItem(item);
        player.prepare();
        handler.removeCallbacks(loadWatchdog);
        handler.postDelayed(loadWatchdog, 8000);
    }


    /**
     * 多段预览：把每一段都做成带裁剪区间的 MediaItem 串成一条序列，
     * 播放时自动从上一段衔接到下一段 —— 不用等导出才看到拼接效果。
     */
    private String sequenceSignature = null;
    private boolean sequencePreparing = false;

    private String buildSequenceSignature() {
        StringBuilder sb = new StringBuilder();
        for (Clip c : clips) {
            sb.append(c.uri).append('#').append(c.startMs).append('-').append(c.endMs)
                    .append(c.hidden ? "H" : "").append(';');
        }
        return sb.toString();
    }

    private int visibleClipCount() {
        int n = 0;
        for (Clip c : clips) if (!c.hidden) n++;
        return n;
    }

    /** 片段下标 → 播放列表里的 item 下标（跳过隐藏段）。 */
    private int visibleItemIndex(int clipIndex) {
        int n = 0;
        for (int i = 0; i < clipIndex && i < clips.size(); i++) if (!clips.get(i).hidden) n++;
        return n;
    }

    /** 第 index 段在整条序列里的起始时间（前面所有段的长度之和）。 */
    private long sequenceOffsetOf(int index) {
        long sum = 0;
        for (int i = 0; i < index && i < clips.size(); i++) sum += clips.get(i).lengthMs();
        return sum;
    }

    /** 多轨时间线定位：把整条序列时间换算成"第几段 + 段内位置"。 */
    private void seekTimeline(long ms) {
        long acc = 0;
        for (int i = 0; i < clips.size(); i++) {
            Clip c = clips.get(i);
            if (c.endMs <= 0 || c.hidden) continue;
            long len = c.lengthMs();
            if (ms < acc + len || i == clips.size() - 1) {
                if (currentIndex != i) {
                    currentIndex = i;
                    previewSequence();
                }
                player.seekTo(Math.max(0, Math.min(len, ms - acc)));
                return;
            }
            acc += len;
        }
    }

    /** 把当前编辑状态喂给多轨时间线。 */
    private void syncTimeline() {
        if (timelineMulti == null) return;
        List<long[]> cues = new ArrayList<>();
        for (TimedTextOverlay.Cue c : subtitleCues) cues.add(new long[]{c.startMs, c.endMs});
        List<long[]> segs = new ArrayList<>();
        long acc = 0;
        for (Clip c : clips) {
            long len = c.endMs <= 0 || c.hidden ? 0 : c.lengthMs();
            segs.add(new long[]{acc, acc + len});
            acc += len;
        }
        long[] starts = new long[segs.size()];
        long[] ends = new long[segs.size()];
        for (int i = 0; i < segs.size(); i++) {
            starts[i] = segs.get(i)[0];
            ends[i] = segs.get(i)[1];
        }
        long pos = sequenceOffsetOf(currentIndex);
        try {
            if (player != null) pos += Math.max(0, player.getCurrentPosition());
        } catch (Exception ignore) {
        }
        timelineMulti.setData(starts, ends, cues, totalLengthMs(), pos,
                musicUri != null, voiceUri != null);
    }

    private void previewSequence() {
        String sig = buildSequenceSignature();
        int itemCount = visibleClipCount();
        if (sig.equals(sequenceSignature) && player.getMediaItemCount() == itemCount) {
            // 关键：多 item 的播放列表里 seekTo(positionMs) 是"当前 item 内"的位置，
            // 用总时长偏移去 seek 会停在上一段中间 —— 用户就会看到"切了段但画面没变，
            // 非得拖一下裁剪条（触发重新 prepare）才切过去"。必须按 item 序号 seek。
            int idx = Math.max(0, Math.min(visibleItemIndex(currentIndex),
                    player.getMediaItemCount() - 1));
            player.seekTo(idx, 0);
            if (player.getPlaybackState() == androidx.media3.common.Player.STATE_IDLE) player.prepare();
            return;
        }
        List<MediaItem> items = new ArrayList<>();
        for (Clip c : clips) {
            if (c.endMs <= 0 || c.hidden) continue;
            items.add(new MediaItem.Builder()
                    .setUri(exportUriOf(c))
                    .setClippingConfiguration(new MediaItem.ClippingConfiguration.Builder()
                            .setStartPositionMs(exportClipStart(c))
                            .setEndPositionMs(exportClipEnd(c))
                            .build())
                    .build());
        }
        if (items.isEmpty()) return;
        sequenceSignature = sig;
        lastPreparedUri = null;
        sequencePreparing = true;
        progress.setVisibility(View.VISIBLE);
        player.setMediaItems(items, Math.min(visibleItemIndex(currentIndex), items.size() - 1), 0);
        player.prepare();
        handler.removeCallbacks(loadWatchdog);
        handler.postDelayed(loadWatchdog, 8000);
    }

    /** 逐帧步进：视频按 30fps 估，一帧 ≈33ms；暂停状态下走一格，方便精确对齐。 */
    private void stepFrame(int dir) {
        if (player == null) return;
        long step = 33L * dir;
        long pos = player.getCurrentPosition() + step;
        pos = Math.max(0, Math.min(pos, Math.max(0, player.getDuration())));
        player.seekTo(Math.max(0, pos));
        player.pause();
    }

    private void setupFrameButtons() {
        android.view.View prev = findViewById(R.id.btnFramePrev);
        android.view.View next = findViewById(R.id.btnFrameNext);
        if (prev != null) prev.setOnClickListener(v -> stepFrame(-1));
        if (next != null) next.setOnClickListener(v -> stepFrame(1));
    }

    private void setupSlider() {
        trimSlider.addOnChangeListener((slider, value, fromUser) -> {
            if (bindingSlider) return;
            List<Float> vals = slider.getValues();
            Clip c = clips.get(currentIndex);
            if (fromUser && c.locked) {
                toast("这一段已锁定，先在「拼接」里解锁");
                bindingSlider = true;
                trimSlider.setValues((float) c.startMs, (float) c.endMs);
                bindingSlider = false;
                return;
            }
            long dur2 = c.durationMs > 0 ? c.durationMs : Long.MAX_VALUE;
            c.startMs = Math.max(0, Math.min(vals.get(0).longValue(), dur2));
            c.endMs = Math.max(c.startMs + 1, Math.min(vals.get(1).longValue(), dur2));
            updateTimeLabel();
            updateSummary();
            refreshToolLabels();
        });
        trimSlider.addOnSliderTouchListener(new RangeSlider.OnSliderTouchListener() {
            @Override
            public void onStartTrackingTouch(RangeSlider slider) {
                player.pause();
            }

            @Override
            public void onStopTrackingTouch(RangeSlider slider) {
                previewCurrentClip();
            }
        });
    }

    private void updateTimeLabel() {
        Clip c = clips.get(currentIndex);
        String head = "第 " + (currentIndex + 1) + "/" + clips.size() + " 段  ";
        syncTimeline();
        tvTime.setText(head + fmt(c.startMs) + " - " + fmt(c.endMs)
                + "   本段 " + fmt(c.lengthMs()) + "   合计 " + fmt(totalLengthMs()));
    }

    private long totalLengthMs() {
        long sum = 0;
        for (Clip c : clips) sum += c.lengthMs();
        return sum;
    }

    private String fmt(long ms) {
        // 按 0.1 秒四舍五入：299ms 显示 00:00.3，和工具芯片的 0.3s 一致
        if (ms < 0) ms = 0;
        long tenths = Math.round(ms / 100.0);
        long m = tenths / 600;
        long s = (tenths / 10) % 60;
        long tenth = tenths % 10;
        return String.format("%02d:%02d.%d", m, s, tenth);
    }

    // ---------------- 工具 ----------------

    /**
     * 成片模板：把"比例 + 导出尺寸 + 色调"三件事一次配好。
     * 目的不是替用户剪，而是让不会剪的人选完就能直接按导出发片。
     */
    private void applyTemplate(int which) {
        switch (which) {
            case 0: // 口播
                aspect = 9f / 16f;
                targetHeight = 1080;
                filterIndex = indexOfFilter("暖调");
                break;
            case 1: // vlog
                aspect = 16f / 9f;
                targetHeight = 1080;
                filterIndex = indexOfFilter("胶片");
                break;
            case 3: // 卡点 3 秒
            case 4: // 卡点 5 秒
                aspect = which == 3 ? 9f / 16f : 16f / 9f;
                targetHeight = 1080;
                filterIndex = indexOfFilter(which == 3 ? "暖调" : "胶片");
                int beatMs = which == 3 ? 3000 : 5000;
                for (Clip c : clips) {
                    if (c.locked) continue;
                    c.startMs = Math.min(c.startMs, Math.max(0, c.endMs - 100));
                    c.endMs = Math.min(c.endMs, c.startMs + beatMs);
                }
                toast("已按 " + (beatMs / 1000) + " 秒/段 卡点");
                break;
            case 2: // 商品
                aspect = 1f;
                targetHeight = 1080;
                filterIndex = indexOfFilter("鲜亮");
                break;
            default:
                return;
        }
        filterStrength = 0.55f;
        applyLiveFilter();
        updateSummary();
        toast("已套用模板：比例/尺寸/色调都配好了，直接点导出");
    }

    private int indexOfFilter(String name) {
        for (int i = 0; i < Filters.ALL.length; i++) {
            if (Filters.ALL[i].name.equals(name)) return i;
        }
        return 0;
    }

    private static final String[] TOOLS = {
            "截取", "裁剪", "微调", "旋转", "缩放", "滤镜", "速度", "声音", "比例", "分辨率", "镜像",
            "压缩预设", "编码", "水印", "信息", "音量", "配乐", "拼接", "封面", "字幕", "提取音频",
            "变速曲线", "波形", "调色", "运镜", "关键帧", "转场", "模板", "预览效果", "撤销", "重做", "保存工程"
    };

    /** 工具分组：名称必须与 TOOLS 一字不差，顺序即组内横排顺序。 */
    private static final String[][] TOOL_GROUPS = {
            {"基础", "截取", "裁剪", "微调", "拼接", "封面", "模板", "保存工程"},
            {"调整", "旋转", "缩放", "镜像", "滤镜", "速度", "变速曲线", "调色", "运镜", "关键帧", "转场", "比例", "分辨率", "压缩预设", "编码"},
            {"叠加", "水印", "字幕", "配乐", "音量", "声音", "波形"},
            {"导出", "预览效果", "提取音频", "撤销", "重做", "信息"}
    };

    private String activeGroup = "基础";
    private final java.util.Map<String, TextView> toolStatusViews = new java.util.HashMap<>();
    private final java.util.Map<String, ImageView> toolIconViews = new java.util.HashMap<>();
    private final java.util.Map<String, View> toolChipViews = new java.util.HashMap<>();

    /** 每个工具的线框图标；同一个图标可在多个工具间复用。 */
    private int toolIcon(String name) {
        switch (name) {
            case "截取": return R.drawable.ic_video_line;
            case "裁剪": return R.drawable.ic_tool_crop;
            case "微调": return R.drawable.ic_tool_tune;
            case "拼接": return R.drawable.ic_video_line;
            case "封面": return R.drawable.ic_image_line;
            case "模板": return R.drawable.ic_tool_template;
            case "保存工程": return R.drawable.ic_tool_save;
            case "旋转": return R.drawable.ic_tool_rotate;
            case "缩放": return R.drawable.ic_tool_scale;
            case "镜像": return R.drawable.ic_tool_mirror;
            case "滤镜": return R.drawable.ic_tool_filter;
            case "速度": return R.drawable.ic_tool_speed;
            case "变速曲线": return R.drawable.ic_tool_wave;
            case "运镜": return R.drawable.ic_video_line;
            case "关键帧": return R.drawable.ic_tool_motion;
            case "转场": return R.drawable.ic_tool_template;
            case "调色": return R.drawable.ic_tool_filter;
            case "比例": return R.drawable.ic_tool_ratio;
            case "分辨率": return R.drawable.ic_grid;
            case "压缩预设": return R.drawable.ic_tool_encode;
            case "编码": return R.drawable.ic_tool_encode;
            case "水印": return R.drawable.ic_tool_watermark;
            case "字幕": return R.drawable.ic_tool_subtitle;
            case "配乐": return R.drawable.ic_tool_music;
            case "音量": return R.drawable.ic_tool_volume;
            case "声音": return R.drawable.ic_tool_volume;
            case "波形": return R.drawable.ic_tool_wave;
            case "预览效果": return R.drawable.ic_video_line;
            case "提取音频": return R.drawable.ic_tool_music;
            case "撤销": return R.drawable.ic_tool_undo;
            case "重做": return R.drawable.ic_tool_redo;
            case "信息": return R.drawable.ic_tool_info;
            default: return R.drawable.ic_grid;
        }
    }

    private java.util.List<String> groupNames() {
        java.util.List<String> out = new java.util.ArrayList<>();
        for (String[] g : TOOL_GROUPS) out.add(g[0]);
        return out;
    }

    private void buildTools() {
        java.util.List<String> groups = groupNames();
        for (String g : groups) {
            TextView tab = new TextView(this);
            tab.setText(g);
            tab.setTag(g);
            tab.setTextSize(13);
            tab.setGravity(Gravity.CENTER);
            tab.setIncludeFontPadding(false);
            tab.setPaddingRelative(dp(16), 0, dp(16), 0);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, dp(30));
            lp.rightMargin = dp(6);
            tab.setLayoutParams(lp);
            tab.setClickable(true);
            tab.setFocusable(true);
            tab.setOnClickListener(v -> renderGroup((String) v.getTag()));
            categoryRow.addView(tab);
            categoryTabs.add(tab);
        }
        renderGroup(activeGroup);
        refreshToolLabels();
        updateSummary();
    }

    private final java.util.List<TextView> categoryTabs = new java.util.ArrayList<>();

    private void renderGroup(String group) {
        activeGroup = group;
        for (TextView tab : categoryTabs) {
            boolean on = group.equals(tab.getTag());
            tab.setTextColor(getColor(on ? R.color.accent : R.color.text_2));
            tab.setBackgroundResource(on ? R.drawable.bg_chip_selected : 0);
            tab.setTypeface(null, on ? Typeface.BOLD : Typeface.NORMAL);
        }
        toolRow.removeAllViews();
        toolStatusViews.clear();
        toolIconViews.clear();
        toolChipViews.clear();
        for (String[] g : TOOL_GROUPS) {
            if (!g[0].equals(group)) continue;
            for (int i = 1; i < g.length; i++) addToolChip(g[i]);
        }
        applyHighlight();
    }

    private void addToolChip(String name) {
        View chip = getLayoutInflater().inflate(R.layout.item_tool, toolRow, false);
        ImageView icon = chip.findViewById(R.id.ivToolIcon);
        TextView label = chip.findViewById(R.id.tvToolName);
        TextView status = chip.findViewById(R.id.tvToolStatus);
        icon.setImageResource(toolIcon(name));
        label.setText(name);
        status.setText("");
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(68), dp(70));
        lp.rightMargin = dp(6);
        chip.setLayoutParams(lp);
        chip.setOnClickListener(v -> openTool(name));
        UiAnim.press(chip, 0.94f);
        toolRow.addView(chip);
        toolChipViews.put(name, chip);
        toolIconViews.put(name, icon);
        toolStatusViews.put(name, status);
    }

    /**
     * 状态值回填：名称已经显示在芯片上了，这里只放「值」，
     * 例如 3.2s / 1.00x / 胶片 / 1080p / H.265·12M。
     */
    private void refreshToolLabels() {
        setTool("截取", String.format("%.1fs", clips.get(currentIndex).lengthMs() / 1000f));
        setTool("裁剪", cropOverlay == null || cropOverlay.isFullFrame() ? "原画" : "自定义");
        Clip cur = clips.get(currentIndex);
        long sOff = cur.startMs, eOff = Math.max(0, cur.durationMs - cur.endMs);
        if (sOff == 0 && eOff == 0) {
            setTool("微调", "整段");
        } else {
            setTool("微调", (sOff > 0 ? "起+" + String.format("%.1fs", sOff / 1000f) : "")
                    + (sOff > 0 && eOff > 0 ? " " : "")
                    + (eOff > 0 ? "尾-" + String.format("%.1fs", eOff / 1000f) : ""));
        }
        setTool("拼接", clips.size() + " 段");
        setTool("封面", "可导出");
        setTool("模板", "本地");
        setTool("保存工程", "自动");
        setTool("旋转", Math.round(rotation) + "°");
        setTool("缩放", (int) (zoom * 100) + "%");
        setTool("镜像", (mirrorH || mirrorV) ? "开" : "关");
        setTool("滤镜", filterIndex == 0 ? "原片" : Filters.ALL[filterIndex].name);
        setTool("速度", trimNum(speed) + "x");
        setTool("变速曲线", speedCurve == 0 ? "线性" : new String[]{"线性", "慢起快走", "快起快收", "两头慢中间快"}[speedCurve]);
        setTool("比例", aspectLabel());
        setTool("分辨率", targetHeight == 0 ? "原始" : targetHeight + "p");
        setTool("压缩预设", exportBitrateMbps == 0 ? "自动" : exportBitrateMbps + "M");
        setTool("编码", (exportHevc ? "H.265" : "H.264") + (compatExport ? "·兼容" : "")
                + "·" + (exportBitrateMbps == 0 ? "自动" : exportBitrateMbps + "M"));
        setTool("水印", watermarkLogo != null ? "图片" : (watermarkText != null ? "文字" : "无"));
        setTool("字幕", subtitleCues.isEmpty() ? "无"
                : subtitleCues.size() + " 条·" + (subY > 0.3f ? "上" : (subY < -0.3f ? "下" : "中")));
        setTool("配乐", musicUri == null ? (fadeInMs > 0 ? "淡" + fadeInMs / 1000f + "s" : "无")
                : "已选" + (fadeInMs > 0 ? "·淡" : ""));
        setTool("音量", (int) (volume * 100) + "%" + (fadeAudio ? "·淡" : ""));
        setTool("调色", colorSummary());
        setTool("关键帧", kfKeys == null ? "未启用"
                : (kfKeys.length + " 帧·" + (keyEasing == 0 ? "线性" : "缓动")));
        setTool("转场", clipTransitionMs == 0 ? "硬切"
                : (transType < 0 ? "黑场 " : TransitionRenderer.nameOf(transType) + " ")
                + (clipTransitionMs / 1000f) + "s");
        setTool("运镜", motion == 0 ? "关闭" : new String[]{
                "关闭", "推近", "拉远", "左→右", "下→上"}[motion]);
        setTool("声音", voiceUri != null ? "配音" + Math.round(voiceVolume * 100) + "%"
                : (mute ? "静音" : "原声"));
        com.offlinelocal.videoeditor.WaveformView waveView = findViewById(R.id.waveform);
        setTool("波形", waveView != null && waveView.getVisibility() == View.VISIBLE ? "显示" : "隐藏");
        setTool("预览效果", "实时");
        setTool("提取音频", "m4a");
        setTool("撤销", undoStack.size() + " 步");
        setTool("重做", redoStack.size() + " 步");
        setTool("信息", resolutionLabel());
    }

    private String resolutionLabel() {
        if (clips.isEmpty()) return "—";
        int w = clips.get(0).width;
        int h = targetHeight == 0 ? clips.get(0).height : targetHeight;
        return w + "x" + h;
    }

    private String groupOf(String name) {
        for (String[] g : TOOL_GROUPS) {
            for (int i = 1; i < g.length; i++) if (g[i].equals(name)) return g[0];
        }
        return null;
    }

    private String activeTool = null;

    /** 当前工具 chip 高亮，让用户一眼知道正在用哪个。 */
    private void highlightTool(String name) {
        activeTool = name;
        if (!toolChipViews.containsKey(name)) {
            String g = groupOf(name);
            if (g != null) renderGroup(g);
        }
        applyHighlight();
    }

    /** 选中态：底 amp 描边 + 文字/图标走 accent，其余回到 bg_chip + text_2。 */
    private void applyHighlight() {
        for (java.util.Map.Entry<String, View> e : toolChipViews.entrySet()) {
            boolean on = e.getKey().equals(activeTool);
            View chip = e.getValue();
            chip.setBackgroundResource(on ? R.drawable.bg_pill_accent : R.drawable.bg_chip);
            TextView label = chip.findViewById(R.id.tvToolName);
            TextView status = chip.findViewById(R.id.tvToolStatus);
            ImageView icon = chip.findViewById(R.id.ivToolIcon);
            label.setTextColor(getColor(on ? R.color.accent : R.color.text_1));
            status.setTextColor(getColor(on ? R.color.accent : R.color.text_3));
            icon.setColorFilter(getColor(on ? R.color.accent : R.color.text_2));
        }
    }

    private void setTool(String name, String label) {
        TextView tv = toolStatusViews.get(name);
        if (tv != null) tv.setText(label);
    }

    private String trimNum(float v) {
        String s = String.valueOf(v);
        return s.endsWith(".0") ? s.substring(0, s.length() - 2) : s;
    }

    private String aspectLabel() {
        if (aspect == 1f) return "1:1";
        if (Math.abs(aspect - 9f / 16f) < 0.001f) return "9:16";
        if (Math.abs(aspect - 16f / 9f) < 0.001f) return "16:9";
        if (Math.abs(aspect - 4f / 3f) < 0.001f) return "4:3";
        return "自定义";
    }

    private void updateSummary() {
        List<String> parts = new ArrayList<>();
        parts.add(clips.size() + " 段共 " + fmt(totalLengthMs()));
        if (rotation != 0f) parts.add("旋转" + Math.round(rotation) + "°");
        if (zoom != 1f) parts.add("缩放" + (int) (zoom * 100) + "%");
        if (filterIndex != 0) parts.add("滤镜·" + Filters.ALL[filterIndex].name);
        if (speed != 1f) parts.add("速度" + trimNum(speed) + "x");
        if (mute) parts.add("静音");
        else if (volume != 1f) parts.add("音量" + (int) (volume * 100) + "%");
        if (fadeAudio) parts.add("声音淡入淡出");
        if (musicUri != null) parts.add("配乐");
        if (aspect != 0f) parts.add("比例" + aspectLabel());
        if (targetHeight != 0) parts.add("导出" + targetHeight + "p");
        if (mirrorH) parts.add("左右镜像");
        if (mirrorV) parts.add("上下镜像");
        tvSummary.setText("将导出： " + String.join(" · ", parts));
    }

    private CropOverlayView cropOverlay;

    private void openCropTool() {
        if (cropOverlay == null) {
            cropOverlay = findViewById(R.id.cropOverlay);
            if (cropOverlay == null) return;
            cropOverlay.setOnCropChanged((l, t, r, b) -> {
                markEdited();
                refreshToolLabels();
            });
        }
        if (cropOverlay.getVisibility() == View.VISIBLE) {
            showCropActions();
            return;
        }
        cropOverlay.setVisibility(View.VISIBLE);
        cropOverlay.bringToFront();
        toast("拖动四角自由裁剪，不锁比例；导出时按框生效");
    }

    private void showCropActions() {
        String[] actions = {"完成（保留当前框）", "复位为整幅", "取消裁剪"};
        new android.app.AlertDialog.Builder(this)
                .setTitle("自由裁剪")
                .setItems(actions, (d, which) -> {
                    if (which == 0) {
                        cropOverlay.setVisibility(View.GONE);
                        refreshToolLabels();
                        toast("裁剪已应用，导出时生效");
                    } else if (which == 1) {
                        cropOverlay.reset();
                        refreshToolLabels();
                    } else {
                        cropOverlay.reset();
                        cropOverlay.setVisibility(View.GONE);
                        refreshToolLabels();
                    }
                }).show();
    }

    private void openTool(String name) {
        if ("裁剪".equals(name)) {
            openCropTool();
            highlightTool(name);
            return;
        }
        if ("提取音频".equals(name)) {
            askExtractAudio();
            return;
        }
        if ("撤销".equals(name)) {
            undo();
            return;
        }
        if ("重做".equals(name)) {
            redo();
            return;
        }
        if ("保存工程".equals(name)) {
            openProjectMenu();
            return;
        }
        highlightTool(name);
        pushUndo();
        if (!"旋转".equals(name) && !"缩放".equals(name)) showTransformPanel(false);
        if (!"滤镜".equals(name)) showFilterPanel(false);
        if (!"速度".equals(name)) showSpeedPanel(false);
        if (!"滤镜".equals(name)) showFilterPanel(false);
        if (!"速度".equals(name)) showSpeedPanel(false);
        switch (name) {
            case "截取":
                toast("滑块两端选择片段；多段时作用于当前选中的这一段");
                break;
            case "微调":
                if (clips.get(currentIndex).locked) {
                    toast("这一段已锁定，先在「拼接」里解锁");
                    break;
                }
                choose("逐帧微调（每次 0.1 秒）", new String[]{
                        "起点 +0.1s", "起点 -0.1s", "终点 +0.1s", "终点 -0.1s"}, 0, which -> {
                    Clip c = clips.get(currentIndex);
                    if (which == 0) c.startMs = Math.min(c.endMs - 200, c.startMs + 100);
                    if (which == 1) c.startMs = Math.max(0, c.startMs - 100);
                    if (which == 2) c.endMs = Math.min(c.durationMs, c.endMs + 100);
                    if (which == 3) c.endMs = Math.max(c.startMs + 200, c.endMs - 100);
                    bindCurrentClip();
                    previewCurrentClip();
                });
                break;
            case "旋转":
                showTransformPanel(true);
                break;
            case "缩放":
                showTransformPanel(true);
                break;
            case "滤镜":
                showFilterPanel(true);
                break;
            case "速度":
                showSpeedPanel(true);
                break;
            case "模板":
                choose("成片模板（一键套好比例/导出尺寸/色调）", new String[]{
                        "口播 9:16 · 暖调", "vlog 16:9 · 胶片", "商品 1:1 · 鲜亮",
                        "卡点 9:16 · 每段 3 秒", "卡点 16:9 · 每段 5 秒"}, -1, which -> {
                    applyTemplate(which);
                });
                break;
            case "字幕":
                openSubtitlePanel();
                break;
            case "波形":
                toggleWaveform();
                break;
            case "变速曲线":
                choose("变速曲线", new String[]{
                        "匀速（关闭曲线）", "慢起快走", "快起慢收", "两头慢中间快"}, speedCurve, which -> {
                    speedCurve = which;
                    afterChange();
                    toast(which == 0 ? "已关闭曲线" : "已应用曲线，导出时生效");
                });
                break;
            case "声音":
                SheetUi.list(this, "声音 / 配音", new String[]{
                        mute ? "恢复原声" : "静音原声",
                        voiceUri == null ? "录音配音（录一段旁白）" : "重新录音配音",
                        "配音音量（当前 " + Math.round(voiceVolume * 100) + "%）",
                        "移除配音"}, -1, which -> {
                            if (which == 0) {
                                mute = !mute;
                                afterChange();
                            } else if (which == 1) {
                                startVoiceRecordingFlow();
                            } else if (which == 2) {
                                chooseVoiceVolume();
                            } else {
                                voiceUri = null;
                                afterChange();
                                toast("已移除配音");
                            }
                        }).show();
                break;
            case "比例":
                choose("画面比例", new String[]{"保持原样", "1:1 方形", "9:16 竖屏", "16:9 横屏", "4:3"},
                        aspect == 0f ? 0 : 1, which -> {
                            aspect = new float[]{0f, 1f, 9f / 16f, 16f / 9f, 4f / 3f}[which];
                            afterChange();
                        });
                break;
            case "分辨率":
                choose("导出分辨率", new String[]{"保持原尺寸", "1080p", "720p", "480p"},
                        targetHeight == 0 ? 0 : (targetHeight == 1080 ? 1 : (targetHeight == 720 ? 2 : 3)), which -> {
                            targetHeight = new int[]{0, 1080, 720, 480}[which];
                            afterChange();
                        });
                break;
            case "编码":
                openEncoderDialog();
                break;
            case "压缩预设":
                choose("导出预设（一次套好尺寸/码率/编码）", new String[]{
                        "朋友圈 · 720p 小体积（约 4Mbps）",
                        "抖音/快手 · 1080p（约 8Mbps）",
                        "高清 · 1080p 高码率（约 12Mbps）",
                        "兼容模式 · 720p + H.264 + 自动码率"}, 1, which -> {
                    targetHeight = new int[]{720, 1080, 1080, 720}[which];
                    exportBitrateMbps = new int[]{4, 8, 12, 0}[which];
                    compatExport = which == 3;
                    if (compatExport) exportHevc = false;
                    afterChange();
                    toast("已套用导出预设：" + new String[]{
                            "朋友圈 720p", "抖音 1080p", "高清 1080p", "兼容模式"}[which]);
                });
                break;
            case "水印":
                openWatermarkDialog();
                break;
            case "音量":
                openVolumeDialog();
                break;
            case "调色":
                new AlertDialog.Builder(this)
                        .setTitle("调色（可叠加在滤镜之上）")
                        .setItems(new String[]{
                                "亮度（当前 " + pct(brightness) + "）",
                                "对比度（当前 " + Math.round(contrast * 100) + "%）",
                                "饱和度（当前 " + Math.round(saturation * 100) + "%）",
                                "色相（当前 " + Math.round(hueDeg) + "°）",
                                "色温（当前 " + (warmth > 0 ? "暖 " : (warmth < 0 ? "冷 " : ""))
                                        + Math.round(Math.abs(warmth) * 100) + "%）",
                                "色调（绿 ↔ 洋红，当前 " + (tint > 0 ? "+" : "") + Math.round(tint * 100) + "%）",
                                "一键调色预设（6 套）",
                                "重置调色"}, (d, which) -> {
                            if (which == 0) choose("亮度", new String[]{
                                    "-40%", "-20%", "0%", "+20%", "+40%"},
                                    brightness < -0.3f ? 0 : (brightness < -0.1f ? 1
                                            : (brightness < 0.1f ? 2 : (brightness < 0.3f ? 3: 4))), idx -> {
                                        brightness = new float[]{-0.4f, -0.2f, 0f, 0.2f, 0.4f}[idx];
                                        afterChange();
                                        toast("亮度 " + pct(brightness));
                                    });
                            else if (which == 1) choose("对比度", new String[]{
                                    "80%", "100%", "120%", "140%"}, Math.round(contrast * 100) <= 80 ? 0
                                            : (Math.round(contrast * 100) <= 100 ? 1
                                            : (Math.round(contrast * 100) <= 120 ? 2 : 3)), idx -> {
                                        contrast = new float[]{0.8f, 1f, 1.2f, 1.4f}[idx];
                                        afterChange();
                                        toast("对比度 " + Math.round(contrast * 100) + "%");
                                    });
                            else if (which == 2) choose("饱和度", new String[]{
                                    "0%（黑白）", "60%", "100%", "130%", "160%"},
                                    saturation <= 0.01f ? 0 : (saturation < 0.8f ? 1
                                            : (saturation < 1.15f ? 2 : (saturation < 1.45f ? 3: 4))), idx -> {
                                        saturation = new float[]{0f, 0.6f, 1f, 1.3f, 1.6f}[idx];
                                        afterChange();
                                        toast("饱和度 " + Math.round(saturation * 100) + "%");
                                    });
                            else if (which == 3) choose("色相偏移", new String[]{
                                    "-30°", "-15°", "0°", "+15°", "+30°"},
                                    hueDeg <= -22 ? 0 : (hueDeg <= -7 ? 1 : (hueDeg <= 7 ? 2 : (hueDeg <= 22 ? 3: 4))), idx -> {
                                        hueDeg = new float[]{-30f, -15f, 0f, 15f, 30f}[idx];
                                        afterChange();
                                        toast("色相 " + Math.round(hueDeg) + "°");
                                    });
                            else if (which == 4) choose("色温", new String[]{
                                    "冷 -30%", "冷 -15%", "中性", "暖 +15%", "暖 +30%"},
                                    warmth <= -0.22f ? 0 : (warmth <= -0.07f ? 1 : (warmth <= 0.07f ? 2 : (warmth <= 0.22f ? 3: 4))), idx -> {
                                        warmth = new float[]{-0.3f, -0.15f, 0f, 0.15f, 0.3f}[idx];
                                        afterChange();
                                        toast("色温 " + Math.round(warmth * 100) + "%");
                                    });
                            else if (which == 5) choose("色调（绿 ↔ 洋红）", new String[]{
                                    "偏绿 -40%", "偏绿 -20%", "中性", "偏洋红 +20%", "偏洋红 +40%"},
                                    tint < -0.3f ? 0 : (tint < -0.1f ? 1 : (tint < 0.1f ? 2 : (tint < 0.3f ? 3 : 4))),
                                    idx -> {
                                        tint = new float[]{-0.4f, -0.2f, 0f, 0.2f, 0.4f}[idx];
                                        afterChange();
                                        toast("色调 " + Math.round(tint * 100) + "%");
                                    });
                            else if (which == 6) chooseColorPreset();
                            else {
                                brightness = 0f;
                                contrast = 1f;
                                saturation = 1f;
                                hueDeg = 0f;
                                warmth = 0f;
                                tint = 0f;
                                filterIndex = 0;
                                afterChange();
                                toast("已重置调色（含滤镜）");
                            }
                        })
                        .setNegativeButton("关闭", null)
                        .show();
                break;
            case "关键帧":
                openKeyframePanel();
                break;
            case "转场":
                openTransitionPanel();
                break;
            case "运镜":
                choose("运镜 / 黑场转场", new String[]{
                        "运镜关闭", "缓慢推近", "缓慢拉远", "左 → 右平移", "下 → 上平移",
                        fadeTransition ? "黑场淡入淡出：开（点击关闭）" : "黑场淡入淡出：关（点击开启）"},
                        motion, which -> {
                            if (which == 5) {
                                fadeTransition = !fadeTransition;
                                afterChange();
                                toast(fadeTransition ? "已开启片头片尾黑场淡入淡出" : "已关闭黑场淡入淡出");
                                return;
                            }
                            motion = which;
                            afterChange();
                            toast(which == 0 ? "已关闭运镜" : "运镜：" + new String[]{
                                    "关闭", "缓慢推近", "缓慢拉远", "左→右", "下→上"}[which]);
                        });
                break;
            case "配乐":
                SheetUi.list(this, "背景配乐", new String[]{"选择本地音乐", "配乐音量（当前 "
                                + Math.round(musicVolume * 100) + "%）",
                                "淡入淡出（当前 " + (fadeInMs / 100) / 10f + "s）",
                                "配音闪避（" + (duckMusic ? "开：一说话配乐自动变轻" : "关") + "）",
                                "移除配乐"}, -1, which -> {
                            if (which == 0) musicPicker.launch(new String[]{"audio/*"});
                            else if (which == 1) chooseMusicVolume();
                            else if (which == 2) chooseFade();
                            else if (which == 3) {
                                duckMusic = !duckMusic;
                                afterChange();
                                toast(duckMusic ? "已开启配音闪避" : "已关闭配音闪避");
                            } else {
                                musicUri = null;
                                afterChange();
                                toast("已移除配乐");
                            }
                        }).show();
                break;
            case "信息":
                SheetUi.list(this, "信息", new String[]{"素材与导出参数", "最近导出记录（诊断）"},
                        -1, which -> {
                            if (which == 0) showMediaInfo();
                            else showExportLog();
                        }).show();
                break;
            case "镜像":
                choose("镜像", new String[]{"不镜像", "左右镜像", "上下镜像", "双向镜像"},
                        !mirrorH && !mirrorV ? 0 : (mirrorH && !mirrorV ? 1 : (!mirrorH ? 2 : 3)), which -> {
                            mirrorH = which == 1 || which == 3;
                            mirrorV = which == 2 || which == 3;
                            afterChange();
                        });
                break;
            case "拼接":
                openClipManager();
                break;
            case "封面":
                SheetUi.list(this, "封面 / 抽帧", new String[]{"保存当前帧", "保存九宫格预览图"},
                        -1, which -> {
                            if (which == 0) saveCover();
                            else saveFrameGrid();
                        }).show();
                break;
            case "预览效果":
                runExport(true);
                break;
            default:
                break;
        }
    }

    // ---------------- 旋转 / 缩放底部面板 ----------------

    private void setupTransformPanel() {
        SeekBar rotBar = findViewById(R.id.seekRotation);
        SeekBar zoomBar = findViewById(R.id.seekZoom);
        final TextView rotValue = findViewById(R.id.tvRotationValue);
        final TextView zoomValue = findViewById(R.id.tvZoomValue);

        rotBar.setProgress((int) (rotation + 180));
        zoomBar.setProgress((int) (zoom * 100));
        rotValue.setText(Math.round(rotation) + "°");
        zoomValue.setText(Math.round(zoom * 100) + "%");

        rotBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar sb, int p, boolean fromUser) {
                rotation = p - 180f;
                rotValue.setText(Math.round(rotation) + "°");
                applyViewTransform();
            }
            @Override public void onStartTrackingTouch(SeekBar sb) { }
            @Override public void onStopTrackingTouch(SeekBar sb) {
                markEdited();
                refreshToolLabels();
            }
        });

        zoomBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar sb, int p, boolean fromUser) {
                zoom = p / 100f;
                zoomValue.setText(p + "%");
                applyViewTransform();
            }
            @Override public void onStartTrackingTouch(SeekBar sb) { }
            @Override public void onStopTrackingTouch(SeekBar sb) {
                markEdited();
                refreshToolLabels();
            }
        });

        findViewById(R.id.btnMirrorH).setOnClickListener(v -> {
            mirrorH = !mirrorH;
            applyViewTransform();
            markEdited();
            refreshToolLabels();
        });
        findViewById(R.id.btnMirrorV).setOnClickListener(v -> {
            mirrorV = !mirrorV;
            applyViewTransform();
            markEdited();
            refreshToolLabels();
        });
        findViewById(R.id.btnTransformReset).setOnClickListener(v -> {
            rotation = 0f;
            zoom = 1f;
            mirrorH = false;
            mirrorV = false;
            rotBar.setProgress(180);
            zoomBar.setProgress(100);
            rotValue.setText("0°");
            zoomValue.setText("100%");
            applyViewTransform();
            markEdited();
            refreshToolLabels();
        });
    }

    /** 三个参数面板都收起时，把 220dp 的固定面板区一并收起，别留一块空白。 */
    private final Runnable panelSync = this::syncPanelHost;

    private void schedulePanelSync() {
        handler.removeCallbacks(panelSync);
        handler.postDelayed(panelSync, 220);
    }

    private void syncPanelHost() {
        View host = findViewById(R.id.panelHost);
        if (host == null) return;
        boolean any = findViewById(R.id.panelVideoFilter).getVisibility() == View.VISIBLE
                || findViewById(R.id.panelSpeed).getVisibility() == View.VISIBLE
                || findViewById(R.id.panelTransform).getVisibility() == View.VISIBLE;
        host.setVisibility(any ? View.VISIBLE : View.GONE);
    }

    private void showTransformPanel(boolean show) {
        UiAnim.panel(findViewById(R.id.panelTransform), show);
        schedulePanelSync();
        if (show) {
            ((SeekBar) findViewById(R.id.seekRotation)).setProgress((int) (rotation + 180));
            ((SeekBar) findViewById(R.id.seekZoom)).setProgress((int) (zoom * 100));
            ((TextView) findViewById(R.id.tvRotationValue)).setText(Math.round(rotation) + "°");
            ((TextView) findViewById(R.id.tvZoomValue)).setText(Math.round(zoom * 100) + "%");
            applyViewTransform();
        }
    }

    // ---------------- 滤镜底部面板 ----------------

    private void setupFilterPanel() {
        LinearLayout row = findViewById(R.id.rowVideoFilters);
        row.removeAllViews();
        filterChips.clear();
        for (int i = 0; i < Filters.ALL.length; i++) {
            final int idx = i;
            TextView tv = new TextView(this);
            tv.setText(Filters.ALL[i].name);
            tv.setTextSize(13);
            tv.setPadding(dp(10), dp(6), dp(10), dp(6));
            tv.setBackgroundResource(R.drawable.bg_chip);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.rightMargin = dp(6);
            tv.setLayoutParams(lp);
            tv.setOnClickListener(v -> {
                filterIndex = idx;
                filterStrength = 1f;
                ((SeekBar) findViewById(R.id.seekVideoFilterStrength)).setProgress(100);
                styleVideoFilterChips();
                applyLiveFilter();
                updateSummary();
                markEdited();
                refreshToolLabels();
            });
            row.addView(tv);
            filterChips.add(tv);
        }
        styleVideoFilterChips();

        SeekBar bar = findViewById(R.id.seekVideoFilterStrength);
        bar.setProgress(Math.round(filterStrength * 100));
        ((TextView) findViewById(R.id.tvVideoFilterStrength))
                .setText(Math.round(filterStrength * 100) + "%");
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar sb, int p, boolean fromUser) {
                filterStrength = p / 100f;
                ((TextView) findViewById(R.id.tvVideoFilterStrength)).setText(p + "%");
                applyLiveFilterThrottled();
            }
            @Override public void onStartTrackingTouch(SeekBar sb) { }
            @Override public void onStopTrackingTouch(SeekBar sb) {
                markEdited();
                refreshToolLabels();
                applyLiveFilter();
            }
        });
    }

    private void styleVideoFilterChips() {
        for (int i = 0; i < filterChips.size(); i++) {
            TextView tv = filterChips.get(i);
            boolean on = i == filterIndex;
            tv.setTextColor(getColor(on ? R.color.text_primary : R.color.text_secondary));
            tv.setTypeface(null, on ? android.graphics.Typeface.BOLD : android.graphics.Typeface.NORMAL);
            tv.setBackgroundResource(on ? R.drawable.bg_pill_accent : R.drawable.bg_chip);
        }
    }

    private void showFilterPanel(boolean show) {
        View panel = findViewById(R.id.panelVideoFilter);
        UiAnim.panel(panel, show);
        schedulePanelSync();
        if (show) {
            ((SeekBar) findViewById(R.id.seekVideoFilterStrength))
                    .setProgress(Math.round(filterStrength * 100));
            styleVideoFilterChips();
            applyLiveFilter();
        } else {
            applyLiveFilter();
        }
    }

    /**
     * 滤镜实时预览：
     * - API 31+ 用 View 的 RenderEffect 颜色滤镜，直接在播放画面上生效，不碰播放器管线，拖动丝滑
     * - 低版本退回"抓帧 + 颜色矩阵"的定格预览
     */
    private boolean filterApplyPending = false;

    /** 滑杆拖动高频回调时合并成一帧一次，避免每个事件都重建 GPU 滤镜。 */
    private void applyLiveFilterThrottled() {
        if (filterApplyPending) return;
        filterApplyPending = true;
        handler.postDelayed(() -> {
            filterApplyPending = false;
            if (!isFinishing() && !isDestroyed()) applyLiveFilter();
        }, 80);
    }

    private void applyLiveFilter() {
        if (filterIndex == 0 || filterStrength <= 0.01f) {
            clearRenderEffect();
            if (filterFrame != null) hideFilterPreview();
            return;
        }
        android.graphics.ColorMatrix cm = Filters.videoPreviewColorMatrix(
                Filters.ALL[filterIndex], filterStrength);
        android.graphics.ColorFilter cf = new android.graphics.ColorMatrixColorFilter(cm);
        if (android.os.Build.VERSION.SDK_INT >= 31) {
            try {
                View surface = playerView.getVideoSurfaceView();
                (surface == null ? playerView : surface).setRenderEffect(
                        android.graphics.RenderEffect.createColorFilterEffect(cf));
                return;
            } catch (Throwable ignored) {
            }
        }
        // 低版本兜底：定格帧预览
        if (filterFrame == null) captureFilterFrame();
        refreshFilterFramePreviewInline(cf);
    }

    private void clearRenderEffect() {
        if (playerView == null) return;
        if (android.os.Build.VERSION.SDK_INT >= 31) {
            try {
                View surface = playerView.getVideoSurfaceView();
                (surface == null ? playerView : surface).setRenderEffect(null);
            } catch (Throwable ignored) {
            }
        }
    }

    private void refreshFilterFramePreviewInline(android.graphics.ColorFilter cf) {
        if (filterPreviewView == null) filterPreviewView = findViewById(R.id.filterPreview);
        if (filterPreviewView == null || filterFrame == null) return;
        filterPreviewView.setColorFilter(cf);
        filterPreviewView.setImageBitmap(filterFrame);
        filterPreviewView.setVisibility(View.VISIBLE);
    }

    // ---------------- 速度底部面板 ----------------

    private void setupSpeedPanel() {
        SeekBar bar = findViewById(R.id.seekSpeed);
        bar.setProgress(speedToProgress(speed));
        ((TextView) findViewById(R.id.tvSpeedValue)).setText(fmtSpeed(speed));
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar sb, int p, boolean fromUser) {
                speed = progressToSpeed(p);
                ((TextView) findViewById(R.id.tvSpeedValue)).setText(fmtSpeed(speed));
            }
            @Override public void onStartTrackingTouch(SeekBar sb) { }
            @Override public void onStopTrackingTouch(SeekBar sb) {
                markEdited();
                refreshToolLabels();
                updateSummary();
                toast("速度 " + fmtSpeed(speed) + "，导出按这个速度成片");
            }
        });
        // 预设胶囊 + 复位（参考稿：0.5x / 1x / 1.5x / 2x，右上角「复位」）
        int[] presetIds = {R.id.btnSpeed05, R.id.btnSpeed1, R.id.btnSpeed15, R.id.btnSpeed2};
        float[] presetVals = {0.5f, 1f, 1.5f, 2f};
        for (int i = 0; i < presetIds.length; i++) {
            final float v = presetVals[i];
            TextView chip = findViewById(presetIds[i]);
            chip.setOnClickListener(c -> {
                speed = v;
                bar.setProgress(speedToProgress(speed));
                ((TextView) findViewById(R.id.tvSpeedValue)).setText(fmtSpeed(speed));
                markEdited();
                refreshToolLabels();
                updateSummary();
            });
        }
        findViewById(R.id.btnSpeedReset).setOnClickListener(v -> {
            speed = 1f;
            bar.setProgress(speedToProgress(1f));
            ((TextView) findViewById(R.id.tvSpeedValue)).setText(fmtSpeed(1f));
            markEdited();
            refreshToolLabels();
            updateSummary();
            toast("速度已复位");
        });

        // 常用速度一键到位
        ((TextView) findViewById(R.id.tvSpeedHint)).setOnClickListener(v -> {
            float[] presets = {0.5f, 1f, 1.5f, 2f, 3f};
            int next = 0;
            for (int i = 0; i < presets.length; i++) {
                if (Math.abs(presets[i] - speed) < 0.01f) next = (i + 1) % presets.length;
            }
            speed = presets[next];
            bar.setProgress(speedToProgress(speed));
            ((TextView) findViewById(R.id.tvSpeedValue)).setText(fmtSpeed(speed));
            markEdited();
            refreshToolLabels();
            updateSummary();
        });
    }

    /** 滑杆 0~375 对应 0.25x ~ 4x，中间取对数刻度，越靠近 1x 越好微调。 */
    private int speedToProgress(float s) {
        return EditorMath.speedToProgress(s);
    }

    private float progressToSpeed(int p) {
        return EditorMath.progressToSpeed(p);
    }

    private String fmtSpeed(float s) {
        return String.format(java.util.Locale.getDefault(), "%.2fx", s);
    }

    private void showSpeedPanel(boolean show) {
        UiAnim.panel(findViewById(R.id.panelSpeed), show);
        schedulePanelSync();
        if (show) {
            ((SeekBar) findViewById(R.id.seekSpeed)).setProgress(speedToProgress(speed));
            ((TextView) findViewById(R.id.tvSpeedValue)).setText(fmtSpeed(speed));
        }
    }

    // ---------------- 时间轴胶片条（可拖拽重排） ----------------

    private void setupTimeline() {
        timelineRow.setOnDragListener((v, event) -> {
            if (event.getAction() == android.view.DragEvent.ACTION_DROP) {
                Object local = event.getLocalState();
                if (local instanceof Integer) {
                    int to = indexAtX(event.getX());
                    moveClip((Integer) local, to);
                }
                return true;
            }
            return true;
        });
    }

    /** 拖到哪就插到哪：按每个胶片卡片的中线判断。 */
    private int indexAtX(float x) {
        if (timelineRow.getChildCount() == 0) return 0;
        for (int i = 0; i < timelineRow.getChildCount(); i++) {
            View child = timelineRow.getChildAt(i);
            float center = (child.getLeft() + child.getRight()) / 2f;
            if (x < center) return i;
        }
        return timelineRow.getChildCount() - 1;
    }

    /** 把第 from 段移到第 to 位，索引与当前选中段同步纠正。 */
    private boolean moveClip(int from, int to) {
        if (from < 0 || from >= clips.size()) return false;
        if (to < 0) to = 0;
        if (to >= clips.size()) to = clips.size() - 1;
        if (from == to) return false;
        pushUndo();
        Clip c = clips.remove(from);
        clips.add(to, c);
        currentIndex = EditorMath.moveIndex(currentIndex, from, to);
        if (currentIndex < 0) currentIndex = 0;
        if (currentIndex >= clips.size()) currentIndex = clips.size() - 1;
        markEdited();
        buildTimeline();
        updateSummary();
        refreshToolLabels();
        previewCurrentClip();
        toast("已移到第 " + (to + 1) + " 段");
        return true;
    }

    private void buildTimeline() {
        if (timelineRow == null) return;
        timelineRow.removeAllViews();
        for (int i = 0; i < clips.size(); i++) {
            final int index = i;
            Clip c = clips.get(i);

            LinearLayout item = new LinearLayout(this);
            item.setOrientation(LinearLayout.VERTICAL);
            item.setGravity(Gravity.CENTER);
            item.setPadding(dp(4), dp(4), dp(4), dp(4));
            item.setBackgroundResource(i == currentIndex ? R.drawable.bg_pill_accent : R.drawable.bg_chip);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(62), dp(74));
            lp.rightMargin = dp(6);
            item.setLayoutParams(lp);

            ImageView iv = new ImageView(this);
            iv.setLayoutParams(new LinearLayout.LayoutParams(dp(54), dp(54)));
            iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
            iv.setBackgroundResource(R.drawable.bg_chip);
            iv.setContentDescription("第 " + (i + 1) + " 段");
            loadThumb(iv, c);

            TextView tv = new TextView(this);
            tv.setText((i + 1) + "·" + fmtShort(c.lengthMs()));
            tv.setTextSize(10);
            tv.setGravity(Gravity.CENTER);
            tv.setTextColor(getColor(R.color.text_primary));
            tv.setPadding(0, dp(2), 0, 0);

            item.addView(iv);
            item.addView(tv);

            item.setOnClickListener(v -> {
                if (currentIndex == index) return;
                currentIndex = index;
                markEdited();
                buildTimeline();
                bindCurrentClip();
                updateSummary();
            });
            item.setOnLongClickListener(v -> {
                ClipData data = ClipData.newPlainText("clip", String.valueOf(index));
                v.startDragAndDrop(data, new View.DragShadowBuilder(v), index, 0);
                toast("拖动到目标位置即可重排");
                return true;
            });
            timelineRow.addView(item);
        }
    }

    private String fmtShort(long ms) {
        long s = Math.max(0, ms / 1000);
        return s >= 60 ? (s / 60) + ":" + String.format("%02d", s % 60) : s + "s";
    }

    private static final java.util.concurrent.ExecutorService THUMB_EXEC =
            java.util.concurrent.Executors.newSingleThreadExecutor(r -> {
                Thread t = new Thread(r, "fc-thumb");
                t.setPriority(Thread.MIN_PRIORITY);
                return t;
            });

    private void loadThumb(ImageView iv, Clip c) {
        String key = c.uri + "#" + c.startMs;
        Bitmap cached = thumbCache.get(key);
        if (cached != null) {
            iv.setImageBitmap(cached);
            return;
        }
        iv.setTag(key);
        THUMB_EXEC.execute(() -> {
            Bitmap bm = frameAt(c.uri, c.startMs);
            if (bm == null) return;
            final Bitmap out = bm;
            runOnUiThread(() -> {
                if (!key.equals(iv.getTag())) {
                    if (!out.isRecycled()) out.recycle();
                    return;
                }
                thumbCache.put(key, out);
                iv.setImageBitmap(out);
            });
        });
    }

    private Bitmap frameAt(Uri uri, long ms) {
        MediaMetadataRetriever r = new MediaMetadataRetriever();
        try {
            r.setDataSource(this, uri);
            if (android.os.Build.VERSION.SDK_INT >= 27) {
                return r.getScaledFrameAtTime(ms * 1000,
                        MediaMetadataRetriever.OPTION_CLOSEST_SYNC, 240, 240);
            }
            Bitmap full = r.getFrameAtTime(ms * 1000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC);
            if (full == null) return null;
            int w = full.getWidth(), h = full.getHeight();
            float scale = 240f / Math.max(w, h);
            if (scale >= 1f) return full;
            Bitmap small = Bitmap.createScaledBitmap(full,
                    Math.max(2, (int) (w * scale)), Math.max(2, (int) (h * scale)), true);
            if (small != full) full.recycle();
            return small;
        } catch (Exception e) {
            return null;
        } finally {
            try {
                r.release();
            } catch (Exception ignored) {
            }
        }
    }

    // ---------------- 撤销 / 重做 ----------------

    private EditorState snapshot() {
        EditorState st = new EditorState();
        for (Clip c : clips) st.clips.add(c.copy());
        st.currentIndex = currentIndex;
        st.rotation = rotation;
        st.zoom = zoom;
        st.filterIndex = filterIndex;
        st.filterStrength = filterStrength;
        st.speed = speed;
        st.speedCurve = speedCurve;
        st.mute = mute;
        st.volume = volume;
        st.fadeAudio = fadeAudio;
        st.aspect = aspect;
        st.targetHeight = targetHeight;
        st.exportBitrateMbps = exportBitrateMbps;
        st.exportHevc = exportHevc;
        st.compatExport = compatExport;
        st.voiceUri = voiceUri == null ? null : voiceUri.toString();
        st.voiceVolume = voiceVolume;
        st.fadeInMs = fadeInMs;
        st.fadeOutMs = fadeOutMs;
        st.motion = motion;
        st.fadeTransition = fadeTransition;
        st.clipTransitionMs = clipTransitionMs;
        st.transType = transType;
        st.kfKeys = kfKeys == null ? null : deepCopy(kfKeys);
        st.keyEasing = keyEasing;
        st.tint = tint;
        st.brightness = brightness;
        st.contrast = contrast;
        st.saturation = saturation;
        st.hueDeg = hueDeg;
        st.warmth = warmth;
        st.mirrorH = mirrorH;
        st.mirrorV = mirrorV;
        st.watermarkText = watermarkText;
        st.watermarkLogo = watermarkLogo;
        st.wmX = wmX;
        st.wmY = wmY;
        st.wmScale = wmScale;
        st.wmAlpha = wmAlpha;
        st.wmRotation = wmRotation;
        st.wmColor = wmColor;
        st.musicUri = musicUri == null ? null : musicUri.toString();
        st.musicVolume = musicVolume;
        st.cues = new ArrayList<>(subtitleCues);
        st.subX = subX;
        st.subY = subY;
        st.subSize = subSize;
        st.subStroke = subStroke;
        st.subBg = subBg;
        st.subAnim = subAnim;
        st.titleText = titleText;
        st.titleMs = titleMs;
        st.subColor = subColor;
        return st;
    }

    private void pushUndo() {
        undoStack.add(snapshot());
        while (undoStack.size() > UNDO_LIMIT) undoStack.remove(0);
        redoStack.clear();
    }

    private void undo() {
        if (undoStack.isEmpty()) {
            toast("没有可撤销的操作");
            return;
        }
        redoStack.add(snapshot());
        applyState(undoStack.remove(undoStack.size() - 1));
        toast("已撤销");
    }

    private void redo() {
        if (redoStack.isEmpty()) {
            toast("没有可重做的操作");
            return;
        }
        undoStack.add(snapshot());
        applyState(redoStack.remove(redoStack.size() - 1));
        toast("已重做");
    }

    private void applyState(EditorState st) {
        clips.clear();
        for (Clip c : st.clips) clips.add(c.copy());
        if (clips.isEmpty()) return;
        currentIndex = Math.max(0, Math.min(st.currentIndex, clips.size() - 1));
        rotation = st.rotation;
        zoom = st.zoom;
        filterIndex = st.filterIndex;
        filterStrength = st.filterStrength;
        speed = st.speed;
        speedCurve = st.speedCurve;
        mute = st.mute;
        volume = st.volume;
        fadeAudio = st.fadeAudio;
        aspect = st.aspect;
        targetHeight = st.targetHeight;
        exportBitrateMbps = st.exportBitrateMbps;
        exportHevc = st.exportHevc;
        compatExport = st.compatExport;
        voiceUri = st.voiceUri == null || st.voiceUri.isEmpty() ? null : Uri.parse(st.voiceUri);
        voiceVolume = st.voiceVolume;
        fadeInMs = st.fadeInMs;
        fadeOutMs = st.fadeOutMs;
        motion = st.motion;
        fadeTransition = st.fadeTransition;
        clipTransitionMs = st.clipTransitionMs;
        transType = st.transType;
        kfKeys = st.kfKeys == null ? null : deepCopy(st.kfKeys);
        keyEasing = st.keyEasing;
        tint = st.tint;
        brightness = st.brightness;
        contrast = st.contrast;
        saturation = st.saturation;
        hueDeg = st.hueDeg;
        warmth = st.warmth;
        mirrorH = st.mirrorH;
        mirrorV = st.mirrorV;
        watermarkText = st.watermarkText;
        watermarkLogo = st.watermarkLogo;
        wmX = st.wmX;
        wmY = st.wmY;
        wmScale = st.wmScale;
        wmAlpha = st.wmAlpha;
        wmRotation = st.wmRotation;
        wmColor = st.wmColor;
        musicUri = st.musicUri == null ? null : Uri.parse(st.musicUri);
        musicVolume = st.musicVolume;
        subtitleCues.clear();
        subtitleCues.addAll(st.cues);
        subX = st.subX;
        subY = st.subY;
        subSize = st.subSize;
        subStroke = st.subStroke;
        subBg = st.subBg;
        subAnim = st.subAnim;
        titleText = st.titleText;
        titleMs = st.titleMs;
        subColor = st.subColor;
        markEdited();
        applyRestoredState();
    }

    /** 把当前字段同步到界面（撤销、读工程、恢复草稿都走这一条）。 */
    private void applyRestoredState() {
        if (clips.isEmpty()) return;
        if (currentIndex >= clips.size()) currentIndex = clips.size() - 1;
        buildTimeline();
        bindCurrentClip();
        applyViewTransform();
        applyLiveFilter();
        styleVideoFilterChips();
        refreshToolLabels();
        updateSummary();
        SeekBar rotBar = findViewById(R.id.seekRotation);
        if (rotBar != null) {
            rotBar.setProgress((int) (rotation + 180));
            ((TextView) findViewById(R.id.tvRotationValue)).setText(Math.round(rotation) + "°");
        }
        SeekBar zoomBar = findViewById(R.id.seekZoom);
        if (zoomBar != null) {
            zoomBar.setProgress((int) (zoom * 100));
            ((TextView) findViewById(R.id.tvZoomValue)).setText(Math.round(zoom * 100) + "%");
        }
        SeekBar sp = findViewById(R.id.seekSpeed);
        if (sp != null) {
            sp.setProgress(speedToProgress(speed));
            ((TextView) findViewById(R.id.tvSpeedValue)).setText(fmtSpeed(speed));
        }
        SeekBar fstr = findViewById(R.id.seekVideoFilterStrength);
        if (fstr != null) {
            fstr.setProgress(Math.round(filterStrength * 100));
            ((TextView) findViewById(R.id.tvVideoFilterStrength))
                    .setText(Math.round(filterStrength * 100) + "%");
        }
    }

    // ---------------- 工程存档 ----------------

    private org.json.JSONObject toJson() {
        try {
            org.json.JSONObject o = new org.json.JSONObject();
            o.put("schemaVersion", SCHEMA_VERSION);
            org.json.JSONArray arr = new org.json.JSONArray();
            for (Clip c : clips) {
                org.json.JSONObject jc = new org.json.JSONObject();
                jc.put("uri", c.uri.toString());
                jc.put("name", c.name == null ? "" : c.name);
                jc.put("durationMs", c.durationMs);
                jc.put("width", c.width);
                jc.put("height", c.height);
                jc.put("startMs", c.startMs);
                jc.put("locked", c.locked);
                jc.put("hidden", c.hidden);
                jc.put("endMs", c.endMs);
                arr.put(jc);
            }
            o.put("clips", arr);
            o.put("currentIndex", currentIndex);
            o.put("rotation", (double) rotation);
            o.put("zoom", (double) zoom);
            o.put("filterIndex", filterIndex);
            o.put("subX", (double) subX);
            o.put("subY", (double) subY);
            o.put("subSize", (double) subSize);
            o.put("subStroke", (double) subStroke);
            o.put("subBg", subBg);
            o.put("subAnim", subAnim);
            o.put("titleText", titleText);
            o.put("titleMs", titleMs);
            o.put("subColor", subColor);
            o.put("filterStrength", (double) filterStrength);
            o.put("speed", (double) speed);
            o.put("speedCurve", speedCurve);
            o.put("mute", mute);
            o.put("volume", (double) volume);
            o.put("fadeAudio", fadeAudio);
            o.put("aspect", (double) aspect);
            o.put("targetHeight", targetHeight);
            o.put("mirrorH", mirrorH);
            o.put("mirrorV", mirrorV);
            o.put("voiceUri", voiceUri == null ? "" : voiceUri.toString());
            o.put("voiceVolume", (double) voiceVolume);
            o.put("fadeInMs", fadeInMs);
            o.put("fadeOutMs", fadeOutMs);
            o.put("motion", motion);
            o.put("fadeTransition", fadeTransition);
            o.put("clipTransitionMs", clipTransitionMs);
            o.put("transType", transType);
            o.put("kfKeys", kfToString(kfKeys));
            o.put("keyEasing", keyEasing);
            o.put("tint", (double) tint);
            o.put("brightness", (double) brightness);
            o.put("contrast", (double) contrast);
            o.put("saturation", (double) saturation);
            o.put("hueDeg", (double) hueDeg);
            o.put("warmth", (double) warmth);
            if (watermarkText != null) o.put("watermarkText", watermarkText);
            if (watermarkLogo != null) o.put("watermarkLogo", watermarkLogo.toString());
            o.put("wmX", (double) wmX);
            o.put("wmY", (double) wmY);
            o.put("wmScale", (double) wmScale);
            o.put("wmAlpha", (double) wmAlpha);
            o.put("wmRotation", (double) wmRotation);
            o.put("wmColor", wmColor);
            if (musicUri != null) o.put("musicUri", musicUri.toString());
            o.put("musicVolume", (double) musicVolume);
            org.json.JSONArray cues = new org.json.JSONArray();
            for (TimedTextOverlay.Cue cue : subtitleCues) {
                org.json.JSONObject j = new org.json.JSONObject();
                j.put("start", cue.startMs);
                j.put("end", cue.endMs);
                j.put("text", cue.text == null ? "" : cue.text);
                cues.put(j);
            }
            o.put("cues", cues);
            return o;
        } catch (Exception e) {
            return null;
        }
    }

    private boolean fromJson(org.json.JSONObject o) {
        if (o == null) return false;
        try {
            org.json.JSONArray arr = o.optJSONArray("clips");
            if (arr == null || arr.length() == 0) return false;
            clips.clear();
            for (int i = 0; i < arr.length(); i++) {
                org.json.JSONObject jc = arr.getJSONObject(i);
                Clip c = new Clip();
                c.uri = Uri.parse(jc.getString("uri"));
                c.name = jc.optString("name", "片段 " + (i + 1));
                c.durationMs = jc.optLong("durationMs", 0);
                c.width = jc.optInt("width", 0);
                c.height = jc.optInt("height", 0);
                c.startMs = jc.optLong("startMs", 0);
                c.locked = jc.optBoolean("locked", false);
                c.hidden = jc.optBoolean("hidden", false);
                c.endMs = jc.optLong("endMs", c.durationMs);
                clips.add(c);
            }
            currentIndex = o.optInt("currentIndex", 0);
            rotation = (float) o.optDouble("rotation", 0);
            zoom = Math.max(0.2f, Math.min(8f, (float) o.optDouble("zoom", 1)));
            filterIndex = o.optInt("filterIndex", 0);
            subX = (float) o.optDouble("subX", 0);
            subY = (float) o.optDouble("subY", -0.72);
            subSize = (float) o.optDouble("subSize", 72);
            subStroke = (float) o.optDouble("subStroke", 2.5);
            subBg = o.optInt("subBg", 0);
            subAnim = o.optInt("subAnim", 0);
            titleText = o.optString("titleText", "");
            titleMs = o.optLong("titleMs", 0);
            subColor = o.optInt("subColor", 0xFFFFFFFF);
            filterStrength = (float) o.optDouble("filterStrength", 1);
            speed = (float) o.optDouble("speed", 1);
            speedCurve = o.optInt("speedCurve", 0);
            mute = o.optBoolean("mute", false);
            volume = (float) o.optDouble("volume", 1);
            fadeAudio = o.optBoolean("fadeAudio", false);
            aspect = (float) o.optDouble("aspect", 0);
            targetHeight = o.optInt("targetHeight", 0);
            mirrorH = o.optBoolean("mirrorH", false);
            mirrorV = o.optBoolean("mirrorV", false);
            String voiceStr = o.optString("voiceUri", "");
            voiceUri = voiceStr.isEmpty() ? null : Uri.parse(voiceStr);
            voiceVolume = (float) o.optDouble("voiceVolume", 0.7);
            fadeInMs = o.optInt("fadeInMs", 600);
            fadeOutMs = o.optInt("fadeOutMs", 600);
            motion = o.optInt("motion", 0);
            fadeTransition = o.optBoolean("fadeTransition", false);
            clipTransitionMs = o.optInt("clipTransitionMs", 0);
            transType = o.optInt("transType", 0);
            kfKeys = kfFromString(o.optString("kfKeys", ""));
            keyEasing = o.optInt("keyEasing", 0);
            tint = (float) o.optDouble("tint", 0);
            brightness = (float) o.optDouble("brightness", 0);
            contrast = (float) o.optDouble("contrast", 1);
            saturation = (float) o.optDouble("saturation", 1);
            hueDeg = (float) o.optDouble("hueDeg", 0);
            warmth = (float) o.optDouble("warmth", 0);
            watermarkText = o.has("watermarkText") ? o.optString("watermarkText", null) : null;
            watermarkLogo = o.has("watermarkLogo") ? Uri.parse(o.getString("watermarkLogo")) : null;
            wmX = (float) o.optDouble("wmX", 0.62);
            wmY = (float) o.optDouble("wmY", -0.72);
            wmScale = (float) o.optDouble("wmScale", 0.5);
            wmAlpha = (float) o.optDouble("wmAlpha", 0.9);
            wmRotation = (float) o.optDouble("wmRotation", 0);
            wmColor = o.optInt("wmColor", 0xFFFFFFFF);
            musicUri = o.has("musicUri") ? Uri.parse(o.getString("musicUri")) : null;
            musicVolume = (float) o.optDouble("musicVolume", 0.6);
            subtitleCues.clear();
            org.json.JSONArray cues = o.optJSONArray("cues");
            if (cues != null) {
                for (int i = 0; i < cues.length(); i++) {
                    org.json.JSONObject j = cues.getJSONObject(i);
                    subtitleCues.add(new TimedTextOverlay.Cue(
                            j.optLong("start", 0), j.optLong("end", 0), j.optString("text", "")));
                }
            }
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private void openProjectMenu() {
        new AlertDialog.Builder(this)
                .setTitle("工程")
                .setItems(new String[]{"保存到工程库（首页可继续编辑）",
                        "导出工程文件（.fcproj，发给别人/换机恢复）",
                        "从工程文件导入",
                        "版本历史（回滚到之前保存的版本）"}, (d, which) -> {
                    if (which == 0) saveProjectAs();
                    else if (which == 1) exportProjectFile();
                    else if (which == 2) projectImporter.launch(new String[]{"application/json", "text/plain", "*/*"});
                    else openVersionHistory();
                })
                .setNegativeButton("关闭", null)
                .show();
    }

    /** 导出 .fcproj：纯 JSON 参数（不含素材本身），方便跨设备/发给同事继续编辑。 */
    private void exportProjectFile() {
        org.json.JSONObject data = toJson();
        if (data == null) {
            toast("导出失败：参数序列化出错");
            return;
        }
        try {
            File dir = new File(getCacheDir(), "projects");
            if (!dir.exists() && !dir.mkdirs()) throw new java.io.IOException("建目录失败");
            String safe = (projectTitle == null || projectTitle.isEmpty()
                    ? "无联网本地视频编辑器工程" : projectTitle).replaceAll("[\\\\/:*?\"<>|]", "_");
            File f = new File(dir, safe + ".fcproj");
            try (java.io.FileOutputStream fo = new java.io.FileOutputStream(f)) {
                fo.write(data.toString(2).getBytes("UTF-8"));
            }
            Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", f);
            Intent share = new Intent(Intent.ACTION_SEND);
            share.setType("application/json");
            share.putExtra(Intent.EXTRA_STREAM, uri);
            share.putExtra(Intent.EXTRA_SUBJECT, "无联网本地视频编辑器工程：" + projectTitle);
            share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(share, "分享工程文件"));
        } catch (Exception e) {
            toast("导出工程失败：" + e.getMessage());
        }
    }

    private void saveProjectAs() {
        EditText et = new EditText(this);
        et.setText(projectTitle);
        et.setSelection(et.getText().length());
        et.setHint("工程名，例如：旅行 vlog 第 1 集");
        new AlertDialog.Builder(this)
                .setTitle("保存工程")
                .setMessage("存的是参数，不是素材：下次打开会自动重新读取这些视频文件。")
                .setView(et)
                .setPositiveButton("保存", (d, w) -> {
                    String name = et.getText().toString().trim();
                    if (name.isEmpty()) name = "未命名工程";
                    org.json.JSONObject data = toJson();
                    if (data == null) {
                        toast("保存失败：参数序列化出错");
                        return;
                    }
                    String id = ProjectStore.save(this, projectId, data, name,
                            totalLengthMs(), clips.size());
                    if (id == null) {
                        toast("保存失败，请重试");
                        return;
                    }
                    projectId = id;
                    projectTitle = name;
                    ProjectStore.clearDraft(this);
                    saveProjectThumb(id, true);
                    toast("工程已保存：" + name + "（回首页「我的工程」可继续编辑）");
                })
                .setNegativeButton("取消", null)
                .show();
    }

    /** 工程封面：抓当前段的一张帧存成小图，首页列表一眼能认出来。 */
    private void saveProjectThumb(String id, boolean force) {
        if (id == null) return;
        if (!force && draftThumbPending) return;
        draftThumbPending = true;
        final String thumbId = id;
        Work.run(() -> {
            try {
                Clip c = clips.get(Math.min(currentIndex, clips.size() - 1));
                Bitmap frame = frameAt(c.uri, c.startMs + Math.min(500, Math.max(0, c.lengthMs() / 3)));
                if (frame == null) return;
                int w = Math.min(240, frame.getWidth());
                int h = Math.max(1, (int) (frame.getHeight() * w / (float) frame.getWidth()));
                Bitmap small = Bitmap.createScaledBitmap(frame, w, h, true);
                if (small != frame) frame.recycle();
                ProjectStore.saveThumb(this, thumbId, small);
                small.recycle();
            } catch (Throwable ignored) {
            } finally {
                draftThumbPending = false;
            }
        });
    }

    private void autoSave() {
        if (clips.isEmpty()) return;
        // 导出中也要存：以前 exporting 直接 return，切后台杀进程就白剪了
        org.json.JSONObject data = toJson();
        if (data == null) return;
        saveProjectThumb(projectId != null ? projectId : "draft", false);
        if (projectId != null) {
            // 已存为工程就以工程为准，不再写 draft，避免两份数据越走越远
            ProjectStore.save(this, projectId, data, projectTitle, totalLengthMs(), clips.size());
        } else {
            ProjectStore.saveDraft(this, data, projectTitle, totalLengthMs(), clips.size());
        }
        draftDirty = false;
    }

    /** 编辑动作后 1.2 秒落盘：以前只靠 10 秒定时器，窗口内被杀就丢改动。 */
    private void markEdited() {
        transReady = false;
        transFiles = null;
        edited = true;
        draftDirty = true;
        handler.removeCallbacks(draftQuick);
        handler.postDelayed(draftQuick, 1200);
    }

    private boolean draftDirty = false;

    private final Runnable draftQuick = new Runnable() {
        @Override
        public void run() {
            if (draftDirty) autoSave();
        }
    };

    /** 每 10 秒自动存一次草稿，崩溃/被杀也能找回。 */
    private final Runnable draftTick = new Runnable() {
        @Override
        public void run() {
            try {
                if (edited) autoSave();
            } catch (Exception ignored) {
            }
            handler.postDelayed(this, 10000);
        }
    };

    private void maybeOfferDraft() {
        if (fromProject) return;
        int n = ProjectStore.draftClipCount(this);
        if (n <= 0) return;
        org.json.JSONObject data = ProjectStore.loadDraftData(this);
        if (data == null) return;
        new AlertDialog.Builder(this)
                .setTitle("继续上次的编辑？")
                .setMessage("检测到一份自动保存的草稿（" + n + " 段）。\n继续会载入上次的片段和参数。")
                .setPositiveButton("继续草稿", (d, w) -> {
                    if (fromJson(data)) {
                        markEdited();
                        applyRestoredState();
                        loadDurations();
                        toast("已恢复草稿");
                    } else {
                        toast("草稿读不出来，已忽略");
                    }
                })
                .setNegativeButton("丢弃草稿", (d, w) -> ProjectStore.clearDraft(this))
                .show();
    }

    private void afterChange() {
        markEdited();
        refreshToolLabels();
        updateSummary();
        applyLivePreviewEffects();
    }

    /**
     * 旋转/缩放/镜像的实时预览：**只改播放视图的变换，不碰播放器管线**。
     * 之前每个滑杆回调都调 setVideoEffects(...)，会重建视频效果管线，
     * 拖动一次重建几十次 → 视频直接播不动。视图变换是纯渲染层，零成本。
     */
    private void applyLivePreviewEffects() {
        applyViewTransform();
    }

    private void applyViewTransform() {
        if (playerView == null) return;
        // 只改视频画面，播放控件（进度条/按钮）保持原大小，否则一缩放进度条也跟着变形
        View target = playerView.getVideoSurfaceView();
        if (target == null) target = playerView;
        playerView.setScaleX(1f);
        playerView.setScaleY(1f);
        playerView.setRotation(0f);
        target.setRotation(rotation);
        float baseScale = 1f;
        if (rotation != 0f) {
            float rest = Math.abs(rotation % 90f);
            if (rest == 0f) {
                // 90/270 会交换宽高：按容器比例缩小，保证整幅画面都在屏幕里
                float w = ((View) playerView.getParent()).getWidth();
                float h = ((View) playerView.getParent()).getHeight();
                if (w > 0 && h > 0) baseScale = Math.min(w, h) / Math.max(w, h);
            } else {
                double rad = Math.toRadians(rest);
                double cover = Math.abs(Math.sin(rad)) + Math.abs(Math.cos(rad));
                baseScale = (float) Math.min(1.18, Math.max(1.0, cover));
            }
        }
        float safeZoom = Math.max(0.2f, Math.min(8f, zoom));
        target.setScaleX((mirrorH ? -safeZoom : safeZoom) * baseScale);
        target.setScaleY((mirrorV ? -safeZoom : safeZoom) * baseScale);
    }

    // ---------------- 滤镜实时预览：抓一帧 + 颜色矩阵叠加 ----------------

    private android.graphics.Bitmap filterFrame;
    private ImageView filterPreviewView;

    /** 抓当前位置的一帧作为滤镜预览底图；抓不到就静默跳过，绝不阻塞播放。 */
    private void captureFilterFrame() {
        if (clips.isEmpty()) return;
        final Clip c = clips.get(currentIndex);
        final long posMs;
        try {
            posMs = Math.max(c.startMs, player == null ? c.startMs : player.getCurrentPosition());
        } catch (Exception e) {
            return;
        }
        final android.net.Uri uri = c.uri;
        Work.run(() -> {
            android.graphics.Bitmap frame = null;
            android.media.MediaMetadataRetriever mmr = new android.media.MediaMetadataRetriever();
            try {
                mmr.setDataSource(VideoEditorActivity.this, uri);
                frame = mmr.getFrameAtTime(posMs * 1000L,
                        android.media.MediaMetadataRetriever.OPTION_CLOSEST_SYNC);
                if (frame == null) {
                    frame = mmr.getFrameAtTime(0,
                            android.media.MediaMetadataRetriever.OPTION_CLOSEST_SYNC);
                }
            } catch (Throwable ignored) {
            } finally {
                try { mmr.release(); } catch (Exception ignored) { }
            }
            final android.graphics.Bitmap f = frame;
            runOnUiThread(() -> {
                if (isFinishing()) return;
                filterFrame = f;
                if (f != null) refreshFilterFramePreview();
            });
        });
    }

    /** 拖动强度 / 换预设：即时重绘预览帧，纯 Canvas 颜色矩阵，不影响播放。 */
    private void refreshFilterFramePreview() {
        if (filterPreviewView == null) filterPreviewView = findViewById(R.id.filterPreview);
        if (filterPreviewView == null) return;
        if (filterFrame == null) {
            filterPreviewView.setVisibility(View.GONE);
            return;
        }
        android.graphics.ColorMatrix cm = Filters.videoPreviewColorMatrix(
                Filters.ALL[filterIndex], filterStrength);
        filterPreviewView.setColorFilter(new android.graphics.ColorMatrixColorFilter(cm));
        filterPreviewView.setImageBitmap(filterFrame);
        filterPreviewView.setVisibility(View.VISIBLE);
    }

    private void hideFilterPreview() {
        if (filterPreviewView == null) filterPreviewView = findViewById(R.id.filterPreview);
        if (filterPreviewView != null) filterPreviewView.setVisibility(View.GONE);
    }

    private void confirmExit() {
        if (!edited || exportedOnce) {
            finish();
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle("还没导出")
                .setMessage("这条剪辑还没有导出成片，确定要离开吗？")
                .setPositiveButton("导出后离开", (d, w) -> {
                    leaveAfterExport = true;
                    exportStage = 0;
                    runExport(false);
                })
                .setNegativeButton("直接离开", (d, w) -> finish())
                .setNeutralButton("继续编辑", null)
                .show();
    }

    @Override
    public void onBackPressed() {
        confirmExit();
    }

    private interface ChoiceCallback {
        void onChoice(int which);
    }

    private void choose(String title, String[] items, int checked, ChoiceCallback cb) {
        if (checked < 0 || checked >= items.length) checked = 0;
        SheetUi.list(this, title, items, checked, cb::onChoice).show();
    }

    // ---------------- 水印 ----------------

    /** 水印在预览画布上直接拖动：换算成 OverlaySettings 的帧锚点 (-1~1)。 */
    private void startWatermarkDrag() {
        if (watermarkText == null && watermarkLogo == null) {
            toast("先加一个水印再拖");
            return;
        }
        android.widget.FrameLayout box = findViewById(R.id.previewBox);
        if (box == null) return;
        showAnchorHandle(box, wmX, wmY, (x, y) -> {
            wmX = x;
            wmY = y;
            markEdited();
            refreshToolLabels();
        });
        toast("拖动绿点调整水印位置，松手即生效");
    }

    private static float clampAnchor(float v) {
        return Math.max(-0.95f, Math.min(0.95f, v));
    }

    private void openWatermarkDialog() {
        new AlertDialog.Builder(this)
                .setTitle("视频水印")
                .setItems(new String[]{"添加文字水印", "用一张图片做水印",
                                "拖动到任意位置（预览上直接拖）", "位置（九宫格）",
                                "大小", "颜色", "透明度", "旋转角度", "清除水印"},
                        (d, which) -> {
                            switch (which) {
                                case 0: askWatermarkText(); break;
                                case 1: logoPicker.launch(new String[]{"image/*"}); break;
                                case 2: startWatermarkDrag(); break;
                                case 3: chooseWatermarkPosition(); break;
                                case 4: chooseWatermarkSize(); break;
                                case 5: chooseWatermarkColor(); break;
                                case 6: chooseWatermarkAlpha(); break;
                                case 7: chooseWatermarkRotation(); break;
                                default:
                                    watermarkText = null;
                                    watermarkLogo = null;
                                    afterChange();
                                    toast("已清除水印");
                                    break;
                            }
                        })
                .setNegativeButton("关闭", null)
                .show();
    }

    private void askWatermarkText() {
        android.widget.EditText input = new android.widget.EditText(this);
        input.setHint("水印文字，如 @无联网本地视频编辑器");
        input.setTextColor(0xFFFFFFFF);
        input.setHintTextColor(0x88FFFFFF);
        android.widget.FrameLayout wrap = new android.widget.FrameLayout(this);
        int pad = dp(16);
        wrap.setPadding(pad, dp(8), pad, 0);
        wrap.addView(input);
        new AlertDialog.Builder(this)
                .setTitle("文字水印")
                .setView(wrap)
                .setNegativeButton("取消", null)
                .setPositiveButton("确定", (d, w) -> {
                    String txt = input.getText().toString().trim();
                    if (txt.isEmpty()) {
                        toast("水印文字不能为空");
                        return;
                    }
                    watermarkText = txt;
                    watermarkLogo = null;
                    afterChange();
                    toast("文字水印已设置");
                })
                .show();
    }

    private void chooseWatermarkSize() {
        String[] items = {"很小", "小", "中", "大", "很大"};
        float[] scales = {0.22f, 0.35f, 0.5f, 0.7f, 1.0f};
        new AlertDialog.Builder(this)
                .setTitle("水印大小")
                .setItems(items, (d, which) -> {
                    wmScale = scales[which];
                    afterChange();
                    toast("水印大小：" + items[which]);
                })
                .setNegativeButton("关闭", null)
                .show();
    }

    private void chooseWatermarkColor() {
        String[] items = {"白色", "黑色", "黄色", "绿色", "红色", "蓝色"};
        int[] colors = {0xFFFFFFFF, 0xFF111111, getColor(R.color.warn), getColor(R.color.accent), 0xFFFF5A5A, 0xFF4D9BFF};
        new AlertDialog.Builder(this)
                .setTitle("水印颜色")
                .setItems(items, (d, which) -> {
                    wmColor = colors[which];
                    afterChange();
                    toast("水印颜色：" + items[which]);
                })
                .setNegativeButton("关闭", null)
                .show();
    }

    private void chooseWatermarkAlpha() {
        String[] items = {"20%", "40%", "60%", "80%", "100%（不透明）"};
        float[] alphas = {0.2f, 0.4f, 0.6f, 0.8f, 1f};
        new AlertDialog.Builder(this)
                .setTitle("水印透明度")
                .setItems(items, (d, which) -> {
                    wmAlpha = alphas[which];
                    afterChange();
                    toast("水印透明度：" + items[which]);
                })
                .setNegativeButton("关闭", null)
                .show();
    }

    private void chooseWatermarkRotation() {
        String[] items = {"0°", "15°", "30°", "-15°", "-30°"};
        float[] degrees = {0f, 15f, 30f, -15f, -30f};
        new AlertDialog.Builder(this)
                .setTitle("水印旋转")
                .setItems(items, (d, which) -> {
                    wmRotation = degrees[which];
                    afterChange();
                    toast("水印旋转：" + items[which]);
                })
                .setNegativeButton("关闭", null)
                .show();
    }

    private void chooseWatermarkPosition() {
        String[] items = {"左上角", "上边居中", "右上角", "左侧居中", "正中", "右侧居中",
                "左下角", "下边居中", "右下角"};
        float[][] anchors = {
                {-0.72f, 0.72f}, {0f, 0.72f}, {0.72f, 0.72f},
                {-0.72f, 0f}, {0f, 0f}, {0.72f, 0f},
                {-0.72f, -0.72f}, {0f, -0.72f}, {0.72f, -0.72f}
        };
        new AlertDialog.Builder(this)
                .setTitle("水印位置")
                .setItems(items, (d, which) -> {
                    wmX = anchors[which][0];
                    wmY = anchors[which][1];
                    afterChange();
                    toast("水印位置：" + items[which]);
                })
                .setNegativeButton("关闭", null)
                .show();
    }

    private OverlaySettings watermarkSettings() {
        return new OverlaySettings.Builder()
                .setOverlayFrameAnchor(wmX, wmY)
                .setScale(wmScale, wmScale)
                .setAlphaScale(wmAlpha)
                .setRotationDegrees(wmRotation)
                .build();
    }

    /** 文字水印按所选颜色渲染，图片水印直接跟随设置。 */
    private SpannableString watermarkSpannable(String text) {
        SpannableString sp = new SpannableString(text);
        sp.setSpan(new android.text.style.ForegroundColorSpan(wmColor), 0, sp.length(),
                android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        return sp;
    }

    // ---------------- 媒体信息 ----------------

    private void showExportLog() {
        java.util.List<ExportLog.Entry> list = ExportLog.load(this);
        if (list.isEmpty()) {
            toast("还没有导出记录");
            return;
        }
        StringBuilder sb = new StringBuilder();
        sb.append(ExportLog.summary(this)).append("\n\n");
        int n = Math.min(list.size(), 8);
        for (int i = 0; i < n; i++) sb.append(list.get(i).line()).append('\n');
        String diag = ExportDiag.dump();
        if (!diag.isEmpty()) {
            sb.append("\n底层诊断：\n").append(diag);
        }
        new AlertDialog.Builder(this)
                .setTitle("最近导出（诊断用）")
                .setMessage(sb.toString().trim())
                .setPositiveButton("关闭", null)
                .setNeutralButton("导出文件", (d, w) -> shareExportLog())
                .setNegativeButton("清空", (d, w) -> {
                    try {
                        new File(getFilesDir(), "export_log.json").delete();
                        toast("已清空导出记录");
                    } catch (Exception ignored) {
                    }
                })
                .show();
    }

    private void showMediaInfo() {
        Clip c = clips.get(currentIndex);
        MediaMetadataRetriever r = new MediaMetadataRetriever();
        StringBuilder sb = new StringBuilder();
        try {
            r.setDataSource(this, c.uri);
            sb.append("片段：第 ").append(currentIndex + 1).append(" / ").append(clips.size()).append(" 段\n");
            sb.append("分辨率：").append(nz(r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)))
                    .append(" × ").append(nz(r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT))).append("\n");
            sb.append("时长：").append(fmt(c.durationMs)).append("（已选 ").append(fmt(c.lengthMs())).append("）\n");
            sb.append("码率：").append(nz(r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_BITRATE))).append(" bps\n");
            sb.append("帧率：").append(nz(r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_CAPTURE_FRAMERATE))).append(" fps\n");
            sb.append("旋转：").append(nz(r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION))).append("°\n");
            sb.append("拍摄时间：").append(nz(r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DATE))).append("\n");
            sb.append("合计时长：").append(fmt(totalLengthMs())).append("\n");
            sb.append("\n导出目标：").append(targetHeight == 0 ? "原尺寸" : targetHeight + "p");
        } catch (Exception e) {
            sb.append("读取失败：").append(e.getMessage());
        } finally {
            try {
                r.release();
            } catch (Exception ignored) {
            }
        }
        new AlertDialog.Builder(this)
                .setTitle("视频信息")
                .setMessage(sb.toString())
                .setPositiveButton("知道了", null)
                .show();
    }

    private String nz(String v) {
        return v == null ? "—" : v;
    }

    // ---------------- 音量 ----------------

    private void openVolumeDialog() {
        new AlertDialog.Builder(this)
                .setTitle("音量与淡化")
                .setItems(new String[]{"音量 200%", "音量 150%", "音量 100%（原声）", "音量 50%", "音量 0%（静音）",
                        fadeAudio ? "关闭淡入淡出" : "开启淡入淡出（0.8 秒）"}, (d, which) -> {
                    switch (which) {
                        case 0: volume = 2f; mute = false; break;
                        case 1: volume = 1.5f; mute = false; break;
                        case 2: volume = 1f; mute = false; break;
                        case 3: volume = 0.5f; mute = false; break;
                        case 4: volume = 1f; mute = true; break;
                        default: fadeAudio = !fadeAudio; break;
                    }
                    if (mute) volume = 1f;
                    afterChange();
                    toast("可点「预览效果」听一下");
                })
                .setNegativeButton("关闭", null)
                .show();
    }

    // ---------------- 多段拼接 ----------------

    private void openClipMore() {
        Clip c = clips.get(currentIndex);
        String[] actions = {
                c.hidden ? "取消隐藏这一段" : "隐藏这一段（不参与预览/导出）",
                c.locked ? "解锁这一段" : "锁定这一段",
                "重命名这一段",
                "上移一段",
                "下移一段"};
        new AlertDialog.Builder(this)
                .setTitle("当前段：" + c.name)
                .setItems(actions, (d, which) -> {
                    switch (which) {
                        case 0:
                            c.hidden = !c.hidden;
                            afterChange();
                            previewCurrentClip();
                            toast(c.hidden ? "已隐藏，导出会跳过这一段" : "已恢复显示");
                            break;
                        case 1:
                            c.locked = !c.locked;
                            markEdited();
                            toast(c.locked ? "已锁定（防误触）" : "已解锁");
                            break;
                        case 2:
                            renameClip();
                            break;
                        case 3:
                            moveClip(-1);
                            break;
                        case 4:
                            moveClip(1);
                            break;
                    }
                })
                .setNegativeButton("返回", (d, w) -> openClipManager())
                .show();
    }

    private void renameClip() {
        Clip c = clips.get(currentIndex);
        EditText et = new EditText(this);
        et.setText(c.name);
        et.setSelection(et.getText().length());
        new AlertDialog.Builder(this)
                .setTitle("重命名片段")
                .setView(et)
                .setPositiveButton("确定", (d, w) -> {
                    String name = et.getText().toString().trim();
                    if (name.isEmpty()) name = c.name;
                    pushUndo();
                    c.name = name;
                    markEdited();
                    refreshToolLabels();
                    openClipManager();
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private void moveClip(int dir) {
        int to = currentIndex + dir;
        if (to < 0 || to >= clips.size()) {
            toast(dir < 0 ? "已经是第一段了" : "已经是最后一段了");
            return;
        }
        if (clips.get(currentIndex).locked) {
            toast("这一段已锁定，先解锁再调整顺序");
            return;
        }
        pushUndo();
        java.util.Collections.swap(clips, currentIndex, to);
        currentIndex = to;
        previewCurrentClip();
        bindCurrentClip();
        markEdited();
        toast("顺序已调整");
    }

    private void openClipManager() {
        String[] items = new String[clips.size() + 1];
        for (int i = 0; i < clips.size(); i++) {
            Clip c = clips.get(i);
            items[i] = (i + 1) + ". " + c.name + "（" + fmt(c.lengthMs()) + "）"
                    + (c.hidden ? " 👁隐藏" : "")
                    + (c.locked ? " 🔒" : "")
                    + (i == currentIndex ? "  ←当前" : "");
        }
        items[clips.size()] = "＋ 添加一段视频";

        new AlertDialog.Builder(this)
                .setTitle("多段拼接（导出会自动统一尺寸，不变形）")
                .setItems(items, (d, which) -> {
                    if (which == clips.size()) {
                        clipPicker.launch(new String[]{"video/*", "image/gif", "image/*"});
                    } else {
                        currentIndex = which;
                        previewCurrentClip();
                        bindCurrentClip();
                    }
                })
                .setNeutralButton("更多…", (d, w) -> openClipMore())
                .setNegativeButton("删除当前段", (d, w) -> {
                    if (clips.size() <= 1) {
                        toast("至少保留一段");
                        return;
                    }
                    if (clips.get(currentIndex).locked) {
                        toast("这一段已锁定，先解锁再删");
                        return;
                    }
                    pushUndo();
                    clips.remove(currentIndex);
                    if (currentIndex >= clips.size()) currentIndex = clips.size() - 1;
                    previewCurrentClip();
                    bindCurrentClip();
                })
                .setPositiveButton("关闭", null)
                .show();
    }

    private void onClipPicked(Uri uri) {
        if (uri == null) return;
        if (GifToVideo.isAnimated(this, uri)) {
            toast("动图正在转成短视频…");
            Work.run(this, () -> {
                File f = GifToVideo.convert(this, uri, new File(getCacheDir(), "gif"));
                runOnUiThread(() -> {
                    if (f == null) {
                        toast("这个动图解不开，换一个试试");
                        return;
                    }
                    try {
                        onClipPicked(FileProvider.getUriForFile(this,
                                getPackageName() + ".fileprovider", f));
                    } catch (Throwable t) {
                        ExportDiag.warn("gif_clip", t);
                        toast("动图转视频失败");
                    }
                });
            });
            return;
        }
        String type = null;
        try {
            type = getContentResolver().getType(uri);
        } catch (Throwable ignore) {
        }
        if (type != null && type.startsWith("image/")) {
            toast("图片正在转成 3 秒片段…");
            Work.run(this, () -> {
                File f = GifToVideo.convertStill(this, uri, new File(getCacheDir(), "gif"), 3000);
                runOnUiThread(() -> {
                    if (f == null) {
                        toast("这张图转不成片段，换一张试试");
                        return;
                    }
                    try {
                        onClipPicked(FileProvider.getUriForFile(this,
                                getPackageName() + ".fileprovider", f));
                    } catch (Throwable t) {
                        ExportDiag.warn("image_clip", t);
                        toast("图片转片段失败");
                    }
                });
            });
            return;
        }
        pushUndo();
        Work.run(() -> {
            long d = readDuration(uri);
            int[] size = readSize(uri);
            runOnUiThread(() -> {
                if (d <= 0) {
                    toast("无法读取该视频时长");
                    return;
                }
                Clip c = new Clip();
                c.uri = uri;
                c.name = "片段 " + (clips.size() + 1);
                c.durationMs = d;
                c.width = size[0];
                c.height = size[1];
                c.startMs = 0;
                c.endMs = d;
                clips.add(c);
                currentIndex = clips.size() - 1;
                previewCurrentClip();
                bindCurrentClip();
                toast("已添加，共 " + clips.size() + " 段");
            });
        });
    }

    // ---------------- 封面 ----------------

    private void saveCover() {
        Clip c = clips.get(currentIndex);
        toast("正在提取封面帧…");
        Work.run(() -> {
            Bitmap frame = null;
            MediaMetadataRetriever r = new MediaMetadataRetriever();
            try {
                r.setDataSource(this, c.uri);
                frame = r.getFrameAtTime(c.startMs * 1000L,
                        MediaMetadataRetriever.OPTION_CLOSEST_SYNC);
            } catch (Exception ignored) {
            } finally {
                try {
                    r.release();
                } catch (Exception ignored2) {
                }
            }
            if (frame == null) {
                runOnUiThread(() -> toast("封面提取失败"));
                return;
            }
            try {
                BitmapUtils.saveImage(this, frame, "FC_cover_" + System.currentTimeMillis() + ".jpg");
                runOnUiThread(() -> toast("封面已保存到相册 Pictures/LocalVideo"));
            } catch (Exception e) {
                runOnUiThread(() -> toast("封面保存失败：" + e.getMessage()));
            }
        });
    }

    private void saveFrameGrid() {
        Clip c = clips.get(currentIndex);
        toast("正在抽取 9 帧…");
        Work.run(() -> {
            Bitmap grid = null;
            MediaMetadataRetriever r = new MediaMetadataRetriever();
            try {
                r.setDataSource(this, c.uri);
                long span = Math.max(1, c.lengthMs());
                Bitmap[] frames = new Bitmap[9];
                for (int i = 0; i < 9; i++) {
                    long t = c.startMs + span * i / 9;
                    frames[i] = r.getFrameAtTime(t * 1000L,
                            MediaMetadataRetriever.OPTION_CLOSEST_SYNC);
                    if (frames[i] == null) {
                        frames[i] = r.getFrameAtTime(t * 1000L);
                    }
                }
                Bitmap any = null;
                for (Bitmap b : frames) {
                    if (b != null) {
                        any = b;
                        break;
                    }
                }
                if (any == null) {
                    runOnUiThread(() -> toast("抽帧失败，该视频可能不支持"));
                    return;
                }
                int cellW = Math.min(540, any.getWidth());
                int cellH = cellW * any.getHeight() / Math.max(1, any.getWidth());
                int gap = Math.max(4, cellW / 100);
                int total = cellW * 3 + gap * 4;
                int totalH = cellH * 3 + gap * 4;
                grid = Bitmap.createBitmap(total, totalH, Bitmap.Config.ARGB_8888);
                android.graphics.Canvas cv = new android.graphics.Canvas(grid);
                cv.drawColor(0xFF101317);
                Paint p = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG);
                android.graphics.Rect dst = new android.graphics.Rect();
                for (int i = 0; i < 9; i++) {
                    if (frames[i] == null) continue;
                    int row = i / 3;
                    int col = i % 3;
                    int left = gap + col * (cellW + gap);
                    int top = gap + row * (cellH + gap);
                    dst.set(left, top, left + cellW, top + cellH);
                    cv.drawBitmap(frames[i], null, dst, p);
                }
            } catch (Exception e) {
                runOnUiThread(() -> toast("抽帧失败：" + e.getMessage()));
            } finally {
                try {
                    r.release();
                } catch (Exception ignored) {
                }
            }
            if (grid == null) {
                runOnUiThread(() -> toast("抽帧失败"));
                return;
            }
            try {
                BitmapUtils.saveImage(this, grid, "FC_grid_" + System.currentTimeMillis() + ".jpg");
                runOnUiThread(() -> toast("九宫格已保存到相册 Pictures/LocalVideo"));
            } catch (Exception e) {
                runOnUiThread(() -> toast("保存失败：" + e.getMessage()));
            }
        });
    }

    private int dp(float v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    // ---------------- 导出 ----------------

    private static class ConstantSpeedProvider implements SpeedProvider {
        private final float speed;

        ConstantSpeedProvider(float speed) {
            this.speed = speed;
        }

        @Override
        public float getSpeed(long timeUs) {
            return speed;
        }

        @Override
        public long getNextSpeedChangeTimeUs(long timeUs) {
            return C.TIME_UNSET;
        }
    }

    /** 变速曲线：按时间返回速度倍率，实现渐快/渐慢而不是整段同一速度。 */
    private static class CurveSpeedProvider implements SpeedProvider {
        private final float base;
        private final int curve;
        private final long totalMs;

        CurveSpeedProvider(float base, int curve, long totalMs) {
            this.base = base;
            this.curve = curve;
            this.totalMs = Math.max(1000, totalMs);
        }

        @Override
        public float getSpeed(long timeUs) {
            double t = Math.min(1.0, Math.max(0.0, (timeUs / 1000.0) / totalMs));
            double k;
            switch (curve) {
                case 1:
                    k = 0.45 + 1.1 * t;
                    break;
                case 2:
                    k = 1.55 - 1.1 * t;
                    break;
                default:
                    k = 0.55 + 0.9 * Math.sin(Math.PI * t);
                    break;
            }
            return (float) Math.max(0.2, base * k);
        }

        @Override
        public long getNextSpeedChangeTimeUs(long timeUs) {
            return C.TIME_UNSET;
        }
    }

    private List<Effect> buildVideoEffects(boolean preview, List<AudioProcessor> audioOut) {
        List<Effect> videoEffects = new ArrayList<>();
        int stage = preview ? 0 : exportStage;
        CropOverlayView co = findViewById(R.id.cropOverlay);
        if (co != null && !co.isFullFrame()) {
            float cl = co.getLeftRatio(), ct = co.getTopRatio();
            float cr = co.getRightRatio(), cb = co.getBottomRatio();
            videoEffects.add(new androidx.media3.effect.Crop(
                    -1f + 2f * cl,      // left
                    -1f + 2f * cr,      // right
                    1f - 2f * cb,       // bottom（NDC 向上为正）
                    1f - 2f * ct));      // top
        }
        if (stage <= 3 && !mute && (volume != 1f || fadeAudio)) {
            long effectiveMs = (long) (totalLengthMs() / Math.max(0.1f, speed));
            long fadeMs = fadeAudio ? Math.min(800, Math.max(50, effectiveMs / 4)) : 0;
            audioOut.add(new GainAudioProcessor(volume, fadeMs, fadeMs, effectiveMs));
        }
        if (stage <= 2 && filterIndex != 0) {
            if (filterStrength > 0.01f) {
                videoEffects.add(new ColorMatrixEffect(
                        Filters.videoMatrix(Filters.ALL[filterIndex], filterStrength)));
            }
        }
        if (stage <= 2 && (Math.abs(warmth) > 0.01f || Math.abs(tint) > 0.01f)) {
            videoEffects.add(new WhiteBalanceEffect(warmth, tint));
        }
        if (stage <= 2 && (Math.abs(brightness) > 0.01f || Math.abs(saturation - 1f) > 0.01f
                || Math.abs(hueDeg) > 0.5f)) {
            videoEffects.add(new androidx.media3.effect.HslAdjustment.Builder()
                    .adjustLightness(brightness)
                    .adjustSaturation(saturation - 1f)
                    .adjustHue(hueDeg)
                    .build());
        }
        if (stage <= 2 && Math.abs(contrast - 1f) > 0.01f) {
            videoEffects.add(new androidx.media3.effect.Contrast(contrast));
        }
        if (stage <= 2 && (speed != 1f || speedCurve != 0)) {
            SpeedProvider provider = speedCurve == 0
                    ? new ConstantSpeedProvider(speed)
                    : new CurveSpeedProvider(speed, speedCurve, totalLengthMs());
            Pair<AudioProcessor, Effect> speedEffect =
                    Effects.createExperimentalSpeedChangingEffect(provider);
            audioOut.add(speedEffect.first);
            videoEffects.add(speedEffect.second);
        }
        if (rotation != 0f || zoom != 1f) {
            // Media3 的缩放/旋转只接受正数缩放，负值会直接抛异常 —— 镜像另走 MirrorEffect
            videoEffects.add(new ScaleAndRotateTransformation.Builder()
                    .setScale(zoom, zoom)
                    .setRotationDegrees(rotation)
                    .build());
        }
        if (mirrorH || mirrorV) {
            videoEffects.add(new MirrorEffect(mirrorH, mirrorV));
        }
        long timelineMs = (long) (totalLengthMs() / Math.max(0.1f, speed));
        if (motion != 0) {
            videoEffects.add(new MotionEffect(motion, timelineMs));
        }
        if (fadeTransition) {
            long fadeMs = Math.min(700, Math.max(150, timelineMs / 6));
            videoEffects.add(new FadeEffect(timelineMs, fadeMs));
        }
        // 画幅 + 分辨率合并成一个 Presentation：Media3 每条管线只允许一个画幅效果，
        // 之前"统一分辨率 + 比例 + 目标高度"叠三个，必然导出失败。
        int outH = preview ? 480 : targetHeight;
        float ratio = aspect != 0f ? aspect : unifiedAspectOfClips();
        // 旋转 90/270 度后画面宽高互换：输出比例不跟着换，导出会多出一圈黑边或裁掉内容
        int rot = ((int) Math.round(rotation) % 360 + 360) % 360;
        if (aspect == 0f && ratio > 0f && (rot == 90 || rot == 270)) {
            ratio = 1f / ratio;
        }
        if (outH != 0 && ratio > 0f) {
            int outW = Math.max(2, (int) (outH * ratio));
            videoEffects.add(Presentation.createForWidthAndHeight(outW, outH,
                    aspect != 0f ? Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP
                            : Presentation.LAYOUT_SCALE_TO_FIT));
        } else if (outH != 0) {
            videoEffects.add(Presentation.createForHeight(outH));
        } else if (ratio > 0f) {
            videoEffects.add(Presentation.createForAspectRatio(ratio,
                    Presentation.LAYOUT_SCALE_TO_FIT));
        }
        java.util.List<TextureOverlay> overlays = new ArrayList<>();
        if (stage >= 1) {
            overlays.clear(); // 降级时先摘水印/字幕：叠层是最容易在低端 GPU 上失败的一段
        } else if (watermarkLogo != null) {
            try {
                overlays.add(BitmapOverlay.createStaticBitmapOverlay(this, watermarkLogo, watermarkSettings()));
            } catch (Exception ignored) {
            }
        } else if (watermarkText != null && !watermarkText.isEmpty()) {
            overlays.add(TextOverlay.createStaticTextOverlay(
                    new SpannableString(watermarkText), watermarkSettings()));
        }
        if (stage == 0 && !subtitleCues.isEmpty()) {
            overlays.add(new StyledSubtitleOverlay(subtitleCues,
                    preview ? Math.max(24f, subSize * 0.55f) : subSize,
                    subX, subY, subColor, subStroke, subBg, subAnim));
        }
        if (stage == 0 && titleMs > 0 && titleText != null && !titleText.isEmpty()) {
            java.util.List<TimedTextOverlay.Cue> tc = new java.util.ArrayList<>();
            tc.add(new TimedTextOverlay.Cue(0, titleMs, titleText));
            overlays.add(new StyledSubtitleOverlay(tc,
                    preview ? Math.max(30f, subSize * 0.9f) : subSize * 1.6f,
                    0f, 0f, 0xFFFFFFFF, Math.max(subStroke, 3f), 0x66000000, 1));
        }
        if (!overlays.isEmpty()) {
            videoEffects.add(new OverlayEffect(ImmutableList.copyOf(overlays)));
        }
        return videoEffects;
    }

    /** 预览画面双指放大看细节：1~5 倍，单指平移，双击还原。不改变导出结果。 */
    private void setupPreviewZoom() {
        final View box = (View) playerView.getParent();
        final android.view.ScaleGestureDetector sgd = new android.view.ScaleGestureDetector(this,
                new android.view.ScaleGestureDetector.SimpleOnScaleGestureListener() {
                    @Override
                    public boolean onScale(android.view.ScaleGestureDetector d) {
                        setPreviewZoom(previewZoom * d.getScaleFactor());
                        return true;
                    }
                });
        final android.view.GestureDetector gd = new android.view.GestureDetector(this,
                new android.view.GestureDetector.SimpleOnGestureListener() {
                    @Override
                    public boolean onDoubleTap(android.view.MotionEvent e) {
                        setPreviewZoom(1f);
                        toast("预览已还原");
                        return true;
                    }
                });
        box.setOnTouchListener((v, e) -> {
            sgd.onTouchEvent(e);
            gd.onTouchEvent(e);
            switch (e.getActionMasked()) {
                case android.view.MotionEvent.ACTION_DOWN:
                    previewLastX = e.getX();
                    previewLastY = e.getY();
                    break;
                case android.view.MotionEvent.ACTION_MOVE:
                    if (previewZoom > 1.01f && e.getPointerCount() == 1) {
                        previewPanX += e.getX() - previewLastX;
                        previewPanY += e.getY() - previewLastY;
                        previewLastX = e.getX();
                        previewLastY = e.getY();
                        applyPreviewZoom();
                    }
                    break;
                default:
                    break;
            }
            // 放大状态下吞掉手势，避免画面被拖动的同时还去点播放暂停
            return previewZoom > 1.01f;
        });
    }

    private void setPreviewZoom(float z) {
        previewZoom = Math.max(1f, Math.min(5f, z));
        if (previewZoom <= 1.01f) {
            previewZoom = 1f;
            previewPanX = 0f;
            previewPanY = 0f;
        }
        applyPreviewZoom();
    }

    private void applyPreviewZoom() {
        if (playerView == null) return;
        playerView.setScaleX(previewZoom);
        playerView.setScaleY(previewZoom);
        playerView.setTranslationX(previewPanX);
        playerView.setTranslationY(previewPanY);
        View fp = findViewById(R.id.filterPreview);
        if (fp != null && fp.getVisibility() == View.VISIBLE) {
            fp.setScaleX(previewZoom);
            fp.setScaleY(previewZoom);
            fp.setTranslationX(previewPanX);
            fp.setTranslationY(previewPanY);
        }
    }

    /** 导出编码 / 码率：默认自动，想更清晰或更小可以自己指定。 */
    private void openEncoderDialog() {
        String[] codecs = {"H.264（兼容性最好）", "H.265 / HEVC（同画质更小）",
                compatExport ? "关闭兼容模式（已开启：720p + H.264）"
                        : "兼容模式（老编不动就选这个：720p + H.264 + 自动码率）"};
        new AlertDialog.Builder(this)
                .setTitle("视频编码")
                .setItems(codecs, (d, which) -> {
                    if (which == 2) {
                        compatExport = !compatExport;
                        if (compatExport) {
                            exportHevc = false;
                            exportBitrateMbps = 0;
                        }
                        afterChange();
                        toast(compatExport ? "已开启兼容模式：720p + H.264，牺牲清晰度换稳定"
                                : "已关闭兼容模式");
                        return;
                    }
                    exportHevc = which == 1;
                    afterChange();
                    choose("码率", new String[]{"自动（推荐）", "4 Mbps 省流", "8 Mbps", "12 Mbps", "20 Mbps 高码率"},
                            exportBitrateMbps == 0 ? 0 : (exportBitrateMbps == 4 ? 1 : (exportBitrateMbps == 8 ? 2
                                    : (exportBitrateMbps == 12 ? 3 : 4))), idx -> {
                                exportBitrateMbps = new int[]{0, 4, 8, 12, 20}[idx];
                                afterChange();
                                toast((exportHevc ? "H.265" : "H.264") + " · "
                                        + (exportBitrateMbps == 0 ? "自动码率" : exportBitrateMbps + " Mbps"));
                            });
                })
                .setNegativeButton("取消", null)
                .show();
    }

    /** 字幕面板：手动加段落、从 SRT 导入、导出 SRT。 */
    private void toggleWaveform() {
        com.offlinelocal.videoeditor.WaveformView wave = findViewById(R.id.waveform);
        if (wave.getVisibility() == View.VISIBLE) {
            wave.setVisibility(View.GONE);
            return;
        }
        if (clips.isEmpty()) {
            toast("先加一段视频");
            return;
        }
        wave.setVisibility(View.VISIBLE);
        wave.setSource(clips.get(currentIndex).uri);
        toast("波形显示当前段");
    }

    /** 字幕位置：复用画布上的把手，拖完直接改锚点，导出按新位置渲染。 */
    private void startSubtitleDrag() {
        if (subtitleCues.isEmpty()) {
            toast("先加一条字幕再拖");
            return;
        }
        android.widget.FrameLayout box = findViewById(R.id.previewBox);
        if (box == null) return;
        showAnchorHandle(box, subX, subY, (x, y) -> {
            subX = x;
            subY = y;
            markEdited();
            refreshToolLabels();
        });
        toast("拖绿点调字幕位置，松手生效");
    }

    private void chooseSubtitleSize() {
        String[] items = {"小（48）", "中（72）", "大（96）", "特大（128）"};
        float[] sizes = {48f, 72f, 96f, 128f};
        new AlertDialog.Builder(this)
                .setTitle("字幕统一字号")
                .setItems(items, (d, which) -> {
                    subSize = sizes[which];
                    afterChange();
                    toast("字幕字号：" + items[which]);
                })
                .setNegativeButton("关闭", null)
                .show();
    }

    private void chooseSubtitleColor() {
        String[] names = {"白色", "黄色", "绿色", "浅灰"};
        int[] colors = {0xFFFFFFFF, 0xFFFFD750, 0xFF3DDC97, 0xFFC9CFD8};
        new AlertDialog.Builder(this)
                .setTitle("字幕统一颜色")
                .setItems(names, (d, which) -> {
                    subColor = colors[which];
                    afterChange();
                    toast("字幕颜色：" + names[which]);
                })
                .setNegativeButton("关闭", null)
                .show();
    }

    /** 通用"画布内拖动把手"：水印和字幕共用，避免两套逻辑各写一遍。 */
    private android.view.View anchorHandle;
    private java.util.function.BiConsumer<Float, Float> anchorSink;
    private android.widget.FrameLayout anchorBox;

    private void showAnchorHandle(android.widget.FrameLayout box, float x0, float y0,
                                  java.util.function.BiConsumer<Float, Float> sink) {
        anchorBox = box;
        anchorSink = sink;
        if (anchorHandle == null) {
            anchorHandle = new android.view.View(this);
            anchorHandle.setBackgroundResource(R.drawable.bg_pill_accent);
            int size = dp(44);
            anchorHandle.setLayoutParams(new android.widget.FrameLayout.LayoutParams(size, size));
            anchorHandle.setAlpha(0.85f);
            anchorHandle.setOnTouchListener(new android.view.View.OnTouchListener() {
                float downX, downY, baseX, baseY;
                @Override
                public boolean onTouch(android.view.View v, android.view.MotionEvent e) {
                    switch (e.getActionMasked()) {
                        case android.view.MotionEvent.ACTION_DOWN:
                            downX = e.getRawX();
                            downY = e.getRawY();
                            baseX = curAnchorX;
                            baseY = curAnchorY;
                            return true;
                        case android.view.MotionEvent.ACTION_MOVE: {
                            float vw = Math.max(1, anchorBox.getWidth());
                            float vh = Math.max(1, anchorBox.getHeight());
                            curAnchorX = clampAnchor(baseX + (e.getRawX() - downX) * 2f / vw);
                            curAnchorY = clampAnchor(baseY - (e.getRawY() - downY) * 2f / vh);
                            placeAnchorHandle();
                            return true;
                        }
                        case android.view.MotionEvent.ACTION_UP:
                            if (anchorSink != null) anchorSink.accept(curAnchorX, curAnchorY);
                            toast("位置已更新，导出按这个位置合成");
                            return true;
                    }
                    return false;
                }
            });
            box.addView(anchorHandle);
        } else if (anchorHandle.getParent() != box) {
            ((android.view.ViewGroup) anchorHandle.getParent()).removeView(anchorHandle);
            box.addView(anchorHandle);
        }
        curAnchorX = x0;
        curAnchorY = y0;
        anchorHandle.setVisibility(android.view.View.VISIBLE);
        anchorHandle.bringToFront();
        placeAnchorHandle();
    }

    private float curAnchorX, curAnchorY;

    private void placeAnchorHandle() {
        if (anchorHandle == null || anchorBox == null || anchorBox.getWidth() == 0) return;
        float cx = (curAnchorX + 1f) / 2f * anchorBox.getWidth();
        float cy = (1f - curAnchorY) / 2f * anchorBox.getHeight();
        int half = dp(22);
        anchorHandle.setX(cx - half);
        anchorHandle.setY(cy - half);
    }

    private void chooseMusicVolume() {
        String[] names = {"静音（0%）", "轻（30%）", "中（50%）", "较大（70%）", "满（100%）"};
        float[] vals = {0f, 0.3f, 0.5f, 0.7f, 1f};
        int cur = 0;
        for (int i = 0; i < vals.length; i++) if (Math.abs(vals[i] - musicVolume) < 0.01f) cur = i;
        new AlertDialog.Builder(this)
                .setTitle("配乐音量")
                .setItems(names, (d, which) -> {
                    musicVolume = vals[which];
                    afterChange();
                    toast("配乐音量：" + names[which]);
                })
                .setNegativeButton("关闭", null)
                .show();
    }

    private void openSubtitlePanel() {
        String[] actions = {"添加一条字幕", "从 SRT 导入", "导出 SRT",
                "拖动字幕位置（预览上直接拖）", "统一字号", "统一颜色",
                "描边粗细（当前 " + (subStroke <= 0 ? "无" : String.format("%.1f", subStroke)) + "）",
                "字幕底色（" + (subBg == 0 ? "无" : (subBg < 90 ? "淡" : "深")) + "）",
                "字幕入场动画（" + new String[]{"无", "淡入", "上滑淡入"}[subAnim] + "）",
                "片头标题卡" + (titleMs > 0 ? "（" + (titleMs / 1000f) + "s）" : "（未设置）"),
                "清空字幕"};
        new android.app.AlertDialog.Builder(this)
                .setTitle(subtitleCues.isEmpty() ? "字幕（还没有）"
                        : "字幕（" + subtitleCues.size() + " 条）")
                .setItems(actions, (d, which) -> {
                    if (which == 0) addSubtitleCue();
                    else if (which == 1) importSrt();
                    else if (which == 2) exportSrt();
                    else if (which == 3) startSubtitleDrag();
                    else if (which == 4) chooseSubtitleSize();
                    else if (which == 5) chooseSubtitleColor();
                    else if (which == 6) chooseSubtitleStroke();
                    else if (which == 7) chooseSubtitleBg();
                    else if (which == 8) chooseSubtitleAnim();
                    else if (which == 9) openTitleCard();
                    else {
                        subtitleCues.clear();
                        afterChange();
                        toast("字幕已清空");
                    }
                })
                .setNegativeButton("关闭", null)
                .show();
    }

    private void addSubtitleCue() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16), dp(6), dp(16), dp(6));

        EditText etText = new EditText(this);
        etText.setHint("字幕内容");
        box.addView(etText);

        EditText etStart = new EditText(this);
        etStart.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        etStart.setHint("开始（毫秒），当前播放位置：" + (player == null ? 0 : player.getCurrentPosition()));
        box.addView(etStart);

        EditText etEnd = new EditText(this);
        etEnd.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        etEnd.setHint("结束（毫秒）");
        box.addView(etEnd);

        new android.app.AlertDialog.Builder(this)
                .setTitle("添加字幕")
                .setView(box)
                .setNegativeButton("取消", null)
                .setPositiveButton("添加", (d, w) -> {
                    String text = etText.getText().toString().trim();
                    if (text.isEmpty()) {
                        toast("字幕内容不能为空");
                        return;
                    }
                    long start = parseLong(etStart.getText().toString(),
                            player == null ? 0 : player.getCurrentPosition());
                    long end = parseLong(etEnd.getText().toString(), start + 3000);
                    if (end <= start) {
                        toast("结束时间要大于开始时间");
                        return;
                    }
                    subtitleCues.add(new TimedTextOverlay.Cue(start, end, text));
                    subtitleCues.sort((a, b) -> Long.compare(a.startMs, b.startMs));
                    afterChange();
                    toast("已添加，共 " + subtitleCues.size() + " 条");
                })
                .show();
    }

    private long parseLong(String raw, long fallback) {
        try {
            return Long.parseLong(raw.trim());
        } catch (Exception e) {
            return fallback;
        }
    }

    private void importSrt() {
        srtPicker.launch(new String[]{"text/*", "application/x-subrip", "*/*"});
    }

    private void exportSrt() {
        if (subtitleCues.isEmpty()) {
            toast("还没有字幕");
            return;
        }
        try {
            String srt = SrtUtils.build(subtitleCues);
            java.io.File dir = new java.io.File(getExternalFilesDir(null), "subtitles");
            if (!dir.exists()) dir.mkdirs();
            java.io.File file = new java.io.File(dir, "freecut_" + System.currentTimeMillis() + ".srt");
            try (java.io.FileWriter w = new java.io.FileWriter(file)) {
                w.write(srt);
            }
            toast("SRT 已导出：" + file.getAbsolutePath());
        } catch (Exception e) {
            toast("导出失败：" + e.getMessage());
        }
    }

    // ---------------- 提取音频 ----------------

    private void askExtractAudio() {
        if (clips.isEmpty()) {
            toast("先加一段视频");
            return;
        }
        if (mute) {
            toast("当前是静音状态，先把「声音」打开再提取");
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle("提取音频")
                .setMessage("把这段剪辑的音轨单独导出成 m4a（只保留声音，不带画面）。")
                .setPositiveButton("开始", (d, w) -> exportAudio())
                .setNegativeButton("取消", null)
                .show();
    }

    private void exportAudio() {
        if (exporting) return;
        exporting = true;
        previewMode = false;
        exportStartMs = System.currentTimeMillis();
        acquireExportWakeLock();
        try {
            getSharedPreferences(EXPORT_PREFS, MODE_PRIVATE).edit()
                    .putBoolean("pending", true).apply();
        } catch (Throwable ignored) {
        }
        ExportService.start(this, "正在提取音频");
        applyLiveFilter();
        UiAnim.fade(exportMask, true);
        exportProgress.setProgress(0);
        tvExportPercent.setText("0%");
        tvExportTitle.setText("正在提取音频…");
        try {
            File dir = new File(getExternalFilesDir(null), "export");
            if (!dir.exists() && !dir.mkdirs()) throw new Exception("无法创建导出目录");
            final File out = new File(dir, "FC_AUDIO_" + System.currentTimeMillis() + ".m4a");
            exportFile = out;
            Transformer t = new Transformer.Builder(this)
                    .setAudioMimeType(MimeTypes.AUDIO_AAC)
                    .setRemoveVideo(true)
                    .addListener(new Transformer.Listener() {
                        @Override
                        public void onCompleted(Composition c, ExportResult r) {
                            finishAudio(out, true, null);
                        }

                        @Override
                        public void onTransformationCompleted(MediaItem m, TransformationResult r) {
                            finishAudio(out, true, null);
                        }

                        @Override
                        public void onError(Composition c, ExportResult r, ExportException e) {
                            finishAudio(out, false, e);
                        }

                        @Override
                        public void onTransformationError(MediaItem m, TransformationException e) {
                            finishAudio(out, false, e);
                        }
                    })
                    .build();
            transformer = t;
            java.util.List<Clip> visible = new ArrayList<>();
            for (Clip c : clips) if (!c.hidden) visible.add(c);
            if (visible.isEmpty()) {
                throw new IllegalStateException("所有片段都被隐藏了，没有可导出的内容");
            }
            if (visible.size() == 1) {
                Clip c = visible.get(0);
                MediaItem item = new MediaItem.Builder()
                        .setUri(exportUriOf(c))
                        .setClippingConfiguration(new MediaItem.ClippingConfiguration.Builder()
                                .setStartPositionMs(c.startMs)
                                .setEndPositionMs(c.endMs)
                                .build())
                        .build();
                t.start(new EditedMediaItem.Builder(item).build(), out.getAbsolutePath());
            } else {
                List<EditedMediaItem> items = new ArrayList<>();
                for (Clip c : visible) {
                    MediaItem item = new MediaItem.Builder()
                            .setUri(exportUriOf(c))
                            .setClippingConfiguration(new MediaItem.ClippingConfiguration.Builder()
                                    .setStartPositionMs(c.startMs)
                                    .setEndPositionMs(c.endMs)
                                    .build())
                            .build();
                    items.add(new EditedMediaItem.Builder(item).setRemoveVideo(true).build());
                }
                EditedMediaItemSequence seq = new EditedMediaItemSequence(items);
                t.start(new Composition.Builder(seq).build(), out.getAbsolutePath());
            }
            handler.post(pollAudioProgress);
            if (player != null) player.pause();
        } catch (Exception e) {
            exporting = false;
            UiAnim.fade(exportMask, false);
            ExportService.stop(this);
            toast("提取失败：" + e.getMessage());
        }
    }

    private final Runnable pollAudioProgress = new Runnable() {
        @Override
        public void run() {
            if (!exporting || transformer == null) return;
            int state = transformer.getProgress(progressHolder);
            if (state == Transformer.PROGRESS_STATE_AVAILABLE) {
                int p = Math.max(0, Math.min(99, progressHolder.progress));
                exportProgress.setProgress(p);
                tvExportPercent.setText(p + "%");
                ExportService.update(VideoEditorActivity.this, p, "正在提取音频");
            }
            handler.postDelayed(this, 200);
        }
    };

    private void finishAudio(final File out, final boolean success, final Exception error) {
        if (!exporting && success) return;
        exporting = false;
        handler.removeCallbacks(pollAudioProgress);
        if (transformer != null) {
            transformer.removeAllListeners();
            transformer = null;
        }
        ExportService.stop(this);
        runOnUiThread(() -> UiAnim.fade(exportMask, false));
        if (!success) {
            String code = error instanceof ExportException
                    ? ((ExportException) error).getErrorCodeName()
                    : error == null ? "" : String.valueOf(error.getMessage());
            runOnUiThread(() -> toast("提取失败（" + code + "）"));
            return;
        }
        Work.run(() -> {
            try {
                BitmapUtils.publishAudio(VideoEditorActivity.this, out,
                        "LocalVideo_" + System.currentTimeMillis() + ".m4a");
                runOnUiThread(() -> toast("音频已保存到「音乐/LocalVideo」"));
            } catch (Exception e) {
                runOnUiThread(() -> toast("已提取，但写入音乐目录失败：" + e.getMessage()));
            }
        });
    }

    private void runExport(boolean preview) {
        if (exporting) return;
        if (clips.isEmpty()) return;
        safeCompositionRetry = false;

        List<AudioProcessor> audioProcessors = new ArrayList<>();
        List<Effect> videoEffects;
        try {
            videoEffects = buildVideoEffects(preview, audioProcessors);
        } catch (Throwable t) {
            // 某台机器不支持这个效果组合时，别让整个导出挂掉
            videoEffects = new ArrayList<>();
            audioProcessors = new ArrayList<>();
            exportStage = 4;
            logExport(false, "EFFECT_BUILD_FAILED", String.valueOf(t.getMessage()));
        }

        if (preview) {
            Clip c = clips.get(currentIndex);
            long end = Math.min(c.endMs, c.startMs + 2000);
            if (end <= c.startMs) end = c.endMs;
            MediaItem item = new MediaItem.Builder()
                    .setUri(exportUriOf(c))
                    .setClippingConfiguration(new MediaItem.ClippingConfiguration.Builder()
                            .setStartPositionMs(c.startMs)
                            .setEndPositionMs(end)
                            .build())
                    .build();
            EditedMediaItem emi = new EditedMediaItem.Builder(item)
                    .setRemoveAudio(true)
                    .setEffects(new Effects(audioProcessors, videoEffects))
                    .build();
            startTransformer(emi, null, true);
            return;
        }

        if (totalLengthMs() < 200) {
            toast("片段太短，请先选择更长的片段");
            return;
        }

        if (android.os.Build.VERSION.SDK_INT >= 33
                && androidx.core.content.ContextCompat.checkSelfPermission(this,
                "android.permission.POST_NOTIFICATIONS")
                != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 9002);
        }
        if (!preflightBypassed) {
            String issue = preflightIssue();
            if (issue != null) {
                new AlertDialog.Builder(this)
                        .setTitle("导出前检查")
                        .setMessage(issue + "\n仍要继续吗？")
                        .setPositiveButton("继续导出", (d, w) -> {
                            preflightBypassed = true;
                            runExport(false);
                        })
                        .setNegativeButton("取消", null)
                        .show();
                return;
            }
        }

        // 8K/HDR 源：Media3 不会把帧尺寸压下来，编码器永远拿到 7680×4320。
        // 导出前先用 MediaCodec 把这类素材转成 1080p SDR 副本，再走正常流程。
        if (!normalizeAttempted) {
            normalizeAttempted = true;
            if (needsSourceNormalize()) {
                prepareNormalizedSources();
                return;
            }
        }

        // 配乐先不参与首轮编码：先出无配乐正片，成功后再单独混音（两段式）。
        // 这样"配乐 + 旋转/缩放/滤镜/速度/比例/镜像"同时用时，编码器不会再被一次压垮。
        final boolean needVideoOnlyFirst = !preview && !mixingPass && exportStage < 2
                && (musicUri != null || voiceUri != null);
        mixingMusicUri = needVideoOnlyFirst ? musicUri : null;
        mixPending = needVideoOnlyFirst;
        final Uri effectiveMusic = (musicUri != null && !needVideoOnlyFirst
                && exportStage < 2) ? musicUri : null;
        // 第一次失败后（stage>=2）单段也走 Composition，把输出尺寸归一化后再编码：
        // ERROR_CODE_ENCODER_INIT_FAILED 多数是"原始尺寸 + 旋转/缩放/镜像"组合下编码器初始化失败，
        // 统一到一个规整的偶数/16 对齐尺寸后基本都能过。
        int srcLongSide = Math.max(clips.get(0).width, clips.get(0).height);
        if (clips.size() == 1 && effectiveMusic == null && exportStage < 2 && !compatExport
                && clips.get(0).uri != null && srcLongSide <= 1920) {
            Clip c = clips.get(0);
            MediaItem item = new MediaItem.Builder()
                    .setUri(exportUriOf(c))
                    .setClippingConfiguration(new MediaItem.ClippingConfiguration.Builder()
                            .setStartPositionMs(exportClipStart(c))
                            .setEndPositionMs(exportClipEnd(c))
                            .build())
                    .build();
            pendingOutW = c.width > 0 ? c.width : 1080;
            pendingOutH = c.height > 0 ? c.height : 1920;
            EditedMediaItem emi = new EditedMediaItem.Builder(item)
                    .setRemoveAudio(mute)
                    .setEffects(new Effects(audioProcessors, videoEffects))
                    .build();
            startTransformer(emi, null, false);
            return;
        }

        // 多段 或 带配乐：Composition（视频序列 + 可选音频序列）
        // 关键：相邻片段尺寸不一致时，Composition 会直接抛 IllegalArgumentException /
        // 或输出成花屏。必须给每个 item 单独套 Presentation，把它们统一到同一输出尺寸。
        int outW = clips.get(0).width > 0 ? clips.get(0).width : 720;
        int outH = clips.get(0).height > 0 ? clips.get(0).height : 1280;
        // 关键：源是 8K/4K 时不能把原尺寸直接丢给编码器（7680×4320@60 会直接 ENCODER_INIT_FAILED）
        int baseCap = compatExport ? 1280 : 1920;
        int srcLong = Math.max(outW, outH);
        if (srcLong > baseCap) {
            float k = baseCap / (float) srcLong;
            outW = Math.round(outW * k);
            outH = Math.round(outH * k);
        }
        if (compatExport) {
            int longSide0 = Math.max(outW, outH);
            if (longSide0 > 1280) {
                float k = 1280f / longSide0;
                outW = Math.round(outW * k);
                outH = Math.round(outH * k);
            }
        }
        if (targetHeight > 0 && targetHeight < outH) {
            outH = targetHeight;
            outW = Math.max(2, Math.round(outW * (targetHeight / (float) Math.max(1, clips.get(0).height))));
        }
        // 编码器兼容尺寸：偶数；降级阶段进一步做 16 对齐 + 长边限制，避免 ENCODER_INIT_FAILED
        if (exportStage >= 2) {
            // 逐档降分辨率：1920 → 1280 → 854 → 640，配合 16 对齐，尽量绕开编码器初始化失败
            int cap = exportStage >= 5 ? 640 : exportStage >= 4 ? 854 : exportStage >= 3 ? 1280 : 1920;
            int longSide = Math.max(outW, outH);
            if (longSide > cap) {
                float k = cap / (float) longSide;
                outW = Math.round(outW * k);
                outH = Math.round(outH * k);
            }
            outW = Math.max(16, (outW / 16) * 16);
            outH = Math.max(16, (outH / 16) * 16);
        } else {
            outW -= outW % 2;
            outH -= outH % 2;
        }
        pendingOutW = outW;
        pendingOutH = outH;
        // 关键：per-item 的 Presentation 只改 item 的布局，最终输出尺寸仍可能沿用 8K 源帧。
        // 在整条 Composition 的最后再压一层尺寸，确保交给编码器的就是 outW×outH。
        videoEffects.add(Presentation.createForWidthAndHeight(
                outW, outH, Presentation.LAYOUT_SCALE_TO_FIT));
        if (kfKeys != null && kfKeys.length >= 2) {
            List<KeyframeEffect.Kf> keys = new ArrayList<>();
            for (float[] k : kfKeys) {
                keys.add(new KeyframeEffect.Kf(k[0], k[1], k[2], k[3], k[4]));
            }
            try {
                videoEffects.add(new KeyframeEffect(keys, totalLengthMs(), keyEasing));
            } catch (Throwable t) {
                ExportDiag.warn("keyframe", t);
                runOnUiThread(() -> toast("关键帧效果不可用，已跳过"));
            }
        }
        // 真转场：先把每个交界渲染成短片段，再按 A(尾减 fade) + 过渡 + B(头跳 fade) 拼。
        boolean realTrans = transType >= 0 && clipTransitionMs > 0 && clips.size() > 1;
        if (realTrans && transBuilding) {
            toast("转场片段还在生成，稍等一下");
            return;
        }
        if (realTrans && !transReady) {
            startTransitionBuild(outW, outH);
            return;
        }
        List<EditedMediaItem> items = new ArrayList<>();
        for (int ci = 0; ci < clips.size(); ci++) {
            Clip c = clips.get(ci);
            if (c.uri == null) continue;
            long cs = exportClipStart(c);
            long ce = exportClipEnd(c);
            long soloMs = Math.max(100, ce - cs);
            if (realTrans && transReady) {
                if (ci > 0 && transFiles != null && transFiles[ci - 1] != null) {
                    cs += transFades[ci - 1];
                }
                if (ci < clips.size() - 1 && transFiles != null && transFiles[ci] != null) {
                    ce -= transFades[ci];
                }
                if (ce - cs < 100) {
                    cs = exportClipStart(c);
                    ce = exportClipEnd(c);
                    if (transFiles != null && ci < transFiles.length) transFiles[ci] = null;
                }
            }
            MediaItem item = new MediaItem.Builder()
                    .setUri(exportUriOf(c))
                    .setClippingConfiguration(new MediaItem.ClippingConfiguration.Builder()
                            .setStartPositionMs(cs)
                            .setEndPositionMs(ce)
                            .build())
                    .build();
            EditedMediaItem.Builder b = new EditedMediaItem.Builder(item)
                    .setRemoveAudio(mute);
            // 统一尺寸：等比缩放并留黑边，不变形、不裁画面
            // 有配乐时：原声和配乐各自按 item 施加音量，避免 Composition 的全局音频处理把配乐音量也改掉
            List<AudioProcessor> itemAudio = new ArrayList<>();
            if (effectiveMusic != null && !mute) {
                itemAudio.add(new GainAudioProcessor(volume, 0, 0, 0));
            }
            List<Effect> itemVideo = new ArrayList<>();
            if (c.width > 0 && c.height > 0) {
                float k = Math.min(outW / (float) c.width, outH / (float) c.height);
                if (k > 0 && k < 0.999f) {
                    // 真正把解码后的 8K 帧缩到目标量级：GL 阶段就缩放，编码器不会再看到 7680×4320
                    itemVideo.add(new androidx.media3.effect.ScaleAndRotateTransformation.Builder()
                            .setScale(k, k).build());
                }
            }
            if (clipTransitionMs > 0) {
                long clipMs = Math.max(100, exportClipEnd(c) - exportClipStart(c));
                long fadeMs = Math.min(clipTransitionMs, clipMs / 2);
                itemVideo.add(new FadeEffect(clipMs, fadeMs));
            }
            itemVideo.add(Presentation.createForWidthAndHeight(
                    outW, outH, Presentation.LAYOUT_SCALE_TO_FIT));
            b.setEffects(new Effects(itemAudio, itemVideo));
            items.add(b.build());
            if (realTrans && transReady && transFiles != null && ci < transFiles.length
                    && transFiles[ci] != null) {
                File tf = transFiles[ci];
                if (tf.isFile() && tf.length() > 1024) {
                    MediaItem ti = new MediaItem.Builder()
                            .setUri(Uri.fromFile(tf))
                            .build();
                    List<Effect> tv = new ArrayList<>();
                    tv.add(Presentation.createForWidthAndHeight(
                            outW, outH, Presentation.LAYOUT_SCALE_TO_FIT));
                    List<AudioProcessor> ta = new ArrayList<>();
                    if (!mute) ta.add(new GainAudioProcessor(volume, 0, 0, 0));
                    items.add(new EditedMediaItem.Builder(ti)
                            .setRemoveAudio(mute)
                            .setEffects(new Effects(ta, tv))
                            .build());
                }
            }
        }
        EditedMediaItemSequence videoSequence = new EditedMediaItemSequence(items);

        Composition composition;
        if (effectiveMusic != null) {
            List<EditedMediaItem> musicItems = new ArrayList<>();
            MediaItem music = new MediaItem.Builder()
                    .setUri(effectiveMusic)
                    .build();
            musicItems.add(new EditedMediaItem.Builder(music)
                    .setRemoveVideo(true)
                    .setEffects(new Effects(
                            new ArrayList<>(List.of(new GainAudioProcessor(musicVolume, 0, 0, 0))),
                            new ArrayList<>()))
                    .build());
            EditedMediaItemSequence audioSequence = new EditedMediaItemSequence(musicItems, true);
            composition = new Composition.Builder(videoSequence, audioSequence)
                    .setEffects(new Effects(new ArrayList<>(), videoEffects))
                    .setHdrMode(hdrModeForStage())
                    .experimentalSetForceAudioTrack(true)
                    .build();
        } else {
            composition = new Composition.Builder(videoSequence)
                    .setEffects(new Effects(audioProcessors, videoEffects))
                    .setHdrMode(hdrModeForStage())
                    .experimentalSetForceAudioTrack(true)
                    .build();
        }
        startTransformer(null, composition, false);
    }

    /**
     * 安全模式拼接：不带滤镜/速度/水印/配乐/旋转，每段只做"裁剪区间 + 统一尺寸"，
     * 只求能拼出来。参数不兼容时（比如某段没音轨、某段是 HDR、尺寸差异过大）兜底用。
     */
    private void startSafeComposition() {
        try {
            int outW = 0, outH = 0;
            for (Clip c : clips) {
                if (c.width > 0 && c.height > 0) {
                    outW = c.width;
                    outH = c.height;
                    break;
                }
            }
            if (targetHeight > 0 && outH > 0) {
                outW = Math.max(2, Math.round(outW * (targetHeight / (float) outH)));
                outH = targetHeight;
            }
            outW -= outW % 2;
            outH -= outH % 2;
            List<EditedMediaItem> items = new ArrayList<>();
            for (Clip c : clips) {
                if (c.uri == null) continue;
                MediaItem item = new MediaItem.Builder()
                        .setUri(exportUriOf(c))
                        .setClippingConfiguration(new MediaItem.ClippingConfiguration.Builder()
                                .setStartPositionMs(c.startMs)
                                .setEndPositionMs(c.endMs)
                                .build())
                        .build();
                EditedMediaItem.Builder b = new EditedMediaItem.Builder(item).setRemoveAudio(mute);
                if (outW > 0 && outH > 0) {
                    b.setEffects(new Effects(new ArrayList<>(),
                            new ArrayList<>(List.of(Presentation.createForWidthAndHeight(
                                    outW, outH, Presentation.LAYOUT_SCALE_TO_FIT)))));
                }
                items.add(b.build());
            }
            Composition composition = new Composition.Builder(
                    new EditedMediaItemSequence(items))
                    .setHdrMode(Composition.HDR_MODE_TONE_MAP_HDR_TO_SDR_USING_MEDIACODEC)
                    .experimentalSetForceAudioTrack(true)
                    .build();
            startTransformer(null, composition, false);
        } catch (Throwable t) {
            finishExport(false, new RuntimeException(t));
        }
    }

    private void startTransformer(EditedMediaItem item, Composition composition, boolean preview) {
        exporting = true;
        previewMode = preview;
        UiAnim.fade(exportMask, true);
        exportProgress.setProgress(0);
        tvExportPercent.setText("0%");
        exportStartMs = System.currentTimeMillis();
        // 导出/预览要重新编码，先把画面上的渲染滤镜摘掉，避免叠加两层
        clearRenderEffect();
        tvExportTitle.setText(preview ? "正在生成效果预览…" : "正在导出…");
        if (!preview) ExportService.start(this, "正在导出成片");

        try {
            File dir = new File(getExternalFilesDir(null), "export");
            if (!dir.exists() && !dir.mkdirs()) throw new Exception("无法创建导出目录");
            exportFile = new File(dir, (preview ? "PREVIEW_" : "FC_") + System.currentTimeMillis() + ".mp4");
            if (exportFile.exists() && !exportFile.delete()) throw new Exception("无法写入导出文件");

            androidx.media3.transformer.DefaultEncoderFactory.Builder enc =
                    new androidx.media3.transformer.DefaultEncoderFactory.Builder(this);
            if (!compatExport && exportStage < 3) {
                int mbps = exportBitrateMbps;
                if (mbps <= 0 && pendingOutW > 0 && pendingOutH > 0) {
                    // 自动码率：约 0.12 bit/pixel/frame，1080p30 ≈ 7.5Mbps
                    double b = pendingOutW * (double) pendingOutH * 30 * 0.12 / 1_000_000.0;
                    mbps = (int) Math.max(3, Math.min(20, Math.round(b)));
                }
                if (mbps > 0) {
                    androidx.media3.transformer.VideoEncoderSettings.Builder vb =
                            new androidx.media3.transformer.VideoEncoderSettings.Builder()
                                    .setBitrate(mbps * 1000 * 1000);
                    if (exportStage >= 3 || compatExport) {
                        // 深降级：明确要求 Main Profile / Level 4.1，避免编码器被 HDR 10bit、4:4:4 顶崩
                        vb.setEncodingProfileLevel(
                                android.media.MediaCodecInfo.CodecProfileLevel.AVCProfileMain,
                                android.media.MediaCodecInfo.CodecProfileLevel.AVCLevel41);
                    }
                    enc.setRequestedVideoEncoderSettings(vb.build());
                }
            }
            transformer = new Transformer.Builder(this)
                    .setVideoMimeType(exportHevc ? MimeTypes.VIDEO_H265 : MimeTypes.VIDEO_H264)
                    .setEncoderFactory(enc.build())
                    .addListener(new Transformer.Listener() {
                        @Override
                        public void onCompleted(Composition c, ExportResult r) {
                            finishExport(true, null);
                        }

                        @Override
                        public void onTransformationCompleted(MediaItem m, TransformationResult r) {
                            finishExport(true, null);
                        }

                        @Override
                        public void onError(Composition c, ExportResult r, ExportException e) {
                            if (!safeCompositionRetry && clips.size() > 1) {
                                safeCompositionRetry = true;
                                runOnUiThread(() -> toast("拼接遇到不兼容参数，正在用安全模式重试…"));
                                startSafeComposition();
                                return;
                            }
                            finishExport(false, e);
                        }

                        @Override
                        public void onTransformationError(MediaItem m, TransformationException e) {
                            finishExport(false, e);
                        }
                    })
                    .build();

            if (composition != null) {
                transformer.start(composition, exportFile.getAbsolutePath());
            } else {
                transformer.start(item, exportFile.getAbsolutePath());
            }
            handler.post(pollProgress);
            if (player != null) player.pause();
        } catch (Exception e) {
            finishExport(false, e);
        }
    }

    /** 拼接导出失败时的"安全重试"：去掉所有特效，只保留裁剪区间，先保证出片。 */
    private boolean safeCompositionRetry = false;

    private final Runnable pollProgress = new Runnable() {
        @Override
        public void run() {
            if (!exporting || transformer == null) return;
            int state = transformer.getProgress(progressHolder);
            if (state == Transformer.PROGRESS_STATE_AVAILABLE) {
                int p = Math.max(0, Math.min(99, progressHolder.progress));
                if (!previewMode) ExportService.update(VideoEditorActivity.this, p, "正在导出成片");
                exportProgress.setProgress(p);
                tvExportPercent.setText(p + "%");
                long elapsed = System.currentTimeMillis() - exportStartMs;
                if (p >= 3 && elapsed > 3000) {
                    long remain = (long) (elapsed * (100 - p) / (double) p);
                    tvExportTitle.setText("正在导出：约剩 "
                            + formatDuration(remain) + "（可切到后台等）");
                }
            }
            handler.postDelayed(this, 200);
        }
    };

    /** 兼容模式：低配机/老是 ENCODER_INIT_FAILED 时，直接 720p + H.264 + 不指定码率 */
    private boolean compatExport = false;
    /** 本次导出实际使用的输出尺寸（用于自动码率计算） */
    private int pendingOutW = 0, pendingOutH = 0;
    /** 导出用的大素材 1080p 副本：原 Uri -> 副本 Uri */
    private java.util.Map<String, Uri> exportUriOverride = null;
    private boolean normalizeAttempted = false;
    private boolean preparingSources = false;
    private boolean preflightBypassed = false;
    private boolean mixPending = false;
    /** 运镜模式：0 关闭 1 推近 2 拉远 3 左→右 4 下→上 */
    private int motion = 0;
    /** 片头片尾黑场淡入淡出 */
    private boolean fadeTransition = false;
    /** 把每个交界预渲染成一个短过渡片段（双解码 + GL 混合 + 音频交叉淡化）。 */
    private void startTransitionBuild(int outW, int outH) {
        if (transBuilding) return;
        transBuilding = true;
        final List<Clip> snap = new ArrayList<>(clips);
        final int type = transType;
        final int cfg = clipTransitionMs;
        final int w = outW;
        final int h = outH;
        toast("正在生成转场片段…");
        Work.run(() -> {
            File dir = new File(getCacheDir(), "trans");
            if (dir.isDirectory()) {
                File[] old = dir.listFiles();
                if (old != null) for (File f : old) f.delete();
            } else {
                dir.mkdirs();
            }
            File[] files = new File[snap.size()];
            long[] fades = new long[snap.size()];
            for (int i = 0; i < snap.size() - 1; i++) {
                Clip a = snap.get(i), b = snap.get(i + 1);
                try {
                    long ea = exportClipEnd(a);
                    long sb = exportClipStart(b);
                    long fa = Math.max(100, ea - exportClipStart(a));
                    long fb = Math.max(100, exportClipEnd(b) - sb);
                    long fade = Math.min(cfg, Math.min(fa / 2, fb / 2));
                    if (fade < 120) {
                        if (!shortTransitionToasted) {
                            shortTransitionToasted = true;
                            final int seg = i;
                            runOnUiThread(() -> toast("第 " + seg + " 段太短，转场已改用硬切"));
                        }
                        continue;
                    }
                    File out = new File(dir, "t" + i + ".mp4");
                    if (TransitionRenderer.render(VideoEditorActivity.this,
                            exportUriOf(a), ea, exportUriOf(b), sb,
                            Math.max(0, type), (int) fade, w, h, out)) {
                        files[i] = out;
                        fades[i] = fade;
                    }
                } catch (Throwable ignore) {
                }
            }
            runOnUiThread(() -> {
                transFiles = files;
                transFades = fades;
                transReady = true;
                transBuilding = false;
                runExport(false);
            });
        });
    }

    private static float[][] deepCopy(float[][] src) {
        if (src == null) return null;
        float[][] out = new float[src.length][];
        for (int i = 0; i < src.length; i++) out[i] = src[i].clone();
        return out;
    }

    private static String kfToString(float[][] keys) {
        if (keys == null) return "";
        StringBuilder sb = new StringBuilder();
        for (float[] k : keys) {
            if (sb.length() > 0) sb.append(';');
            sb.append(String.format("%.3f,%.3f,%.3f,%.3f,%.1f",
                    k[0], k[1], k[2], k[3], k[4]));
        }
        return sb.toString();
    }

    private static float[][] kfFromString(String raw) {
        if (raw == null || raw.trim().isEmpty()) return null;
        try {
            String[] rows = raw.split(";");
            float[][] out = new float[rows.length][5];
            for (int i = 0; i < rows.length; i++) {
                String[] cols = rows[i].split(",");
                if (cols.length < 5) return null;
                for (int j = 0; j < 5; j++) out[i][j] = Float.parseFloat(cols[j].trim());
            }
            return out.length >= 2 ? out : null;
        } catch (Throwable t) {
            return null;
        }
    }

    /** 关键帧运镜面板：预设 + 逐帧参数编辑 + 缓动。 */
    private void openKeyframePanel() {
        SheetUi.Panel p = SheetUi.panel(this, "关键帧运镜");
        if (kfKeys == null) {
            kfKeys = new float[][]{
                    {0f, 1f, 0f, 0f, 0f},
                    {1f, 1.12f, 0f, 0f, 0f}
            };
        }
        final float[][] keys = kfKeys;
        final int[] selected = {0};
        final int[] ease = {keyEasing};

        SheetUi.section(this, p.body, "预设");
        SheetUi.chips(this, p.body, new String[]{"关闭", "推近", "拉远", "横向平移", "呼吸"}, 0, i -> {
            float[][][] presets = {
                    null,
                    {{0f, 1f, 0f, 0f, 0f}, {1f, 1.16f, 0f, 0f, 0f}},
                    {{0f, 1.16f, 0f, 0f, 0f}, {1f, 1f, 0f, 0f, 0f}},
                    {{0f, 1.06f, -0.12f, 0f, 0f}, {1f, 1.06f, 0.12f, 0f, 0f}},
                    {{0f, 1f, 0f, 0f, 0f}, {0.5f, 1.14f, 0f, 0f, 0f}, {1f, 1f, 0f, 0f, 0f}}
            };
            if (i == 0) {
                kfKeys = null;
                toast("已关闭关键帧运镜");
                p.dismiss();
                markEdited();
                refreshToolLabels();
                return;
            }
            float[][] src = presets[i];
            kfKeys = src;
            p.dismiss();
            markEdited();
            refreshToolLabels();
            toast("已应用关键帧预设：" + new String[]{"关闭", "推近", "拉远", "横向平移", "呼吸"}[i]);
        });

        SheetUi.section(this, p.body, "缓动");
        SheetUi.chips(this, p.body, new String[]{"线性", "缓入缓出"}, keyEasing, i -> {
            ease[0] = i;
            keyEasing = i;
        });

        int n = keys.length;
        SheetUi.section(this, p.body, "编辑关键帧");
        SheetUi.chips(this, p.body, new String[]{"第 1 帧", "第 2 帧", "第 3 帧", "第 4 帧"}, 0, i -> {
            if (i < n) selected[0] = i;
        });

        SheetUi.slider(this, p.body, "时间 %", 0, 100, Math.round(keys[0][0] * 100), v -> {
            float[] k = keys[selected[0]];
            k[0] = v / 100f;
        });
        SheetUi.slider(this, p.body, "缩放 %", 80, 160, Math.round(keys[0][1] * 100), v -> {
            keys[selected[0]][1] = v / 100f;
        });
        SheetUi.slider(this, p.body, "横向 ‰", -300, 300, Math.round(keys[0][2] * 1000), v -> {
            keys[selected[0]][2] = v / 1000f;
        });
        SheetUi.slider(this, p.body, "纵向 ‰", -300, 300, Math.round(keys[0][3] * 1000), v -> {
            keys[selected[0]][3] = v / 1000f;
        });
        SheetUi.slider(this, p.body, "旋转 °", -15, 15, Math.round(keys[0][4]), v -> {
            keys[selected[0]][4] = (float) v;
        });
        SheetUi.hint(this, p.body, "关键帧会作用在整条成片时间轴上，导出时逐帧插值，预览同样生效。");
        SheetUi.primaryButton(this, p.body, "应用", () -> {
            kfKeys = keys;
            markEdited();
            refreshToolLabels();
            p.dismiss();
            toast("已应用关键帧运镜");
        });
        p.show();
    }

    /** 段间转场面板：样式芯片 + 时长芯片 + 应用。 */
    private void openTransitionPanel() {
        SheetUi.Panel p = SheetUi.panel(this, "段间转场");
        final int[] type = {transType < 0 ? 4 : Math.min(3, transType)};
        final int[] ms = {clipTransitionMs};
        SheetUi.section(this, p.body, "样式");
        SheetUi.chips(this, p.body, new String[]{"叠化", "擦除", "推拉", "缩放", "黑场"},
                type[0], i -> {
                    type[0] = i;
                    if (ms[0] == 0) ms[0] = 500;
                });
        SheetUi.section(this, p.body, "时长");
        int[] opts = {0, 300, 500, 800, 1000};
        int dsel = 0;
        for (int i = 0; i < opts.length; i++) if (opts[i] == ms[0]) dsel = i;
        final int[] chooseMs = {dsel};
        SheetUi.chips(this, p.body, new String[]{"关闭", "0.3 秒", "0.5 秒", "0.8 秒", "1.0 秒"},
                dsel, i -> {
                    chooseMs[0] = i;
                    ms[0] = opts[i];
                });
        SheetUi.hint(this, p.body,
                "转场会真正把两段画面叠在一起渲染（双轨 GL 合成），过渡段音频自动交叉淡化。\n"
                        + "过渡时长会从总时长里扣掉，导出时生效；预览仍是硬切。");
        SheetUi.primaryButton(this, p.body, "应用转场", () -> {
            if (chooseMs[0] == 0) {
                clipTransitionMs = 0;
                toast("已关闭段间转场");
            } else {
                clipTransitionMs = ms[0];
                transType = type[0] == 4 ? -1 : type[0];
                toast(type[0] == 4
                        ? "段间黑场 " + (clipTransitionMs / 1000f) + "s"
                        : "段间" + TransitionRenderer.nameOf(transType) + " "
                        + (clipTransitionMs / 1000f) + "s");
            }
            markEdited();
            refreshToolLabels();
            p.dismiss();
        });
        p.show();
    }

    /** 段间转场时长（0 = 硬切） */
    private int clipTransitionMs = 0;
    /** 段间转场类型：0 叠化 / 1 擦除 / 2 推拉 / 3 缩放（-1 = 只用黑场） */
    private int transType = 0;
    /** 关键帧运镜：[t, scale, dx, dy, rot]，null = 未启用 */
    private float[][] kfKeys;
    private int keyEasing = 0;
    /** 预渲染出来的过渡片段（每个交界一个） */
    private File[] transFiles;
    private long[] transFades;
    private boolean transReady;
    private boolean transBuilding;
    /** 色调（绿 ↔ 洋红），与色温一起构成白平衡 */
    private float tint = 0f;
    /** 调色：亮度 / 对比度 / 饱和度 / 色相 / 色温，叠加在滤镜之上 */
    private float brightness = 0f;
    private float contrast = 1f;
    private float saturation = 1f;
    private float hueDeg = 0f;
    private float warmth = 0f;
    /** 配音（录音旁白）与配乐淡入淡出 */
    private Uri voiceUri = null;
    private float voiceVolume = 0.7f;
    private int fadeInMs = 600;
    /** 配乐在配音出现时自动闪避（默认开）。 */
    private boolean duckMusic = true;
    private int fadeOutMs = 600;
    private MediaRecorder recorder;
    private File recordingFile;
    private android.os.PowerManager.WakeLock exportWakeLock;
    private static final String EXPORT_PREFS = "freecut_export_state";
    private boolean shortTransitionToasted;
    private boolean hevcFallbackUsed = false;
    /** 两段式导出：先出"无配乐正片"，再单独混音。避免"配乐 + 旋转/缩放/滤镜"一次性把编码器搞崩。 */
    private Uri mixingMusicUri = null;
    private boolean mixingPass = false;

    /** 第二段：正片 + 配乐混音。不再带任何画面特效，编码器压力最小。 */
    private void startMixPass(File video, Uri music) {
        File dir = new File(getExternalFilesDir(null), "export");
        if (!dir.exists() && !dir.mkdirs()) {
            exportFile = video;
            finishExport(true, null);
            return;
        }
        final File out = new File(dir, "FC_MIX_" + System.currentTimeMillis() + ".mp4");
        mixingPass = true;
        exporting = true;
        tvExportTitle.setText("正在混入配乐…");
        UiAnim.fade(exportMask, true);
        final long dur = totalLengthMs();
        final boolean keepOriginal = !mute;
        final float mv = musicVolume;
        final float ov = volume;
        Work.run(() -> {
            boolean ok;
            try {
                ok = AudioMixer.mix(VideoEditorActivity.this, video, music,
                        keepOriginal, ov, mv, voiceUri, voiceVolume,
                        fadeInMs, fadeOutMs, out, dur, duckMusic);
            } catch (Throwable t) {
                logExport(false, "MIX_EXCEPTION", String.valueOf(t.getMessage()));
                ok = false;
            }
            final boolean mixed = ok;
            runOnUiThread(() -> {
                mixingPass = false;
                if (mixed) {
                    deleteQuietly(video);
                    exportFile = out;
                    logExport(true, "", "配乐混音成功（自建混流）");
                    finishExport(true, null);
                } else {
                    deleteQuietly(out);
                    exportFile = video;
                    logExport(false, "MIX_FAILED", "配乐混音失败，回退无配乐版");
                    toast("配乐混音失败，已导出无配乐版本（日志已记录）");
                    finishExport(true, null);
                }
            });
        });
    }

    private void deleteQuietly(File f) {
        try {
            if (f != null && f.exists()) {
                //noinspection ResultOfMethodCallIgnored
                f.delete();
            }
        } catch (Exception ignored) {
        }
    }

    private void logExport(final boolean ok, final String code, final String note) {
        try {
            ExportLog.Entry e = new ExportLog.Entry();
            e.ok = ok;
            e.code = code == null ? "" : code;
            e.stage = exportStage;
            e.clips = clips.size();
            e.subtitles = !subtitleCues.isEmpty();
            e.music = musicUri != null;
            e.hevc = exportHevc;
            String n = note == null ? "" : note;
            if (voiceUri != null) n = n + " +配音";
            e.durationMs = exportStartMs > 0 ? Math.max(0, System.currentTimeMillis() - exportStartMs) : 0;
            e.note = n
                    + (pendingOutW > 0 ? " out=" + pendingOutW + "x" + pendingOutH : "");
            ExportLog.add(this, e);
        } catch (Throwable ignored) {
        }
    }

    private void finishExport(final boolean success, final Exception error) {
        if (!exporting) return;
        // 正片先出来了：接着做配乐混音，混完再走最终交付
        if (success && !previewMode && mixPending) {
            final Uri music = mixingMusicUri;
            mixingMusicUri = null;
            mixPending = false;
            startMixPass(exportFile, music);
            return;
        }
        exporting = false;
        releaseExportWakeLock();
        if (success) {
            try {
                getSharedPreferences(EXPORT_PREFS, MODE_PRIVATE).edit()
                        .putBoolean("pending", false).apply();
            } catch (Throwable t) {
                ExportDiag.warn("export_pref", t);
            }
        }
        final boolean wasPreview = previewMode;
        handler.removeCallbacks(pollProgress);
        handler.removeCallbacks(loadWatchdog);
        if (transformer != null) {
            transformer.removeAllListeners();
            transformer = null;
        }
        runOnUiThread(() -> {
            exportProgress.setProgress(success ? 100 : 0);
            tvExportPercent.setText(success ? "100%" : "失败");
            UiAnim.fade(exportMask, false);
        });

        applyLiveFilter();
        if (!success) {
            String code = "";
            if (error instanceof ExportException) {
                code = ((ExportException) error).getErrorCodeName();
            } else if (error instanceof TransformationException) {
                code = ((TransformationException) error).getErrorCodeName();
            }
            logExport(false, code, "stage=" + exportStage
                    + (error == null ? "" : " " + String.valueOf(error.getMessage())));
            // 编码器类失败：先把 H.265 回落成 H.264 再试一次（大多数"编不动"其实是不支持 HEVC）
            if (!wasPreview && !hevcFallbackUsed && exportHevc
                    && (code.contains("ENCOD") || code.contains("CODEC") || code.contains("MUX"))) {
                hevcFallbackUsed = true;
                exportHevc = false;
                logExport(false, code, "H.265 编码器不可用，回落 H.264");
                runOnUiThread(() -> toast("本机 H.265 编不动，自动换 H.264 重试…"));
                handler.postDelayed(() -> {
                    if (!isFinishing() && !isDestroyed()) {
                        exporting = false;
                        runExport(false);
                    }
                }, 400);
                return;
            }
            // 失败后按层级降级重试：先摘叠层，再摘滤镜/变速，最后原片直出
            if (!wasPreview && exportStage < 5) {
                exportStage++;
                final int stageNow = exportStage;
                final String failCode = code;
                logExport(false, failCode, "降级前 stage=" + (stageNow - 1));
                String stageText = stageNow == 1 ? "去掉水印/字幕"
                        : stageNow == 2 ? "去掉配乐"
                        : stageNow == 3 ? "去掉滤镜/变速（降 1280）"
                        : stageNow == 4 ? "原片直出（降 854）"
                        : "降到 640 最小配置";
                runOnUiThread(() -> toast("这个效果本机不支持"
                        + (failCode.isEmpty() ? "" : "（" + failCode + "）")
                        + "，正在" + stageText + "后重试…"));
                handler.postDelayed(() -> {
                    if (!isFinishing() && !isDestroyed()) {
                        exporting = false;
                        runExport(false);
                    }
                }, 400);
                return;
            }
            String msg = error == null ? "未知错误" : String.valueOf(error.getMessage());
            if (error instanceof ExportException) {
                msg = "导出失败（" + ((ExportException) error).getErrorCodeName() + "）";
            } else if (error instanceof TransformationException) {
                msg = "导出失败（" + ((TransformationException) error).getErrorCodeName() + "）";
            }
            final String finalMsg = msg + (exportStage > 0 ? "（已去掉部分效果）" : "");
            ExportService.notifyDone(this, false, null);
            runOnUiThread(() -> {
                ExportService.stop(VideoEditorActivity.this);
                new AlertDialog.Builder(VideoEditorActivity.this)
                        .setTitle("导出失败")
                        .setMessage(finalMsg + "\n\n已记录本地诊断（不上传）。")
                        .setPositiveButton("查看导出记录", (d, w) -> showExportLog())
                        .setNegativeButton("关闭", null)
                        .show();
            });
            return;
        }

        ExportService.stop(this);
        logExport(true, "", exportStage > 0 ? "降级导出" : "");
        final File out = exportFile;
        if (wasPreview) {
            runOnUiThread(() -> openPreview(out));
            return;
        }
        Work.run(() -> {
            try {
                Uri published = BitmapUtils.publishVideo(VideoEditorActivity.this, out, out.getName());
                HistoryStore.add(VideoEditorActivity.this, "video", out.getName(), published, projectId);
                ExportService.notifyDone(VideoEditorActivity.this, true, out.getName());
                runOnUiThread(() -> {
                    exportedOnce = true;
                    showSuccessDialog(out, published);
                });
            } catch (Exception e) {
                runOnUiThread(() -> toast("已导出，但写入相册失败：" + e.getMessage()));
            }
        });
    }

    private String formatDuration(long ms) {
        long sec = Math.max(1, ms / 1000);
        if (sec < 60) return sec + " 秒";
        long min = sec / 60;
        long rest = sec % 60;
        return min + " 分" + (rest > 0 ? rest + " 秒" : "");
    }

    private void openPreview(File file) {
        try {
            Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", file);
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setDataAndType(uri, "video/mp4");
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(intent);
        } catch (Exception e) {
            toast("没有可播放视频的应用，预览文件已生成：" + file.getName());
        }
    }

    private void leaveIfRequested() {
        if (leaveAfterExport) {
            leaveAfterExport = false;
            finish();
        }
    }

    private void showSuccessDialog(File file, Uri published) {
        runOnUiThread(() -> new AlertDialog.Builder(this)
                .setTitle("导出完成")
                .setMessage("视频已保存到相册 Movies/LocalVideo\n\n文件：" + file.getName()
                        + (exportStage > 0
                        ? "\n\n注意：本机不支持部分特效，这版已去掉"
                        + (exportStage == 1 ? "水印/字幕" : exportStage == 2 ? "滤镜" : "变速")
                        + "以保证出片。" : ""))
                .setNegativeButton("知道了", (d2, w2) -> leaveIfRequested())
                .setOnDismissListener(d2 -> leaveIfRequested())
                .setPositiveButton("分享", (d, w) -> {
                    Intent share = new Intent(Intent.ACTION_SEND);
                    share.setType("video/mp4");
                    share.putExtra(Intent.EXTRA_STREAM, published);
                    share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    startActivity(Intent.createChooser(share, "分享视频"));
                })
                .show());
    }

    private void cancelExport() {
        if (transformer != null) transformer.cancel();
        // 取消后把半成品删掉，不然每取消一次就留一个几 MB 的 mp4
        if (previewMode && exportFile != null && exportFile.exists()) {
            //noinspection ResultOfMethodCallIgnored
            exportFile.delete();
        }
        exporting = false;
        handler.removeCallbacks(pollProgress);
        UiAnim.fade(exportMask, false);
        toast("已取消");
    }

    @Override
    protected void onDestroy() {
        Work.cancelOwner(this);
        releaseExportWakeLock();
        super.onDestroy();
        handler.removeCallbacks(pollProgress);
        if (transformer != null) {
            transformer.cancel();
            transformer = null;
        }
        if (player != null) {
            player.release();
            player = null;
        }
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }

    /** HDR 源：默认用 MediaCodec 色调映射到 SDR；深降级时直接按 SDR 解释，避开 10bit/4:4:4 编码器。 */
    private int hdrModeForStage() {
        return exportStage >= 4
                ? Composition.HDR_MODE_EXPERIMENTAL_FORCE_INTERPRET_HDR_AS_SDR
                : Composition.HDR_MODE_TONE_MAP_HDR_TO_SDR_USING_MEDIACODEC;
    }

    /** 超 4K 的源必须先在本地压成 1080p 副本，否则编码器会被 8K 帧直接顶崩。 */
    private boolean needsSourceNormalize() {
        for (Clip c : clips) {
            if (c == null || c.uri == null) continue;
            int longSide = Math.max(c.width, c.height);
            if (longSide > 2160) return true;
        }
        return false;
    }

    private Uri exportUriOf(Clip c) {
        if (c == null || c.uri == null) return null;
        if (exportUriOverride != null) {
            Uri u = exportUriOverride.get(c.uri.toString());
            if (u != null) return u;
        }
        return c.uri;
    }

    private long exportClipStart(Clip c) {
        return exportUriOverride != null && exportUriOverride.containsKey(c.uri.toString())
                ? 0 : c.startMs;
    }

    private long exportClipEnd(Clip c) {
        return exportUriOverride != null && exportUriOverride.containsKey(c.uri.toString())
                ? Math.max(1, c.endMs - c.startMs) : c.endMs;
    }

    /** 后台把超大素材压成 1080p SDR 副本，然后再正常导出。 */
    private void prepareNormalizedSources() {
        if (preparingSources) return;
        preparingSources = true;
        exporting = true;
        UiAnim.fade(exportMask, true);
        exportProgress.setProgress(0);
        tvExportPercent.setText("0%");
        tvExportTitle.setText("正在压缩超大素材…");
        final java.util.List<Clip> snapshot = new ArrayList<>(clips);
        Work.run(() -> {
            java.util.Map<String, Uri> map = new java.util.HashMap<>();
            int total = 0;
            for (Clip c : snapshot) {
                if (c.uri != null && Math.max(c.width, c.height) > 2160) total++;
            }
            int done = 0;
            for (Clip c : snapshot) {
                if (c.uri == null || Math.max(c.width, c.height) <= 2160) continue;
                try {
                    int cap = compatExport ? 1280 : 1920;
                    int w = c.width > 0 ? c.width : cap;
                    int h = c.height > 0 ? c.height : cap;
                    int longSide = Math.max(w, h);
                    if (longSide > cap) {
                        float k = cap / (float) longSide;
                        w = Math.round(w * k);
                        h = Math.round(h * k);
                    }
                    File dir = new File(getCacheDir(), "norm");
                    if (!dir.exists()) dir.mkdirs();
                    File dst = new File(dir, "n" + System.currentTimeMillis() + "_" + done + ".mp4");
                    boolean ok = VideoNormalizer.normalize(
                            VideoEditorActivity.this, c.uri, c.startMs, c.endMs, w, h, dst);
                    if (ok) {
                        map.put(c.uri.toString(), Uri.fromFile(dst));
                    } else {
                        logExport(false, "NORMALIZE_FAILED", "素材压缩失败，回退原始编码");
                    }
                } catch (Throwable t) {
                    logExport(false, "NORMALIZE_FAILED", String.valueOf(t.getMessage()));
                }
                done++;
                final int shown = total <= 0 ? 100 : Math.round(100f * done / total);
                final int doneShown = done;
                final int totalShown = total;
                runOnUiThread(() -> {
                    exportProgress.setProgress(shown);
                    tvExportPercent.setText(shown + "%");
                    tvExportTitle.setText("正在压缩超大素材 " + Math.min(doneShown, totalShown)
                            + "/" + totalShown + "…");
                });
            }
            runOnUiThread(() -> {
                exportUriOverride = map;
                preparingSources = false;
                exporting = false;
                UiAnim.fade(exportMask, false);
                if (map.isEmpty()) {
                    toast("素材压缩没成功，改用原始尺寸直接导出（可能仍会失败）");
                }
                try {
                    runExport(false);
                } catch (Throwable t) {
                    exporting = false;
                    preparingSources = false;
                    UiAnim.fade(exportMask, false);
                    logExport(false, "EXPORT_START_FAILED", String.valueOf(t.getMessage()));
                    toast("导出启动失败：" + t.getMessage());
                }
            });
        });
    }

    /** 导出前检查：空片段、异常时长、剩余空间。返回 null 表示没问题。 */
    private String preflightIssue() {
        StringBuilder sb = new StringBuilder();
        int invalid = 0;
        for (Clip c : clips) {
            if (c == null || c.uri == null) invalid++;
            else if (c.endMs <= c.startMs) invalid++;
        }
        if (invalid > 0) {
            sb.append("有 ").append(invalid).append(" 段素材无效（空或时长为 0），导出时会被跳过。\n");
        }
        try {
            File base = getExternalFilesDir(null);
            if (base != null) {
                android.os.StatFs sf = new android.os.StatFs(base.getAbsolutePath());
                long freeMb = sf.getAvailableBytes() / (1024 * 1024);
                long needMb = 60 + totalLengthMs() / 1000 * 2;
                if (freeMb < needMb) {
                    sb.append("可用空间约 ").append(freeMb).append("MB，低于预计需要的 ")
                            .append(needMb).append("MB，导出可能中断。\n");
                }
            }
        } catch (Throwable ignored) {
        }
        return sb.length() == 0 ? null : sb.toString();
    }

    private void acquireExportWakeLock() {
        try {
            if (exportWakeLock == null) {
                android.os.PowerManager pm =
                        (android.os.PowerManager) getSystemService(POWER_SERVICE);
                if (pm != null) {
                    exportWakeLock = pm.newWakeLock(
                            android.os.PowerManager.PARTIAL_WAKE_LOCK, "LocalVideo:export");
                    exportWakeLock.setReferenceCounted(false);
                }
            }
            if (exportWakeLock != null && !exportWakeLock.isHeld()) {
                exportWakeLock.acquire(30 * 60 * 1000L);
            }
        } catch (Throwable ignored) {
        }
    }

    private void releaseExportWakeLock() {
        try {
            if (exportWakeLock != null && exportWakeLock.isHeld()) {
                exportWakeLock.release();
            }
        } catch (Throwable ignored) {
        }
    }

    /** 把诊断日志写成 txt 分享出去（不用截图、不用手打）。 */
    private void shareExportLog() {
        try {
            File dir = new File(getCacheDir(), "diagnostics");
            if (!dir.exists() && !dir.mkdirs()) throw new java.io.IOException("建目录失败");
            File f = new File(dir, "export_diagnostics.txt");
            StringBuilder sb = new StringBuilder();
            sb.append("无联网本地视频编辑器导出诊断\n");
            sb.append(new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss",
                    java.util.Locale.getDefault()).format(new java.util.Date())).append("\n\n");
            sb.append(ExportLog.summary(this)).append("\n\n");
            for (ExportLog.Entry e : ExportLog.load(this)) {
                sb.append(e.line()).append('\n');
            }
            try (java.io.FileOutputStream fo = new java.io.FileOutputStream(f)) {
                fo.write(sb.toString().getBytes("UTF-8"));
            }
            Uri uri = FileProvider.getUriForFile(this,
                    getPackageName() + ".fileprovider", f);
            Intent share = new Intent(Intent.ACTION_SEND);
            share.setType("text/plain");
            share.putExtra(Intent.EXTRA_STREAM, uri);
            share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(share, "分享导出诊断"));
        } catch (Throwable t) {
            toast("导出诊断失败：" + t.getMessage());
        }
    }

    /** 版本历史：每次覆盖保存都会留一份旧快照，最多 10 份。 */
    private void openVersionHistory() {
        String id = projectId;
        if (id == null || id.isEmpty()) {
            toast("先保存一次工程，版本历史才会开始记录");
            return;
        }
        java.util.List<Long> versions = ProjectStore.listVersions(this, id);
        if (versions.isEmpty()) {
            toast("还没有历史版本，下次保存后就会出现");
            return;
        }
        java.text.SimpleDateFormat f = new java.text.SimpleDateFormat(
                "MM-dd HH:mm:ss", java.util.Locale.getDefault());
        String[] labels = new String[versions.size()];
        for (int i = 0; i < versions.size(); i++) {
            labels[i] = f.format(new java.util.Date(versions.get(i))) + " 保存的版本";
        }
        new AlertDialog.Builder(this)
                .setTitle("版本历史（最多 10 份）")
                .setItems(labels, (d, which) -> {
                    org.json.JSONObject data = ProjectStore.loadVersion(this, id, versions.get(which));
                    if (data == null) {
                        toast("这个版本读不出来");
                        return;
                    }
                    new AlertDialog.Builder(this)
                            .setTitle("回滚到这个版本？")
                            .setMessage("当前未保存的修改会丢失（可以先保存一次再回滚）。")
                            .setPositiveButton("回滚", (dd, ww) -> {
                                if (fromJson(data)) {
                                    applyRestoredState();
                                    loadDurations();
                                    markEdited();
                                    toast("已回滚到 " + labels[which]);
                                } else {
                                    toast("回滚失败：工程结构不兼容");
                                }
                            })
                            .setNegativeButton("取消", null)
                            .show();
                })
                .setNegativeButton("关闭", null)
                .show();
    }

    private static String pct(float v) {
        int p = Math.round(v * 100);
        return (p > 0 ? "+" : "") + p + "%";
    }

    private String colorSummary() {
        if (Math.abs(brightness) < 0.01f && Math.abs(contrast - 1f) < 0.01f
                && Math.abs(saturation - 1f) < 0.01f && Math.abs(hueDeg) < 0.5f
                && Math.abs(warmth) < 0.01f && Math.abs(tint) < 0.01f) return "默认";
        return "已调" + (warmth > 0 ? "·暖" : (warmth < 0 ? "·冷" : ""))
                + (tint > 0.01f ? "·洋红" : (tint < -0.01f ? "·绿" : ""));
    }

    private void chooseVoiceVolume() {
        choose("配音音量", new String[]{"关闭（0%）", "轻（30%）", "中（70%）", "响（100%）", "很响（150%）"},
                voiceVolume <= 0 ? 0 : (voiceVolume < 0.5f ? 1 : (voiceVolume < 0.9f ? 2 : (voiceVolume <= 1.01f ? 3 : 4))),
                idx -> {
                    voiceVolume = new float[]{0f, 0.3f, 0.7f, 1f, 1.5f}[idx];
                    afterChange();
                    toast("配音音量 " + Math.round(voiceVolume * 100) + "%");
                });
    }

    private void chooseFade() {
        choose("配乐淡入淡出", new String[]{"关闭", "0.3 秒", "0.6 秒", "1.2 秒"},
                fadeInMs <= 0 ? 0 : (fadeInMs <= 300 ? 1 : (fadeInMs <= 600 ? 2 : 3)), idx -> {
                    fadeInMs = new int[]{0, 300, 600, 1200}[idx];
                    fadeOutMs = fadeInMs;
                    afterChange();
                    toast(fadeInMs == 0 ? "已关闭淡入淡出" : "配乐淡入淡出 " + fadeInMs + "ms");
                });
    }

    /** 录音配音：第一次点开始录，再点一次停止并保存。 */
    private void startVoiceRecordingFlow() {
        if (recorder != null) {
            stopVoiceRecording();
            return;
        }
        if (androidx.core.content.ContextCompat.checkSelfPermission(this,
                android.Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{android.Manifest.permission.RECORD_AUDIO}, 9001);
            toast("先允许录音权限，再点一次「录音配音」");
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle("录音配音")
                .setMessage("点「开始录音」后开始录旁白，录完再点一次「声音 → 录音配音」结束。\n建议录音时长与视频大致相同。")
                .setPositiveButton("开始录音", (d, w) -> startVoiceRecording())
                .setNegativeButton("取消", null)
                .show();
    }

    private void startVoiceRecording() {
        try {
            File dir = new File(getCacheDir(), "voice");
            if (!dir.exists() && !dir.mkdirs()) throw new java.io.IOException("无法创建录音目录");
            recordingFile = new File(dir, "voice_" + System.currentTimeMillis() + ".m4a");
            MediaRecorder r = android.os.Build.VERSION.SDK_INT >= 31
                    ? new MediaRecorder(this) : new MediaRecorder();
            r.setAudioSource(MediaRecorder.AudioSource.MIC);
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
            r.setAudioSamplingRate(44100);
            r.setAudioEncodingBitRate(96000);
            r.setOutputFile(recordingFile.getAbsolutePath());
            r.prepare();
            r.start();
            recorder = r;
            toast("开始录音，再点一次「录音配音」结束");
        } catch (Throwable t) {
            toast("录音启动失败：" + t.getMessage());
            try {
                if (recorder != null) recorder.release();
            } catch (Throwable ignored) {
            }
            recorder = null;
        }
    }

    private void stopVoiceRecording() {
        try {
            recorder.stop();
        } catch (Throwable t) {
            toast("录音太短，没有保存");
            try {
                recorder.release();
            } catch (Throwable ignored) {
            }
            recorder = null;
            return;
        }
        try {
            recorder.release();
        } catch (Throwable ignored) {
        }
        recorder = null;
        if (recordingFile != null && recordingFile.isFile() && recordingFile.length() > 1024) {
            voiceUri = Uri.fromFile(recordingFile);
            afterChange();
            toast("配音已保存，导出时会与原声/配乐一起混音");
        } else {
            toast("录音没有生成文件");
        }
    }


    /** 6 套商业向调色预设：同时设参数与滤镜，一次到位。 */
    private void chooseColorPreset() {
        choose("一键调色预设", new String[]{
                "电影青橙", "日系清新", "黑金夜景", "复古胶片", "通透人像", "冷调雪景"}, -1, which -> {
            switch (which) {
                case 0:
                    contrast = 1.2f;
                    saturation = 1.3f;
                    warmth = 0.35f;
                    tint = 0.05f;
                    brightness = -0.05f;
                    filterIndex = indexOfFilter("胶片");
                    break;
                case 1:
                    contrast = 0.85f;
                    saturation = 0.8f;
                    warmth = -0.15f;
                    tint = 0f;
                    brightness = 0.2f;
                    filterIndex = indexOfFilter("鲜亮");
                    break;
                case 2:
                    contrast = 1.35f;
                    saturation = 1.4f;
                    warmth = 0.4f;
                    tint = -0.1f;
                    brightness = -0.25f;
                    filterIndex = indexOfFilter("暗夜");
                    break;
                case 3:
                    contrast = 1.1f;
                    saturation = 0.7f;
                    warmth = 0.2f;
                    tint = 0.15f;
                    brightness = 0.05f;
                    filterIndex = indexOfFilter("胶片");
                    break;
                case 4:
                    contrast = 1.05f;
                    saturation = 1.1f;
                    warmth = 0.15f;
                    tint = 0f;
                    brightness = 0.1f;
                    filterIndex = indexOfFilter("暖调");
                    break;
                default:
                    contrast = 1.15f;
                    saturation = 0.75f;
                    warmth = -0.45f;
                    tint = 0.05f;
                    brightness = 0.05f;
                    filterIndex = indexOfFilter("冷调");
                    break;
            }
            afterChange();
            toast("已套用调色预设：" + new String[]{
                    "电影青橙", "日系清新", "黑金夜景", "复古胶片", "通透人像", "冷调雪景"}[which]);
        });
    }

    private void chooseSubtitleStroke() {
        choose("字幕描边粗细", new String[]{"无描边", "细 1.5", "标准 2.5", "粗 4", "很粗 6"},
                subStroke <= 0 ? 0 : (subStroke < 2f ? 1 : (subStroke < 3.2f ? 2 : (subStroke < 5f ? 3 : 4))),
                idx -> {
                    subStroke = new float[]{0f, 1.5f, 2.5f, 4f, 6f}[idx];
                    afterChange();
                    toast(subStroke == 0 ? "已关闭字幕描边" : "字幕描边 " + subStroke);
                });
    }

    private void chooseSubtitleBg() {
        choose("字幕底色", new String[]{"无底色", "淡黑 25%", "黑底 45%", "深黑 65%"},
                subBg == 0 ? 0 : (subBg < 80 ? 1 : (subBg < 140 ? 2 : 3)), idx -> {
                    subBg = new int[]{0, 64, 115, 166}[idx];
                    afterChange();
                    toast(idx == 0 ? "已去掉字幕底色" : "字幕底色 " + new String[]{"", "淡黑", "黑底", "深黑"}[idx]);
                });
    }

    private void chooseSubtitleAnim() {
        choose("字幕入场动画", new String[]{"无（直接出现）", "淡入 0.26s", "上滑淡入 0.26s"},
                subAnim, idx -> {
                    subAnim = idx;
                    afterChange();
                    toast(idx == 0 ? "字幕动画已关闭" : "字幕动画：" + new String[]{"无", "淡入", "上滑淡入"}[idx]);
                });
    }

    /** 片头标题卡：开头 N 秒居中大字，淡入。 */
    private void openTitleCard() {
        EditText et = new EditText(this);
        et.setText(titleText);
        et.setHint("例如：第一章 · 出发");
        new AlertDialog.Builder(this)
                .setTitle("片头标题卡")
                .setView(et)
                .setPositiveButton("下一步", (d, w) -> {
                    String text = et.getText().toString().trim();
                    if (text.isEmpty()) {
                        titleMs = 0;
                        titleText = "";
                        afterChange();
                        toast("已关闭片头标题卡");
                        return;
                    }
                    titleText = text;
                    choose("显示时长", new String[]{"1 秒", "2 秒", "3 秒", "5 秒"},
                            titleMs <= 1000 ? 0 : (titleMs <= 2000 ? 1 : (titleMs <= 3000 ? 2 : 3)), idx -> {
                                titleMs = new long[]{1000, 2000, 3000, 5000}[idx];
                                afterChange();
                                toast("片头标题卡：" + titleMs / 1000f + "s");
                            });
                })
                .setNegativeButton("取消", null)
                .show();
    }
}
