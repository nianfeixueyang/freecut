package com.offlinelocal.videoeditor;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Typeface;
import android.graphics.Color;
import android.graphics.ColorMatrix;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;

import androidx.exifinterface.media.ExifInterface;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import java.util.ArrayList;
import java.util.List;

public class ImageEditorActivity extends AppCompatActivity {

    private static final int REQ_WRITE = 101;

    private EditImageView canvas;
    private ProgressBar progress;
    private TextView tvHint;
    private Uri sourceUri;
    private Bitmap original;

    private View panelFilter, panelAdjust, panelRotate, panelText, panelSticker,
            panelDraw, panelMosaic, panelLayers, panelBorder, panelCrop,
            panelVignette, panelWatermark, panelGradient;
    private LinearLayout rowFilters, rowCropAspect, rowTextColors, rowDrawColors,
            rowBorderColors, rowLayers, toolRow, toolRow2;

    private final List<TextView> toolViews = new ArrayList<>();
    private final List<View> toolLines = new ArrayList<>();
    private final List<View> filterChips = new ArrayList<>();
    private final List<TextView> aspectChips = new ArrayList<>();
    private final List<TextView> borderChips = new ArrayList<>();

    private int gradDir = 0;
    private boolean saving = false;
    private boolean savedOnce = false;
    /** 正在从草稿恢复：期间不要再自动保存，避免把草稿覆盖成半成品。 */
    private boolean restoring = false;
    private boolean leaveAfterSave = false;
    private String wmText = null;
    private float wmSizeRatio = 0.022f;
    private float wmAlpha = 0.6f;
    private float wmRotation = 0f;
    private int wmColor = 0xFFFFFFFF;
    private int filterIndex = 0;
    private float filterStrength = 1f;
    private float brightness = 0f, contrast = 0f, saturation = 0f, temperature = 0f;
    private float hue = 0f, fade = 0f;

    private boolean multiSelect = false;
    private final java.util.Set<Integer> pickedLayers = new java.util.HashSet<>();

    private int fontIndex = 0;
    private int strokeMode = 0;
    private int textBgMode = 0;
    private int alignIndex = 1;
    private boolean shadowOn = true;

    private ActivityResultLauncher<String[]> stickerPicker;
    private ActivityResultLauncher<android.content.Intent> signaturePicker;
    private Runnable pendingSave;

    public static Intent buildIntent(Context ctx, Uri uri) {
        Intent i = new Intent(ctx, ImageEditorActivity.class);
        i.setData(uri);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        return i;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_image_editor);

        canvas = findViewById(R.id.canvas);
        progress = findViewById(R.id.progress);
        tvHint = findViewById(R.id.tvHint);

        panelFilter = findViewById(R.id.panelFilter);
        panelAdjust = findViewById(R.id.panelAdjust);
        panelRotate = findViewById(R.id.panelRotate);
        panelText = findViewById(R.id.panelText);
        panelSticker = findViewById(R.id.panelSticker);
        panelDraw = findViewById(R.id.panelDraw);
        panelMosaic = findViewById(R.id.panelMosaic);
        panelLayers = findViewById(R.id.panelLayers);
        panelBorder = findViewById(R.id.panelBorder);
        panelCrop = findViewById(R.id.panelCrop);
        panelVignette = findViewById(R.id.panelVignette);
        panelWatermark = findViewById(R.id.panelWatermark);
        panelGradient = findViewById(R.id.panelGradient);
        setupGradient();
        setupVignette();
        setupWatermark();

        rowFilters = findViewById(R.id.rowFilters);
        rowCropAspect = findViewById(R.id.rowCropAspect);
        rowTextColors = findViewById(R.id.rowTextColors);
        rowDrawColors = findViewById(R.id.rowDrawColors);
        rowBorderColors = findViewById(R.id.rowBorderColors);
        rowLayers = findViewById(R.id.rowLayers);
        toolRow = findViewById(R.id.toolRow);
        toolRow2 = findViewById(R.id.toolRow2);

        findViewById(R.id.btnBack).setOnClickListener(v -> confirmExit());
        findViewById(R.id.btnUndo).setOnClickListener(v -> {
            if (canvas.undo()) {
                refreshLayers();
            } else {
                toast("没有可撤销的操作");
            }
        });
        findViewById(R.id.btnRedo).setOnClickListener(v -> {
            if (canvas.redo()) {
                refreshLayers();
            } else {
                toast("没有可重做的操作");
            }
        });
        canvas.setOnLongClickListener(v -> {
            boolean showing = !canvas.isShowingOriginal();
            canvas.setShowOriginal(showing);
            toast(showing ? "正在看原图，再长按恢复" : "已回到编辑预览");
            return true;
        });
        findViewById(R.id.btnSave).setOnClickListener(v -> saveImage());

        stickerPicker = registerForActivityResult(
                new ActivityResultContracts.OpenDocument(), this::onStickerPicked);

        signaturePicker = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(), result -> {
                    if (result.getResultCode() != RESULT_OK || result.getData() == null) return;
                    String path = result.getData().getStringExtra("path");
                    if (path == null) return;
                    Bitmap bmp = android.graphics.BitmapFactory.decodeFile(path);
                    if (bmp == null) {
                        toast("签名载入失败");
                        return;
                    }
                    canvas.addSticker(bmp);
                    refreshLayers();
                    toast("签名已添加，可拖动缩放");
                });

        sourceUri = getIntent().getData();
        if (sourceUri == null) {
            toast("没有收到图片");
            finish();
            return;
        }

        buildToolbar();
        buildFilterChips();
        buildAspectChips();
        buildColorRows();
        setupFilterStrength();
        setupAdjust();
        setupRotate();
        setupText();
        setupDraw();
        setupMosaic();
        setupLayers();
        setupBorder();
        setupShapes();
        setupFineRotate();
        setupBlend();
        setupFrames();
        bindCropButtons();

        canvas.onLayerChanged = this::refreshLayers;

        load();
    }

    // ---------------- 通用 ----------------

    private int dp(float v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    private TextView makeChip(String label, boolean selected) {
        TextView tv = new TextView(this);
        tv.setText(label);
        tv.setTextSize(12);
        tv.setGravity(Gravity.CENTER);
        tv.setPadding(dp(12), 0, dp(12), 0);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, dp(32));
        lp.rightMargin = dp(8);
        lp.gravity = Gravity.CENTER_VERTICAL;
        tv.setLayoutParams(lp);
        tv.setClickable(true);
        tv.setFocusable(true);
        styleChip(tv, selected);
        return tv;
    }

    private void styleChip(TextView tv, boolean selected) {
        tv.setBackgroundResource(selected ? R.drawable.bg_chip_selected : R.drawable.bg_chip);
        tv.setTextColor(selected ? getColor(R.color.on_accent) : getColor(R.color.text_1));
        tv.getPaint().setFakeBoldText(selected);
        tv.setTextSize(selected ? 13 : 12);
    }

    private View colorDot(int color, ColorListener listener) {
        View v = new View(this);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(26), dp(26));
        lp.rightMargin = dp(10);
        lp.gravity = Gravity.CENTER_VERTICAL;
        v.setLayoutParams(lp);
        v.setBackgroundResource(R.drawable.bg_dot);
        v.getBackground().mutate().setColorFilter(color, android.graphics.PorterDuff.Mode.SRC_IN);
        v.setClickable(true);
        v.setOnClickListener(x -> listener.onColor(color));
        return v;
    }

    private interface ColorListener {
        void onColor(int color);
    }

    // ---------------- 工具栏 ----------------

    private static final String[] TOOLS = {
            "裁剪", "滤镜", "调整", "调色", "旋转", "文字", "贴纸", "涂鸦", "马赛克",
            "图层", "边框", "暗角", "渐变", "水印", "信息", "重置"
    };

    private void buildToolbar() {
        int half = (TOOLS.length + 1) / 2;
        for (int i = 0; i < TOOLS.length; i++) {
            final String t = TOOLS[i];
            LinearLayout cell = new LinearLayout(this);
            cell.setOrientation(LinearLayout.VERTICAL);
            cell.setGravity(Gravity.CENTER_HORIZONTAL);
            cell.setPadding(dp(2), dp(8), dp(2), dp(4));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            cell.setLayoutParams(lp);
            cell.setClickable(true);
            cell.setFocusable(true);
            cell.setOnClickListener(v -> onTool(t));
            UiAnim.press(cell, 0.95f);

            TextView tv = new TextView(this);
            tv.setText(t);
            tv.setTextSize(12);
            tv.setMaxLines(1);
            tv.setGravity(Gravity.CENTER);
            tv.setTextColor(getColor(R.color.text_2));
            cell.addView(tv, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, dp(20)));

            View line = new View(this);
            LinearLayout.LayoutParams llp = new LinearLayout.LayoutParams(dp(22), dp(2));
            llp.topMargin = dp(6);
            line.setLayoutParams(llp);
            line.setBackgroundColor(getColor(R.color.accent));
            line.setVisibility(View.INVISIBLE);
            cell.addView(line);

            (i < half ? toolRow : toolRow2).addView(cell);
            toolViews.add(tv);
            toolLines.add(line);
        }
    }

    private void showOnly(View panel) {
        View[] all = {panelFilter, panelAdjust, panelRotate, panelText, panelSticker,
                panelDraw, panelMosaic, panelLayers, panelBorder, panelCrop,
                panelVignette, panelWatermark, panelGradient};
        for (View v : all) {
            if (v == panel) UiAnim.panel(v, true);
            else if (v.getVisibility() == View.VISIBLE) UiAnim.panel(v, false);
        }
    }

    private void setToolSelected(String tool) {
        for (int i = 0; i < toolViews.size(); i++) {
            TextView tv = toolViews.get(i);
            boolean on = tv.getText().toString().equals(tool);
            tv.setTextColor(getColor(on ? R.color.accent : R.color.text_2));
            tv.getPaint().setFakeBoldText(on);
            toolLines.get(i).setVisibility(on ? View.VISIBLE : View.INVISIBLE);
        }
    }

    private void onTool(String tool) {
        if ("重置".equals(tool)) {
            new AlertDialog.Builder(this)
                    .setTitle("重置")
                    .setMessage("会丢弃所有修改与图层，恢复原始图片，确定吗？")
                    .setNegativeButton("取消", null)
                    .setPositiveButton("重置", (d, w) -> reloadOriginal())
                    .show();
            return;
        }
        setToolSelected(tool);
        // 离开马赛克工具就把整图马赛克/模糊缓存放掉（P0-1：闲置不占几十 MB）
        if (!"马赛克".equals(tool)) canvas.trimImageCaches();
        switch (tool) {
            case "裁剪":
                showOnly(panelCrop);
                canvas.setMode(EditImageView.Mode.CROP);
                showHint("拖动四角调整裁剪框，框内拖动可平移");
                break;
            case "滤镜":
                showOnly(panelFilter);
                canvas.setMode(EditImageView.Mode.NONE);
                hideHint();
                break;
            case "调整":
                showOnly(panelAdjust);
                canvas.setMode(EditImageView.Mode.NONE);
                hideHint();
                break;
            case "调色":
                setToolSelected("调色");
                openColorGrade();
                break;
            case "旋转":
                showOnly(panelRotate);
                canvas.setMode(EditImageView.Mode.NONE);
                hideHint();
                break;
            case "文字":
                showOnly(panelText);
                canvas.setMode(EditImageView.Mode.TEXT);
                showHint("单指拖动文字位置，双指缩放旋转");
                break;
            case "贴纸":
                showOnly(panelSticker);
                canvas.setMode(EditImageView.Mode.NONE);
                showHint("选中贴纸后单指拖动、双指缩放旋转");
                break;
            case "涂鸦":
                showOnly(panelDraw);
                canvas.setMode(EditImageView.Mode.DRAW);
                showHint("在画面上直接手绘");
                break;
            case "马赛克":
                showOnly(panelMosaic);
                canvas.setMode(EditImageView.Mode.MOSAIC);
                showHint("涂抹要打码的区域");
                break;
            case "图层":
                showOnly(panelLayers);
                canvas.setMode(EditImageView.Mode.NONE);
                refreshLayers();
                showHint("点选图层后可用下方按钮调整");
                break;
            case "边框":
                showOnly(panelBorder);
                canvas.setMode(EditImageView.Mode.NONE);
                hideHint();
                break;
            case "暗角":
                showOnly(panelVignette);
                canvas.setMode(EditImageView.Mode.NONE);
                hideHint();
                break;
            case "渐变":
                showOnly(panelGradient);
                canvas.setMode(EditImageView.Mode.NONE);
                hideHint();
                break;
            case "水印":
                showOnly(panelWatermark);
                canvas.setMode(EditImageView.Mode.NONE);
                hideHint();
                break;
            case "信息":
                setToolSelected("");
                showExifDialog();
                break;
            default:
                break;
        }
    }

    private void showHint(String text) {
        tvHint.setText(text);
        tvHint.setVisibility(View.VISIBLE);
    }

    private void hideHint() {
        tvHint.setVisibility(View.GONE);
    }

    private void savePreset() {
        EditText input = new EditText(this);
        input.setHint("给这套参数起个名字");
        input.setTextColor(getColor(R.color.text_primary));
        input.setHintTextColor(getColor(R.color.text_secondary));
        new AlertDialog.Builder(this)
                .setTitle("存为我的预设")
                .setView(input)
                .setNegativeButton("取消", null)
                .setPositiveButton("保存", (d, w) -> {
                    String name = input.getText().toString().trim();
                    if (name.isEmpty()) name = "预设 " + (PresetStore.all(this).size() + 1);
                    PresetStore.Preset p = new PresetStore.Preset();
                    p.name = name;
                    p.filterIndex = filterIndex;
                    p.strength = filterStrength;
                    p.brightness = brightness;
                    p.contrast = contrast;
                    p.saturation = saturation;
                    p.temperature = temperature;
                    p.vignette = canvas.getVignette();
                    PresetStore.add(this, p);
                    ((TextView) findViewById(R.id.tvPresetHint)).setText("已存：" + name);
                    toast("已保存");
                })
                .show();
    }

    private void showPresetList() {
        List<PresetStore.Preset> list = PresetStore.all(this);
        if (list.isEmpty()) {
            toast("还没有预设，先调好参数点“存为我的预设”");
            return;
        }
        String[] items = new String[list.size()];
        for (int i = 0; i < list.size(); i++) {
            PresetStore.Preset p = list.get(i);
            items[i] = p.name + (p.vignette > 0 ? String.format(java.util.Locale.US, " · 暗角 %d%%", (int) (p.vignette * 100)) : "");
        }
        new AlertDialog.Builder(this)
                .setTitle("我的预设")
                .setItems(items, (d, which) -> applyPreset(list.get(which)))
                .setNeutralButton("删除…", (d, w) -> {
                    String[] names = new String[list.size()];
                    for (int i = 0; i < list.size(); i++) names[i] = list.get(i).name;
                    new AlertDialog.Builder(this)
                            .setTitle("删除预设")
                            .setItems(names, (d2, idx) -> {
                                PresetStore.remove(this, names[idx]);
                                toast("已删除 " + names[idx]);
                            })
                            .show();
                })
                .setNegativeButton("关闭", null)
                .show();
    }

    private void applyPreset(PresetStore.Preset p) {
        filterIndex = p.filterIndex;
        filterStrength = p.strength;
        styleFilterChips();
        ((SeekBar) findViewById(R.id.seekFilterStrength)).setProgress((int) (p.strength * 100));
        brightness = p.brightness;
        contrast = p.contrast;
        saturation = p.saturation;
        temperature = p.temperature;
        ((SeekBar) findViewById(R.id.seekBrightness)).setProgress((int) (100 + p.brightness * 100));
        ((SeekBar) findViewById(R.id.seekContrast)).setProgress((int) (100 + p.contrast * 100));
        ((SeekBar) findViewById(R.id.seekSaturation)).setProgress((int) (100 + p.saturation * 100));
        ((SeekBar) findViewById(R.id.seekTemperature)).setProgress((int) (100 + p.temperature * 100));
        ((SeekBar) findViewById(R.id.seekVignette)).setProgress((int) (p.vignette * 100));
        canvas.setVignette(p.vignette);
        applyColor();
        ((TextView) findViewById(R.id.tvPresetHint)).setText("已套用：" + p.name);
        toast("已套用 " + p.name);
    }

    private void setupVignette() {
        SeekBar seek = findViewById(R.id.seekVignette);
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar sb, int p, boolean fromUser) {
                canvas.setVignette(p / 100f);
            }
            @Override public void onStartTrackingTouch(SeekBar sb) { }
            @Override public void onStopTrackingTouch(SeekBar sb) { }
        });
        findViewById(R.id.btnVignettePreset1).setOnClickListener(v -> { seek.setProgress(25); canvas.setVignette(0.25f); });
        findViewById(R.id.btnVignettePreset2).setOnClickListener(v -> { seek.setProgress(55); canvas.setVignette(0.55f); });
        findViewById(R.id.btnVignettePreset3).setOnClickListener(v -> { seek.setProgress(85); canvas.setVignette(0.85f); });
        findViewById(R.id.btnVignetteClear).setOnClickListener(v -> { seek.setProgress(0); canvas.setVignette(0f); });
    }

    private void setupGradient() {
        SeekBar seek = findViewById(R.id.seekGradient);
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar sb, int p, boolean fromUser) {
                if (gradDir == 0) return;
                canvas.setGradientMask(gradDir, p / 100f);
            }
            @Override public void onStartTrackingTouch(SeekBar sb) { }
            @Override public void onStopTrackingTouch(SeekBar sb) { }
        });
        int[] dirs = {0, 1, 2, 3, 4};
        int[] ids = {R.id.gradOff, R.id.gradTop, R.id.gradBottom, R.id.gradLeft, R.id.gradCorner};
        for (int i = 0; i < ids.length; i++) {
            final int dir = dirs[i];
            findViewById(ids[i]).setOnClickListener(v -> {
                gradDir = dir;
                canvas.setGradientMask(dir, seek.getProgress() / 100f);
                toast(dir == 0 ? "渐变已关闭" : "已应用渐变");
            });
        }
    }

    private void setupWatermark() {
        SeekBar sizeSeek = findViewById(R.id.seekWmSize);
        SeekBar alphaSeek = findViewById(R.id.seekWatermark);
        SeekBar rotSeek = findViewById(R.id.seekWmRotate);
        EditText et = findViewById(R.id.etWatermark);
        TextView posLabel = findViewById(R.id.tvWmPos);

        wmSizeRatio = sizeSeek.getProgress() / 1000f;
        wmAlpha = alphaSeek.getProgress() / 100f;
        wmRotation = rotSeek.getProgress() - 30f;

        SeekBar.OnSeekBarChangeListener listener = new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar sb, int p, boolean fromUser) {
                applyWatermarkStyle();
            }
            @Override public void onStartTrackingTouch(SeekBar sb) { }
            @Override public void onStopTrackingTouch(SeekBar sb) { }
        };
        sizeSeek.setOnSeekBarChangeListener(listener);
        alphaSeek.setOnSeekBarChangeListener(listener);
        rotSeek.setOnSeekBarChangeListener(listener);

        findViewById(R.id.btnWatermarkApply).setOnClickListener(v -> {
            String text = et.getText().toString().trim();
            if (text.isEmpty()) {
                toast("先输入水印文字");
                return;
            }
            wmText = text;
            canvas.setTileWatermark(wmText, wmAlpha);
            canvas.setWatermarkStyle(wmSizeRatio, wmColor, wmAlpha, wmRotation);
            canvas.setMode(EditImageView.Mode.WATERMARK);
            toast("水印已放上，可直接在画面上拖动定位");
        });

        findViewById(R.id.btnWatermarkClear).setOnClickListener(v -> {
            et.setText("");
            wmText = null;
            canvas.setTileWatermark(null, wmAlpha);
            toast("已清除水印");
        });

        findViewById(R.id.wmModeSingle).setOnClickListener(v -> {
            canvas.setWatermarkTiled(false);
            canvas.setMode(EditImageView.Mode.WATERMARK);
            posLabel.setText("位置：拖动画面");
            toast("单个水印");
        });
        findViewById(R.id.wmModeTile).setOnClickListener(v -> {
            canvas.setWatermarkTiled(true);
            canvas.setMode(EditImageView.Mode.NONE);
            posLabel.setText("铺满全图");
            toast("铺满水印");
        });

        int[] colors = {0xFFFFFFFF, 0xFF111111, getColor(R.color.warn), getColor(R.color.accent),
                0xFFFF5A5A, 0xFF4D9BFF, 0xFFB388FF};
        String[] names = {"白", "黑", "黄", "绿", "红", "蓝", "紫"};
        LinearLayout rowColors = findViewById(R.id.rowWmColors);
        for (int i = 0; i < colors.length; i++) {
            final int color = colors[i];
            final String name = names[i];
            TextView chip = new TextView(this);
            chip.setText(name);
            chip.setTextSize(11);
            chip.setTextColor(color == 0xFF111111 ? 0xFFFFFFFF : 0xFF111111);
            chip.setGravity(Gravity.CENTER);
            android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable();
            bg.setColor(color);
            bg.setCornerRadius(dp(8));
            chip.setBackground(bg);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(38), dp(30));
            lp.rightMargin = dp(6);
            chip.setLayoutParams(lp);
            chip.setOnClickListener(v -> {
                wmColor = color;
                applyWatermarkStyle();
                toast("水印颜色：" + name);
            });
            rowColors.addView(chip);
        }

        LinearLayout rowPos = findViewById(R.id.rowWmPositions);
        String[] posNames = {"左上", "上", "右上", "左", "中", "右", "左下", "下", "右下"};
        float[][] anchors = {
                {0.18f, 0.12f}, {0.5f, 0.12f}, {0.82f, 0.12f},
                {0.18f, 0.5f}, {0.5f, 0.5f}, {0.82f, 0.5f},
                {0.18f, 0.9f}, {0.5f, 0.9f}, {0.82f, 0.9f}
        };
        for (int i = 0; i < posNames.length; i++) {
            final int idx = i;
            TextView chip = new TextView(this);
            chip.setText(posNames[i]);
            chip.setTextSize(11);
            chip.setTextColor(getColor(R.color.text_primary));
            chip.setGravity(Gravity.CENTER);
            chip.setBackgroundResource(R.drawable.bg_chip);
            chip.setPadding(dp(12), dp(6), dp(12), dp(6));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.rightMargin = dp(6);
            chip.setLayoutParams(lp);
            chip.setOnClickListener(v -> {
                canvas.setWatermarkTiled(false);
                canvas.setWatermarkAnchor(anchors[idx][0], anchors[idx][1]);
                posLabel.setText("位置：" + posNames[idx]);
            });
            rowPos.addView(chip);
        }
    }

    private void applyWatermarkStyle() {
        wmSizeRatio = ((SeekBar) findViewById(R.id.seekWmSize)).getProgress() / 1000f;
        wmAlpha = ((SeekBar) findViewById(R.id.seekWatermark)).getProgress() / 100f;
        wmRotation = ((SeekBar) findViewById(R.id.seekWmRotate)).getProgress() - 30f;
        String typed = ((EditText) findViewById(R.id.etWatermark)).getText().toString().trim();
        if (!typed.isEmpty()) wmText = typed;
        if (wmText != null && !wmText.isEmpty()) {
            canvas.setTileWatermark(wmText, wmAlpha);
        }
        canvas.setWatermarkStyle(wmSizeRatio, wmColor, wmAlpha, wmRotation);
    }

    /** 查看源图的 EXIF；导出的图片本身不带元数据，这里明确告知。 */
    private void showExifDialog() {
        StringBuilder sb = new StringBuilder();
        try (java.io.InputStream in = getContentResolver().openInputStream(sourceUri)) {
            ExifInterface exif = new ExifInterface(in);
            appendExif(sb, "拍摄时间", exif.getAttribute(ExifInterface.TAG_DATETIME_ORIGINAL));
            appendExif(sb, "设备", (exif.getAttribute(ExifInterface.TAG_MAKE) == null ? "" :
                    exif.getAttribute(ExifInterface.TAG_MAKE)) + " " +
                    (exif.getAttribute(ExifInterface.TAG_MODEL) == null ? "" :
                            exif.getAttribute(ExifInterface.TAG_MODEL)));
            appendExif(sb, "光圈", exif.getAttribute(ExifInterface.TAG_F_NUMBER));
            appendExif(sb, "快门", exif.getAttribute(ExifInterface.TAG_EXPOSURE_TIME));
            appendExif(sb, "ISO", exif.getAttribute(ExifInterface.TAG_PHOTOGRAPHIC_SENSITIVITY));
            appendExif(sb, "焦距", exif.getAttribute(ExifInterface.TAG_FOCAL_LENGTH));
            String lat = exif.getAttribute(ExifInterface.TAG_GPS_LATITUDE);
            appendExif(sb, "GPS", lat == null ? null : "有（" + lat + ", " + exif.getAttribute(ExifInterface.TAG_GPS_LONGITUDE) + "）");
        } catch (Exception e) {
            sb.append("源文件没有可读的 EXIF 信息");
        }
        sb.append("\n\n分辨率：").append(original.getWidth()).append(" × ").append(original.getHeight());
        sb.append("\n\n提示：导出的图片会重新编码，GPS 与设备信息不会带出去。");
        new AlertDialog.Builder(this)
                .setTitle("图片信息")
                .setMessage(sb.toString())
                .setPositiveButton("知道了", null)
                .show();
    }

    private void appendExif(StringBuilder sb, String label, String value) {
        if (value == null || value.trim().isEmpty() || "null".equals(value)) return;
        sb.append(label).append("：").append(value.trim()).append("\n");
    }

    // ---------------- 滤镜 / 调整 ----------------

    private void buildFilterChips() {
        rowFilters.removeAllViews();
        filterChips.clear();
        Bitmap thumb = canvas.baseThumbnail(dp(52));
        if (thumb == null) {
            for (int i = 0; i < Filters.ALL.length; i++) {
                final int idx = i;
                TextView tv = makeChip(Filters.ALL[i].name, i == 0);
                tv.setOnClickListener(v -> {
                    filterIndex = idx;
                    filterStrength = 1f;
                    ((SeekBar) findViewById(R.id.seekFilterStrength)).setProgress(100);
                    styleFilterChips();
                    applyColor();
                    if (idx != 0) showHint("强度滑杆可调 0–100%，拖到 0 就是原图");
                });
                rowFilters.addView(tv);
                filterChips.add(tv);
            }
            return;
        }
        // 有底图时：每个预设直接给出"套上之后长什么样"的小样，光看名字分不出差别
        for (int i = 0; i < Filters.ALL.length; i++) {
            final int idx = i;
            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setGravity(Gravity.CENTER_HORIZONTAL);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.rightMargin = dp(6);
            lp.gravity = Gravity.CENTER_VERTICAL;
            card.setLayoutParams(lp);

            int size = dp(54);
            ImageView iv = new ImageView(this);
            iv.setLayoutParams(new LinearLayout.LayoutParams(size, size));
            iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
            iv.setImageBitmap(thumb);
            if (i != 0) {
                iv.setColorFilter(new android.graphics.ColorMatrixColorFilter(
                        Filters.imageMatrix(Filters.ALL[i], 0f, 0f, 0f, 0f)));
            }
            iv.setBackgroundResource(R.drawable.bg_chip);
            iv.setPadding(dp(2), dp(2), dp(2), dp(2));
            iv.setClipToOutline(true);
            iv.setOutlineProvider(new android.view.ViewOutlineProvider() {
                @Override
                public void getOutline(View v, android.graphics.Outline o) {
                    o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), dp(7));
                }
            });

            TextView tv = new TextView(this);
            tv.setText(Filters.ALL[i].name);
            tv.setTextSize(10);
            tv.setGravity(Gravity.CENTER);
            tv.setTextColor(getColor(i == 0 ? R.color.text_primary : R.color.text_secondary));
            tv.setPadding(0, dp(3), 0, 0);

            card.addView(iv);
            card.addView(tv);
            card.setClickable(true);
            card.setOnClickListener(v -> {
                filterIndex = idx;
                filterStrength = 1f;
                ((SeekBar) findViewById(R.id.seekFilterStrength)).setProgress(100);
                styleFilterChips();
                applyColor();
                if (idx != 0) showHint("强度滑杆可调 0–100%，拖到 0 就是原图");
            });
            rowFilters.addView(card);
            filterChips.add(card);
        }
    }

    /** 滤镜条的高亮：缩略图卡片与老式文字 chip 都要处理。 */
    private void styleFilterChips() {
        for (int k = 0; k < filterChips.size(); k++) {
            View chip = filterChips.get(k);
            boolean on = k == filterIndex;
            if (chip instanceof LinearLayout) {
                LinearLayout card = (LinearLayout) chip;
                TextView tv = (TextView) card.getChildAt(1);
                tv.setTextColor(getColor(on ? R.color.text_primary : R.color.text_secondary));
                tv.setTypeface(null, on ? Typeface.BOLD : Typeface.NORMAL);
                View iv = card.getChildAt(0);
                iv.setAlpha(on ? 1f : 0.7f);
                iv.setBackgroundResource(on ? R.drawable.bg_pill_accent : R.drawable.bg_chip);
            } else if (chip instanceof TextView) {
                styleChip((TextView) chip, on);
            }
        }
    }

    private void setupAdjust() {
        SeekBar b = findViewById(R.id.seekBrightness);
        SeekBar c = findViewById(R.id.seekContrast);
        SeekBar s = findViewById(R.id.seekSaturation);
        SeekBar t = findViewById(R.id.seekTemperature);
        SeekBar.OnSeekBarChangeListener l = new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar sb, int p, boolean fromUser) {
                brightness = (b.getProgress() - 100) / 100f;
                contrast = (c.getProgress() - 100) / 100f;
                saturation = (s.getProgress() - 100) / 100f;
                temperature = (t.getProgress() - 100) / 100f;
                applyColor();
            }

            @Override public void onStartTrackingTouch(SeekBar sb) {}
            @Override public void onStopTrackingTouch(SeekBar sb) {}
        };
        b.setOnSeekBarChangeListener(l);
        c.setOnSeekBarChangeListener(l);
        s.setOnSeekBarChangeListener(l);
        t.setOnSeekBarChangeListener(l);
    }

    private void setupFilterStrength() {
        SeekBar seek = findViewById(R.id.seekFilterStrength);
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar sb, int p, boolean fromUser) {
                filterStrength = p / 100f;
                applyColor();
                ((TextView) findViewById(R.id.tvPresetHint)).setText(
                        "滤镜强度 " + p + "%");
            }
            @Override public void onStartTrackingTouch(SeekBar sb) { }
            @Override public void onStopTrackingTouch(SeekBar sb) { }
        });
    }

    private void applyColor() {
        ColorMatrix cm = Filters.imageMatrix(Filters.ALL[filterIndex],
                brightness, contrast, saturation, temperature, hue, fade);
        if (filterStrength < 0.999f) {
            cm = Filters.blendWithIdentity(cm, filterStrength);
        }
        canvas.setColorMatrix(cm);
    }

    /** 图片调色工作台：6 参数 + 预设，和视频侧的调色保持同一套口径。 */
    private void openColorGrade() {
        SheetUi.Panel p = SheetUi.panel(this, "调色工作台");
        String[] presetNames = new String[Filters.ALL.length];
        for (int i = 0; i < presetNames.length; i++) presetNames[i] = Filters.ALL[i].name;
        SheetUi.section(this, p.body, "预设");
        SheetUi.chips(this, p.body, presetNames, Math.max(0, filterIndex), i -> {
            filterIndex = i;
            applyColor();
        });
        SheetUi.section(this, p.body, "参数");
        SheetUi.slider(this, p.body, "亮度", -100, 100, Math.round(brightness * 100), v -> {
            brightness = v / 100f;
            applyColor();
        });
        SheetUi.slider(this, p.body, "对比度", -100, 100, Math.round(contrast * 100), v -> {
            contrast = v / 100f;
            applyColor();
        });
        SheetUi.slider(this, p.body, "饱和度", -100, 100, Math.round(saturation * 100), v -> {
            saturation = v / 100f;
            applyColor();
        });
        SheetUi.slider(this, p.body, "色温", -100, 100, Math.round(temperature * 100), v -> {
            temperature = v / 100f;
            applyColor();
        });
        SheetUi.slider(this, p.body, "色调", -100, 100, Math.round(hue * 100), v -> {
            hue = v / 100f;
            applyColor();
        });
        SheetUi.slider(this, p.body, "褪色", 0, 100, Math.round(fade * 100), v -> {
            fade = v / 100f;
            applyColor();
        });
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        SheetUi.section(this, p.body, "");
        SheetUi.primaryButton(this, p.body, "完成", () -> {
            p.dismiss();
            showHint("调色已应用，长按画面可对比原图");
        });
        TextView reset = new TextView(this);
        reset.setText("重置全部参数");
        reset.setTextSize(13);
        reset.setTextColor(SheetUi.MUTED);
        reset.setGravity(Gravity.CENTER);
        reset.setPadding(0, dp(10), 0, dp(4));
        reset.setOnClickListener(v -> {
            brightness = contrast = saturation = temperature = hue = fade = 0f;
            filterIndex = 0;
            applyColor();
            p.dismiss();
            toast("已重置调色");
        });
        p.body.addView(reset);
        p.show();
    }

    // ---------------- 旋转 ----------------

    private void setupRotate() {
        findViewById(R.id.btnRotateLeft).setOnClickListener(v -> {
            canvas.rotate90(false);
            refreshLayers();
        });
        findViewById(R.id.btnRotateRight).setOnClickListener(v -> {
            canvas.rotate90(true);
            refreshLayers();
        });
        findViewById(R.id.btnFlipH).setOnClickListener(v -> canvas.flip(true));
        findViewById(R.id.btnFlipV).setOnClickListener(v -> canvas.flip(false));
    }

    // ---------------- 文字 ----------------

    private void setupText() {
        findViewById(R.id.btnAddText).setOnClickListener(v -> askText());
        findViewById(R.id.btnFont).setOnClickListener(v -> {
            fontIndex = (fontIndex + 1) % 3;
            canvas.setTextTypeface(fontIndex);
            ((TextView) findViewById(R.id.btnFont)).setText(
                    new String[]{"字体·常规", "字体·衬线", "字体·等宽"}[fontIndex]);
        });
        findViewById(R.id.btnStroke).setOnClickListener(v -> {
            strokeMode = (strokeMode + 1) % 3;
            if (strokeMode == 0) canvas.setTextStroke(0f, Color.BLACK);
            else if (strokeMode == 1) canvas.setTextStroke(2f, Color.WHITE);
            else canvas.setTextStroke(3f, Color.BLACK);
            ((TextView) findViewById(R.id.btnStroke)).setText(
                    new String[]{"描边·无", "描边·白", "描边·黑"}[strokeMode]);
        });
        findViewById(R.id.btnTextBg).setOnClickListener(v -> {
            textBgMode = (textBgMode + 1) % 4;
            int[] colors = {0, 0x66000000, 0x99000000, 0x66FFFFFF};
            float pad = 8f;
            canvas.setTextBg(colors[textBgMode], pad);
            ((TextView) findViewById(R.id.btnTextBg)).setText(
                    new String[]{"底色·无", "底色·黑 40%", "底色·黑 60%", "底色·白 40%"}[textBgMode]);
            toast(textBgMode == 0 ? "已去掉文字底色" : "已应用文字底色");
        });
        findViewById(R.id.btnShadow).setOnClickListener(v -> {
            shadowOn = !shadowOn;
            canvas.setTextShadow(shadowOn);
            ((TextView) findViewById(R.id.btnShadow)).setText(shadowOn ? "阴影·开" : "阴影·关");
        });
        findViewById(R.id.btnAlign).setOnClickListener(v -> {
            alignIndex = (alignIndex + 1) % 3;
            canvas.setTextAlign(alignIndex);
            ((TextView) findViewById(R.id.btnAlign)).setText(
                    new String[]{"对齐·左", "对齐·中", "对齐·右"}[alignIndex]);
        });

        SeekBar seek = findViewById(R.id.seekTextSize);
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar sb, int p, boolean fromUser) {
                canvas.setTextSizeDp(10 + p * 0.9f);
            }

            @Override public void onStartTrackingTouch(SeekBar sb) {}
            @Override public void onStopTrackingTouch(SeekBar sb) {}
        });
    }

    private void askText() {
        EditText input = new EditText(this);
        input.setHint("输入要添加的文字");
        input.setTextColor(Color.WHITE);
        input.setHintTextColor(0x88FFFFFF);
        input.setInputType(InputType.TYPE_CLASS_TEXT);
        FrameLayout wrap = new FrameLayout(this);
        wrap.setPadding(dp(16), dp(8), dp(16), 0);
        wrap.addView(input);
        new AlertDialog.Builder(this)
                .setTitle("添加文字")
                .setView(wrap)
                .setNegativeButton("取消", null)
                .setPositiveButton("添加", (d, w) -> {
                    canvas.addText(input.getText().toString());
                    SeekBar seek = findViewById(R.id.seekTextSize);
                    canvas.setTextSizeDp(10 + seek.getProgress() * 0.9f);
                    canvas.setTextTypeface(fontIndex);
                    canvas.setTextAlign(alignIndex);
                    refreshLayers();
                })
                .show();
    }

    // ---------------- 贴纸 ----------------

    private void onStickerPicked(Uri uri) {
        if (uri == null) return;
        try {
            getContentResolver().takePersistableUriPermission(uri,
                    android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } catch (Throwable t) {
            ExportDiag.warn("sticker_saf", t);
        }
        Work.run(this, () -> {
            try {
                Bitmap bmp = BitmapUtils.load(this, uri, 1024);
                runOnUiThread(() -> {
                    canvas.addSticker(bmp);
                    refreshLayers();
                    toast("贴纸已添加，可双指缩放旋转");
                });
            } catch (Exception e) {
                runOnUiThread(() -> toast("贴纸加载失败：" + e.getMessage()));
            }
        });
    }

    private static final java.util.concurrent.ExecutorService STICKER_EXEC =
            java.util.concurrent.Executors.newSingleThreadExecutor();

    /** 贴纸面板：底部弹层 + 搜索 + 最近使用 + 分类 Tab + 5 列网格。 */
    private void openStickerLibrary() {
        final com.google.android.material.bottomsheet.BottomSheetDialog sheet =
                new com.google.android.material.bottomsheet.BottomSheetDialog(this);
        android.widget.LinearLayout root = new android.widget.LinearLayout(this);
        root.setOrientation(android.widget.LinearLayout.VERTICAL);
        root.setBackgroundColor(getColor(R.color.bg_s1));
        root.setPadding(dp(16), dp(12), dp(16), dp(8));

        android.widget.TextView title = new android.widget.TextView(this);
        title.setText("贴纸 · " + StickerLibrary.COUNT + " 张");
        title.setTextSize(15);
        title.setTextColor(getColor(R.color.text_1));
        root.addView(title);

        android.widget.EditText search = new android.widget.EditText(this);
        search.setHint("搜索贴纸，如：笑 / 心 / 点赞");
        search.setTextSize(13);
        search.setSingleLine(true);
        search.setTextColor(getColor(R.color.text_1));
        search.setHintTextColor(getColor(R.color.text_3));
        search.setBackgroundResource(R.drawable.bg_chip);
        search.setPadding(dp(12), dp(6), dp(12), dp(6));
        android.widget.LinearLayout.LayoutParams slp0 = new android.widget.LinearLayout.LayoutParams(
                android.view.ViewGroup.LayoutParams.MATCH_PARENT, dp(40));
        slp0.topMargin = dp(8);
        slp0.bottomMargin = dp(6);
        search.setLayoutParams(slp0);
        root.addView(search);

        android.widget.HorizontalScrollView tabScroll = new android.widget.HorizontalScrollView(this);
        tabScroll.setHorizontalScrollBarEnabled(false);
        android.widget.LinearLayout tabRow = new android.widget.LinearLayout(this);
        tabRow.setOrientation(android.widget.LinearLayout.HORIZONTAL);
        tabScroll.addView(tabRow);
        root.addView(tabScroll);

        android.widget.ScrollView scroll = new android.widget.ScrollView(this);
        android.widget.GridLayout grid = new android.widget.GridLayout(this);
        grid.setColumnCount(5);
        grid.setPadding(0, dp(10), 0, dp(4));
        scroll.addView(grid);
        android.widget.LinearLayout.LayoutParams slp = new android.widget.LinearLayout.LayoutParams(
                android.view.ViewGroup.LayoutParams.MATCH_PARENT, dp(300));
        slp.topMargin = dp(8);
        scroll.setLayoutParams(slp);
        root.addView(scroll);

        final int[] currentCat = {0}; // -1 = 最近使用
        final String[] query = {""};

        final Runnable[] refresh = new Runnable[1];
        refresh[0] = () -> {
            grid.removeAllViews();
            java.util.List<Integer> ids = new java.util.ArrayList<>();
            String q = query[0].trim();
            if (!q.isEmpty()) {
                for (int i = 0; i < StickerLibrary.COUNT; i++) {
                    if (StickerLibrary.NAMES[i].contains(q)) ids.add(i);
                }
            } else if (currentCat[0] == -1) {
                ids.addAll(StickerLibrary.recent(this));
            } else {
                int start = StickerLibrary.CATEGORY_START[currentCat[0]];
                int end = currentCat[0] + 1 < StickerLibrary.CATEGORY_START.length
                        ? StickerLibrary.CATEGORY_START[currentCat[0] + 1] : StickerLibrary.COUNT;
                for (int i = start; i < end; i++) ids.add(i);
            }
            if (ids.isEmpty()) {
                android.widget.TextView empty = new android.widget.TextView(this);
                empty.setText(currentCat[0] == -1 && q.isEmpty()
                        ? "还没有最近使用的贴纸，选一张就会出现在这里" : "没找到匹配的贴纸");
                empty.setTextColor(getColor(R.color.text_3));
                empty.setTextSize(13);
                empty.setPadding(dp(6), dp(16), dp(6), dp(6));
                grid.addView(empty);
                return;
            }
            for (final int idx : ids) {
                android.widget.FrameLayout cell = new android.widget.FrameLayout(this);
                android.widget.GridLayout.LayoutParams glp = new android.widget.GridLayout.LayoutParams(
                        android.widget.GridLayout.spec(android.widget.GridLayout.UNDEFINED, 1f),
                        android.widget.GridLayout.spec(android.widget.GridLayout.UNDEFINED, 1f));
                glp.width = 0;
                glp.height = dp(64);
                glp.setMargins(dp(4), dp(4), dp(4), dp(4));
                cell.setLayoutParams(glp);
                cell.setBackgroundResource(R.drawable.bg_chip);

                final android.widget.ImageView iv = new android.widget.ImageView(this);
                android.widget.FrameLayout.LayoutParams ilp = new android.widget.FrameLayout.LayoutParams(
                        android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                        android.view.ViewGroup.LayoutParams.MATCH_PARENT);
                ilp.setMargins(dp(6), dp(6), dp(6), dp(6));
                iv.setLayoutParams(ilp);
                iv.setScaleType(android.widget.ImageView.ScaleType.FIT_CENTER);
                iv.setContentDescription(StickerLibrary.NAMES[idx]);
                cell.addView(iv);

                cell.setOnClickListener(v -> {
                    Bitmap bmp = StickerLibrary.make(this, idx, 512);
                    canvas.addSticker(bmp);
                    StickerLibrary.pushRecent(this, idx);
                    refreshLayers();
                    toast(StickerLibrary.NAMES[idx] + " 已添加");
                    sheet.dismiss();
                });
                grid.addView(cell);

                STICKER_EXEC.execute(() -> {
                    Bitmap thumb = StickerLibrary.thumb(this, idx, dp(56));
                    if (thumb != null) runOnUiThread(() -> iv.setImageBitmap(thumb));
                });
            }
        };

        String[] tabNames = new String[StickerLibrary.CATEGORIES.length + 1];
        tabNames[0] = "最近";
        System.arraycopy(StickerLibrary.CATEGORIES, 0, tabNames, 1, StickerLibrary.CATEGORIES.length);
        for (int c = 0; c < tabNames.length; c++) {
            final int tabIndex = c;
            final int catValue = c == 0 ? -1 : c - 1;
            android.widget.TextView tab = new android.widget.TextView(this);
            tab.setText(tabNames[c]);
            tab.setTextSize(13);
            tab.setGravity(android.view.Gravity.CENTER);
            tab.setPadding(dp(14), 0, dp(14), 0);
            android.widget.LinearLayout.LayoutParams tlp =
                    new android.widget.LinearLayout.LayoutParams(
                            android.view.ViewGroup.LayoutParams.WRAP_CONTENT, dp(34));
            tlp.rightMargin = dp(8);
            tab.setLayoutParams(tlp);
            tab.setOnClickListener(v -> {
                currentCat[0] = catValue;
                for (int k = 0; k < tabRow.getChildCount(); k++) {
                    android.widget.TextView t = (android.widget.TextView) tabRow.getChildAt(k);
                    boolean on = k == tabIndex;
                    t.setBackgroundResource(on ? R.drawable.bg_pill_accent : R.drawable.bg_chip);
                    t.setTextColor(getColor(on ? R.color.accent : R.color.text_2));
                }
                refresh[0].run();
            });
            boolean on = c == 0;
            tab.setBackgroundResource(on ? R.drawable.bg_pill_accent : R.drawable.bg_chip);
            tab.setTextColor(getColor(on ? R.color.accent : R.color.text_2));
            tabRow.addView(tab);
        }

        search.addTextChangedListener(new android.text.TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) {
                query[0] = s == null ? "" : s.toString();
                refresh[0].run();
            }
            @Override public void afterTextChanged(android.text.Editable s) { }
        });

        android.widget.TextView close = new android.widget.TextView(this);
        close.setText("关闭");
        close.setTextSize(13);
        close.setTextColor(getColor(R.color.text_3));
        close.setGravity(android.view.Gravity.CENTER);
        close.setPadding(0, dp(10), 0, dp(6));
        close.setOnClickListener(v -> sheet.dismiss());
        root.addView(close);

        refresh[0].run();
        sheet.setContentView(root);
        sheet.show();
    }

    /** 贴纸的显式大小 / 旋转滑杆：不靠双指也能精确改尺寸。 */
    private void setupStickerTransform() {
        final SeekBar size = findViewById(R.id.seekStickerSize);
        final SeekBar rot = findViewById(R.id.seekStickerRot);
        final TextView sizeVal = findViewById(R.id.tvStickerSizeVal);
        final TextView rotVal = findViewById(R.id.tvStickerRotVal);

        size.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar sb, int p, boolean fromUser) {
                sizeVal.setText(Math.max(3, p) + "%");
                if (!fromUser) return;
                if (!canvas.hasSelectedSticker()) return;
                canvas.setSelectedStickerWidthRatio(Math.max(3, p) / 100f);
            }

            @Override
            public void onStartTrackingTouch(SeekBar sb) {
                if (canvas.hasSelectedSticker()) canvas.pushHistory();
                else toast("先点选一个贴纸，再拖这根杆");
            }

            @Override public void onStopTrackingTouch(SeekBar sb) { }
        });

        rot.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar sb, int p, boolean fromUser) {
                int deg = p - 180;
                rotVal.setText(deg + "°");
                if (!fromUser || canvas.getSelected() == null) return;
                canvas.setSelectedRotationDeg(deg);
            }

            @Override
            public void onStartTrackingTouch(SeekBar sb) {
                if (canvas.getSelected() != null) canvas.pushHistory();
                else toast("先点选一个图层，再拖这根杆");
            }

            @Override public void onStopTrackingTouch(SeekBar sb) { }
        });
    }

    /** 选中对象变化后，把滑杆拨到当前值（没选中就恢复到默认并置灰）。 */
    private void syncStickerTransform() {
        SeekBar size = findViewById(R.id.seekStickerSize);
        SeekBar rot = findViewById(R.id.seekStickerRot);
        TextView sizeVal = findViewById(R.id.tvStickerSizeVal);
        TextView rotVal = findViewById(R.id.tvStickerRotVal);
        if (size == null || rot == null) return;
        boolean has = canvas.hasSelectedSticker();
        size.setEnabled(has);
        rot.setEnabled(canvas.getSelected() != null);
        if (has) {
            int p = Math.round(canvas.getSelectedStickerWidthRatio() * 100f);
            p = Math.max(3, Math.min(160, p));
            size.setProgress(p);
            sizeVal.setText(p + "%");
        }
        if (canvas.getSelected() != null) {
            int deg = Math.round(canvas.getSelectedRotationDeg());
            while (deg > 180) deg -= 360;
            while (deg < -180) deg += 360;
            rot.setProgress(deg + 180);
            rotVal.setText(deg + "°");
        }
    }

    // ---------------- 涂鸦 / 马赛克 ----------------

    private void buildColorRows() {
        int[] colors = {Color.WHITE, 0xFF111111, 0xFFFF5A5A, getColor(R.color.accent), 0xFF4D9BFF, getColor(R.color.warn)};
        for (int c : colors) {
            rowDrawColors.addView(colorDot(c, color -> canvas.setDrawColor(color)));
            rowTextColors.addView(colorDot(c, color -> canvas.setTextColor(color)));
        }
        findViewById(R.id.btnAddSticker).setOnClickListener(v -> stickerPicker.launch(new String[]{"image/*"}));
        setupStickerTransform();
        findViewById(R.id.btnBuiltinSticker).setOnClickListener(v -> openStickerLibrary());
        findViewById(R.id.btnSignature).setOnClickListener(v -> signaturePicker.launch(
                new android.content.Intent(this, SignatureActivity.class)));
        findViewById(R.id.btnSavePreset).setOnClickListener(v -> savePreset());
        findViewById(R.id.btnUsePreset).setOnClickListener(v -> showPresetList());
    }

    private void setupDraw() {
        findViewById(R.id.btnClearDraw).setOnClickListener(v -> {
            if (!canvas.undoStroke()) toast("没有可撤销的笔画");
            else refreshLayers();
        });
        SeekBar seek = findViewById(R.id.seekBrush);
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar sb, int p, boolean fromUser) {
                canvas.setDrawWidthDp(1 + p);
            }

            @Override public void onStartTrackingTouch(SeekBar sb) {}
            @Override public void onStopTrackingTouch(SeekBar sb) {}
        });
    }

    private int mosaicStyle = 0;

    private void setupMosaic() {
        SeekBar seek = findViewById(R.id.seekMosaic);
        SeekBar brush = findViewById(R.id.seekMosaicBrush);
        final java.util.List<TextView> typeChips = new java.util.ArrayList<>();
        String[] typeNames = {"像素块", "磨砂模糊", "色块遮挡"};
        for (int i = 0; i < typeNames.length; i++) {
            final int idx = i;
            TextView tv = makeChip(typeNames[i], i == 0);
            tv.setOnClickListener(v -> {
                mosaicStyle = idx;
                for (int k = 0; k < typeChips.size(); k++) styleChip(typeChips.get(k), k == mosaicStyle);
                canvas.setMosaicStyle(mosaicStyle, seek.getProgress(), brush.getProgress());
            });
            ((android.widget.LinearLayout) findViewById(R.id.rowMosaicTypes)).addView(tv);
            typeChips.add(tv);
        }

        canvas.setMosaicStyle(mosaicStyle, seek.getProgress(), brush.getProgress());
        SeekBar.OnSeekBarChangeListener l = new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar sb, int p, boolean fromUser) {
                canvas.setMosaicStyle(mosaicStyle, Math.max(4, seek.getProgress()),
                        Math.max(6, brush.getProgress()));
            }

            @Override public void onStartTrackingTouch(SeekBar sb) {}
            @Override public void onStopTrackingTouch(SeekBar sb) {}
        };
        seek.setOnSeekBarChangeListener(l);
        brush.setOnSeekBarChangeListener(l);
        findViewById(R.id.btnClearMosaic).setOnClickListener(v -> {
            boolean removed = false;
            List<EditImageView.Layer> layers = canvas.getLayers();
            for (int i = layers.size() - 1; i >= 0; i--) {
                if (layers.get(i).type == EditImageView.LayerType.MOSAIC) {
                    canvas.selectLayer(i);
                    canvas.deleteSelected();
                    removed = true;
                    break;
                }
            }
            if (!removed) toast("没有马赛克可撤销");
            refreshLayers();
        });
    }

    // ---------------- 图层 ----------------

    private void setupLayers() {
        findViewById(R.id.btnLayerUp).setOnClickListener(v -> {
            EditImageView.Layer cur = canvas.getSelected();
            if (cur == null) { toast("先点上面的图层标签，或直接点画面里的文字/贴纸"); return; }
            if (cur.type == EditImageView.LayerType.MOSAIC) { toast("马赛克锁定在底图上，不能上下移"); return; }
            int before = canvas.selectedIndex();
            canvas.moveSelected(true);
            refreshLayers();
            toast(canvas.selectedIndex() != before ? "已上移" : "已经在最上层");
        });
        findViewById(R.id.btnLayerDown).setOnClickListener(v -> {
            EditImageView.Layer cur = canvas.getSelected();
            if (cur == null) { toast("先点上面的图层标签，或直接点画面里的文字/贴纸"); return; }
            if (cur.type == EditImageView.LayerType.MOSAIC) { toast("马赛克锁定在底图上，不能上下移"); return; }
            int before = canvas.selectedIndex();
            canvas.moveSelected(false);
            refreshLayers();
            toast(canvas.selectedIndex() != before ? "已下移" : "已经在最下层");
        });
        findViewById(R.id.btnLayerDelete).setOnClickListener(v -> {
            EditImageView.Layer cur = canvas.getSelected();
            if (cur == null) { toast("先点上面的图层标签，或直接点画面里的文字/贴纸"); return; }
            String name = cur.type == EditImageView.LayerType.TEXT ? "文字"
                    : cur.type == EditImageView.LayerType.STICKER ? "贴纸"
                    : cur.type == EditImageView.LayerType.MOSAIC ? "马赛克" : "涂鸦";
            canvas.deleteSelected();
            refreshLayers();
            toast("已删除这个" + name);
        });
        SeekBar alpha = findViewById(R.id.seekLayerAlpha);
        alpha.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar sb, int p, boolean fromUser) {
                if (fromUser) canvas.setSelectedAlpha(p / 100f);
            }

            @Override public void onStartTrackingTouch(SeekBar sb) {
                if (canvas.getSelected() == null) toast("先选中一个图层再调透明度");
            }
            @Override public void onStopTrackingTouch(SeekBar sb) {}
        });

        final TextView multi = findViewById(R.id.btnMultiSelect);
        multi.setOnClickListener(v -> {
            multiSelect = !multiSelect;
            pickedLayers.clear();
            styleChip(multi, multiSelect);
            multi.setText(multiSelect ? "多选中" : "多选");
            refreshLayers();
            toast(multiSelect ? "多选：点图层标签勾选，再编组/删除" : "已退出多选");
        });

        findViewById(R.id.btnGroup).setOnClickListener(v -> {
            List<Integer> ids = new ArrayList<>(pickedLayers);
            if (ids.isEmpty()) {
                int cur = canvas.selectedIndex();
                if (cur < 0) { toast("先勾选要编组的图层"); return; }
                ids.add(cur);
            }
            if (ids.size() < 2) { toast("至少勾两个图层才能编组"); return; }
            canvas.groupIndexes(ids);
            multiSelect = false;
            pickedLayers.clear();
            styleChip(multi, false);
            multi.setText("多选");
            refreshLayers();
            toast("已编组 " + ids.size() + " 个图层，拖一个整组一起动");
        });

        findViewById(R.id.btnUngroup).setOnClickListener(v -> {
            if (canvas.getSelected() == null) { toast("先选中一个编组里的图层"); return; }
            toast(canvas.ungroupSelected() ? "已解组，图层恢复独立" : "这个图层没有编组");
            refreshLayers();
        });

        findViewById(R.id.btnDeletePicked).setOnClickListener(v -> {
            List<Integer> ids = new ArrayList<>(pickedLayers);
            if (ids.isEmpty()) { toast("先勾选要删除的图层"); return; }
            canvas.deleteIndexes(ids);
            pickedLayers.clear();
            refreshLayers();
            toast("已删除 " + ids.size() + " 个图层");
        });

        setupMaskRow();
        setupViewZoomChip();
    }

    /** 蒙版：无 / 矩形 / 圆形 / 线性，加羽化和范围。 */
    private void setupMaskRow() {
        String[] names = {"无", "矩形", "圆形", "线性"};
        LinearLayout row = findViewById(R.id.rowMaskTypes);
        if (row == null) return;
        List<TextView> chips = new ArrayList<>();
        for (int i = 0; i < names.length; i++) {
            final int idx = i;
            TextView tv = makeChip(names[i], i == 0);
            tv.setOnClickListener(v -> {
                if (canvas.getSelected() == null) { toast("先选中一个图层再加蒙版"); return; }
                for (int k = 0; k < chips.size(); k++) styleChip(chips.get(k), k == idx);
                canvas.setSelectedMaskType(idx);
                toast(idx == 0 ? "已去掉蒙版" : names[idx] + " 蒙版已应用");
            });
            row.addView(tv);
            chips.add(tv);
        }

        SeekBar feather = findViewById(R.id.seekMaskFeather);
        feather.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar sb, int p, boolean fromUser) {
                if (fromUser) canvas.setSelectedMaskFeather(p / 100f);
            }
            @Override public void onStartTrackingTouch(SeekBar sb) { }
            @Override public void onStopTrackingTouch(SeekBar sb) { }
        });
        SeekBar inset = findViewById(R.id.seekMaskInset);
        inset.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar sb, int p, boolean fromUser) {
                if (fromUser) canvas.setSelectedMaskInset(p / 100f);
            }
            @Override public void onStartTrackingTouch(SeekBar sb) { }
            @Override public void onStopTrackingTouch(SeekBar sb) { }
        });
    }

    /** 画面缩放：进入后单指平移、双指放大到 6 倍看细节，再点一次还原。 */
    private void setupViewZoomChip() {
        TextView tv = makeChip("画面缩放", false);
        tv.setOnClickListener(v -> {
            boolean on = !canvas.isViewZoomMode();
            canvas.setViewZoomMode(on);
            styleChip(tv, on);
            if (on) {
                showHint("画面缩放：双指放大看细节（最多 6 倍）、单指平移；再点一次还原");
                toast("已进入画面缩放，不影响图层大小");
            } else {
                toast("画面已还原");
            }
        });
        toolRow2.addView(tv);
    }

    private void refreshLayers() {
        if (rowLayers == null) return;
        rowLayers.removeAllViews();
        List<EditImageView.Layer> layers = canvas.getLayers();
        int selectedIndex = canvas.selectedIndex();
        syncStickerTransform();
        TextView status = findViewById(R.id.tvLayerStatus);
        if (status != null) {
            if (layers.isEmpty()) {
                status.setText("共 0 个图层 · 先用 文字 / 贴纸 / 涂鸦 / 马赛克 添加内容");
            } else if (selectedIndex < 0) {
                status.setText("共 " + layers.size() + " 个图层 · 未选中，点下面的标签或直接点画面里的内容");
            } else {
                EditImageView.Layer sel = layers.get(selectedIndex);
                String name = sel.type == EditImageView.LayerType.TEXT ? "文字"
                        : sel.type == EditImageView.LayerType.STICKER ? "贴纸"
                        : sel.type == EditImageView.LayerType.MOSAIC ? "马赛克（锁定位置）" : "涂鸦";
                status.setText("共 " + layers.size() + " 个图层 · 当前选中："
                        + (selectedIndex + 1) + " " + name);
            }
        }
        if (layers.isEmpty()) {
            TextView tv = new TextView(this);
            tv.setText("暂无图层，先用文字/贴纸/涂鸦添加内容");
            tv.setTextColor(getColor(R.color.text_2));
            tv.setTextSize(12);
            tv.setPadding(0, dp(8), 0, dp(8));
            rowLayers.addView(tv);
            return;
        }
        for (int i = layers.size() - 1; i >= 0; i--) {
            final int idx = i;
            EditImageView.Layer l = layers.get(i);
            String typeName;
            if (l.type == EditImageView.LayerType.TEXT) typeName = "文字";
            else if (l.type == EditImageView.LayerType.STICKER) typeName = "贴纸";
            else if (l.type == EditImageView.LayerType.STROKE) typeName = "涂鸦";
            else if (l.type == EditImageView.LayerType.MOSAIC) typeName = "马赛克·锁";
            else typeName = "形状";
            final int groupId = l.groupId;
            boolean picked = pickedLayers.contains(i);
            String label = (groupId != 0 ? "[组] " : "") + (picked ? "✓ " : "") + (i + 1) + " " + typeName;
            TextView tv = makeChip(label, picked || idx == selectedIndex);
            tv.setOnClickListener(v -> {
                if (multiSelect) {
                    if (!pickedLayers.remove(idx)) pickedLayers.add(idx);
                    refreshLayers();
                    return;
                }
                canvas.selectLayer(idx);
                // 编组里的成员被点中时提示一下，避免"为什么一整块都在动"的疑惑
                if (groupId != 0) toast("这个图层在编组里，拖动会整组一起动");
                refreshLayers();
            });
            rowLayers.addView(tv);
        }
    }

    // ---------------- 形状标注 ----------------

    private static final String[] SHAPE_LABELS = {"箭头", "矩形", "圆形", "直线"};

    private void setupShapes() {
        LinearLayout row = findViewById(R.id.rowShapes);
        List<TextView> chips = new ArrayList<>();
        for (int i = 0; i < SHAPE_LABELS.length; i++) {
            final int idx = i;
            TextView tv = makeChip(SHAPE_LABELS[i], i == 3);
            tv.setOnClickListener(v -> {
                for (int k = 0; k < chips.size(); k++) styleChip(chips.get(k), k == idx);
                canvas.setShapeType(idx == 0 ? 3 : (idx == 1 ? 0 : (idx == 2 ? 1 : 2)));
                canvas.setMode(EditImageView.Mode.SHAPE);
                setToolSelected("涂鸦");
                showOnly(panelDraw);
                showHint(SHAPE_LABELS[idx] + "：在画面上按住拖出形状");
            });
            row.addView(tv);
            chips.add(tv);
        }
    }

    // ---------------- 微调旋转 ----------------

    private void setupFineRotate() {
        SeekBar seek = findViewById(R.id.seekFineRotate);
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar sb, int p, boolean fromUser) {
                canvas.setFineRotation((p - 30) * 1f);
            }

            @Override public void onStartTrackingTouch(SeekBar sb) {}

            @Override
            public void onStopTrackingTouch(SeekBar sb) {
                canvas.commitFineRotation();
                seek.setProgress(30);
                refreshLayers();
            }
        });
        findViewById(R.id.btnApplyFineRotate).setOnClickListener(v -> {
            canvas.commitFineRotation();
            seek.setProgress(30);
            refreshLayers();
            toast("已应用微调角度");
        });
    }

    // ---------------- 混合模式 ----------------

    private static final String[] BLEND_LABELS = {"正常", "正片叠底", "滤色", "叠加"};

    private void setupBlend() {
        LinearLayout row = findViewById(R.id.rowBlend);
        List<TextView> chips = new ArrayList<>();
        for (int i = 0; i < BLEND_LABELS.length; i++) {
            final int idx = i;
            TextView tv = makeChip(BLEND_LABELS[i], i == 0);
            tv.setOnClickListener(v -> {
                if (canvas.getSelected() == null) {
                    toast("请先点选一个图层");
                    return;
                }
                for (int k = 0; k < chips.size(); k++) styleChip(chips.get(k), k == idx);
                canvas.setSelectedBlend(idx);
            });
            row.addView(tv);
            chips.add(tv);
        }
    }

    // ---------------- 相框模板 ----------------

    private static final String[] FRAME_LABELS = {"无框", "拍立得", "白细框", "胶片黑"};

    private void setupFrames() {
        LinearLayout row = findViewById(R.id.rowFrames);
        for (int i = 1; i < FRAME_LABELS.length; i++) {
            final int style = i;
            TextView tv = makeChip(FRAME_LABELS[i], false);
            tv.setOnClickListener(v -> {
                int color;
                if (style == 1) color = 0xFFFFFFFF;
                else if (style == 2) color = 0xFFFFFFFF;
                else color = 0xFF111111;
                int frameStyle = style == 2 ? 4 : style;
                canvas.applyFrame(frameStyle, color);
                refreshLayers();
                toast(FRAME_LABELS[style] + " 已套用");
            });
            row.addView(tv);
        }
    }

    // ---------------- 边框 ----------------

    private static final int[] BORDER_COLORS = {0, Color.WHITE, Color.BLACK, 0xFFF2E3C6, 0xFF3A3A3A};

    private void setupBorder() {
        String[] labels = {"无", "白", "黑", "米金", "深灰"};
        for (int i = 0; i < BORDER_COLORS.length; i++) {
            final int idx = i;
            TextView tv = makeChip(labels[i], i == 0);
            tv.setOnClickListener(v -> {
                for (int k = 0; k < borderChips.size(); k++) {
                    styleChip(borderChips.get(k), k == idx);
                }
                SeekBar seek = findViewById(R.id.seekBorder);
                int w = Math.max(3, seek.getProgress());
                canvas.setBorder(BORDER_COLORS[idx], idx == 0 ? 0f : w);
                if (idx != 0) seek.setProgress(w);
            });
            rowBorderColors.addView(tv);
            borderChips.add(tv);
        }
        SeekBar seek = findViewById(R.id.seekBorder);
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar sb, int p, boolean fromUser) {
                int color = BORDER_COLORS[0];
                for (int i = 0; i < borderChips.size(); i++) {
                    if (borderChips.get(i).getPaint().isFakeBoldText()) color = BORDER_COLORS[i];
                }
                if (color == 0) {
                    canvas.setBorder(0, 0f);
                } else {
                    canvas.setBorder(color, p <= 0 ? 0f : Math.max(3, p));
                }
            }

            @Override public void onStartTrackingTouch(SeekBar sb) {}
            @Override public void onStopTrackingTouch(SeekBar sb) {}
        });
    }

    // ---------------- 裁剪 ----------------

    private static final String[] ASPECT_LABELS = {"自由", "1:1", "4:3", "3:4", "16:9", "9:16"};
    private static final float[] ASPECT_RATIOS = {0f, 1f, 4f / 3f, 3f / 4f, 16f / 9f, 9f / 16f};

    private void buildAspectChips() {
        for (int i = 0; i < ASPECT_LABELS.length; i++) {
            final float ratio = ASPECT_RATIOS[i];
            final int pos = i;
            TextView tv = makeChip(ASPECT_LABELS[i], i == 0);
            tv.setOnClickListener(v -> {
                for (int k = 0; k < aspectChips.size(); k++) {
                    styleChip(aspectChips.get(k), k == pos);
                }
                canvas.setCropAspect(ratio);
            });
            rowCropAspect.addView(tv);
            aspectChips.add(tv);
        }
    }

    private void bindCropButtons() {
        findViewById(R.id.btnCropApply).setOnClickListener(v -> {
            canvas.applyCrop();
            toast("已裁剪");
            canvas.setMode(EditImageView.Mode.NONE);
        });
        findViewById(R.id.btnCropCancel).setOnClickListener(v -> {
            canvas.cancelCrop();
            setToolSelected("");
            showOnly(null);
        });
    }

    // ---------------- 加载 / 重置 / 保存 ----------------

    @Override
    protected void onDestroy() {
        Work.cancelOwner(this);
        super.onDestroy();
    }

    @Override
    protected void onPause() {
        super.onPause();
        // 切后台/被系统回收前，把当前画面拍平成草稿，回来可继续
        if (!saving && !restoring) {
            // 底图只烘涂鸦/马赛克/形状，文字与贴纸单独存 JSON，恢复后可继续编辑
            Bitmap flat = canvas.renderExcludingTextSticker();
            if (flat != null) {
                final Bitmap out = flat;
                final java.util.List<EditImageView.Layer> keep = canvas.textAndStickerLayers();
                final Uri src = sourceUri;
                Work.run(this, () -> {
                    ImageDraft.saveLayered(this, src, out, keep);
                    if (!out.isRecycled()) out.recycle();
                });
            }
            // 草稿拍完就把整图缓存放掉，闲时不再占几十 MB（P0-1）
            canvas.releaseCaches();
        }
    }

    @Override
    public void onTrimMemory(int level) {
        super.onTrimMemory(level);
        // 系统内存吃紧：立刻把马赛克/模糊整图缓存交出去（P0-1）
        if (level >= TRIM_MEMORY_RUNNING_LOW) canvas.releaseCaches();
    }

    private void maybeOfferDraft() {
        if (restoring || !ImageDraft.has(this, sourceUri)) return;
        new AlertDialog.Builder(this)
                .setTitle("发现未完成的编辑")
                .setMessage("上次退出时还有未保存的编辑，要继续吗？\n（恢复后图层会合并成一张图，继续在此基础上编辑）")
                .setPositiveButton("继续编辑", (d, w) -> restoreDraft())
                .setNegativeButton("从原图开始", (d, w) -> ImageDraft.clear(this))
                .show();
    }

    private void restoreDraft() {
        Work.run(this, () -> {
            Bitmap bmp = ImageDraft.load(this);
            runOnUiThread(() -> {
                if (bmp == null) {
                    toast("草稿读取失败，已从原图开始");
                    return;
                }
                restoring = true;
                original = bmp;
                canvas.setBitmap(bmp);
                canvas.clearHistory();
                for (EditImageView.Layer l : ImageDraft.loadLayers(this)) {
                    canvas.addRestoredLayer(l);
                }
                filterIndex = 0;
                filterStrength = 1f;
                brightness = contrast = saturation = temperature = hue = fade = 0f;
                canvas.setColorMatrix(new ColorMatrix());
                ImageDraft.clear(this);
                restoring = false;
                toast("已恢复上次编辑");
            });
        });
    }

    private void load() {
        ImageDraft.prune(this);
        progress.setVisibility(View.VISIBLE);
        Work.run(this, () -> {
            try {
                Bitmap bmp = BitmapUtils.load(this, sourceUri, BitmapUtils.safeMaxDim());
                runOnUiThread(() -> {
                    original = bmp;
                    canvas.setBitmap(bmp);
                    progress.setVisibility(View.GONE);
                    setToolSelected("");
                    buildFilterChips();
                    styleFilterChips();
                    onTool("滤镜");
                    maybeOfferDraft();
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    progress.setVisibility(View.GONE);
                    toast("打开失败：" + e.getMessage());
                    finish();
                });
            }
        });
    }

    private void reloadOriginal() {
        if (original == null) return;
        canvas.setBitmap(original);
        filterIndex = 0;
        brightness = contrast = saturation = temperature = 0f;
        canvas.setBorder(0, 0f);
        styleFilterChips();
        for (int k = 0; k < borderChips.size(); k++) styleChip(borderChips.get(k), k == 0);
        ((SeekBar) findViewById(R.id.seekBorder)).setProgress(0);
        ((SeekBar) findViewById(R.id.seekBrightness)).setProgress(100);
        ((SeekBar) findViewById(R.id.seekContrast)).setProgress(100);
        ((SeekBar) findViewById(R.id.seekSaturation)).setProgress(100);
        ((SeekBar) findViewById(R.id.seekTemperature)).setProgress(100);
        refreshLayers();
        applyColor();
        toast("已重置为原图");
    }

    /** 编辑过但没保存就返回时，先问一句，避免用户的活儿白做。 */
    private void confirmExit() {
        if (!hasAnyEdit() || savedOnce) {
            finish();
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle("还没保存")
                .setMessage("当前的修改还没导出，确定要离开吗？")
                .setPositiveButton("保存后离开", (d, w) -> {
                    leaveAfterSave = true;
                    saveImage();
                })
                .setNegativeButton("直接离开", (d, w) -> finish())
                .setNeutralButton("继续编辑", null)
                .show();
    }

    private boolean hasAnyEdit() {
        return filterIndex != 0 || canvas.getLayerCount() > 0
                || canvas.getVignette() > 0.01f || canvas.getGradientStrength() > 0.01f
                || wmText != null || canvas.getBorderWidth() > 0f;
    }

    @Override
    public void onBackPressed() {
        confirmExit();
    }

    private void saveImage() {
        if (original == null) {
            toast("图片还没加载好");
            return;
        }
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P
                && ContextCompat.checkSelfPermission(this, android.Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
            pendingSave = this::saveImage;
            requestPermissions(new String[]{android.Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQ_WRITE);
            return;
        }
        askQualityThenSave();
    }

    /** 让用户选质量，并在保存前给出真实体积预估（不是估公式，是实际压一遍量字节）。 */
    private void askQualityThenSave() {
        int[] qualities = {95, 85, 72};
        String[] labels = {"原画质 95", "推荐 85", "小体积 72"};
        android.app.AlertDialog.Builder b = new android.app.AlertDialog.Builder(this);
        b.setTitle("导出质量");
        b.setItems(labels, (d, which) -> estimateAndSave(qualities[which]));
        b.setNegativeButton("取消", null);
        b.show();
    }

    private void estimateAndSave(int quality) {
        progress.setVisibility(View.VISIBLE);
        tvHint.setText("正在估算体积…");
        tvHint.setVisibility(View.VISIBLE);
        Work.run(this, () -> {
            Bitmap out;
            int estKB = 0;
            try {
                out = canvas.render();
                if (out == null) throw new Exception("内存不足，请先关闭其他应用再试");
                java.io.ByteArrayOutputStream probe = new java.io.ByteArrayOutputStream();
                out.compress(Bitmap.CompressFormat.JPEG, quality, probe);
                estKB = probe.size() / 1024;
                probe.reset();
            } catch (Exception e) {
                runOnUiThread(() -> {
                    progress.setVisibility(View.GONE);
                    hideHint();
                    toast("渲染失败：" + e.getMessage());
                });
                return;
            }
            final int size = estKB;
            runOnUiThread(() -> {
                hideHint();
                new android.app.AlertDialog.Builder(this)
                        .setTitle("确认导出")
                        .setMessage("尺寸 " + out.getWidth() + " × " + out.getHeight()
                                + "\n质量 " + quality + "，预计约 " + fmtSize(size))
                        .setNegativeButton("再想想", (d2, w2) -> {
                            progress.setVisibility(View.GONE);
                            // 用户放弃保存，全尺寸位图立刻释放，不等 GC
                            if (!out.isRecycled()) out.recycle();
                        })
                        .setPositiveButton("保存", (d2, w2) -> doSave(out, quality))
                        .show();
            });
        });
    }

    private String fmtSize(int kb) {
        if (kb >= 1024) return String.format(java.util.Locale.US, "%.1f MB", kb / 1024f);
        return kb + " KB";
    }

    private void doSave(Bitmap out, int quality) {
        if (saving) return;
        saving = true;
        Work.run(this, () -> {
            try {
                String name = "FC_" + System.currentTimeMillis() + ".jpg";
                Uri saved = BitmapUtils.saveImage(this, out, name, quality);
                HistoryStore.add(this, "image", name, saved);
                runOnUiThread(() -> {
                    progress.setVisibility(View.GONE);
                    saving = false;
                    savedOnce = true;
        ImageDraft.clear(this);
                    toast("已保存到相册 Pictures/LocalVideo");
                    if (leaveAfterSave) finish();
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    progress.setVisibility(View.GONE);
                    saving = false;
                    toast("保存失败：" + e.getMessage());
                });
            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int code, @NonNull String[] p, @NonNull int[] r) {
        super.onRequestPermissionsResult(code, p, r);
        if (code == REQ_WRITE && pendingSave != null) {
            if (r.length > 0 && r[0] == PackageManager.PERMISSION_GRANTED) pendingSave.run();
            else toast("需要存储权限才能保存");
            pendingSave = null;
        }
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }
}
