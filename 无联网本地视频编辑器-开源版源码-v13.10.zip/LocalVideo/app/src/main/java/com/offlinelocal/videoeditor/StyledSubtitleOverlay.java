package com.offlinelocal.videoeditor;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.text.TextPaint;

import androidx.media3.effect.BitmapOverlay;
import androidx.media3.effect.OverlaySettings;

import java.util.ArrayList;
import java.util.List;

/**
 * 可描边、可加底色的字幕叠加层。
 * TextOverlay 只会把 Spannable 画成字，做不出描边/底板；这里直接自己画位图，
 * 一部手机就能拿到"短视频字幕"该有的样子：黑描边 + 半透明底板 + 始终清晰。
 */
public class StyledSubtitleOverlay extends BitmapOverlay {

    private final List<TimedTextOverlay.Cue> cues;
    private final float textSizePx;
    private final float anchorX;
    private final float anchorY;
    private final int textColor;
    private final int strokeColor;
    private final float strokeWidthPx;
    private final int bgColor;
    /** 0 无动画 1 淡入 2 上滑淡入 */
    private final int animMode;
    private final OverlaySettings settings;

    /** 文本 → 位图缓存（最多 4 张）：字幕来回切换时避免反复重建，也不在帧处理中途回收位图 */
    private final java.util.LinkedHashMap<String, Bitmap> cache =
            new java.util.LinkedHashMap<>(8, 0.75f, true) {
                @Override
                protected boolean removeEldestEntry(java.util.Map.Entry<String, Bitmap> eldest) {
                    if (size() > 4) {
                        Bitmap b = eldest.getValue();
                        if (b != null && !b.isRecycled() && b != EMPTY) b.recycle();
                        return true;
                    }
                    return false;
                }
            };
    private static final Bitmap EMPTY;

    static {
        EMPTY = Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888);
        EMPTY.eraseColor(Color.TRANSPARENT);
    }

    public StyledSubtitleOverlay(List<TimedTextOverlay.Cue> cues, float textSizePx,
                                 float anchorX, float anchorY, int textColor,
                                 float strokeWidth, int bgColor, int animMode) {
        this.cues = cues == null ? new ArrayList<>() : new ArrayList<>(cues);
        this.textSizePx = Math.max(12f, textSizePx);
        this.anchorX = anchorX;
        this.anchorY = anchorY;
        this.textColor = textColor;
        this.strokeColor = Color.BLACK;
        this.strokeWidthPx = Math.max(0f, strokeWidth) * (this.textSizePx / 72f);
        this.bgColor = bgColor;
        this.animMode = animMode;
        this.settings = new OverlaySettings.Builder()
                .setBackgroundFrameAnchor(anchorX, anchorY)
                .setOverlayFrameAnchor(0f, 0f)
                .setAlphaScale(1f)
                .build();
    }

    private TimedTextOverlay.Cue cueAt(long ms) {
        for (TimedTextOverlay.Cue c : cues) {
            if (ms >= c.startMs && ms < c.endMs) return c;
        }
        return null;
    }

    private String textAt(long ms) {
        TimedTextOverlay.Cue c = cueAt(ms);
        return c == null || c.text == null ? "" : c.text;
    }

    @Override
    public Bitmap getBitmap(long presentationTimeUs) {
        String text = textAt(presentationTimeUs / 1000L);
        if (text.isEmpty()) return EMPTY;
        Bitmap hit = cache.get(text);
        if (hit != null && !hit.isRecycled()) return hit;

        TextPaint fill = new TextPaint(Paint.ANTI_ALIAS_FLAG);
        fill.setTypeface(Typeface.DEFAULT_BOLD);
        fill.setTextSize(textSizePx);
        fill.setColor(textColor);

        TextPaint stroke = new TextPaint(Paint.ANTI_ALIAS_FLAG);
        stroke.setTypeface(Typeface.DEFAULT_BOLD);
        stroke.setTextSize(textSizePx);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(strokeWidthPx > 0 ? strokeWidthPx : 1f);
        stroke.setColor(strokeColor);

        float pad = textSizePx * 0.35f;
        float textW = fill.measureText(text);
        int w = Math.max(2, (int) (textW + pad * 2));
        int h = Math.max(2, (int) (textSizePx * 1.5f));
        Bitmap bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bmp);
        if (Color.alpha(bgColor) > 0) {
            Paint bg = new Paint(Paint.ANTI_ALIAS_FLAG);
            bg.setColor(bgColor);
            float r = textSizePx * 0.25f;
            canvas.drawRoundRect(new RectF(0, 0, w, h), r, r, bg);
        }
        float baseline = h / 2f - (fill.descent() + fill.ascent()) / 2f;
        if (strokeWidthPx > 0) canvas.drawText(text, pad, baseline, stroke);
        canvas.drawText(text, pad, baseline, fill);

        cache.put(text, bmp);
        return bmp;
    }

    @Override
    public OverlaySettings getOverlaySettings(long presentationTimeUs) {
        long ms = presentationTimeUs / 1000L;
        TimedTextOverlay.Cue cue = cueAt(ms);
        if (cue == null || cue.text == null || cue.text.isEmpty()) {
            return new OverlaySettings.Builder()
                    .setBackgroundFrameAnchor(anchorX, anchorY)
                    .setOverlayFrameAnchor(0f, 0f)
                    .setAlphaScale(0f)
                    .build();
        }
        if (animMode == 0) return settings;
        float t = Math.min(1f, Math.max(0f, (ms - cue.startMs) / 260f));
        float y = animMode == 2 ? anchorY - 0.05f * (1f - t) : anchorY;
        return new OverlaySettings.Builder()
                .setBackgroundFrameAnchor(anchorX, y)
                .setOverlayFrameAnchor(0f, 0f)
                .setAlphaScale(t)
                .build();
    }

    @Override
    public synchronized void release() throws androidx.media3.common.VideoFrameProcessingException {
        for (Bitmap b : cache.values()) {
            if (b != null && b != EMPTY && !b.isRecycled()) b.recycle();
        }
        cache.clear();
        super.release();
    }
}
