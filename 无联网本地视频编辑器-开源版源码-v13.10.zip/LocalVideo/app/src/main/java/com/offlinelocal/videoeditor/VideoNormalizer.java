package com.offlinelocal.videoeditor;

import android.content.Context;
import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.media.MediaMuxer;
import android.net.Uri;
import android.opengl.EGL14;
import android.opengl.EGLConfig;
import android.opengl.EGLContext;
import android.opengl.EGLDisplay;
import android.opengl.EGLExt;
import android.opengl.EGLSurface;
import android.opengl.GLES11Ext;
import android.opengl.GLES20;
import android.opengl.Matrix;
import android.view.Surface;

import java.io.File;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;

/**
 * 把超大 / HDR 视频重新编码成规整的 1080p(H.264/SDR) 副本。
 *
 * 为什么需要它：Media3 的 Presentation/ScaleAndRotate 在真机上并没有改变“交给编码器的帧尺寸”，
 * 8K 源始终以 7680×4320 进编码器（真机日志可见），编码器直接 ENCODER_INIT_FAILED。
 * 这里用 MediaCodec 解码 → GL 缩放/色调映射 → MediaCodec 编码，尺寸在编码器配置阶段就锁死，绕开该问题。
 */
public final class VideoNormalizer {

    private static final String VERTEX =
            "attribute vec4 aPos;\n" +
            "attribute vec2 aTex;\n" +
            "uniform mat4 uMvp;\n" +
            "varying vec2 vTex;\n" +
            "void main() {\n" +
            "  gl_Position = aPos;\n" +
            "  vTex = (uMvp * vec4(aTex, 0.0, 1.0)).xy;\n" +
            "}\n";

    /** 近似色调映射：HDR 的 PQ/HLG 数值压回 SDR 可显示范围，避免 10bit 4:4:4 编码器要求。 */
    private static final String FRAGMENT =
            "#extension GL_OES_EGL_image_external : require\n" +
            "precision mediump float;\n" +
            "varying vec2 vTex;\n" +
            "uniform samplerExternalOES uTex;\n" +
            "void main() {\n" +
            "  vec4 c = texture2D(uTex, vTex);\n" +
            "  c.rgb = pow(clamp(c.rgb, 0.0, 1.0), vec3(1.0 / 1.2));\n" +
            "  gl_FragColor = vec4(c.rgb, 1.0);\n" +
            "}\n";

    private VideoNormalizer() {
    }

    /**
     * @param startMs / endMs 需要保留的区间（endMs<=0 表示到结尾）
     * @param outW / outH     目标尺寸（必须 16 对齐、偶数）
     */
    public static boolean normalize(Context ctx, Uri src, long startMs, long endMs,
                                    int outW, int outH, File dst) throws Exception {
        outW = Math.max(16, (outW / 16) * 16);
        outH = Math.max(16, (outH / 16) * 16);

        MediaExtractor ex = new MediaExtractor();
        MediaExtractor audioEx = null;
        MediaCodec dec = null;
        MediaCodec enc = null;
        MediaMuxer muxer = null;
        Surface decSurface = null;
        SurfaceTextureHolder st = null;
        GlHolder gl = null;

        try {
            ex.setDataSource(ctx, src, null);
            int vIdx = -1, aIdx = -1;
            MediaFormat vf = null, af = null;
            for (int i = 0; i < ex.getTrackCount(); i++) {
                MediaFormat f = ex.getTrackFormat(i);
                String mime = f.getString(MediaFormat.KEY_MIME);
                if (mime == null) continue;
                if (mime.startsWith("video/") && vIdx < 0) {
                    vIdx = i;
                    vf = f;
                } else if (mime.startsWith("audio/") && aIdx < 0) {
                    aIdx = i;
                    af = f;
                }
            }
            if (vIdx < 0 || vf == null) return false;
            String vmime = vf.getString(MediaFormat.KEY_MIME);
            if (vmime == null) return false;

            int srcW = vf.getInteger(MediaFormat.KEY_WIDTH);
            int srcH = vf.getInteger(MediaFormat.KEY_HEIGHT);
            int rot = vf.containsKey(MediaFormat.KEY_ROTATION)
                    ? vf.getInteger(MediaFormat.KEY_ROTATION) : 0;

            long startUs = Math.max(0, startMs) * 1000L;
            ex.selectTrack(vIdx);
            if (startUs > 0) ex.seekTo(startUs, MediaExtractor.SEEK_TO_PREVIOUS_SYNC);

            // 1) 编码器：尺寸在这一步就定死，后面解码出的 8K 帧只会被画到 outW×outH 的画布上
            enc = MediaCodec.createEncoderByType("video/avc");
            MediaFormat ef = MediaFormat.createVideoFormat("video/avc", outW, outH);
            ef.setInteger(MediaFormat.KEY_COLOR_FORMAT,
                    MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface);
            int bitrate = Math.max(3_000_000, (int) (outW * (long) outH * 30 * 0.12));
            bitrate = Math.min(20_000_000, bitrate);
            ef.setInteger(MediaFormat.KEY_BIT_RATE, bitrate);
            ef.setInteger(MediaFormat.KEY_FRAME_RATE, 30);
            ef.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1);
            ef.setInteger(MediaFormat.KEY_PROFILE,
                    MediaCodecInfo.CodecProfileLevel.AVCProfileMain);
            ef.setInteger(MediaFormat.KEY_LEVEL,
                    MediaCodecInfo.CodecProfileLevel.AVCLevel41);
            try {
                enc.configure(ef, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
            } catch (Throwable profileFailed) {
                // 有些编码器不接受显式 profile/level，退回不指定
                MediaFormat plain = MediaFormat.createVideoFormat("video/avc", outW, outH);
                plain.setInteger(MediaFormat.KEY_COLOR_FORMAT,
                        MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface);
                plain.setInteger(MediaFormat.KEY_BIT_RATE, bitrate);
                plain.setInteger(MediaFormat.KEY_FRAME_RATE, 30);
                plain.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1);
                safeStop(enc);
                enc = MediaCodec.createEncoderByType("video/avc");
                enc.configure(plain, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
            }
            Surface encSurface = enc.createInputSurface();
            enc.start();

            // 2) GL：解码帧 → OES 纹理 → 编码器输入 Surface
            gl = new GlHolder(encSurface);
            st = new SurfaceTextureHolder(gl.textureId, srcW, srcH);
            decSurface = st.surface;

            dec = MediaCodec.createDecoderByType(vmime);
            dec.configure(vf, decSurface, null, 0);
            dec.start();

            // 3) 封装器（视频轨 + 原音轨）
            muxer = new MediaMuxer(dst.getAbsolutePath(),
                    MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
            if (rot != 0) {
                try {
                    muxer.setOrientationHint(rot);
                } catch (Throwable ignore) {
                }
            }
            int audioTrackOut = -1;
            if (aIdx >= 0 && af != null) {
                try {
                    audioEx = new MediaExtractor();
                    audioEx.setDataSource(ctx, src, null);
                    audioEx.selectTrack(aIdx);
                    audioTrackOut = muxer.addTrack(af);
                } catch (Throwable t) {
                    safeRelease(audioEx);
                    audioEx = null;
                    audioTrackOut = -1;
                }
            }

            // 4) 解码 → 绘制 → 编码 主循环
            MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
            boolean inputDone = false;
            boolean outputDone = false;
            long endUs = endMs > 0 ? endMs * 1000L : Long.MAX_VALUE;
            long minGapUs = 1_000_000L / 30;
            long lastPtsUs = -1;

            int videoTrackOut = -1;
            boolean muxStarted = false;
            boolean endSignalSent = false;

            long deadline = System.currentTimeMillis() + 5 * 60 * 1000L;
            while (!outputDone && System.currentTimeMillis() < deadline) {
                if (!inputDone) {
                    int inIdx = dec.dequeueInputBuffer(10_000);
                    if (inIdx >= 0) {
                        ByteBuffer ib = dec.getInputBuffer(inIdx);
                        int size = ib == null ? -1 : ex.readSampleData(ib, 0);
                        long pts = ex.getSampleTime();
                        if (size < 0 || pts < 0 || pts > endUs) {
                            dec.queueInputBuffer(inIdx, 0, 0, 0,
                                    MediaCodec.BUFFER_FLAG_END_OF_STREAM);
                            inputDone = true;
                        } else {
                            dec.queueInputBuffer(inIdx, 0, size, pts, 0);
                            ex.advance();
                        }
                    }
                }

                int outIdx = dec.dequeueOutputBuffer(info, 10_000);
                if (outIdx >= 0) {
                    boolean inRange = info.size != 0
                            && info.presentationTimeUs >= startUs
                            && info.presentationTimeUs <= endUs;
                    boolean draw = inRange
                            && (lastPtsUs < 0 || info.presentationTimeUs - lastPtsUs >= minGapUs);
                    if (draw) lastPtsUs = info.presentationTimeUs;
                    dec.releaseOutputBuffer(outIdx, draw);
                    if (draw) {
                        st.update();
                        gl.draw(st.textureId, st.transform, outW, outH, info.presentationTimeUs);
                    }
                    if ((info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                        inputDone = true;
                    }
                }

                // 编码器出队
                while (true) {
                    MediaCodec.BufferInfo ei = new MediaCodec.BufferInfo();
                    int ei2 = enc.dequeueOutputBuffer(ei, 0);
                    if (ei2 == MediaCodec.INFO_TRY_AGAIN_LATER) break;
                    if (ei2 == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                        if (!muxStarted) {
                            videoTrackOut = muxer.addTrack(enc.getOutputFormat());
                            muxer.start();
                            muxStarted = true;
                        }
                        continue;
                    }
                    if (ei2 < 0) continue;
                    ByteBuffer eb = enc.getOutputBuffer(ei2);
                    if (eb != null && ei.size > 0 && (ei.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0) {
                        eb.position(ei.offset);
                        eb.limit(ei.offset + ei.size);
                        if (muxStarted && videoTrackOut >= 0) {
                            muxer.writeSampleData(videoTrackOut, eb, ei);
                        }
                    }
                    boolean eos = (ei.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0;
                    enc.releaseOutputBuffer(ei2, false);
                    if (eos) {
                        outputDone = true;
                        break;
                    }
                }

                if (inputDone && !outputDone && !endSignalSent) {
                    try {
                        enc.signalEndOfInputStream();
                        endSignalSent = true;
                    } catch (Throwable ignore) {
                    }
                }
            }

            // 5) 原音轨直接搬运（不重编码，保时间轴）
            if (audioEx != null && audioTrackOut >= 0 && muxStarted) {
                long endA = endUs == Long.MAX_VALUE ? Long.MAX_VALUE : endUs;
                audioEx.seekTo(startUs, MediaExtractor.SEEK_TO_PREVIOUS_SYNC);
                MediaCodec.BufferInfo ai = new MediaCodec.BufferInfo();
                ByteBuffer buf = ByteBuffer.allocateDirect(64 * 1024)
                        .order(ByteOrder.nativeOrder());
                while (true) {
                    int size = audioEx.readSampleData(buf, 0);
                    if (size < 0) break;
                    long pts = audioEx.getSampleTime();
                    if (pts < 0 || pts > endA) break;
                    if (pts >= startUs) {
                        ai.offset = 0;
                        ai.size = size;
                        ai.presentationTimeUs = pts - startUs;
                        ai.flags = audioEx.getSampleFlags() == MediaExtractor.SAMPLE_FLAG_SYNC
                                ? MediaCodec.BUFFER_FLAG_KEY_FRAME : 0;
                        try {
                            muxer.writeSampleData(audioTrackOut, buf, ai);
                        } catch (Throwable ignore) {
                        }
                    }
                    audioEx.advance();
                }
            }

            if (!muxStarted) return false;
            return dst.isFile() && dst.length() > 1024;
        } finally {
            safeStop(dec);
            safeStop(enc);
            if (decSurface != null) {
                try {
                    decSurface.release();
                } catch (Throwable ignore) {
                }
            }
            if (st != null) st.release();
            if (gl != null) gl.release();
            if (muxer != null) {
                try {
                    muxer.stop();
                } catch (Throwable ignore) {
                }
                try {
                    muxer.release();
                } catch (Throwable ignore) {
                }
            }
            safeRelease(ex);
            safeRelease(audioEx);
        }
    }

    private static void safeStop(MediaCodec c) {
        if (c == null) return;
        try {
            c.stop();
        } catch (Throwable ignore) {
        }
        try {
            c.release();
        } catch (Throwable ignore) {
        }
    }

    private static void safeRelease(MediaExtractor e) {
        if (e == null) return;
        try {
            e.release();
        } catch (Throwable ignore) {
        }
    }

    /** EGL + 着色器。 */
    private static final class GlHolder {
        final EGLDisplay display;
        final EGLContext context;
        final EGLSurface surface;
        final int textureId;
        final int program;
        final FloatBuffer quad;
        final FloatBuffer texCoord;
        final int aPos, aTex, uMvp;

        GlHolder(Surface encoderSurface) {
            display = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY);
            int[] ver = new int[2];
            EGL14.eglInitialize(display, ver, 0, ver, 1);
            int[] attrs = {
                    EGL14.EGL_RED_SIZE, 8,
                    EGL14.EGL_GREEN_SIZE, 8,
                    EGL14.EGL_BLUE_SIZE, 8,
                    EGL14.EGL_ALPHA_SIZE, 8,
                    EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT,
                    EGL14.EGL_SURFACE_TYPE, EGL14.EGL_WINDOW_BIT,
                    EGLExt.EGL_RECORDABLE_ANDROID, 1,
                    EGL14.EGL_NONE
            };
            EGLConfig[] configs = new EGLConfig[1];
            int[] n = new int[1];
            int[] visual = {EGL14.EGL_NONE};
            EGL14.eglChooseConfig(display, attrs, 0, configs, 0, 1, n, 0);
            if (n[0] <= 0) throw new IllegalStateException("EGL config 不支持离屏编码");
            int[] ctxAttrs = {EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE};
            context = EGL14.eglCreateContext(display, configs[0], EGL14.EGL_NO_CONTEXT, ctxAttrs, 0);
            surface = EGL14.eglCreateWindowSurface(display, configs[0], encoderSurface, visual, 0);
            if (surface == null || surface == EGL14.EGL_NO_SURFACE) {
                throw new IllegalStateException("无法创建编码器 EGLSurface");
            }
            EGL14.eglMakeCurrent(display, surface, surface, context);

            int[] tex = new int[1];
            GLES20.glGenTextures(1, tex, 0);
            textureId = tex[0];
            GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, textureId);
            GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES,
                    GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR);
            GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES,
                    GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR);
            GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES,
                    GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE);
            GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES,
                    GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE);

            int vs = compile(GLES20.GL_VERTEX_SHADER, VERTEX);
            int fs = compile(GLES20.GL_FRAGMENT_SHADER, FRAGMENT);
            program = GLES20.glCreateProgram();
            GLES20.glAttachShader(program, vs);
            GLES20.glAttachShader(program, fs);
            GLES20.glLinkProgram(program);
            aPos = GLES20.glGetAttribLocation(program, "aPos");
            aTex = GLES20.glGetAttribLocation(program, "aTex");
            uMvp = GLES20.glGetUniformLocation(program, "uMvp");

            float[] q = {-1f, -1f, 1f, -1f, -1f, 1f, 1f, 1f};
            quad = toBuffer(q);
            float[] t = {0f, 1f, 1f, 1f, 0f, 0f, 1f, 0f};
            texCoord = toBuffer(t);
        }

        private static FloatBuffer toBuffer(float[] data) {
            FloatBuffer b = ByteBuffer.allocateDirect(data.length * 4)
                    .order(ByteOrder.nativeOrder()).asFloatBuffer();
            b.put(data).position(0);
            return b;
        }

        private static int compile(int type, String src) {
            int s = GLES20.glCreateShader(type);
            GLES20.glShaderSource(s, src);
            GLES20.glCompileShader(s);
            int[] ok = new int[1];
            GLES20.glGetShaderiv(s, GLES20.GL_COMPILE_STATUS, ok, 0);
            if (ok[0] == 0) {
                throw new IllegalStateException("着色器编译失败: "
                        + GLES20.glGetShaderInfoLog(s));
            }
            return s;
        }

        void draw(int texId, float[] mvp, int outW, int outH, long ptsUs) {
            GLES20.glViewport(0, 0, outW, outH);
            GLES20.glClearColor(0f, 0f, 0f, 1f);
            GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT);
            GLES20.glUseProgram(program);
            GLES20.glActiveTexture(GLES20.GL_TEXTURE0);
            GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, texId);
            GLES20.glUniformMatrix4fv(uMvp, 1, false, mvp, 0);
            GLES20.glEnableVertexAttribArray(aPos);
            GLES20.glVertexAttribPointer(aPos, 2, GLES20.GL_FLOAT, false, 0, quad);
            GLES20.glEnableVertexAttribArray(aTex);
            GLES20.glVertexAttribPointer(aTex, 2, GLES20.GL_FLOAT, false, 0, texCoord);
            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4);
            GLES20.glDisableVertexAttribArray(aPos);
            GLES20.glDisableVertexAttribArray(aTex);
            EGLExt.eglPresentationTimeANDROID(display, surface, ptsUs * 1000L);
            EGL14.eglSwapBuffers(display, surface);
        }

        void release() {
            try {
                EGL14.eglMakeCurrent(display, EGL14.EGL_NO_SURFACE,
                        EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT);
                EGL14.eglDestroySurface(display, surface);
                EGL14.eglDestroyContext(display, context);
                EGL14.eglTerminate(display);
            } catch (Throwable ignore) {
            }
        }
    }

    /** SurfaceTexture 包装，负责把解码帧送进 GL。 */
    private static final class SurfaceTextureHolder {
        final android.graphics.SurfaceTexture st;
        final Surface surface;
        final int textureId;
        final float[] transform = new float[16];

        SurfaceTextureHolder(int textureId, int w, int h) {
            this.textureId = textureId;
            st = new android.graphics.SurfaceTexture(textureId);
            st.setDefaultBufferSize(Math.max(1, w), Math.max(1, h));
            surface = new Surface(st);
            Matrix.setIdentityM(transform, 0);
        }

        void update() {
            st.updateTexImage();
            st.getTransformMatrix(transform);
        }

        void release() {
            try {
                st.release();
            } catch (Throwable ignore) {
            }
            try {
                surface.release();
            } catch (Throwable ignore) {
            }
        }
    }
}
