package com.offlinelocal.videoeditor;

import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Future;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * 全应用统一的后台线程池。以前到处 new Thread()，频繁解码/导出会不停创建销毁线程，
 * 也没有取消能力。这里给一个上限 4 的池 + 可取消句柄，异常统一进诊断。
 */
public final class Work {

    private static final int MAX = 4;
    private static final AtomicInteger SEQ = new AtomicInteger();
    private static final Set<Future<?>> RUNNING = ConcurrentHashMap.newKeySet();
    private static final java.util.Map<Object, Set<Future<?>>> OWNED = new java.util.concurrent.ConcurrentHashMap<>();

    private static final ThreadPoolExecutor POOL = new ThreadPoolExecutor(
            0, MAX, 30, TimeUnit.SECONDS, new LinkedBlockingQueue<>(64),
            new ThreadFactory() {
                @Override
                public Thread newThread(Runnable r) {
                    Thread t = new Thread(r, "freecut-work-" + SEQ.incrementAndGet());
                    t.setDaemon(true);
                    t.setPriority(Thread.NORM_PRIORITY - 1);
                    return t;
                }
            });

    private Work() {
    }

    public static void run(Runnable task) {
        if (task == null) return;
        final Future<?>[] holder = new Future<?>[1];
        Runnable wrapped = () -> {
            try {
                task.run();
            } catch (Throwable t) {
                ExportDiag.warn("worker", t);
            } finally {
                if (holder[0] != null) RUNNING.remove(holder[0]);
            }
        };
        try {
            Future<?> f = POOL.submit(wrapped);
            holder[0] = f;
            RUNNING.add(f);
        } catch (Throwable t) {
            // 队列满（64）时直接在当前线程跑，绝不丢任务
            ExportDiag.warn("work_queue_full", t);
            wrapped.run();
        }
    }

    /** 归属到某个 Activity 的任务：页面销毁时可精确取消，不误伤别处的导出。 */
    public static void run(Object owner, Runnable task) {
        if (task == null) return;
        final Future<?>[] holder = new Future<?>[1];
        Runnable wrapped = () -> {
            try {
                task.run();
            } catch (Throwable t) {
                ExportDiag.warn("worker", t);
            } finally {
                if (holder[0] != null) RUNNING.remove(holder[0]);
            }
        };
        try {
            Future<?> f = POOL.submit(wrapped);
            holder[0] = f;
            RUNNING.add(f);
            if (owner != null) {
                Set<Future<?>> set = OWNED.get(owner);
                if (set == null) {
                    set = java.util.Collections.newSetFromMap(new java.util.concurrent.ConcurrentHashMap<>());
                    OWNED.put(owner, set);
                }
                set.add(f);
            }
        } catch (Throwable t) {
            ExportDiag.warn("work_queue_full", t);
            wrapped.run();
        }
    }

    /** 取消某个页面发起的全部任务（onDestroy 调用）。 */
    public static void cancelOwner(Object owner) {
        if (owner == null) return;
        Set<Future<?>> set = OWNED.remove(owner);
        if (set == null) return;
        for (Future<?> f : set) {
            try {
                f.cancel(true);
            } catch (Throwable ignore) {
            }
            RUNNING.remove(f);
        }
    }

    /** 取消所有排队/执行中的任务（离开编辑器时调用，避免旧任务回写已销毁的界面）。 */
    public static void cancelAll() {
        for (Future<?> f : RUNNING) {
            try {
                f.cancel(true);
            } catch (Throwable ignore) {
            }
        }
        RUNNING.clear();
    }

    public static int activeCount() {
        return RUNNING.size();
    }
}
