package com.offlinelocal.videoeditor;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;

import java.util.List;

/** 拼图引擎：把多张图按网格拼成一张（九宫格 / 上下长图 / 左右对比）。 */
public class CollageEngine {

    /** 长图拼接高度上限（约 16000×1080 → 66MB，留出余量给缩放副本）。 */
    public static final int MAX_STITCH_HEIGHT = 16000;

    public static final String[] STYLE_NAMES = {"九宫格", "两列", "左右对比", "上下长图", "长截图拼接"};

    /**
     * @param style 0 九宫格(3列) 1 两列 2 左右对比(1行2列) 3 上下长图(1列)
     */
    public static Bitmap build(List<Bitmap> images, int style, int gapPx, int cornerPx,
                               int bgColor, int maxWidth) {
        if (images == null || images.isEmpty()) return null;
        if (style == 4) return stitch(images, maxWidth);
        int cols;
        switch (style) {
            case 0: cols = 3; break;
            case 1: cols = 2; break;
            case 2: cols = Math.min(2, images.size()); break;
            default: cols = 1; break;
        }
        int rows = (int) Math.ceil(images.size() / (double) cols);

        // 单格宽 = 总宽按列平分（以前误用 maxWidth 当单格宽，3 列直接放大 3 倍，源图被拉伸发糊）
        int cellW = Math.max(1, (maxWidth - gapPx * (cols + 1)) / cols);
        int minSourceW = Integer.MAX_VALUE;
        int minSourceH = Integer.MAX_VALUE;
        for (Bitmap b : images) {
            minSourceW = Math.min(minSourceW, b.getWidth());
            minSourceH = Math.min(minSourceH, b.getHeight());
        }
        // 源图比格子还小就别再放大，避免糊
        cellW = Math.min(cellW, Math.max(minSourceW, 240));

        int cellH;
        if (style == 2) {
            cellH = cellW;
        } else {
            int minSide = Integer.MAX_VALUE;
            for (Bitmap b : images) {
                float ratio = Math.min(((float) b.getWidth()) / b.getHeight(), 1.6f);
                int h = (int) (cellW / Math.max(1f, ratio));
                minSide = Math.min(minSide, Math.max(h, cellW / 3));
            }
            cellH = minSide == Integer.MAX_VALUE ? cellW : Math.min(minSide, cellW);
        }
        cellH = Math.min(cellH, Math.max(minSourceH, 240));

        int totalW = cols * cellW + gapPx * (cols + 1);
        int totalH = rows * cellH + gapPx * (rows + 1);
        Bitmap out = Bitmap.createBitmap(totalW, totalH, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(out);
        c.drawColor(bgColor);

        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        for (int i = 0; i < images.size(); i++) {
            Bitmap b = images.get(i);
            int row = i / cols;
            int col = i % cols;
            int left = gapPx + col * (cellW + gapPx);
            int top = gapPx + row * (cellH + gapPx);
            // 居中裁切填满单元格
            int srcW = b.getWidth();
            int srcH = b.getHeight();
            float scale = Math.max((float) cellW / srcW, (float) cellH / srcH);
            int cutW = (int) (cellW / scale);
            int cutH = (int) (cellH / scale);
            cutW = Math.min(cutW, srcW);
            cutH = Math.min(cutH, srcH);
            int sx = (srcW - cutW) / 2;
            int sy = (srcH - cutH) / 2;
            Rect dst = new Rect(left, top, left + cellW, top + cellH);
            // 直接 drawBitmap 缩放只有一次双线性采样，大幅缩小时会糊；
            // 先居中裁出目标比例，再逐级减半缩放，细节保留明显更好。
            Bitmap cell = smartScale(b, sx, sy, cutW, cutH, cellW, cellH);
            if (cell != null) {
                c.drawBitmap(cell, null, dst, p);
                if (cell != b) cell.recycle();
            }
        }
        return out;
    }

    /**
     * 居中裁切 + 逐级缩小。先裁出目标比例的矩形，再每次减半缩放，最后一步精确缩到目标尺寸。
     * 这样比一次 drawBitmap 双线性放大/缩小清晰得多，内存也只多占一张小图。
     */
    private static Bitmap smartScale(Bitmap src, int sx, int sy, int cutW, int cutH,
                                     int targetW, int targetH) {
        if (src == null || targetW <= 0 || targetH <= 0) return null;
        Bitmap cropped;
        if (cutW >= src.getWidth() && cutH >= src.getHeight()) {
            cropped = src;
        } else {
            try {
                cropped = Bitmap.createBitmap(src, Math.max(0, sx), Math.max(0, sy),
                        Math.min(cutW, src.getWidth()), Math.min(cutH, src.getHeight()));
            } catch (Exception e) {
            ExportDiag.warn("collage", e);
                cropped = src;
            }
        }
        int w = cropped.getWidth();
        int h = cropped.getHeight();
        Bitmap cur = cropped;
        // 逐级减半，直到不超过目标的两倍
        while (w > targetW * 2 && h > targetH * 2 && w > 2 && h > 2) {
            int nw = w / 2;
            int nh = h / 2;
            Bitmap half = Bitmap.createScaledBitmap(cur, nw, nh, true);
            if (cur != cropped && cur != src) cur.recycle();
            cur = half;
            w = nw;
            h = nh;
        }
        Bitmap out = Bitmap.createScaledBitmap(cur, targetW, targetH, true);
        if (cur != cropped && cur != src) cur.recycle();
        if (cropped != src) cropped.recycle();
        return out;
    }

    /**
     * 长截图拼接：自动检测相邻两张截图的重叠高度，把重复部分去掉再拼起来。
     * 找不到重叠（普通照片）时按直接拼接处理。
     */
    public static Bitmap stitch(java.util.List<Bitmap> images, int maxWidth) {
        return stitch(images, maxWidth, MAX_STITCH_HEIGHT);
    }

    /**
     * @param maxHeight 允许的最大输出高度。传大值即"不限像素"，由调用方按可用内存算。
     */
    public static Bitmap stitch(java.util.List<Bitmap> images, int maxWidth, int maxHeight) {
        if (images == null || images.isEmpty()) return null;
        Bitmap first = images.get(0);
        int w = Math.min(maxWidth, first.getWidth());
        if (w <= 0) return null;

        // 先只用尺寸估算高度，超限就把宽度等比缩窄——绝不为了省内存去 recycle 调用方传进来的原图。
        long estimated = estimateHeight(images, w);
        int guard = 0;
        while (estimated > maxHeight && w > 64 && guard++ < 8) {
            w = (int) Math.max(64, (long) w * maxHeight / estimated);
            estimated = estimateHeight(images, w);
        }

        java.util.List<Bitmap> scaled = new java.util.ArrayList<>();
        java.util.List<Boolean> owned = new java.util.ArrayList<>();
        java.util.List<Integer> overlaps = new java.util.ArrayList<>();
        float scale = w / (float) first.getWidth();
        for (int i = 0; i < images.size(); i++) {
            Bitmap src = images.get(i);
            Bitmap b;
            if (src.getWidth() == w) {
                b = src;
                owned.add(Boolean.FALSE);
            } else {
                b = Bitmap.createScaledBitmap(src, w,
                        Math.max(1, (int) (src.getHeight() * w / (float) src.getWidth())), true);
                owned.add(Boolean.TRUE);
            }
            scaled.add(b);
            if (i > 0) overlaps.add(findOverlap(scaled.get(i - 1), b));
        }

        int totalH = scaled.get(0).getHeight();
        for (int i = 1; i < scaled.size(); i++) {
            totalH += scaled.get(i).getHeight() - overlaps.get(i - 1);
        }
        if (totalH <= 0 || totalH > maxHeight) {
            // 极端情况（多张超高图扣掉重叠后仍超限）：直接放弃，避免 createBitmap 崩溃
            return null;
        }

        Bitmap out = Bitmap.createBitmap(w, totalH, Bitmap.Config.ARGB_8888);
        android.graphics.Canvas canvas = new android.graphics.Canvas(out);
        canvas.drawColor(0xFF000000);
        android.graphics.Paint paint = new android.graphics.Paint(android.graphics.Paint.FILTER_BITMAP_FLAG);
        canvas.drawBitmap(scaled.get(0), 0f, 0f, paint);
        int y = scaled.get(0).getHeight();
        for (int i = 1; i < scaled.size(); i++) {
            y -= overlaps.get(i - 1);
            canvas.drawBitmap(scaled.get(i), 0f, y, paint);
            y += scaled.get(i).getHeight();
        }
        // 只回收自己缩放的副本，原图留给调用方
        for (int i = 0; i < scaled.size(); i++) {
            if (owned.get(i)) {
                Bitmap b = scaled.get(i);
                if (b != null && !b.isRecycled()) b.recycle();
            }
        }
        return out;
    }

    private static long estimateHeight(java.util.List<Bitmap> images, int w) {
        long sum = 0;
        for (Bitmap b : images) {
            sum += (long) b.getHeight() * w / Math.max(1, b.getWidth());
        }
        return sum;
    }

    /**
     * 在上一张的尾部与下一张的头部之间找最佳重叠行数。
     * 先用 96px 缩略图粗扫（长图逐像素扫会卡一下），再在原分辨率上精修候选位置，
     * 既快又准。
     */
    private static int findOverlap(Bitmap prev, Bitmap next) {
        final int W = 96;
        int ph = Math.max(2, (int) (prev.getHeight() * W / (float) prev.getWidth()));
        int nh = Math.max(2, (int) (next.getHeight() * W / (float) next.getWidth()));
        int[] pRows = new int[W * ph];
        int[] nRows = new int[W * nh];
        Bitmap pSmall = Bitmap.createScaledBitmap(prev, W, ph, true);
        Bitmap nSmall = Bitmap.createScaledBitmap(next, W, nh, true);
        try {
            pSmall.getPixels(pRows, 0, W, 0, 0, W, ph);
            nSmall.getPixels(nRows, 0, W, 0, 0, W, nh);
        } finally {
            if (pSmall != prev && !pSmall.isRecycled()) pSmall.recycle();
            if (nSmall != next && !nSmall.isRecycled()) nSmall.recycle();
        }
        int maxCheck = Math.min(ph, nh) / 2;
        int bestOverlap = 0;
        int bestScore = Integer.MAX_VALUE;
        for (int overlap = 6; overlap <= maxCheck; overlap += 2) {
            long diff = 0;
            int samples = 0;
            int prevTop = ph - overlap;
            for (int row = 0; row < overlap; row += 2) {
                int pi = (prevTop + row) * W;
                int ni = row * W;
                for (int x = 0; x < W; x += 2) {
                    int a = pRows[pi + x];
                    int b = nRows[ni + x];
                    diff += Math.abs(((a >> 16) & 0xFF) - ((b >> 16) & 0xFF));
                    diff += Math.abs(((a >> 8) & 0xFF) - ((b >> 8) & 0xFF));
                    diff += Math.abs((a & 0xFF) - (b & 0xFF));
                    samples++;
                }
            }
            int score = (int) (samples == 0 ? Integer.MAX_VALUE : diff / samples);
            // 边缘是纯色时多个候选项完全并列，取更大的重叠，避免把重复条带留下来
            if (score < bestScore || (score == bestScore && overlap > bestOverlap)) {
                bestScore = score;
                bestOverlap = overlap;
            }
        }
        if (bestScore > 20) return 0;

        // 缩略图上的行数换算回原图，并在 ±3 个缩略像素范围内做原分辨率精修
        double scale = prev.getHeight() / (double) ph;
        int center = (int) Math.round(bestOverlap * scale);
        int window = Math.max(2, (int) Math.round(3 * scale));
        int low = Math.max(2, center - window);
        int high = Math.min(Math.min(prev.getHeight(), next.getHeight()) / 2, center + window);
        int w = Math.min(prev.getWidth(), next.getWidth());
        int[] pRow = new int[w];
        int[] nRow = new int[w];
        int bestExact = 0;
        int bestExactScore = Integer.MAX_VALUE;
        for (int overlap = low; overlap <= high; overlap++) {
            long diff = 0;
            int samples = 0;
            int prevTop = prev.getHeight() - overlap;
            for (int row = 0; row < overlap; row += 2) {
                prev.getPixels(pRow, 0, w, 0, prevTop + row, w, 1);
                next.getPixels(nRow, 0, w, 0, row, w, 1);
                for (int x = 0; x < w; x += 3) {
                    int a = pRow[x];
                    int b = nRow[x];
                    diff += Math.abs(((a >> 16) & 0xFF) - ((b >> 16) & 0xFF));
                    diff += Math.abs(((a >> 8) & 0xFF) - ((b >> 8) & 0xFF));
                    diff += Math.abs((a & 0xFF) - (b & 0xFF));
                    samples++;
                }
            }
            int score = (int) (samples == 0 ? Integer.MAX_VALUE : diff / samples);
            if (score < bestExactScore || (score == bestExactScore && overlap > bestExact)) {
                bestExactScore = score;
                bestExact = overlap;
            }
        }
        return bestExactScore <= 12 ? bestExact : 0;
    }

    public static Bitmap placeholder(int w, int h) {
        Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b);
        c.drawColor(Color.DKGRAY);
        return b;
    }
}
