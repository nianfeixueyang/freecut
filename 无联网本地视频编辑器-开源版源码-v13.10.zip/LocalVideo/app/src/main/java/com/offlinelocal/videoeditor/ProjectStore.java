package com.offlinelocal.videoeditor;

import android.content.Context;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * 工程存档（.fcproj 就是一份 JSON）。
 *
 * 目录结构：
 *   files/projects/<id>/project.json   正式工程
 *   files/projects/draft.json          自动保存的草稿（只有一个）
 *
 * 只存参数与 URI，不存素材本身 —— 素材还在用户相册里，工程文件只有几 KB。
 */
public class ProjectStore {

    public static final String EXTRA_PROJECT_ID = "freecut_project_id";

    public static class Meta {
        public String id;
        public String title;
        public long updatedAt;
        public long durationMs;
        public int clipCount;
        public int versionCode;
    }

    private static File root(Context ctx) {
        File dir = new File(ctx.getFilesDir(), "projects");
        if (!dir.exists()) dir.mkdirs();
        return dir;
    }

    private static File dirOf(Context ctx, String id) {
        File dir = new File(root(ctx), id);
        if (!dir.exists()) dir.mkdirs();
        return dir;
    }

    private static File fileOf(Context ctx, String id) {
        return new File(new File(root(ctx), id), "project.json");
    }

    private static File draftFile(Context ctx) {
        return new File(root(ctx), "draft.json");
    }

    /** 保存工程；id 传 null 表示新建，返回工程 id。 */
    public static String save(Context ctx, String id, JSONObject data, String title,
                              long durationMs, int clipCount) {
        if (id == null || id.trim().isEmpty()) id = "p" + System.currentTimeMillis();
        try {
            JSONObject wrapper = new JSONObject();
            wrapper.put("title", title == null || title.isEmpty() ? "未命名工程" : title);
            wrapper.put("updatedAt", System.currentTimeMillis());
            wrapper.put("durationMs", durationMs);
            wrapper.put("clipCount", clipCount);
            wrapper.put("data", data);
            dirOf(ctx, id); // 确保目录存在（读工程时不会建目录）
            snapshotOld(ctx, id);
            writeFile(fileOf(ctx, id), wrapper.toString());
            return id;
        } catch (Exception e) {
            android.util.Log.e("LocalVideoProject", "save failed", e);
            return null;
        }
    }

    public static JSONObject load(Context ctx, String id) {
        try {
            File f = fileOf(ctx, id);
            if (!f.exists()) return null;
            JSONObject wrapper = new JSONObject(readFile(f));
            return wrapper.optJSONObject("data");
        } catch (Exception e) {
            return null;
        }
    }

    public static String loadTitle(Context ctx, String id) {
        try {
            File f = fileOf(ctx, id);
            if (!f.exists()) return null;
            return new JSONObject(readFile(f)).optString("title", "未命名工程");
        } catch (Exception e) {
            return null;
        }
    }

    public static List<Meta> list(Context ctx) {
        List<Meta> out = new ArrayList<>();
        File[] dirs = root(ctx).listFiles();
        if (dirs == null) return out;
        for (File d : dirs) {
            if (!d.isDirectory()) continue;
            File f = new File(d, "project.json");
            if (!f.exists()) continue;
            try {
                JSONObject w = new JSONObject(readFile(f));
                Meta m = new Meta();
                m.id = d.getName();
                m.title = w.optString("title", "未命名工程");
                m.updatedAt = w.optLong("updatedAt", f.lastModified());
                m.durationMs = w.optLong("durationMs", 0);
                m.clipCount = w.optInt("clipCount", 0);
                out.add(m);
            } catch (Throwable ignored) {
            ExportDiag.warn("proj_store", ignored);
            }
        }
        Collections.sort(out, (a, b) -> Long.compare(b.updatedAt, a.updatedAt));
        return out;
    }

    public static void delete(Context ctx, String id) {
        File dir = new File(root(ctx), id);
        deleteRecursive(dir);
    }

    private static void deleteRecursive(File f) {
        if (f == null || !f.exists()) return;
        if (f.isDirectory()) {
            File[] kids = f.listFiles();
            if (kids != null) for (File k : kids) deleteRecursive(k);
        }
        //noinspection ResultOfMethodCallIgnored
        f.delete();
    }

    // ---------------- 封面缩略图 ----------------

    private static File thumbFile(Context ctx, String id) {
        return new File(new File(root(ctx), id), "thumb.jpg");
    }

    public static void saveThumb(Context ctx, String id, android.graphics.Bitmap thumb) {
        if (id == null || thumb == null) return;
        try {
            dirOf(ctx, id);
            File f = thumbFile(ctx, id);
            try (FileOutputStream fos = new FileOutputStream(f)) {
                thumb.compress(android.graphics.Bitmap.CompressFormat.JPEG, 82, fos);
            }
        } catch (Throwable ignored) {
            ExportDiag.warn("proj_store", ignored);
        }
    }

    public static android.graphics.Bitmap loadThumb(Context ctx, String id) {
        try {
            File f = thumbFile(ctx, id);
            if (!f.exists()) return null;
            return android.graphics.BitmapFactory.decodeFile(f.getAbsolutePath());
        } catch (Throwable t) {
            return null;
        }
    }

    /** 草稿的概要（首页「继续编辑」卡片用）。 */
    public static String draftTitle(Context ctx) {
        try {
            File f = draftFile(ctx);
            if (!f.exists()) return null;
            return new JSONObject(readFile(f)).optString("title", "未命名工程");
        } catch (Exception e) {
            return null;
        }
    }

    public static long draftDuration(Context ctx) {
        try {
            File f = draftFile(ctx);
            if (!f.exists()) return 0;
            return new JSONObject(readFile(f)).optLong("durationMs", 0);
        } catch (Exception e) {
            return 0;
        }
    }

    /** 清理导出临时目录占用的空间（预览残留 + 过期成片）。 */
    public static long cacheBytes(Context ctx) {
        File dir = new File(ctx.getExternalFilesDir(null), "export");
        long sum = 0;
        File[] fs = dir.listFiles();
        if (fs != null) for (File f : fs) sum += f.length();
        return sum;
    }

    public static void clearCache(Context ctx) {
        File dir = new File(ctx.getExternalFilesDir(null), "export");
        File[] fs = dir.listFiles();
        if (fs == null) return;
        for (File f : fs) {
            //noinspection ResultOfMethodCallIgnored
            f.delete();
        }
    }

    // ---------------- 草稿 ----------------

    public static void saveDraft(Context ctx, JSONObject data, String title, long durationMs,
                                 int clipCount) {
        try {
            JSONObject w = new JSONObject();
            w.put("v", 3);                 // 草稿版本号：老草稿缺 v 也能读，但会标记为待迁移
            w.put("title", title);
            w.put("updatedAt", System.currentTimeMillis());
            w.put("durationMs", durationMs);
            w.put("clipCount", clipCount);
            w.put("data", data);
            writeFile(draftFile(ctx), w.toString());
        } catch (Throwable ignored) {
            ExportDiag.warn("proj_store", ignored);
        }
    }

    public static JSONObject loadDraftData(Context ctx) {
        try {
            File f = draftFile(ctx);
            if (!f.exists()) return null;
            JSONObject root = new JSONObject(readFile(f));
            JSONObject data = root.optJSONObject("data");
            if (data == null) return null;
            // 老草稿没有版本号：不丢，标记 legacy，下次自动保存时补到 v3；结构实在读不出再放弃
            data.optInt("draftV", root.optInt("v", 0));
            return data;
        } catch (Exception e) {
            return null;
        }
    }

    /** 草稿是不是老格式（没有版本号），首页提示"可继续"时不必吓用户，只是内部要迁移。 */
    public static int draftVersion(Context ctx) {
        try {
            File f = draftFile(ctx);
            if (!f.exists()) return 0;
            return new JSONObject(readFile(f)).optInt("v", 0);
        } catch (Exception e) {
            return 0;
        }
    }

    public static long draftUpdatedAt(Context ctx) {
        File f = draftFile(ctx);
        return f.exists() ? f.lastModified() : 0;
    }

    public static int draftClipCount(Context ctx) {
        try {
            File f = draftFile(ctx);
            if (!f.exists()) return 0;
            return new JSONObject(readFile(f)).optInt("clipCount", 0);
        } catch (Exception e) {
            return 0;
        }
    }

    public static void clearDraft(Context ctx) {
        File f = draftFile(ctx);
        if (f.exists()) {
            //noinspection ResultOfMethodCallIgnored
            f.delete();
        }
    }

    // ---------------- IO ----------------

    private static void writeFile(File f, String content) throws Exception {
        File tmp = new File(f.getParentFile(), f.getName() + ".tmp");
        try (FileOutputStream fos = new FileOutputStream(tmp);
             OutputStreamWriter w = new OutputStreamWriter(fos, "UTF-8")) {
            w.write(content);
            w.flush();
        }
        // 先写临时文件再改名，中途被杀不会留下半个损坏的工程
        if (f.exists()) {
            //noinspection ResultOfMethodCallIgnored
            f.delete();
        }
        if (!tmp.renameTo(f)) throw new IOExceptionWrapper("rename failed");
    }

    private static String readFile(File f) throws Exception {
        try (FileInputStream fis = new FileInputStream(f);
             InputStreamReader r = new InputStreamReader(fis, "UTF-8")) {
            StringBuilder sb = new StringBuilder();
            char[] buf = new char[4096];
            int n;
            while ((n = r.read(buf)) > 0) sb.append(buf, 0, n);
            return sb.toString();
        }
    }

    static class IOExceptionWrapper extends Exception {
        IOExceptionWrapper(String msg) {
            super(msg);
        }
    }

    /** 便于测试：把 JSON 往返一遍，确认字段没丢。 */
    public static JSONObject roundTrip(JSONObject in) throws JSONException {
        return new JSONObject(in.toString());
    }

    // ---------------- 版本快照 ----------------

    private static final int VERSION_LIMIT = 10;

    private static File versionsDir(Context ctx, String id) {
        File dir = new File(dirOf(ctx, id), "versions");
        if (!dir.exists()) dir.mkdirs();
        return dir;
    }

    /** 覆盖保存前，把上一版 project.json 留一份，最多保留 10 份。 */
    private static void snapshotOld(Context ctx, String id) {
        try {
            File cur = fileOf(ctx, id);
            if (!cur.exists()) return;
            File dir = versionsDir(ctx, id);
            File v = new File(dir, System.currentTimeMillis() + ".json");
            writeFile(v, readFile(cur));
            pruneVersions(dir);
        } catch (Throwable ignored) {
            ExportDiag.warn("proj_store", ignored);
        }
    }

    private static void pruneVersions(File dir) {
        File[] fs = dir.listFiles();
        if (fs == null || fs.length <= VERSION_LIMIT) return;
        java.util.Arrays.sort(fs, (a, b) -> Long.compare(a.lastModified(), b.lastModified()));
        for (int i = 0; i < fs.length - VERSION_LIMIT; i++) {
            //noinspection ResultOfMethodCallIgnored
            fs[i].delete();
        }
    }

    /** 版本列表（时间倒序）。 */
    public static List<Long> listVersions(Context ctx, String id) {
        List<Long> out = new ArrayList<>();
        File[] fs = versionsDir(ctx, id).listFiles();
        if (fs == null) return out;
        for (File f : fs) {
            String name = f.getName();
            if (!name.endsWith(".json")) continue;
            try {
                out.add(Long.parseLong(name.substring(0, name.length() - 5)));
            } catch (Throwable ignored) {
            ExportDiag.warn("proj_store", ignored);
            }
        }
        Collections.sort(out, Collections.reverseOrder());
        return out;
    }

    /** 读某个时间点的版本内容（返回工程 data）。 */
    public static JSONObject loadVersion(Context ctx, String id, long ts) {
        try {
            File f = new File(versionsDir(ctx, id), ts + ".json");
            if (!f.exists()) return null;
            JSONObject wrapper = new JSONObject(readFile(f));
            return wrapper.optJSONObject("data");
        } catch (Exception e) {
            return null;
        }
    }
}
