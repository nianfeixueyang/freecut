package com.offlinelocal.videoeditor;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** 导出历史（本地 SharedPreferences，最多保留 100 条）。 */
public class HistoryStore {

    public static class Item {
        public String name;
        public String type;      // image / video / cover / batch
        public String uri;
        public long time;
        public String projectId; // 视频成片关联的工程，点击可回编辑器继续改

        public String timeText() {
            SimpleDateFormat f = new SimpleDateFormat("MM-dd HH:mm", Locale.getDefault());
            return f.format(new Date(time));
        }
    }

    private static final String PREFS = "freecut_history";
    private static final String KEY = "items";
    private static final int LIMIT = 100;

    private static SharedPreferences prefs(Context ctx) {
        return ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public static void add(Context ctx, String type, String name, Uri uri) {
        add(ctx, type, name, uri, null);
    }

    public static void add(Context ctx, String type, String name, Uri uri, String projectId) {
        try {
            List<Item> items = load(ctx);
            Item it = new Item();
            it.name = name;
            it.type = type;
            it.uri = uri == null ? "" : uri.toString();
            it.time = System.currentTimeMillis();
            it.projectId = projectId;
            items.add(0, it);
            while (items.size() > LIMIT) items.remove(items.size() - 1);

            JSONArray arr = new JSONArray();
            for (Item i : items) {
                JSONObject o = new JSONObject();
                o.put("n", i.name);
                o.put("t", i.type);
                o.put("u", i.uri);
                o.put("d", i.time);
                if (i.projectId != null && !i.projectId.isEmpty()) o.put("p", i.projectId);
                arr.put(o);
            }
            prefs(ctx).edit().putString(KEY, arr.toString()).apply();
        } catch (Throwable ignored) {
            ExportDiag.warn("history_store", ignored);
        }
    }

    public static List<Item> load(Context ctx) {
        List<Item> out = new ArrayList<>();
        try {
            String raw = prefs(ctx).getString(KEY, "[]");
            JSONArray arr = new JSONArray(raw);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                Item it = new Item();
                it.name = o.optString("n");
                it.type = o.optString("t");
                it.uri = o.optString("u");
                it.time = o.optLong("d");
                it.projectId = o.optString("p", null);
                out.add(it);
            }
        } catch (Throwable ignored) {
            ExportDiag.warn("history_store", ignored);
        }
        return out;
    }

    public static void clear(Context ctx) {
        prefs(ctx).edit().remove(KEY).apply();
    }
}
