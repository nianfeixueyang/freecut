package com.offlinelocal.videoeditor;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.util.List;

/** 导出历史：查看、重新打开、清空。 */
public class HistoryActivity extends AppCompatActivity {

    private LinearLayout row;
    private TextView tvEmpty;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);

        row = findViewById(R.id.rowHistory);
        tvEmpty = findViewById(R.id.tvEmpty);

        findViewById(R.id.btnBack).setOnClickListener(v -> finish());
        findViewById(R.id.btnClear).setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle("清空历史")
                .setMessage("只清空列表记录，不会删除已导出的文件。")
                .setNegativeButton("取消", null)
                .setPositiveButton("清空", (d, w) -> {
                    HistoryStore.clear(this);
                    bind();
                })
                .show());

        bind();
    }

    private int dp(float v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    private String typeName(String type) {
        if ("video".equals(type)) return "视频";
        if ("cover".equals(type)) return "封面";
        if ("batch".equals(type)) return "批量";
        return "图片";
    }

    private void bind() {
        row.removeAllViews();
        List<HistoryStore.Item> items = HistoryStore.load(this);
        tvEmpty.setVisibility(items.isEmpty() ? View.VISIBLE : View.GONE);

        for (final HistoryStore.Item it : items) {
            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setPadding(dp(14), dp(12), dp(14), dp(12));
            card.setBackgroundResource(R.drawable.bg_chip);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            lp.bottomMargin = dp(8);
            card.setLayoutParams(lp);

            TextView title = new TextView(this);
            title.setText(it.name);
            title.setTextColor(getColor(R.color.text_1));
            title.setTextSize(13);
            title.setSingleLine(true);
            title.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE);
            card.addView(title);

            TextView sub = new TextView(this);
            sub.setText(typeName(it.type) + " · " + it.timeText());
            sub.setTextColor(getColor(R.color.text_2));
            sub.setTextSize(11);
            sub.setGravity(Gravity.START);
            card.addView(sub);

            if (it.projectId != null && !it.projectId.isEmpty()) {
                sub.setText(sub.getText() + " · 长按回工程继续改");
                card.setOnLongClickListener(v -> {
                    try {
                        startActivity(VideoEditorActivity.buildProjectIntent(this, it.projectId));
                    } catch (Exception e) {
                        toast("这个工程已被删除");
                    }
                    return true;
                });
            }
            card.setClickable(true);
            card.setOnClickListener(v -> open(it));
            row.addView(card);
        }
    }

    private void open(HistoryStore.Item it) {
        if (it.uri == null || it.uri.isEmpty()) {
            toast("这条记录没有可打开的文件");
            return;
        }
        try {
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setDataAndType(Uri.parse(it.uri), "video".equals(it.type) ? "video/mp4" : "image/*");
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(i);
        } catch (Exception e) {
            toast("没有能打开它的应用");
        }
    }

    private void toast(String m) {
        Toast.makeText(this, m, Toast.LENGTH_SHORT).show();
    }
}
