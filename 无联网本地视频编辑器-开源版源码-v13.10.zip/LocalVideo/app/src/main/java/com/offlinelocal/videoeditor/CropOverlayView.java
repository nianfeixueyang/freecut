package com.offlinelocal.videoeditor;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

/**
 * 预览画布上的「自由裁剪」框：四角可独立拖动，不限制比例。
 * 归一化坐标 (0~1) 存在 l/t/r/b，导出时换成 Media3 的 Crop(NDC) 生效。
 */
public class CropOverlayView extends View {

    public interface OnCropChanged { void onChanged(float l, float t, float r, float b); }

    private float l = 0f, t = 0f, r = 1f, b = 1f;
    private final Paint dimPaint = new Paint();
    private final Paint linePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint handlePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF tmp = new RectF();
    private int dragCorner = -1;   // 0 左上 1 右上 2 右下 3 左下
    private float downX, downY, startL, startT, startR, startB;
    private OnCropChanged listener;
    private float density = 3f;

    public CropOverlayView(Context c) { this(c, null); }

    public CropOverlayView(Context c, AttributeSet attrs) {
        super(c, attrs);
        density = c.getResources().getDisplayMetrics().density;
        dimPaint.setColor(c.getColor(R.color.scrim_mid));
        linePaint.setStyle(Paint.Style.STROKE);
        linePaint.setStrokeWidth(1.5f * density);
        linePaint.setColor(c.getColor(R.color.accent));
        handlePaint.setColor(c.getColor(R.color.accent));
    }

    public void setOnCropChanged(OnCropChanged l) { this.listener = l; }

    public float getLeftRatio() { return l; }
    public float getTopRatio() { return t; }
    public float getRightRatio() { return r; }
    public float getBottomRatio() { return b; }

    public void setRect(float nl, float nt, float nr, float nb) {
        l = clamp(nl); t = clamp(nt); r = clamp(nr); b = clamp(nb);
        if (r - l < 0.1f) r = Math.min(1f, l + 0.1f);
        if (b - t < 0.1f) b = Math.min(1f, t + 0.1f);
        invalidate();
    }

    public void reset() { l = 0f; t = 0f; r = 1f; b = 1f; invalidate(); }

    public boolean isFullFrame() {
        return l <= 0.005f && t <= 0.005f && r >= 0.995f && b >= 0.995f;
    }

    private static float clamp(float v) { return Math.max(0f, Math.min(1f, v)); }

    @Override
    protected void onDraw(Canvas c) {
        super.onDraw(c);
        float w = getWidth(), h = getHeight();
        tmp.set(l * w, t * h, r * w, b * h);
        // 框外压暗
        c.drawRect(0, 0, w, tmp.top, dimPaint);
        c.drawRect(0, tmp.bottom, w, h, dimPaint);
        c.drawRect(0, tmp.top, tmp.left, tmp.bottom, dimPaint);
        c.drawRect(tmp.right, tmp.top, w, tmp.bottom, dimPaint);
        c.drawRect(tmp, linePaint);
        // 三分线
        for (int i = 1; i <= 2; i++) {
            float x = tmp.left + tmp.width() * i / 3f;
            float y = tmp.top + tmp.height() * i / 3f;
            c.drawLine(x, tmp.top, x, tmp.bottom, linePaint);
            c.drawLine(tmp.left, y, tmp.right, y, linePaint);
        }
        // 四角把手
        float rad = 9f * density;
        c.drawCircle(tmp.left, tmp.top, rad, handlePaint);
        c.drawCircle(tmp.right, tmp.top, rad, handlePaint);
        c.drawCircle(tmp.right, tmp.bottom, rad, handlePaint);
        c.drawCircle(tmp.left, tmp.bottom, rad, handlePaint);
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        float w = getWidth(), h = getHeight();
        if (w <= 0 || h <= 0) return false;
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN: {
                float best = 44f * density, pick = -1f;
                float[] cx = {l * w, r * w, r * w, l * w};
                float[] cy = {t * h, t * h, b * h, b * h};
                for (int i = 0; i < 4; i++) {
                    float d = (float) Math.hypot(e.getX() - cx[i], e.getY() - cy[i]);
                    if (d < best) { best = d; pick = i; }
                }
                dragCorner = (int) pick;
                downX = e.getX(); downY = e.getY();
                startL = l; startT = t; startR = r; startB = b;
                return dragCorner >= 0;
            }
            case MotionEvent.ACTION_MOVE: {
                if (dragCorner < 0) return false;
                float dx = (e.getX() - downX) / w;
                float dy = (e.getY() - downY) / h;
                float nl = startL, nt = startT, nr = startR, nb = startB;
                if (dragCorner == 0) { nl = startL + dx; nt = startT + dy; }
                else if (dragCorner == 1) { nr = startR + dx; nt = startT + dy; }
                else if (dragCorner == 2) { nr = startR + dx; nb = startB + dy; }
                else { nl = startL + dx; nb = startB + dy; }
                setRect(nl, nt, nr, nb);
                if (listener != null) listener.onChanged(l, t, r, b);
                return true;
            }
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                if (dragCorner >= 0 && listener != null) listener.onChanged(l, t, r, b);
                dragCorner = -1;
                return true;
        }
        return false;
    }
}
