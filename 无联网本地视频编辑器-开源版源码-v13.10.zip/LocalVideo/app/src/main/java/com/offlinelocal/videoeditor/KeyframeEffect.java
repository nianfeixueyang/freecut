package com.offlinelocal.videoeditor;

import android.graphics.Matrix;

import androidx.media3.effect.MatrixTransformation;

import java.util.ArrayList;
import java.util.List;

/**
 * 自定义关键帧运镜：任意多个关键帧（时间 t + 缩放 + 位移 + 旋转），
 * 段间用线性或缓入缓出插值，逐帧生成矩阵。比固定 4 档运镜自由得多。
 */
public class KeyframeEffect implements MatrixTransformation {

    public static class Kf {
        public float t;        // 0~1
        public float scale = 1f;
        public float dx = 0f;  // NDC，-1~1
        public float dy = 0f;
        public float rot = 0f; // 度

        public Kf(float t, float scale, float dx, float dy, float rot) {
            this.t = t;
            this.scale = scale;
            this.dx = dx;
            this.dy = dy;
            this.rot = rot;
        }
    }

    public static final int EASE_LINEAR = 0;
    public static final int EASE_IN_OUT = 1;

    private final List<Kf> keys;
    private final long durationUs;
    private final int easing;

    public KeyframeEffect(List<Kf> keys, long durationMs, int easing) {
        this.keys = new ArrayList<>(keys);
        this.keys.sort((a, b) -> Float.compare(a.t, b.t));
        this.durationUs = Math.max(1, durationMs) * 1000L;
        this.easing = easing;
    }

    @Override
    public Matrix getMatrix(long presentationTimeUs) {
        float t = Math.max(0f, Math.min(1f, presentationTimeUs / (float) durationUs));
        Kf a = keys.get(0);
        Kf b = keys.get(keys.size() - 1);
        for (int i = 0; i < keys.size() - 1; i++) {
            if (t >= keys.get(i).t && t <= keys.get(i + 1).t) {
                a = keys.get(i);
                b = keys.get(i + 1);
                break;
            }
        }
        float span = b.t - a.t;
        float p = span <= 0.0001f ? 1f : (t - a.t) / span;
        p = Math.max(0f, Math.min(1f, p));
        if (easing == EASE_IN_OUT) {
            p = p * p * (3f - 2f * p);
        }
        float scale = a.scale + (b.scale - a.scale) * p;
        float dx = a.dx + (b.dx - a.dx) * p;
        float dy = a.dy + (b.dy - a.dy) * p;
        float rot = a.rot + (b.rot - a.rot) * p;
        Matrix m = new Matrix();
        m.postScale(scale, scale);
        if (rot != 0f) m.postRotate(rot);
        m.postTranslate(dx, dy);
        return m;
    }
}
