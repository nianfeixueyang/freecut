package com.offlinelocal.videoeditor;

import androidx.annotation.NonNull;
import androidx.media3.common.audio.AudioProcessor;
import androidx.media3.common.audio.AudioProcessor.AudioFormat;
import androidx.media3.common.audio.AudioProcessor.UnhandledAudioFormatException;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/**
 * 音量 + 淡入淡出处理器。
 * 直接处理 PCM 16bit 数据，按帧计算增益包络：
 *   前 fadeInMs 线性淡入，后 fadeOutMs 线性淡出，中间按 volume 放大/压低。
 */
public class GainAudioProcessor implements AudioProcessor {

    private float volume;
    private long fadeInMs;
    private long fadeOutMs;
    private long totalDurationMs;

    private AudioFormat format = AudioFormat.NOT_SET;
    private boolean active = true;

    private ByteBuffer buffer = AudioProcessor.EMPTY_BUFFER;
    private boolean outputEnded;
    private long framesWritten;

    public GainAudioProcessor(float volume, long fadeInMs, long fadeOutMs, long totalDurationMs) {
        this.volume = Math.max(0f, Math.min(2f, volume));
        this.fadeInMs = Math.max(0, fadeInMs);
        this.fadeOutMs = Math.max(0, fadeOutMs);
        this.totalDurationMs = Math.max(0, totalDurationMs);
    }

    @NonNull
    @Override
    public AudioFormat configure(@NonNull AudioFormat inputFormat) throws UnhandledAudioFormatException {
        if (inputFormat.encoding != androidx.media3.common.C.ENCODING_PCM_16BIT) {
            throw new UnhandledAudioFormatException(inputFormat);
        }
        format = inputFormat;
        active = volume != 1f || fadeInMs > 0 || fadeOutMs > 0;
        return inputFormat;
    }

    @Override
    public boolean isActive() {
        return active;
    }

    @Override
    public void queueInput(@NonNull ByteBuffer inputBuffer) {
        int size = inputBuffer.remaining();
        if (size == 0) {
            buffer = AudioProcessor.EMPTY_BUFFER;
            return;
        }
        if (buffer.capacity() < size) {
            buffer = ByteBuffer.allocateDirect(size).order(ByteOrder.nativeOrder());
            buffer.mark();
        }
        buffer.clear();
        int channels = Math.max(1, format.channelCount);
        int frameSize = 2 * channels;
        long totalFrames = format.sampleRate > 0
                ? (long) (totalDurationMs / 1000.0 * format.sampleRate)
                : 0L;

        ByteBuffer in = inputBuffer.order(ByteOrder.nativeOrder());
        int frames = size / frameSize;
        for (int f = 0; f < frames; f++) {
            float gain = volume;
            long frameIndex = framesWritten + f;
            long fadeInFrames = (long) (fadeInMs / 1000.0 * format.sampleRate);
            long fadeOutFrames = (long) (fadeOutMs / 1000.0 * format.sampleRate);
            if (fadeInFrames > 0 && frameIndex < fadeInFrames) {
                gain *= (float) frameIndex / fadeInFrames;
            }
            if (fadeOutFrames > 0 && totalFrames > 0) {
                long remain = totalFrames - frameIndex;
                if (remain < fadeOutFrames) {
                    gain *= Math.max(0f, (float) remain / fadeOutFrames);
                }
            }
            for (int c = 0; c < channels; c++) {
                short sample = in.getShort();
                int v = (int) (sample * gain);
                if (v > 32767) v = 32767;
                if (v < -32768) v = -32768;
                buffer.putShort((short) v);
            }
        }
        framesWritten += frames;
        // 尾部不足一帧的字节丢弃（每帧样本数固定，正常不会出现）
        buffer.flip();
    }

    @Override
    public void queueEndOfStream() {
        outputEnded = true;
    }

    @NonNull
    @Override
    public ByteBuffer getOutput() {
        ByteBuffer out = buffer;
        buffer = AudioProcessor.EMPTY_BUFFER;
        return out;
    }

    @Override
    public boolean isEnded() {
        return outputEnded && buffer == AudioProcessor.EMPTY_BUFFER;
    }

    @Override
    public void flush() {
        buffer = AudioProcessor.EMPTY_BUFFER;
        outputEnded = false;
        framesWritten = 0;
    }

    @Override
    public void reset() {
        flush();
        format = AudioFormat.NOT_SET;
    }
}
