package com.offlinelocal.videoeditor;

import static org.junit.Assert.assertNotNull;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;

import androidx.appcompat.view.ContextThemeWrapper;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.Robolectric;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.annotation.Config;

@RunWith(RobolectricTestRunner.class)
@Config(sdk = 34, qualifiers = "w411dp-h891dp-xxhdpi")
public class SmokeTest {

    private Context themed() {
        return new ContextThemeWrapper(
                org.robolectric.RuntimeEnvironment.getApplication(), R.style.Theme_LocalVideo);
    }

    @Test
    public void mainActivityInflates() {
        Activity a = Robolectric.buildActivity(MainActivity.class).setup().get();
        assertNotNull(a.findViewById(R.id.cardImage));
        assertNotNull(a.findViewById(R.id.cardVideo));
        assertNotNull(a.findViewById(R.id.cardBatch));
        assertNotNull(a.findViewById(R.id.btnHistory));
        assertNotNull(a.findViewById(R.id.cardCollage));
    }

    @Test
    public void imageEditorLayoutInflates() {
        View v = LayoutInflater.from(themed()).inflate(R.layout.activity_image_editor, null);
        assertNotNull(v.findViewById(R.id.canvas));
        assertNotNull(v.findViewById(R.id.toolRow));
        assertNotNull(v.findViewById(R.id.seekBrightness));
        assertNotNull(v.findViewById(R.id.panelLayers));
        assertNotNull(v.findViewById(R.id.panelBorder));
        assertNotNull(v.findViewById(R.id.rowLayers));
        assertNotNull(v.findViewById(R.id.btnAddSticker));
        assertNotNull(v.findViewById(R.id.btnStroke));
        assertNotNull(v.findViewById(R.id.btnShadow));
        assertNotNull(v.findViewById(R.id.btnAlign));
        assertNotNull(v.findViewById(R.id.seekLayerAlpha));
        assertNotNull(v.findViewById(R.id.seekMosaic));
        assertNotNull(v.findViewById(R.id.seekFilterStrength));
        assertNotNull(v.findViewById(R.id.seekFineRotate));
        assertNotNull(v.findViewById(R.id.rowShapes));
        assertNotNull(v.findViewById(R.id.rowBlend));
        assertNotNull(v.findViewById(R.id.rowFrames));
        assertNotNull(v.findViewById(R.id.btnRedo));
    }

    @Test
    public void videoEditorLayoutInflates() {
        View v = LayoutInflater.from(themed()).inflate(R.layout.activity_video_editor, null);
        assertNotNull(v.findViewById(R.id.playerView));
        assertNotNull(v.findViewById(R.id.trimSlider));
        assertNotNull(v.findViewById(R.id.btnExport));
        assertNotNull(v.findViewById(R.id.toolRow));
    }

    @Test
    public void batchLayoutInflates() {
        View v = LayoutInflater.from(themed()).inflate(R.layout.activity_batch, null);
        assertNotNull(v.findViewById(R.id.preview));
        assertNotNull(v.findViewById(R.id.rowFilters));
        assertNotNull(v.findViewById(R.id.rowBorderColors));
        assertNotNull(v.findViewById(R.id.btnRun));
        assertNotNull(v.findViewById(R.id.seekBrightness));
    }

    @Test
    public void historyLayoutInflates() {
        View v = LayoutInflater.from(themed()).inflate(R.layout.activity_history, null);
        assertNotNull(v.findViewById(R.id.rowHistory));
        assertNotNull(v.findViewById(R.id.tvEmpty));
    }

    @Test
    public void collageLayoutInflates() {
        View v = LayoutInflater.from(themed()).inflate(R.layout.activity_collage, null);
        assertNotNull(v.findViewById(R.id.preview));
        assertNotNull(v.findViewById(R.id.rowStyles));
        assertNotNull(v.findViewById(R.id.seekGap));
        assertNotNull(v.findViewById(R.id.btnSave));
    }

    @Test
    public void editCanvasHandlesBitmapOps() {
        View v = LayoutInflater.from(themed()).inflate(R.layout.activity_image_editor, null);
        EditImageView canvas = v.findViewById(R.id.canvas);
        assertNotNull(canvas);
    }
}
