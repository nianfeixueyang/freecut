package com.offlinelocal.videoeditor;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;

/** v13.2：线程池、手势仲裁、草稿、重采样、前台服务诊断。 */
public class StabilityBatchTest {

    private static String read(String p) throws Exception {
        return new String(Files.readAllBytes(Paths.get(p)), StandardCharsets.UTF_8);
    }

    @Test
    public void 全站统一线程池且无裸线程() throws Exception {
        String work = read("src/main/java/com/offlinelocal/videoeditor/Work.java");
        assertTrue(work.contains("ThreadPoolExecutor"));
        assertTrue(work.contains("public static void cancelAll()"));
        for (String f : new String[]{"VideoEditorActivity.java", "ImageEditorActivity.java",
                "MainActivity.java", "BatchActivity.java", "CollageActivity.java",
                "EditImageView.java"}) {
            String src = read("src/main/java/com/offlinelocal/videoeditor/" + f);
            assertTrue(f + " 仍有裸线程", !src.contains("new Thread(() ->"));
        }
    }

    @Test
    public void 手势目标在按下时锁定() throws Exception {
        String v = read("src/main/java/com/offlinelocal/videoeditor/EditImageView.java");
        assertTrue(v.contains("gestureOnCanvas"));
        assertTrue(v.contains("手势仲裁"));
        assertTrue(v.contains("整段手势期间不再改判"));
    }

    @Test
    public void 图片草稿自动保存与恢复() throws Exception {
        String d = read("src/main/java/com/offlinelocal/videoeditor/ImageDraft.java");
        assertTrue(d.contains("public static void save"));
        assertTrue(d.contains("public static Bitmap load"));
        String img = read("src/main/java/com/offlinelocal/videoeditor/ImageEditorActivity.java");
        assertTrue(img.contains("maybeOfferDraft"));
        assertTrue(img.contains("ImageDraft.saveLayered(this, src, out, keep)"));
        assertTrue(img.contains("clearHistory"));
    }

    @Test
    public void 重采样改三次插值() throws Exception {
        String a = read("src/main/java/com/offlinelocal/videoeditor/AudioMixer.java");
        assertTrue(a.contains("Catmull-Rom"));
        assertTrue(a.contains("sampleAt("));
    }

    @Test
    public void 前台服务异常留痕() throws Exception {
        String s = read("src/main/java/com/offlinelocal/videoeditor/ExportService.java");
        assertTrue(s.contains("ExportDiag.warn(\"fgs_start\""));
        assertTrue(s.contains("FOREGROUND_SERVICE_TYPE_DATA_SYNC"));
        assertEquals(true, s.contains("startForeground"));
    }
}
