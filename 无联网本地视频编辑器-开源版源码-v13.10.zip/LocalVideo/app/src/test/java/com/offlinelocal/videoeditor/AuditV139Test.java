package com.offlinelocal.videoeditor;

import static org.junit.Assert.assertTrue;

import org.junit.Test;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;

/** v13.9：图片/动图当片段、配乐闪避、滤镜扩容、黑金夜景预设修正。 */
public class AuditV139Test {

    private static String read(String p) throws Exception {
        return new String(Files.readAllBytes(Paths.get(p)), StandardCharsets.UTF_8);
    }

    @Test
    public void 图片也能当视频片段() throws Exception {
        String g = read("src/main/java/com/offlinelocal/videoeditor/GifToVideo.java");
        assertTrue(g.contains("convertStill"));
        assertTrue(read("src/main/java/com/offlinelocal/videoeditor/VideoEditorActivity.java")
                .contains("convertStill"));
        assertTrue(read("src/main/java/com/offlinelocal/videoeditor/MainActivity.java")
                .contains("convertStill"));
    }

    @Test
    public void 片段选择器接受图片与动图() throws Exception {
        assertTrue(read("src/main/java/com/offlinelocal/videoeditor/VideoEditorActivity.java")
                .contains("new String[]{\"video/*\", \"image/gif\", \"image/*\"}"));
    }

    @Test
    public void 配乐会闪避配音() throws Exception {
        String a = read("src/main/java/com/offlinelocal/videoeditor/AudioMixer.java");
        assertTrue(a.contains("duckMusic"));
        assertTrue(a.contains("duckGain"));
        assertTrue(read("src/main/java/com/offlinelocal/videoeditor/VideoEditorActivity.java")
                .contains("配音闪避"));
    }

    @Test
    public void 新滤镜与黑金夜景修正() throws Exception {
        String f = read("src/main/java/com/offlinelocal/videoeditor/Filters.java");
        assertTrue(f.contains("new Preset(\"赛博\""));
        assertTrue(f.contains("new Preset(\"落日金\""));
        assertTrue(read("src/main/java/com/offlinelocal/videoeditor/VideoEditorActivity.java")
                .contains("indexOfFilter(\"暗夜\")"));
    }
}
