package com.offlinelocal.videoeditor;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;

/** v13.1：内存与稳定性专项（流式混音、蒙版复用、缓存回收、诊断日志）。 */
public class MemoryHygieneTest {

    private static String read(String p) throws Exception {
        return new String(Files.readAllBytes(Paths.get(p)), StandardCharsets.UTF_8);
    }

    @Test
    public void 混音不再一次性解码整段音频() throws Exception {
        String a = read("src/main/java/com/offlinelocal/videoeditor/AudioMixer.java");
        assertTrue(a.contains("mixChunk("));
        assertTrue("必须是分块流式", a.contains("chunkFrames = SR * 4"));
        assertTrue(!a.contains("short[] mixed = new short[frames * CH]"));
        assertTrue("区间解码必须在 endMs 处截断", a.contains("pts > endMs * 1000L"));
    }

    @Test
    public void 蒙版位图复用且可回收() throws Exception {
        String v = read("src/main/java/com/offlinelocal/videoeditor/EditImageView.java");
        assertTrue(v.contains("maskScratch"));
        assertTrue(v.contains("releaseCaches()"));
        assertTrue(v.contains("onDetachedFromWindow"));
    }

    @Test
    public void 撤销快照保留文字底色() throws Exception {
        String v = read("src/main/java/com/offlinelocal/videoeditor/EditImageView.java");
        assertTrue(v.contains("l.textBgColor = textBgColor;"));
        assertTrue(v.contains("l.textBgPad = textBgPad;"));
    }

    @Test
    public void 导出失败不再静默() throws Exception {
        String d = read("src/main/java/com/offlinelocal/videoeditor/ExportDiag.java");
        assertEquals(true, d.contains("public static void warn"));
        String tr = read("src/main/java/com/offlinelocal/videoeditor/TransitionRenderer.java");
        assertTrue(tr.contains("ExportDiag.warn(\"transition_render\""));
        String vs = read("src/main/java/com/offlinelocal/videoeditor/VideoEditorActivity.java");
        assertTrue(vs.contains("ExportDiag.dump()"));
    }

    @Test
    public void 贴纸选择持久化权限() throws Exception {
        String i = read("src/main/java/com/offlinelocal/videoeditor/ImageEditorActivity.java");
        assertTrue(i.contains("takePersistableUriPermission"));
    }
}
