package com.offlinelocal.videoeditor;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;

/** v12.21：双轨转场引擎 + 底部面板 + 图片调色工作台。 */
public class TransitionAndSheetTest {

    private static String read(String p) throws Exception {
        return new String(Files.readAllBytes(Paths.get(p)), StandardCharsets.UTF_8);
    }

    @Test
    public void 转场引擎具备双路纹理与混合着色器() throws Exception {
        String src = read("src/main/java/com/offlinelocal/videoeditor/TransitionRenderer.java");
        assertTrue(src.contains("samplerExternalOES uTexA"));
        assertTrue(src.contains("samplerExternalOES uTexB"));
        assertTrue(src.contains("uProgress"));
        assertTrue(src.contains("uType"));
        assertTrue(src.contains("DISSOLVE") && src.contains("WIPE")
                && src.contains("PUSH") && src.contains("ZOOM"));
        assertTrue("必须用编码器 Surface", src.contains("createInputSurface"));
    }

    @Test
    public void 转场音频交叉淡化与区间解码() throws Exception {
        String mp = read("src/main/java/com/offlinelocal/videoeditor/AudioMixer.java");
        assertTrue(mp.contains("public static short[] pcmRange"));
        String tr = read("src/main/java/com/offlinelocal/videoeditor/TransitionRenderer.java");
        assertTrue(tr.contains("crossfade("));
        assertTrue(tr.contains("encodeAac("));
        assertTrue(tr.contains("addTrack(audio.format)"));
    }

    @Test
    public void 导出按过渡片段拼接并裁剪两端() throws Exception {
        String vs = read("src/main/java/com/offlinelocal/videoeditor/VideoEditorActivity.java");
        assertTrue(vs.contains("startTransitionBuild"));
        assertTrue(vs.contains("transFiles[ci - 1]"));
        assertTrue(vs.contains("transFiles[ci]"));
        assertTrue(vs.contains("o.put(\"transType\", transType)"));
    }

    @Test
    public void 未支持机型会退回黑场而不是崩() throws Exception {
        String vs = read("src/main/java/com/offlinelocal/videoeditor/VideoEditorActivity.java");
        assertTrue(vs.contains("if (clipTransitionMs > 0)"));
        assertTrue(vs.contains("new FadeEffect(clipMs, fadeMs)"));
        assertTrue(vs.contains("transFiles[ci] = null"));
    }

    @Test
    public void 参数面板是自绘底部卡片() throws Exception {
        String ui = read("src/main/java/com/offlinelocal/videoeditor/SheetUi.java");
        assertTrue(ui.contains("public static Panel panel"));
        assertTrue(ui.contains("public static Panel list"));
        assertTrue(ui.contains("public static TextView[] chips"));
        assertTrue(ui.contains("public static android.widget.SeekBar slider"));
        String vs = read("src/main/java/com/offlinelocal/videoeditor/VideoEditorActivity.java");
        assertTrue(vs.contains("SheetUi.list(this, title, items, checked"));
    }

    @Test
    public void 图片侧补齐六参数调色() throws Exception {
        String f = read("src/main/java/com/offlinelocal/videoeditor/Filters.java");
        assertTrue(f.contains("float hue, float fade"));
        String img = read("src/main/java/com/offlinelocal/videoeditor/ImageEditorActivity.java");
        assertTrue(img.contains("openColorGrade"));
        assertTrue(img.contains("\"褪色\""));
        assertTrue(img.contains("\"色调\""));
        assertEquals(true, img.contains("SheetUi.slider"));
    }
}
