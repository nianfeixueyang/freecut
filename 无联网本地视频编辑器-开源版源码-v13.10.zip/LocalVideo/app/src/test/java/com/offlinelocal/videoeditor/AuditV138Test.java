package com.offlinelocal.videoeditor;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

/** v13.8：动图进视频编辑、长视频音频、退出取消任务、转场/关键帧提示、SRT 状态机。 */
public class AuditV138Test {

    private static String read(String p) throws Exception {
        return new String(Files.readAllBytes(Paths.get(p)), StandardCharsets.UTF_8);
    }

    @Test
    public void 动图能进视频编辑入口() throws Exception {
        assertTrue(read("src/main/java/com/offlinelocal/videoeditor/MainActivity.java")
                .contains("image/gif"));
        assertTrue(read("src/main/java/com/offlinelocal/videoeditor/VideoEditorActivity.java")
                .contains("image/gif"));
        String g = read("src/main/java/com/offlinelocal/videoeditor/GifToVideo.java");
        assertTrue(g.contains("Movie.decodeStream"));
        assertTrue(g.contains("MediaMuxer"));
        assertTrue(g.contains("isAnimated"));
    }

    @Test
    public void 混音不再截断二十分钟且配音不被淡掉() throws Exception {
        String a = read("src/main/java/com/offlinelocal/videoeditor/AudioMixer.java");
        assertTrue(!a.contains("20 * 60 * SR"));
        assertTrue(a.contains("val += v[src] * vg;"));
    }

    @Test
    public void 退出视频页会取消后台任务() throws Exception {
        String v = read("src/main/java/com/offlinelocal/videoeditor/VideoEditorActivity.java");
        assertTrue(v.contains("Work.cancelOwner(this);"));
    }

    @Test
    public void 短转场与关键帧失败有提示() throws Exception {
        String v = read("src/main/java/com/offlinelocal/videoeditor/VideoEditorActivity.java");
        assertTrue(v.contains("转场已改用硬切"));
        assertTrue(v.contains("ExportDiag.warn(\"keyframe\""));
        assertTrue(v.contains("ExportDiag.warn(\"export_pref\""));
    }

    @Test
    public void 时间显示按四舍五入() throws Exception {
        String v = read("src/main/java/com/offlinelocal/videoeditor/VideoEditorActivity.java");
        assertTrue(v.contains("Math.round(ms / 100.0)"));
    }

    @Test
    public void srt正文含空行仍是一条字幕() {
        String srt = "1\n00:00:01,000 --> 00:00:03,000\n第一行\n\n第三行\n\n2\n00:00:04,000 --> 00:00:06,000\n第二条\n";
        List<TimedTextOverlay.Cue> cues = SrtUtils.parse(srt);
        assertEquals(2, cues.size());
        assertEquals(1000, cues.get(0).startMs);
        assertTrue(cues.get(0).text.contains("第一行"));
        assertTrue(cues.get(0).text.contains("第三行"));
        assertEquals("第二条", cues.get(1).text);
    }
}
