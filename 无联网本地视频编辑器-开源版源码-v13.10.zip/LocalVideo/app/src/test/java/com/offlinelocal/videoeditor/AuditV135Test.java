package com.offlinelocal.videoeditor;

import static org.junit.Assert.assertTrue;

import org.junit.Test;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;

/** v13.5：手势跨对象、缩放上限、页面级取消、草稿清理、短片段兜底。 */
public class AuditV135Test {

    private static String read(String p) throws Exception {
        return new String(Files.readAllBytes(Paths.get(p)), StandardCharsets.UTF_8);
    }

    @Test
    public void 第二根手指落图层可改锁() throws Exception {
        String v = read("src/main/java/com/offlinelocal/videoeditor/EditImageView.java");
        assertTrue(v.contains("ACTION_POINTER_DOWN && gestureOnCanvas"));
        assertTrue(v.contains("hitLayer(e.getX(1), e.getY(1))"));
    }

    @Test
    public void 图层缩放有上限() throws Exception {
        String v = read("src/main/java/com/offlinelocal/videoeditor/EditImageView.java");
        assertTrue(v.contains("curScale > 16f"));
        assertTrue(v.contains("0.02f"));
    }

    @Test
    public void 页面销毁取消自己的任务() throws Exception {
        String w = read("src/main/java/com/offlinelocal/videoeditor/Work.java");
        assertTrue(w.contains("cancelOwner"));
        for (String f : new String[]{"BatchActivity.java", "CollageActivity.java",
                "ImageEditorActivity.java"}) {
            assertTrue(f, read("src/main/java/com/offlinelocal/videoeditor/" + f).contains("Work.cancelOwner(this)"));
        }
    }

    @Test
    public void 草稿有过期清理与碎片清理() throws Exception {
        String d = read("src/main/java/com/offlinelocal/videoeditor/ImageDraft.java");
        assertTrue(d.contains("public static void prune"));
        assertTrue(d.contains("layer_"));
        assertTrue(d.contains("临近") || d.contains("7L * 24"));
    }

    @Test
    public void 崩溃日志文件名带毫秒() throws Exception {
        String c = read("src/main/java/com/offlinelocal/videoeditor/LocalVideoApp.java");
        assertTrue(c.contains("MMdd-HHmmss-SSS"));
    }

    @Test
    public void 极短片段有兜底提示() throws Exception {
        String v = read("src/main/java/com/offlinelocal/videoeditor/VideoEditorActivity.java");
        assertTrue(v.contains("片段过短"));
        assertTrue(v.contains("Math.min(500f"));
    }

    @Test
    public void 进入编辑器不会把片段截成零点几秒() throws Exception {
        String v = read("src/main/java/com/offlinelocal/videoeditor/VideoEditorActivity.java");
        assertTrue(v.contains("if (c.endMs <= c.startMs || c.endMs > c.durationMs + 1)"));
        assertTrue(v.contains("c.endMs = c.durationMs;"));
        assertTrue(v.contains("float range = Math.max(300f, dur);"));
    }

    @Test
    public void 裁剪值不会超出素材时长() throws Exception {
        String v = read("src/main/java/com/offlinelocal/videoeditor/VideoEditorActivity.java");
        assertTrue(v.contains("Math.min(vals.get(1).longValue(), dur2)"));
    }

    @Test
    public void 预览有自愈与诊断() throws Exception {
        String v = read("src/main/java/com/offlinelocal/videoeditor/VideoEditorActivity.java");
        assertTrue(v.contains("selfHealPreview"));
        assertTrue(v.contains("onRenderedFirstFrame"));
        assertTrue(v.contains("RESIZE_MODE_ZOOM"));
        assertTrue(v.contains("\" box=\""));
    }

    @Test
    public void 缩放值恢复时有夹取() throws Exception {
        String v = read("src/main/java/com/offlinelocal/videoeditor/VideoEditorActivity.java");
        assertTrue(v.contains("Math.max(0.2f, Math.min(8f, zoom))"));
    }
}
