package com.offlinelocal.videoeditor;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import android.graphics.Bitmap;

import androidx.test.core.app.ApplicationProvider;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;

/** 63 张贴纸必须全部能从 assets 解出来，且名字与文件一一对应。 */
@RunWith(RobolectricTestRunner.class)
public class StickerPackTest {

    @Test
    public void namesAndFilesMatchCount() {
        assertEquals(63, StickerLibrary.COUNT);
        assertEquals(StickerLibrary.COUNT, StickerLibrary.NAMES.length);
        assertEquals(StickerLibrary.COUNT, StickerLibrary.FILES.length);
        assertEquals(StickerLibrary.CATEGORIES.length, StickerLibrary.CATEGORY_START.length);
        for (String n : StickerLibrary.NAMES) assertTrue(n != null && !n.isEmpty());
    }

    @Test
    public void everyStickerLoadsFromAssets() {
        for (int i = 0; i < StickerLibrary.COUNT; i++) {
            Bitmap bmp = StickerLibrary.make(ApplicationProvider.getApplicationContext(), i, 64);
            assertNotNull("贴纸 " + (i + 1) + " 没解出来：" + StickerLibrary.FILES[i], bmp);
            assertEquals(64, bmp.getWidth());
            assertNotNull(bmp.getConfig());
        }
    }

    @Test
    public void thumbnailsDecode() {
        Bitmap t = StickerLibrary.thumb(ApplicationProvider.getApplicationContext(), 0, 48);
        assertNotNull(t);
        assertEquals(48, t.getWidth());
    }
}
