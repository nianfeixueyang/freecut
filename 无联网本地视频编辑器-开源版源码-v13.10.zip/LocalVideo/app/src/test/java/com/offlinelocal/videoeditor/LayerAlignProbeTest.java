package com.offlinelocal.videoeditor;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.annotation.Config;
import org.robolectric.annotation.GraphicsMode;

@RunWith(RobolectricTestRunner.class)
@Config(sdk = 34, qualifiers = "w411dp-h891dp-xxhdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
public class LayerAlignProbeTest {

    private static int[] bbox(Bitmap b, int test) {
        // test==2: 任何非白像素（贴纸内容）
        int minX = Integer.MAX_VALUE, minY = Integer.MAX_VALUE, maxX = -1, maxY = -1;
        for (int y = 0; y < b.getHeight(); y++) {
            for (int x = 0; x < b.getWidth(); x++) {
                int c = b.getPixel(x, y);
                boolean hit;
                if (test == 0) hit = Color.red(c) > 200 && Color.green(c) < 80 && Color.blue(c) < 80;
                else if (test == 1) hit = Color.green(c) > 180 && Color.red(c) < 120 && Color.blue(c) < 160;
                else hit = Color.red(c) < 240 || Color.green(c) < 240 || Color.blue(c) < 240;
                if (hit) {
                    if (x < minX) minX = x;
                    if (y < minY) minY = y;
                    if (x > maxX) maxX = x;
                    if (y > maxY) maxY = y;
                }
            }
        }
        return new int[]{minX, minY, maxX, maxY};
    }

    @Test
    public void stickerBoxMatchesArt() {
        EditImageView v = new EditImageView(org.robolectric.RuntimeEnvironment.getApplication());
        Bitmap base = Bitmap.createBitmap(400, 400, Bitmap.Config.ARGB_8888);
        Canvas bc = new Canvas(base);
        bc.drawColor(Color.WHITE);
        v.setBitmap(base);
        v.measure(android.view.View.MeasureSpec.makeMeasureSpec(400, android.view.View.MeasureSpec.EXACTLY),
                android.view.View.MeasureSpec.makeMeasureSpec(400, android.view.View.MeasureSpec.EXACTLY));
        v.layout(0, 0, 400, 400);

        Bitmap st = Bitmap.createBitmap(100, 100, Bitmap.Config.ARGB_8888);
        st.eraseColor(Color.RED);
        v.addSticker(st);

        EditImageView.Layer l = v.getLayers().get(0);
        System.out.println("VIEW=" + v.getWidth() + "x" + v.getHeight() + " base=" + base.getWidth()
                + " matrix=" + l.matrix + " sticker=" + l.stickerW);
        Bitmap out = Bitmap.createBitmap(400, 400, Bitmap.Config.ARGB_8888);
        v.draw(new Canvas(out));
        int[] art = bbox(out, 0);
        int[] box = bbox(out, 1);
        System.out.println("ART=" + art[0] + "," + art[1] + "," + art[2] + "," + art[3]
                + " BOX=" + box[0] + "," + box[1] + "," + box[2] + "," + box[3]);
        int dcx = ((art[0] + art[2]) / 2) - ((box[0] + box[2]) / 2);
        int dcy = ((art[1] + art[3]) / 2) - ((box[1] + box[3]) / 2);
        System.out.println("CENTER DELTA=" + dcx + "," + dcy);
        assertTrue("delta " + dcx + "," + dcy, Math.abs(dcx) <= 8 && Math.abs(dcy) <= 8);
    }

    @Test
    public void realAssetStickerKeepsBoxOnArt() {
        EditImageView v = new EditImageView(org.robolectric.RuntimeEnvironment.getApplication());
        Bitmap base = Bitmap.createBitmap(400, 400, Bitmap.Config.ARGB_8888);
        new Canvas(base).drawColor(Color.WHITE);
        v.setBitmap(base);
        v.measure(android.view.View.MeasureSpec.makeMeasureSpec(400, android.view.View.MeasureSpec.EXACTLY),
                android.view.View.MeasureSpec.makeMeasureSpec(400, android.view.View.MeasureSpec.EXACTLY));
        v.layout(0, 0, 400, 400);

        Bitmap st = StickerLibrary.make(org.robolectric.RuntimeEnvironment.getApplication(), 0, 512);
        assertTrue("sticker decoded", st != null);
        v.addSticker(st);

        Bitmap out = Bitmap.createBitmap(400, 400, Bitmap.Config.ARGB_8888);
        v.draw(new Canvas(out));
        int[] art = bbox(out, 2);   // 非白即贴纸
        int[] box = bbox(out, 1);
        System.out.println("ASSET ART=" + art[0] + "," + art[1] + "," + art[2] + "," + art[3]
                + " BOX=" + box[0] + "," + box[1] + "," + box[2] + "," + box[3]);
        int artW = art[2] - art[0], boxW = box[2] - box[0];
        int dcx = ((art[0] + art[2]) / 2) - ((box[0] + box[2]) / 2);
        int dcy = ((art[1] + art[3]) / 2) - ((box[1] + box[3]) / 2);
        System.out.println("ASSET artW=" + artW + " boxW=" + boxW + " delta=" + dcx + "," + dcy);
        assertTrue("center delta " + dcx + "," + dcy, Math.abs(dcx) <= 10 && Math.abs(dcy) <= 10);
        assertTrue("art should not exceed box much: " + artW + " vs " + boxW, artW <= boxW + 6);
    }

    @Test
    public void textBoxMatchesArt() {
        EditImageView v = new EditImageView(org.robolectric.RuntimeEnvironment.getApplication());
        Bitmap base = Bitmap.createBitmap(400, 400, Bitmap.Config.ARGB_8888);
        new Canvas(base).drawColor(Color.WHITE);
        v.setBitmap(base);
        v.measure(android.view.View.MeasureSpec.makeMeasureSpec(400, android.view.View.MeasureSpec.EXACTLY),
                android.view.View.MeasureSpec.makeMeasureSpec(400, android.view.View.MeasureSpec.EXACTLY));
        v.layout(0, 0, 400, 400);
        v.addText("无联网本地视频编辑器");
        v.setTextColor(Color.RED);

        Bitmap out = Bitmap.createBitmap(400, 400, Bitmap.Config.ARGB_8888);
        v.draw(new Canvas(out));
        int[] art = bbox(out, 0);
        int[] box = bbox(out, 1);
        int dcx = ((art[0] + art[2]) / 2) - ((box[0] + box[2]) / 2);
        int dcy = ((art[1] + art[3]) / 2) - ((box[1] + box[3]) / 2);
        System.out.println("TEXT ART=" + art[0] + "," + art[1] + "," + art[2] + "," + art[3]
                + " BOX=" + box[0] + "," + box[1] + "," + box[2] + "," + box[3] + " delta=" + dcx + "," + dcy);
        // 水平居中，垂直方向也要落在框里（允许基线造成的少量偏移）
        assertTrue("text center x " + dcx, Math.abs(dcx) <= 12);
        assertTrue("text inside box y " + dcy, Math.abs(dcy) <= 30);
    }


    @Test
    public void textLayerCanBeDraggedByFinger() {
        EditImageView v = new EditImageView(org.robolectric.RuntimeEnvironment.getApplication());
        Bitmap base = Bitmap.createBitmap(400, 400, Bitmap.Config.ARGB_8888);
        new Canvas(base).drawColor(Color.WHITE);
        v.setBitmap(base);
        v.measure(android.view.View.MeasureSpec.makeMeasureSpec(400, android.view.View.MeasureSpec.EXACTLY),
                android.view.View.MeasureSpec.makeMeasureSpec(400, android.view.View.MeasureSpec.EXACTLY));
        v.layout(0, 0, 400, 400);
        EditImageView.Layer l = v.addText("无联网本地视频编辑器");
        v.setMode(EditImageView.Mode.TEXT);

        float[] pt = new float[]{250, 190};
        assertTrue("text hit at 250,190", v.layerAt(pt[0], pt[1]) == l);

        long t = 100;
        v.onTouchEvent(android.view.MotionEvent.obtain(t, t, android.view.MotionEvent.ACTION_DOWN, 250, 190, 0));
        v.onTouchEvent(android.view.MotionEvent.obtain(t, t + 50, android.view.MotionEvent.ACTION_MOVE, 310, 220, 0));
        float[] after = new float[9];
        l.matrix.getValues(after);
        v.onTouchEvent(android.view.MotionEvent.obtain(t, t + 80, android.view.MotionEvent.ACTION_UP, 310, 220, 0));
        System.out.println("TEXT DRAG matrix=" + after[2] + "," + after[5] + " (start 200,200)");
        assertTrue("dx " + after[2], Math.abs(after[2] - 260f) <= 4);
        assertTrue("dy " + after[5], Math.abs(after[5] - 230f) <= 4);
    }


    @Test
    public void mosaicCannotBePickedOrDragged() {
        EditImageView v = new EditImageView(org.robolectric.RuntimeEnvironment.getApplication());
        Bitmap base = Bitmap.createBitmap(400, 400, Bitmap.Config.ARGB_8888);
        new Canvas(base).drawColor(Color.WHITE);
        v.setBitmap(base);
        v.measure(android.view.View.MeasureSpec.makeMeasureSpec(400, android.view.View.MeasureSpec.EXACTLY),
                android.view.View.MeasureSpec.makeMeasureSpec(400, android.view.View.MeasureSpec.EXACTLY));
        v.layout(0, 0, 400, 400);

        v.setMode(EditImageView.Mode.MOSAIC);
        long t = 200;
        v.onTouchEvent(android.view.MotionEvent.obtain(t, t, android.view.MotionEvent.ACTION_DOWN, 100, 100, 0));
        v.onTouchEvent(android.view.MotionEvent.obtain(t, t + 50, android.view.MotionEvent.ACTION_MOVE, 220, 160, 0));
        v.onTouchEvent(android.view.MotionEvent.obtain(t, t + 80, android.view.MotionEvent.ACTION_UP, 220, 160, 0));

        boolean hasMosaic = false;
        for (EditImageView.Layer l : v.getLayers()) {
            if (l.type == EditImageView.LayerType.MOSAIC) hasMosaic = true;
        }
        assertTrue("mosaic stroke created", hasMosaic);

        v.setMode(EditImageView.Mode.NONE);
        assertTrue("mosaic must not be hit", v.layerAt(150, 130) == null);
    }


    @Test
    public void nonSquareBaseKeepsBoxOnArt() {
        EditImageView v = new EditImageView(org.robolectric.RuntimeEnvironment.getApplication());
        Bitmap base = Bitmap.createBitmap(300, 800, Bitmap.Config.ARGB_8888);
        new Canvas(base).drawColor(Color.WHITE);
        v.setBitmap(base);
        v.measure(android.view.View.MeasureSpec.makeMeasureSpec(400, android.view.View.MeasureSpec.EXACTLY),
                android.view.View.MeasureSpec.makeMeasureSpec(400, android.view.View.MeasureSpec.EXACTLY));
        v.layout(0, 0, 400, 400);

        Bitmap st = Bitmap.createBitmap(100, 100, Bitmap.Config.ARGB_8888);
        st.eraseColor(Color.RED);
        v.addSticker(st);

        Bitmap out = Bitmap.createBitmap(400, 400, Bitmap.Config.ARGB_8888);
        EditImageView.Layer sl = v.getLayers().get(v.getLayers().size() - 1);
        float[] mv = new float[9];
        sl.matrix.getValues(mv);
        System.out.println("TALL MATRIX=" + mv[0] + "," + mv[2] + "," + mv[5] + " sel=" + (v.getSelected() == sl));
        v.draw(new Canvas(out));
        int[] art = bbox(out, 0);
        int[] box = bbox(out, 1);
        android.graphics.RectF r = v.selectionRectForTest();
        System.out.println("TALL rect=" + r);
        Bitmap out2 = Bitmap.createBitmap(400, 400, Bitmap.Config.ARGB_8888);
        v.selectLayer(-1);
        v.draw(new Canvas(out2));
        int[] box2 = bbox(out2, 1);
        System.out.println("TALL no-select BOX=" + box2[0] + "," + box2[1] + "," + box2[2] + "," + box2[3]);
        System.out.println("TALL ART=" + art[0] + "," + art[1] + "," + art[2] + "," + art[3]
                + " BOX=" + box[0] + "," + box[1] + "," + box[2] + "," + box[3]);
        int dcx = ((art[0] + art[2]) / 2) - ((box[0] + box[2]) / 2);
        int dcy = ((art[1] + art[3]) / 2) - ((box[1] + box[3]) / 2);
        System.out.println("TALL delta=" + dcx + "," + dcy);
        assertTrue("tall delta " + dcx + "," + dcy, Math.abs(dcx) <= 8 && Math.abs(dcy) <= 8);
    }


    @Test
    public void undoMustNotLeaveGhostSelection() {
        EditImageView v = new EditImageView(org.robolectric.RuntimeEnvironment.getApplication());
        Bitmap base = Bitmap.createBitmap(400, 400, Bitmap.Config.ARGB_8888);
        new Canvas(base).drawColor(Color.WHITE);
        v.setBitmap(base);
        v.measure(android.view.View.MeasureSpec.makeMeasureSpec(400, android.view.View.MeasureSpec.EXACTLY),
                android.view.View.MeasureSpec.makeMeasureSpec(400, android.view.View.MeasureSpec.EXACTLY));
        v.layout(0, 0, 400, 400);
        EditImageView.Layer l = v.addText("你好");
        v.setMode(EditImageView.Mode.NONE);

        long t = 300;
        v.onTouchEvent(android.view.MotionEvent.obtain(t, t, android.view.MotionEvent.ACTION_DOWN, 220, 200, 0));
        v.onTouchEvent(android.view.MotionEvent.obtain(t, t + 40, android.view.MotionEvent.ACTION_MOVE, 260, 240, 0));
        v.onTouchEvent(android.view.MotionEvent.obtain(t, t + 60, android.view.MotionEvent.ACTION_UP, 260, 240, 0));

        v.undo();

        EditImageView.Layer sel = v.getSelected();
        boolean inList = false;
        for (EditImageView.Layer x : v.getLayers()) if (x == sel) inList = true;
        System.out.println("UNDO selected=" + (sel == null ? "null" : "layer") + " inList=" + inList
                + " layers=" + v.getLayers().size());
        assertTrue("选中对象必须在图层列表里，不能是幽灵", sel == null || inList);
    }


    @Test
    public void stickerSizeSliderChangesWidthAndKeepsBox() {
        EditImageView v = new EditImageView(org.robolectric.RuntimeEnvironment.getApplication());
        Bitmap base = Bitmap.createBitmap(300, 800, Bitmap.Config.ARGB_8888);
        new Canvas(base).drawColor(Color.WHITE);
        v.setBitmap(base);
        v.measure(android.view.View.MeasureSpec.makeMeasureSpec(400, android.view.View.MeasureSpec.EXACTLY),
                android.view.View.MeasureSpec.makeMeasureSpec(400, android.view.View.MeasureSpec.EXACTLY));
        v.layout(0, 0, 400, 400);

        Bitmap st = Bitmap.createBitmap(100, 100, Bitmap.Config.ARGB_8888);
        st.eraseColor(Color.RED);
        v.addSticker(st);
        v.setMode(EditImageView.Mode.NONE);
        assertTrue("应当识别到选中贴纸", v.hasSelectedSticker());

        v.setSelectedStickerWidthRatio(0.8f);
        float ratio = v.getSelectedStickerWidthRatio();
        System.out.println("RATIO after slider=" + ratio);
        assertTrue("滑杆应能改到 80% 宽", Math.abs(ratio - 0.8f) < 0.02f);

        Bitmap out = Bitmap.createBitmap(400, 400, Bitmap.Config.ARGB_8888);
        v.draw(new Canvas(out));
        int[] art = bbox(out, 0);
        int[] box = bbox(out, 1);
        int w = art[2] - art[0] + 1;
        System.out.println("RATIO ART W=" + w + " BOX=" + box[0] + "," + box[1] + "," + box[2] + "," + box[3]
                + " delta=" + (((art[0] + art[2]) / 2) - ((box[0] + box[2]) / 2)) + ","
                + (((art[1] + art[3]) / 2) - ((box[1] + box[3]) / 2)));
        assertTrue("80% 下图案宽应约 0.8*300*0.5=120，实测 " + w, Math.abs(w - 120) <= 12);
        int dcx = ((art[0] + art[2]) / 2) - ((box[0] + box[2]) / 2);
        int dcy = ((art[1] + art[3]) / 2) - ((box[1] + box[3]) / 2);
        assertTrue("改大小后框还得贴住图案 " + dcx + "," + dcy, Math.abs(dcx) <= 8 && Math.abs(dcy) <= 8);
    }

    @Test
    public void mosaicBrushPaintsOnlyAlongStroke() {
        EditImageView v = new EditImageView(org.robolectric.RuntimeEnvironment.getApplication());
        Bitmap base = Bitmap.createBitmap(400, 400, Bitmap.Config.ARGB_8888);
        Canvas bc = new Canvas(base);
        bc.drawColor(Color.WHITE);
        Paint p = new Paint();
        p.setColor(Color.RED);
        bc.drawRect(0, 0, 200, 400, p);   // 左半红、右半白，竖边在 x=200
        v.setBitmap(base);
        v.measure(android.view.View.MeasureSpec.makeMeasureSpec(400, android.view.View.MeasureSpec.EXACTLY),
                android.view.View.MeasureSpec.makeMeasureSpec(400, android.view.View.MeasureSpec.EXACTLY));
        v.layout(0, 0, 400, 400);
        v.setMode(EditImageView.Mode.MOSAIC);
        v.setMosaicStyle(0, 12, 20);

        long t = 500;
        v.onTouchEvent(android.view.MotionEvent.obtain(t, t, android.view.MotionEvent.ACTION_DOWN, 150, 200, 0));
        v.onTouchEvent(android.view.MotionEvent.obtain(t, t + 30, android.view.MotionEvent.ACTION_MOVE, 200, 200, 0));
        v.onTouchEvent(android.view.MotionEvent.obtain(t, t + 60, android.view.MotionEvent.ACTION_MOVE, 250, 200, 0));
        System.out.println("MOSAIC layers=" + v.getLayers().size());
        // 手指还没抬起来，就应该已经在画面上了
        Bitmap mid = Bitmap.createBitmap(400, 400, Bitmap.Config.ARGB_8888);
        v.draw(new Canvas(mid));

        System.out.println("MOSAIC p100=" + Integer.toHexString(mid.getPixel(100, 200))
                + " p300=" + Integer.toHexString(mid.getPixel(300, 200)));
        int onStroke = mid.getPixel(200, 200);   // 笔迹正压在红白交界上，像素块会把两色混成粉色
        int offStroke = mid.getPixel(200, 60);
        System.out.println("MOSAIC onStroke=" + Integer.toHexString(onStroke)
                + " off=" + Integer.toHexString(offStroke));
        assertTrue("笔迹压过的地方必须已打码（红白交界被混色，而不是纯白/纯红），实测 "
                + Integer.toHexString(onStroke), onStroke != Color.WHITE && onStroke != Color.RED);
        int inCap = mid.getPixel(130, 200);   // 起笔的圆头（笔迹左端）
        assertTrue("起笔要有圆头笔尖，不是细线", inCap == Color.RED || inCap != Color.WHITE);
        assertEquals("笔迹之外的区域不该被动到", Color.WHITE, offStroke);

        v.onTouchEvent(android.view.MotionEvent.obtain(t, t + 90, android.view.MotionEvent.ACTION_UP, 250, 200, 0));
    }


    @Test
    public void viewZoomKeepsBoxOnArtAndEnlarges() {
        EditImageView v = new EditImageView(org.robolectric.RuntimeEnvironment.getApplication());
        Bitmap base = Bitmap.createBitmap(300, 800, Bitmap.Config.ARGB_8888);
        new Canvas(base).drawColor(Color.WHITE);
        v.setBitmap(base);
        v.measure(android.view.View.MeasureSpec.makeMeasureSpec(400, android.view.View.MeasureSpec.EXACTLY),
                android.view.View.MeasureSpec.makeMeasureSpec(400, android.view.View.MeasureSpec.EXACTLY));
        v.layout(0, 0, 400, 400);

        Bitmap st = Bitmap.createBitmap(100, 100, Bitmap.Config.ARGB_8888);
        st.eraseColor(Color.RED);
        v.addSticker(st);
        v.setViewZoomMode(true);
        v.setViewZoomAbsolute(3f, 200, 200);

        Bitmap out = Bitmap.createBitmap(400, 400, Bitmap.Config.ARGB_8888);
        v.draw(new Canvas(out));
        int[] art = bbox(out, 0);
        int[] box = bbox(out, 1);
        int dcx = ((art[0] + art[2]) / 2) - ((box[0] + box[2]) / 2);
        int dcy = ((art[1] + art[3]) / 2) - ((box[1] + box[3]) / 2);
        int w = art[2] - art[0] + 1;
        System.out.println("ZOOM zoom=" + v.getViewZoom() + " ART W=" + w + " delta=" + dcx + "," + dcy
                + " center=" + Integer.toHexString(out.getPixel(200, 200))
                + " p60=" + Integer.toHexString(out.getPixel(60, 200)));
        assertTrue("放大后图案应明显变大", w > 150);
        assertTrue("放大后框仍要贴住图案 " + dcx + "," + dcy, Math.abs(dcx) <= 8 && Math.abs(dcy) <= 8);
        assertTrue("缩放不能超过 6 倍", v.getViewZoom() <= 6f);
    }

    @Test
    public void groupedLayersMoveTogether() {
        EditImageView v = new EditImageView(org.robolectric.RuntimeEnvironment.getApplication());
        Bitmap base = Bitmap.createBitmap(400, 400, Bitmap.Config.ARGB_8888);
        new Canvas(base).drawColor(Color.WHITE);
        v.setBitmap(base);
        v.measure(android.view.View.MeasureSpec.makeMeasureSpec(400, android.view.View.MeasureSpec.EXACTLY),
                android.view.View.MeasureSpec.makeMeasureSpec(400, android.view.View.MeasureSpec.EXACTLY));
        v.layout(0, 0, 400, 400);

        Bitmap st = Bitmap.createBitmap(60, 60, Bitmap.Config.ARGB_8888);
        st.eraseColor(Color.RED);
        Bitmap st2 = Bitmap.createBitmap(60, 60, Bitmap.Config.ARGB_8888);
        st2.eraseColor(Color.BLUE);
        EditImageView.Layer a = v.addSticker(st);
        EditImageView.Layer b = v.addSticker(st2);
        b.matrix.postTranslate(100f, 0f);

        v.groupIndexes(java.util.Arrays.asList(0, 1));
        v.setMode(EditImageView.Mode.NONE);
        float[] ma = new float[9];
        float[] mb = new float[9];
        a.matrix.getValues(ma);
        b.matrix.getValues(mb);
        System.out.println("GROUP before a=" + ma[2] + "," + ma[5] + " b=" + mb[2] + "," + mb[5]);

        long t = 700;
        // 从 a 的中心开始拖（400x400 底图，贴纸在中心）
        v.onTouchEvent(android.view.MotionEvent.obtain(t, t, android.view.MotionEvent.ACTION_DOWN, 200, 200, 0));
        v.onTouchEvent(android.view.MotionEvent.obtain(t, t + 30, android.view.MotionEvent.ACTION_MOVE, 240, 220, 0));
        v.onTouchEvent(android.view.MotionEvent.obtain(t, t + 60, android.view.MotionEvent.ACTION_UP, 240, 220, 0));

        a.matrix.getValues(ma);
        b.matrix.getValues(mb);
        System.out.println("GROUP after a=" + ma[2] + "," + ma[5] + " b=" + mb[2] + "," + mb[5]);
        assertTrue("第一个图层要跟着动", ma[2] != 200f || ma[5] != 200f);
        assertTrue("第二个图层也要同步动",
                Math.abs((mb[2] - ma[2]) - 100f) < 1f && Math.abs(mb[5] - ma[5]) < 1f);
    }

    @Test
    public void maskClipsLayerContent() {
        EditImageView v = new EditImageView(org.robolectric.RuntimeEnvironment.getApplication());
        Bitmap base = Bitmap.createBitmap(400, 400, Bitmap.Config.ARGB_8888);
        new Canvas(base).drawColor(Color.WHITE);
        v.setBitmap(base);
        v.measure(android.view.View.MeasureSpec.makeMeasureSpec(400, android.view.View.MeasureSpec.EXACTLY),
                android.view.View.MeasureSpec.makeMeasureSpec(400, android.view.View.MeasureSpec.EXACTLY));
        v.layout(0, 0, 400, 400);
        Bitmap st = Bitmap.createBitmap(200, 200, Bitmap.Config.ARGB_8888);
        st.eraseColor(Color.RED);
        v.addSticker(st);              // 200x200 铺满中心
        v.setMode(EditImageView.Mode.NONE);

        v.setSelectedMaskType(1);
        v.setSelectedMaskInset(0.25f); // 只剩中间一半

        Bitmap out = Bitmap.createBitmap(400, 400, Bitmap.Config.ARGB_8888);
        v.draw(new Canvas(out));
        int[] art = bbox(out, 0);
        int w = art[2] - art[0] + 1;
        System.out.println("MASK art=" + art[0] + "," + art[1] + "," + art[2] + "," + art[3] + " w=" + w);
        assertTrue("加矩形蒙版后图案应缩进到中间约一半，实测宽 " + w, w < 150);
        assertEquals("蒙版之外应当是底图（白）", Color.WHITE, out.getPixel(40, 40));
    }

}
