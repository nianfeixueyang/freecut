package com.offlinelocal.videoeditor;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import android.graphics.Matrix;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.annotation.GraphicsMode;

/** v12.16 运镜（Ken Burns）与黑场淡入淡出的时间曲线测试。 */
@RunWith(RobolectricTestRunner.class)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
public class MotionFadeTest {

    private float scaleOf(Matrix m) {
        float[] v = new float[9];
        m.getValues(v);
        return v[Matrix.MSCALE_X];
    }

    @Test
    public void 推近随时间放大() {
        MotionEffect e = new MotionEffect(MotionEffect.PUSH_IN, 5000);
        assertEquals(1f, scaleOf(e.getMatrix(0)), 0.02f);
        assertEquals(1.14f, scaleOf(e.getMatrix(5_000_000L)), 0.03f);
        assertTrue("中途应介于两者之间",
                scaleOf(e.getMatrix(2_500_000L)) > 1.02f);
    }

    @Test
    public void 拉远随时间缩小() {
        MotionEffect e = new MotionEffect(MotionEffect.PULL_OUT, 5000);
        assertEquals(1.14f, scaleOf(e.getMatrix(0)), 0.03f);
        assertEquals(1f, scaleOf(e.getMatrix(5_000_000L)), 0.03f);
    }

    @Test
    public void 黑场首尾变黑中间正常() {
        FadeEffect f = new FadeEffect(4000, 500);
        float[] head = f.getMatrix(0, false);
        float[] mid = f.getMatrix(2_000_000L, false);
        float[] tail = f.getMatrix(4_000_000L, false);
        assertEquals(0f, head[0], 0.02f);
        assertEquals(1f, mid[0], 0.02f);
        assertEquals(0f, tail[0], 0.02f);
        assertEquals("亮度三通道同步", head[0], head[5], 0.001f);
    }

    @Test
    public void 段间黑场时长不超过半段() {
        FadeEffect f = new FadeEffect(1000, 300);
        assertEquals(0f, f.getMatrix(0, false)[0], 0.02f);
        assertEquals(0f, f.getMatrix(1_000_000L, false)[0], 0.02f);
        assertEquals(1f, f.getMatrix(500_000L, false)[0], 0.05f);
    }

    @Test
    public void 色温偏暖抬红压蓝() {
        float[] m = new WhiteBalanceEffect(0.5f, 0f).getMatrix(0, false);
        assertTrue(m[0] > 1f);   // R
        assertTrue(m[10] < 1f);  // B
        assertTrue(Math.abs(m[5] - 1f) < 0.01f); // G 不变
    }

    @Test
    public void 中性白平衡不做任何事() {
        assertTrue(new WhiteBalanceEffect(0f, 0f).isNoOp(1920, 1080));
    }
}
