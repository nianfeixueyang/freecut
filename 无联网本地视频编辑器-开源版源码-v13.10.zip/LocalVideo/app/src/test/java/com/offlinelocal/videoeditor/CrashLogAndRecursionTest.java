package com.offlinelocal.videoeditor;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import android.content.Context;

import androidx.test.core.app.ApplicationProvider;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.annotation.Config;

import java.io.File;
import java.lang.reflect.Method;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;

/**
 * 两条回归：崩溃日志必须真的落盘/可导出，以及 markEdited 不能自递归
 * （v11.8 就是 markEdited 里又调 markEdited，用户一编辑就 StackOverflow）。
 */
@RunWith(RobolectricTestRunner.class)
@Config(sdk = 34)
public class CrashLogAndRecursionTest {

    private void writeCrash(Throwable t) throws Exception {
        LocalVideoApp app = (LocalVideoApp) ApplicationProvider.getApplicationContext();
        Method m = LocalVideoApp.class.getDeclaredMethod("writeCrash", Throwable.class);
        m.setAccessible(true);
        m.invoke(app, t);
    }

    @Test
    public void 崩溃日志落盘且第二次崩溃会归档第一份() throws Exception {
        Context ctx = ApplicationProvider.getApplicationContext();
        LocalVideoApp.clearCrash(ctx);
        writeCrash(new IllegalStateException("第一次炸"));
        File first = LocalVideoApp.crashFile(ctx);
        assertTrue("崩溃后必须留下文件", first.exists() && first.length() > 0);
        String text = LocalVideoApp.readCrash(ctx, 0);
        assertTrue("日志里要有异常类型", text.contains("IllegalStateException"));
        assertTrue("日志里要有版本号，不然没法定位是哪版", text.contains("version="));

        // 第二次崩溃：旧的一份必须进 crash_history，不能被覆盖丢掉
        writeCrash(new RuntimeException("第二次炸"));
        String second = LocalVideoApp.readCrash(ctx, 0);
        assertTrue(second.contains("第二次炸"));
        assertFalse("首页显示的是最新一份", second.contains("第一次炸"));
        assertTrue("上一份应归档", LocalVideoApp.crashHistory(ctx).length >= 1);

        // 可导出：导出的文件要存在且非空，分享面板才有东西可发
        File exported = LocalVideoApp.exportCrash(ctx);
        assertNotNull("导出日志失败，用户没法把日志发出来", exported);
        assertTrue(exported.exists() && exported.length() > 0);
    }

    @Test
    public void 日志不会被截断到四千字节() throws Exception {
        Context ctx = ApplicationProvider.getApplicationContext();
        LocalVideoApp.clearCrash(ctx);
        Throwable deep = new Throwable("长栈");
        // 造一条很长的栈，模拟多层调用
        Throwable cur = deep;
        for (int i = 0; i < 60; i++) {
            cur = new RuntimeException("层 " + i, cur);
        }
        writeCrash(cur);
        String full = LocalVideoApp.readCrash(ctx, 0);
        assertTrue("完整日志应远大于弹窗预览长度", full.length() > 5000);
    }

    @Test
    public void markEdited不能自己调自己() throws Exception {
        String src = new String(Files.readAllBytes(java.nio.file.Paths.get(
                "src/main/java/com/offlinelocal/videoeditor/VideoEditorActivity.java")), StandardCharsets.UTF_8);
        int idx = src.indexOf("private void markEdited()");
        assertTrue("找不到 markEdited 定义", idx > 0);
        String body = src.substring(idx, Math.min(src.length(), idx + 120));
        assertFalse("markEdited 里又调 markEdited，会无限递归爆栈", body.contains("markEdited();"));
        assertTrue(body.contains("edited = true;"));
    }

    /** 轨道锁定要真的进工程文件，否则下次打开锁就没了。 */
    @Test
    public void 工程结构版本与锁定字段都在() throws Exception {
        java.lang.reflect.Field f = VideoEditorActivity.class.getDeclaredField("SCHEMA_VERSION");
        f.setAccessible(true);
        assertTrue("工程结构版本至少要 >= 4（锁定/裁剪字段）", f.getInt(null) >= 4);

        String src = new String(Files.readAllBytes(java.nio.file.Paths.get(
                "src/main/java/com/offlinelocal/videoeditor/VideoEditorActivity.java")), StandardCharsets.UTF_8);
        assertTrue("toJson 必须写 schemaVersion", src.contains("o.put(\"schemaVersion\", SCHEMA_VERSION)"));
        assertTrue("toJson 必须写 locked", src.contains("jc.put(\"locked\", c.locked)"));
        assertTrue("fromJson 必须读 locked", src.contains("c.locked = jc.optBoolean(\"locked\", false)"));
        assertTrue("锁定后滑块要拦住", src.contains("这一段已锁定，先在「拼接」里解锁"));
    }

    /** 水印拖动锚点必须夹在 -0.95~0.95，否则会拖到画面外看不见。 */
    @Test
    public void 水印锚点夹紧在可视区内() throws Exception {
        Method m = VideoEditorActivity.class.getDeclaredMethod("clampAnchor", float.class);
        m.setAccessible(true);
        assertEquals(0.95f, (Float) m.invoke(null, 3f), 0.0001f);
        assertEquals(-0.95f, (Float) m.invoke(null, -3f), 0.0001f);
        assertEquals(0.3f, (Float) m.invoke(null, 0.3f), 0.0001f);
    }

    /** 多段切换必须按 item 序号 seek，不能再用总时长偏移（这是"要拖绿条才切过去"的根因）。 */
    @Test
    public void 多段切换按序号seek() throws Exception {
        String src = new String(Files.readAllBytes(java.nio.file.Paths.get(
                "src/main/java/com/offlinelocal/videoeditor/VideoEditorActivity.java")), StandardCharsets.UTF_8);
        assertTrue("必须用 seekTo(itemIndex, 0)", src.contains("player.seekTo(idx, 0)"));
        assertFalse("不能再按全局偏移 seek", src.contains("player.seekTo(sequenceOffsetOf(currentIndex))"));
    }

    /** 字幕位置可改：字号/锚点/颜色要能传进 TimedTextOverlay 并落到 OverlaySettings。 */
    @Test
    public void 字幕位置字号颜色可自定义() throws Exception {
        TimedTextOverlay.Cue cue = new TimedTextOverlay.Cue(0, 1000, "测试");
        TimedTextOverlay overlay = new TimedTextOverlay(
                java.util.Collections.singletonList(cue), 96f, 0.2f, 0.4f, 0xFFFFD750);
        androidx.media3.effect.OverlaySettings st = overlay.getOverlaySettings(500000L);
        assertEquals(0.2f, (Float) st.backgroundFrameAnchor.first, 0.001f);
        assertEquals(0.4f, (Float) st.backgroundFrameAnchor.second, 0.001f);
        assertTrue("500ms 落在 cue 区间内要有字", overlay.getText(500000L).length() > 0);
        // 区间外必须给"空格 + 全透明"，不能给 0 宽空串（真机会报 FRAME_PROCESSING_FAILED）
        assertEquals("区间外仍要有非空占位", 1, overlay.getText(1_500_000L).length());
        assertEquals("区间外透明度应为 0", 0f,
                overlay.getOverlaySettings(1_500_000L).alphaScale, 0.001f);
        assertEquals("区间内透明度应为 1", 1f,
                overlay.getOverlaySettings(500000L).alphaScale, 0.001f);
    }

    /** 配乐音量必须独立于原声，并且要落盘。 */
    @Test
    public void 配乐音量独立且落盘() throws Exception {
        String src = new String(Files.readAllBytes(java.nio.file.Paths.get(
                "src/main/java/com/offlinelocal/videoeditor/VideoEditorActivity.java")), StandardCharsets.UTF_8);
        assertTrue("要有独立配乐音量字段", src.contains("private float musicVolume"));
        assertTrue("导出工程要写 musicVolume", src.contains("o.put(\"musicVolume\""));
        assertTrue("读回要有默认值", src.contains("o.optDouble(\"musicVolume\""));
        assertTrue("配乐要走 GainAudioProcessor", src.contains("new GainAudioProcessor(musicVolume"));
    }

    /** 图片画布：两指落在空白处要缩放画布，而不是当成图层缩放。 */
    @Test
    public void 画布双指缩放不再被图层抢占() throws Exception {
        String src = new String(Files.readAllBytes(java.nio.file.Paths.get(
                "src/main/java/com/offlinelocal/videoeditor/EditImageView.java")), StandardCharsets.UTF_8);
        assertTrue(src.contains("gestureOnCanvas"));
        assertTrue(src.contains("return handleViewZoomTouch(e);"));
    }

    /** 导出诊断日志：要能落盘、读回，并按时间倒序保留。 */
    @Test
    public void 导出诊断记录可落盘读回() throws Exception {
        Context ctx = ApplicationProvider.getApplicationContext();
        java.io.File f = new java.io.File(ctx.getFilesDir(), "export_log.json");
        if (f.exists()) assertTrue(f.delete());

        ExportLog.Entry e1 = new ExportLog.Entry();
        e1.ok = false;
        e1.code = "ERROR_CODE_VIDEO_FRAME_PROCESSING_FAILED";
        e1.stage = 1;
        e1.clips = 2;
        e1.subtitles = true;
        e1.music = true;
        ExportLog.add(ctx, e1);

        ExportLog.Entry e2 = new ExportLog.Entry();
        e2.ok = true;
        e2.clips = 1;
        ExportLog.add(ctx, e2);

        java.util.List<ExportLog.Entry> list = ExportLog.load(ctx);
        assertEquals(2, list.size());
        assertTrue("最新一条在最前面", list.get(0).ok);
        assertFalse(list.get(1).ok);
        assertEquals("ERROR_CODE_VIDEO_FRAME_PROCESSING_FAILED", list.get(1).code);
        assertEquals(1, list.get(1).stage);
        assertTrue(list.get(1).line().contains("2段"));
        assertTrue(list.get(1).line().contains("字幕"));
    }

    /** 配乐必须走"先出正片再混音"的两段式，避免配乐+特效一起把编码器压崩。 */
    @Test
    public void 配乐走两段式导出() throws Exception {
        String src = new String(Files.readAllBytes(java.nio.file.Paths.get(
                "src/main/java/com/offlinelocal/videoeditor/VideoEditorActivity.java")), StandardCharsets.UTF_8);
        assertTrue(src.contains("needVideoOnlyFirst"));
        assertTrue(src.contains("private void startMixPass(File video, Uri music)"));
        assertTrue("混音失败要回退无配乐版", src.contains("已导出无配乐版本"));
        assertTrue("效果不支持也要留日志", src.contains("EFFECT_BUILD_FAILED"));
    }

    /** 8K 源必须把输出尺寸压到 1080p 以内，并按像素给码率，否则编码器会被 7680×4320 直接顶崩。 */
    @Test
    public void 大尺寸源必须限制输出尺寸与码率() throws Exception {
        String src = new String(Files.readAllBytes(java.nio.file.Paths.get(
                "src/main/java/com/offlinelocal/videoeditor/VideoEditorActivity.java")), StandardCharsets.UTF_8);
        assertTrue("要有 1080p 上限", src.contains("int baseCap = compatExport ? 1280 : 1920"));
        assertTrue("超 1080p 的源不能走单段直编", src.contains("srcLongSide <= 1920"));
        assertTrue("自动码率要按像素算并封顶", src.contains("Math.min(20, Math.round(b))"));
        assertTrue("要有输出尺寸记录", src.contains("pendingOutW"));
    }

    /** 仅给每个 item 套 Presentation 不够：最终输出尺寸要再压一层，否则 8K 源仍会以 7680×4320 进编码器。 */
    @Test
    public void 合成末层也要限制输出尺寸() throws Exception {
        String src = new String(Files.readAllBytes(java.nio.file.Paths.get(
                "src/main/java/com/offlinelocal/videoeditor/VideoEditorActivity.java")), StandardCharsets.UTF_8);
        assertTrue(src.contains("在整条 Composition 的最后再压一层尺寸"));
        assertTrue("日志要带实际输出尺寸", src.contains("out="));
    }

    /** 真机上 Presentation 没能改变编码器输入尺寸，必须再加：像素级缩放 + HDR 转 SDR + Main Profile 约束。 */
    @Test
    public void 导出必须做像素级缩放与HDR映射() throws Exception {
        String src = new String(Files.readAllBytes(java.nio.file.Paths.get(
                "src/main/java/com/offlinelocal/videoeditor/VideoEditorActivity.java")), StandardCharsets.UTF_8);
        assertTrue("要按宽高比真正缩放像素", src.contains("ScaleAndRotateTransformation.Builder()"));
        assertTrue("HDR 必须色调映射到 SDR", src.contains("HDR_MODE_TONE_MAP_HDR_TO_SDR_USING_MEDIACODEC"));
        assertTrue("深降级按 SDR 解释", src.contains("HDR_MODE_EXPERIMENTAL_FORCE_INTERPRET_HDR_AS_SDR"));
        assertTrue("深降级要求 Main Profile", src.contains("AVCProfileMain"));
    }

    /** 8K/HDR 源：必须先用 MediaCodec 压成 1080p 副本再导出，不能指望 Media3 的尺寸效果。 */
    @Test
    public void 超大素材导出前先压成副本() throws Exception {
        String src = new String(Files.readAllBytes(java.nio.file.Paths.get(
                "src/main/java/com/offlinelocal/videoeditor/VideoEditorActivity.java")), StandardCharsets.UTF_8);
        assertTrue("要检测超 4K 源", src.contains("longSide > 2160"));
        assertTrue("要调用压缩器", src.contains("VideoNormalizer.normalize"));
        assertTrue("导出要用副本 Uri", src.contains("exportUriOf"));
        assertTrue("副本要重算裁剪区间", src.contains("exportClipStart"));
        assertTrue("压缩失败要有日志", src.contains("NORMALIZE_FAILED"));

        String norm = new String(Files.readAllBytes(java.nio.file.Paths.get(
                "src/main/java/com/offlinelocal/videoeditor/VideoNormalizer.java")), StandardCharsets.UTF_8);
        assertTrue("编码器尺寸要在配置阶段锁死", norm.contains("createVideoFormat(\"video/avc\", outW, outH)"));
        assertTrue("要带超时避免卡死", norm.contains("deadline"));
        assertTrue("原音轨要搬运", norm.contains("MUXER_OUTPUT_MPEG_4"));
    }

    /** v12.10 真机崩溃：片段 uri 为空时 exportUriOf 直接 NPE。必须空安全，并且没 uri 的段要跳过。 */
    @Test
    public void 导出不能因空Uri崩溃() throws Exception {
        String src = new String(Files.readAllBytes(java.nio.file.Paths.get(
                "src/main/java/com/offlinelocal/videoeditor/VideoEditorActivity.java")), StandardCharsets.UTF_8);
        assertTrue(src.contains("if (c == null || c.uri == null) return null;"));
        assertTrue("组装 item 时要跳过空 uri", src.contains("if (c.uri == null) continue;"));
        assertTrue("压缩阶段要跳过空 uri", src.contains("if (c.uri == null || Math.max(c.width, c.height) <= 2160) continue;"));
    }

    /** 配乐混音改用自建管线：Media3 的 Composition 混音在真机上报 invalid error code。 */
    @Test
    public void 配乐混音走自建管线() throws Exception {
        String src = new String(Files.readAllBytes(java.nio.file.Paths.get(
                "src/main/java/com/offlinelocal/videoeditor/VideoEditorActivity.java")), StandardCharsets.UTF_8);
        assertTrue("要调用自建混音", src.contains("AudioMixer.mix("));
        assertTrue("失败必须回退无配乐版", src.contains("MIX_FAILED"));
        assertTrue("混音要跑在线程池", src.contains("Work.run(() ->"));
        String mixer = new String(Files.readAllBytes(java.nio.file.Paths.get(
                "src/main/java/com/offlinelocal/videoeditor/AudioMixer.java")), StandardCharsets.UTF_8);
        assertTrue("视频轨要直接复制", mixer.contains("MUXER_OUTPUT_MPEG_4"));
        assertTrue("要有统一采样率", mixer.contains("44100"));
    }

    /** 稳定性专项：导出预检、唤醒锁、中断标记、成功率汇总、诊断文件分享。 */
    @Test
    public void 导出稳定性能力齐备() throws Exception {
        String log = new String(Files.readAllBytes(java.nio.file.Paths.get(
                "src/main/java/com/offlinelocal/videoeditor/ExportLog.java")), StandardCharsets.UTF_8);
        assertTrue("日志要记耗时", log.contains("durationMs"));
        assertTrue("要有成功率汇总", log.contains("public static String summary"));
        assertTrue("汇总要含失败码分布", log.contains("失败码"));

        String src = new String(Files.readAllBytes(java.nio.file.Paths.get(
                "src/main/java/com/offlinelocal/videoeditor/VideoEditorActivity.java")), StandardCharsets.UTF_8);
        assertTrue("导出前要预检空间与素材", src.contains("preflightIssue"));
        assertTrue("要持有唤醒锁", src.contains("PARTIAL_WAKE_LOCK"));
        assertTrue("要有中断标记", src.contains("EXPORT_PREFS"));
        assertTrue("诊断要能导出文件", src.contains("shareExportLog"));
        assertTrue("manifest 要有 WAKE_LOCK 权限",
                new String(Files.readAllBytes(java.nio.file.Paths.get("src/main/AndroidManifest.xml")),
                        StandardCharsets.UTF_8).contains("WAKE_LOCK"));
    }

    /** v12.15：录音配音 + 配乐淡入淡出，从界面到混音全链路齐备。 */
    @Test
    public void 配音与淡入淡出能力齐备() throws Exception {
        String act = new String(Files.readAllBytes(java.nio.file.Paths.get(
                "src/main/java/com/offlinelocal/videoeditor/VideoEditorActivity.java")), StandardCharsets.UTF_8);
        assertTrue("要能启动录音", act.contains("startVoiceRecording"));
        assertTrue("要能停止并保存配音", act.contains("stopVoiceRecording"));
        assertTrue("要有配音音量", act.contains("chooseVoiceVolume"));
        assertTrue("要有淡入淡出档位", act.contains("chooseFade"));
        assertTrue("配音要写进工程 JSON", act.contains("\"voiceUri\""));
        assertTrue("配音只读也要触发混音", act.contains("mixPending"));
        assertTrue("manifest 要有录音权限",
                new String(Files.readAllBytes(java.nio.file.Paths.get("src/main/AndroidManifest.xml")),
                        StandardCharsets.UTF_8).contains("RECORD_AUDIO"));

        String mixer = new String(Files.readAllBytes(java.nio.file.Paths.get(
                "src/main/java/com/offlinelocal/videoeditor/AudioMixer.java")), StandardCharsets.UTF_8);
        assertTrue("混音要接配音轨", mixer.contains("Uri voice"));
        assertTrue("配乐要按淡入淡出包络", mixer.contains("fadeInMs") && mixer.contains("env"));
        assertTrue("混音必须分块", mixer.contains("mixChunk("));
    }

    /** v12.16：运镜工具接入到工具栏、预览与导出。 */
    @Test
    public void 运镜与黑场接入齐备() throws Exception {
        String src = new String(Files.readAllBytes(java.nio.file.Paths.get(
                "src/main/java/com/offlinelocal/videoeditor/VideoEditorActivity.java")), StandardCharsets.UTF_8);
        assertTrue(src.contains("\"运镜\""));
        assertTrue(src.contains("new MotionEffect(motion, timelineMs)"));
        assertTrue(src.contains("new FadeEffect(timelineMs, fadeMs)"));
        assertTrue(src.contains("\"motion\""));
    }

    /** v12.17：段间黑场转场接进每一段的 item 效果。 */
    @Test
    public void 段间转场接入齐备() throws Exception {
        String src = new String(Files.readAllBytes(java.nio.file.Paths.get(
                "src/main/java/com/offlinelocal/videoeditor/VideoEditorActivity.java")), StandardCharsets.UTF_8);
        assertTrue(src.contains("\"转场\""));
        assertTrue(src.contains("clipTransitionMs"));
        assertTrue("每段都要加黑场效果", src.contains("new FadeEffect(clipMs, fadeMs)"));
    }

    /** v12.18：调色工作台 6 参数 + 6 套预设。 */
    @Test
    public void 调色工作台齐备() throws Exception {
        String src = new String(Files.readAllBytes(java.nio.file.Paths.get(
                "src/main/java/com/offlinelocal/videoeditor/VideoEditorActivity.java")), StandardCharsets.UTF_8);
        assertTrue(src.contains("chooseColorPreset"));
        for (String preset : new String[]{"电影青橙", "日系清新", "黑金夜景", "复古胶片", "通透人像", "冷调雪景"}) {
            assertTrue("缺少预设 " + preset, src.contains(preset));
        }
        assertTrue("要有色调参数", src.contains("\"tint\"") && src.contains("WhiteBalanceEffect"));
    }

    /** v12.19：字幕描边 + 底色接入字幕面板与叠加层。 */
    @Test
    public void 字幕描边底色齐备() throws Exception {
        String src = new String(Files.readAllBytes(java.nio.file.Paths.get(
                "src/main/java/com/offlinelocal/videoeditor/VideoEditorActivity.java")), StandardCharsets.UTF_8);
        assertTrue(src.contains("StyledSubtitleOverlay"));
        assertTrue(src.contains("chooseSubtitleStroke"));
        assertTrue(src.contains("chooseSubtitleBg"));
        assertTrue(src.contains("subStroke") && src.contains("subBg"));
        String overlay = new String(Files.readAllBytes(java.nio.file.Paths.get(
                "src/main/java/com/offlinelocal/videoeditor/StyledSubtitleOverlay.java")), StandardCharsets.UTF_8);
        assertTrue(overlay.contains("Paint.Style.STROKE"));
        assertTrue(overlay.contains("drawRoundRect"));
    }

    /** v12.20：字幕动画、片头标题卡、导出完成通知。 */
    @Test
    public void 字幕动画标题卡与完成通知齐备() throws Exception {
        String src = new String(Files.readAllBytes(java.nio.file.Paths.get(
                "src/main/java/com/offlinelocal/videoeditor/VideoEditorActivity.java")), StandardCharsets.UTF_8);
        assertTrue(src.contains("chooseSubtitleAnim"));
        assertTrue(src.contains("openTitleCard"));
        assertTrue(src.contains("titleMs") && src.contains("titleText"));
        assertTrue(src.contains("ExportService.notifyDone"));
        String svc = new String(Files.readAllBytes(java.nio.file.Paths.get(
                "src/main/java/com/offlinelocal/videoeditor/ExportService.java")), StandardCharsets.UTF_8);
        assertTrue(svc.contains("public static void notifyDone"));
        assertTrue(svc.contains("setAutoCancel(true)"));
    }
}
