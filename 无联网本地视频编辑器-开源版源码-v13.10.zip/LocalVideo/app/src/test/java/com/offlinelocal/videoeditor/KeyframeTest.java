package com.offlinelocal.videoeditor;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import android.graphics.Matrix;

import androidx.test.core.app.ApplicationProvider;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Arrays;

@RunWith(RobolectricTestRunner.class)
public class KeyframeTest {

    private float scaleAt(KeyframeEffect e, long us) {
        float[] v = new float[9];
        e.getMatrix(us).getValues(v);
        return v[0];
    }

    @Test
    public void 关键帧线性插值缩放() {
        KeyframeEffect e = new KeyframeEffect(Arrays.asList(
                new KeyframeEffect.Kf(0f, 1f, 0f, 0f, 0f),
                new KeyframeEffect.Kf(1f, 1.4f, 0f, 0f, 0f)), 1000, 0);
        assertEquals(1f, scaleAt(e, 0), 0.02f);
        assertEquals(1.2f, scaleAt(e, 500_000L), 0.02f);
        assertEquals(1.4f, scaleAt(e, 1_000_000L), 0.03f);
    }

    @Test
    public void 缓入缓出中段一阶导更平缓() {
        KeyframeEffect e = new KeyframeEffect(Arrays.asList(
                new KeyframeEffect.Kf(0f, 1f, 0f, 0f, 0f),
                new KeyframeEffect.Kf(1f, 1.4f, 0f, 0f, 0f)), 1000, 1);
        assertEquals(1.2f, scaleAt(e, 500_000L), 0.02f);
        assertTrue("缓动前段应更接近起点", scaleAt(e, 200_000L) < 1.1f);
    }

    @Test
    public void 关键帧能写进工程并读回() throws Exception {
        String src = new String(Files.readAllBytes(Paths.get(
                "src/main/java/com/offlinelocal/videoeditor/VideoEditorActivity.java")), StandardCharsets.UTF_8);
        assertTrue(src.contains("kfToString(kfKeys)"));
        assertTrue(src.contains("kfFromString(o.optString(\"kfKeys\""));
        assertTrue(src.contains("new KeyframeEffect(keys, totalLengthMs(), keyEasing)"));
            assertTrue(src.contains("openKeyframePanel"));
    }

    @Test
    public void 图片文字底色与调色齐备() throws Exception {
        String v = new String(Files.readAllBytes(Paths.get(
                "src/main/java/com/offlinelocal/videoeditor/EditImageView.java")), StandardCharsets.UTF_8);
        assertTrue(v.contains("public void setTextBg"));
        assertTrue(v.contains("textBgColor"));
        assertTrue(v.contains("canvas.drawRoundRect(left - pad"));
    }
}
