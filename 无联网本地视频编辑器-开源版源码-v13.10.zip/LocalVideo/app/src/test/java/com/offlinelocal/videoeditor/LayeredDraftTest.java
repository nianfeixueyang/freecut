package com.offlinelocal.videoeditor;

import static org.junit.Assert.assertTrue;

import org.junit.Test;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;

/** v13.4：草稿升级为图层级（文字/贴纸可恢复），并回收马赛克缓存。 */
public class LayeredDraftTest {

    private static String read(String p) throws Exception {
        return new String(Files.readAllBytes(Paths.get(p)), StandardCharsets.UTF_8);
    }

    @Test
    public void 草稿底图不烘文字贴纸() throws Exception {
        String v = read("src/main/java/com/offlinelocal/videoeditor/EditImageView.java");
        assertTrue(v.contains("renderExcludingTextSticker"));
        assertTrue(v.contains("textAndStickerLayers"));
        assertTrue(v.contains("addRestoredLayer"));
    }

    @Test
    public void 图层写入草稿JSON并可读回() throws Exception {
        String d = read("src/main/java/com/offlinelocal/videoeditor/ImageDraft.java");
        assertTrue(d.contains("saveLayered"));
        assertTrue(d.contains("loadLayers"));
        assertTrue(d.contains("layers"));
        assertTrue(d.contains("stickerW"));
    }

    @Test
    public void 内存吃紧时释放整图缓存() throws Exception {
        String a = read("src/main/java/com/offlinelocal/videoeditor/ImageEditorActivity.java");
        assertTrue(a.contains("onTrimMemory"));
        assertTrue(a.contains("canvas.releaseCaches()"));
    }
}
