package com.offlinelocal.videoeditor;

import static org.junit.Assert.assertTrue;

import org.junit.Test;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;

/** v13.3 多轨时间线。 */
public class TimelineTest {

    private static String read(String p) throws Exception {
        return new String(Files.readAllBytes(Paths.get(p)), StandardCharsets.UTF_8);
    }

    @Test
    public void 时间线有三条轨道() throws Exception {
        String v = read("src/main/java/com/offlinelocal/videoeditor/TimelineView.java");
        assertTrue(v.contains("多轨时间线"));
        assertTrue(v.contains("主轨"));
        assertTrue(v.contains("字幕轨"));
        assertTrue(v.contains("音频轨"));
    }

    @Test
    public void 拖动字幕块改起止() throws Exception {
        String v = read("src/main/java/com/offlinelocal/videoeditor/TimelineView.java");
        assertTrue(v.contains("onCueRangeChanged"));
        assertTrue(v.contains("dragMode == 1"));
        assertTrue(v.contains("dragMode == 2"));
    }

    @Test
    public void 时间线已接入编辑器布局() throws Exception {
        String lay = read("src/main/res/layout/activity_video_editor.xml");
        assertTrue(lay.contains("com.offlinelocal.videoeditor.TimelineView"));
        String act = read("src/main/java/com/offlinelocal/videoeditor/VideoEditorActivity.java");
        assertTrue(act.contains("syncTimeline()"));
        assertTrue(act.contains("seekTimeline(ms)"));
    }

    @Test
    public void 序列时间换算到段内位置() throws Exception {
        String act = read("src/main/java/com/offlinelocal/videoeditor/VideoEditorActivity.java");
        assertTrue(act.contains("private void seekTimeline(long ms)"));
        assertTrue(act.contains("player.seekTo(Math.max(0, Math.min(len, ms - acc))"));
    }
}
