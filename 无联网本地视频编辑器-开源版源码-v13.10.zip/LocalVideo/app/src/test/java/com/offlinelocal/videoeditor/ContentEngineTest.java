package com.offlinelocal.videoeditor;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import android.content.Context;
import android.graphics.Bitmap;

import androidx.appcompat.view.ContextThemeWrapper;
import androidx.media3.common.C;
import androidx.media3.common.audio.AudioProcessor;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.RuntimeEnvironment;
import org.robolectric.annotation.Config;
import org.robolectric.annotation.GraphicsMode;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.List;

/** v4 新增能力：拼图引擎、内置贴纸、音量/淡入淡出处理器。 */
@RunWith(RobolectricTestRunner.class)
@Config(sdk = 34, qualifiers = "w411dp-h891dp-xxhdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
public class ContentEngineTest {

    private Context themed() {
        return new ContextThemeWrapper(RuntimeEnvironment.getApplication(), R.style.Theme_LocalVideo);
    }

    private List<Bitmap> squares(int n, int size) {
        List<Bitmap> list = new ArrayList<>();
        for (int i = 0; i < n; i++) list.add(Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888));
        return list;
    }

    @Test
    public void collageBuildsNineGrid() {
        Bitmap out = CollageEngine.build(squares(9, 200), 0, 8, 4, 0xFFFFFFFF, 900);
        assertNotNull(out);
        assertTrue(out.getWidth() > 0);
        assertTrue(out.getHeight() > 0);
        // 三列：宽 ≈ 3*cell + 4*gap
        assertTrue(out.getWidth() >= 3 * 200);
    }

    @Test
    public void collageBuildsLongStrip() {
        Bitmap out = CollageEngine.build(squares(3, 160), 3, 6, 0, 0xFF000000, 800);
        assertNotNull(out);
        assertEquals(1, 1);
        assertTrue(out.getHeight() >= 3 * 100);
    }

    @Test
    public void stickerLibraryRendersPixels() {
        Bitmap bmp = StickerLibrary.make(themed(), 0, 128);
        assertNotNull(bmp);
        assertEquals(128, bmp.getWidth());
        boolean hasPixel = false;
        for (int y = 0; y < 128 && !hasPixel; y += 8) {
            for (int x = 0; x < 128; x += 8) {
                if ((bmp.getPixel(x, y) & 0x00FFFFFF) != 0) {
                    hasPixel = true;
                    break;
                }
            }
        }
        assertTrue("贴纸应当是可见图形", hasPixel);
    }

    @Test
    public void everyStickerRendersPixels() {
        for (int i = 0; i < StickerLibrary.NAMES.length; i++) {
            Bitmap bmp = StickerLibrary.make(themed(), i, 96);
            boolean hasPixel = false;
            for (int y = 0; y < 96 && !hasPixel; y += 6) {
                for (int x = 0; x < 96; x += 6) {
                    if ((bmp.getPixel(x, y) & 0x00FFFFFF) != 0) {
                        hasPixel = true;
                        break;
                    }
                }
            }
            assertTrue(StickerLibrary.NAMES[i] + " 应当画出可见图形", hasPixel);
        }
    }

    @Test
    public void crashLogRoundTrip() {
        Context ctx = themed();
        LocalVideoApp.clearCrash(ctx);
        assertTrue(!LocalVideoApp.hasCrash(ctx));

        try {
            java.io.FileOutputStream out = new java.io.FileOutputStream(LocalVideoApp.crashFile(ctx));
            out.write("java.lang.RuntimeException: boom\n".getBytes("UTF-8"));
            out.close();
        } catch (Exception e) {
            throw new AssertionError(e);
        }
        assertTrue(LocalVideoApp.hasCrash(ctx));
        String log = LocalVideoApp.readCrash(ctx, 200);
        assertTrue(log.contains("boom"));

        LocalVideoApp.clearCrash(ctx);
        assertTrue(!LocalVideoApp.hasCrash(ctx));
    }

    @Test
    public void safeMaxDimIsSane() {
        int dim = BitmapUtils.safeMaxDim();
        assertTrue("解码上限应不低于 2048，实际 " + dim, dim >= 2048);
        assertTrue("也不该无限放大，实际 " + dim, dim <= 4096);
    }

    @Test
    public void srtRoundTrip() {
        List<TimedTextOverlay.Cue> cues = new java.util.ArrayList<>();
        cues.add(new TimedTextOverlay.Cue(1000, 3000, "第一句"));
        cues.add(new TimedTextOverlay.Cue(4000, 6500, "第二句\n换行"));
        String srt = SrtUtils.build(cues);
        assertTrue(srt.contains("00:00:01,000 --> 00:00:03,000"));
        List<TimedTextOverlay.Cue> parsed = SrtUtils.parse(srt);
        assertEquals(2, parsed.size());
        assertEquals("第一句", parsed.get(0).text);
        assertEquals(1000, parsed.get(0).startMs);
        assertEquals(6500, parsed.get(1).endMs);
        assertTrue(parsed.get(1).text.contains("换行"));
    }

    @Test
    public void timedOverlayShowsCueOnlyInRange() {
        List<TimedTextOverlay.Cue> cues = new java.util.ArrayList<>();
        cues.add(new TimedTextOverlay.Cue(0, 2000, "开场"));
        cues.add(new TimedTextOverlay.Cue(2000, 4000, "中段"));
        TimedTextOverlay overlay = new TimedTextOverlay(cues);
        assertEquals("开场", overlay.getText(500_000L).toString());     // 0.5s
        assertEquals("中段", overlay.getText(3_000_000L).toString());   // 3s
        // 5s 无字幕：给空格占位（空串会生成 0 宽位图，真机 GPU 报 FRAME_PROCESSING_FAILED）
        assertEquals(" ", overlay.getText(5_000_000L).toString());
        assertEquals(0f, overlay.getOverlaySettings(5_000_000L).alphaScale, 0.001f);
        assertNotNull(overlay.getOverlaySettings(0L));
        assertTrue(overlay.hasCueAt(2500));
    }

    @Test
    public void stitchRemovesOverlap() {
        // 造两张上下重叠 40px 的"截图"
        android.graphics.Bitmap a = android.graphics.Bitmap.createBitmap(200, 300,
                android.graphics.Bitmap.Config.ARGB_8888);
        android.graphics.Bitmap b = android.graphics.Bitmap.createBitmap(200, 300,
                android.graphics.Bitmap.Config.ARGB_8888);
        android.graphics.Canvas ca = new android.graphics.Canvas(a);
        android.graphics.Canvas cb = new android.graphics.Canvas(b);
        ca.drawColor(0xFF102030);
        cb.drawColor(0xFF102030);
        android.graphics.Paint p = new android.graphics.Paint();
        p.setColor(0xFFEEEEEE);
        // a 的第 260~300 行与 b 的 0~40 行画同样的白条，构成重叠
        ca.drawRect(0, 260, 200, 300, p);
        cb.drawRect(0, 0, 200, 40, p);

        java.util.List<android.graphics.Bitmap> list = new java.util.ArrayList<>();
        list.add(a);
        list.add(b);
        android.graphics.Bitmap out = CollageEngine.build(list, 4, 0, 0, 0xFF000000, 200);
        assertNotNull(out);
        assertEquals(200, out.getWidth());
        // 理想高度 300 + 300 - 40 = 560
        assertTrue("应去掉重叠区，实际高 " + out.getHeight(), out.getHeight() <= 580);
    }

    @Test
    public void presetStoreRoundTrip() {
        PresetStore.Preset p = new PresetStore.Preset();
        p.name = "夜景";
        p.filterIndex = 3;
        p.strength = 0.8f;
        p.vignette = 0.4f;
        p.brightness = 0.1f;
        PresetStore.add(themed(), p);

        List<PresetStore.Preset> all = PresetStore.all(themed());
        assertEquals(1, all.size());
        assertEquals("夜景", all.get(0).name);
        assertEquals(3, all.get(0).filterIndex);
        assertTrue(Math.abs(all.get(0).vignette - 0.4f) < 0.01f);
        assertTrue(Math.abs(all.get(0).strength - 0.8f) < 0.01f);

        PresetStore.remove(themed(), "夜景");
        assertTrue(PresetStore.all(themed()).isEmpty());
    }

    @Test
    public void recentStoreKeepsNewestFirstAndDedupes() {
        RecentStore.touch(themed(), "content://a", "a.jpg", "image");
        RecentStore.touch(themed(), "content://b", "b.mp4", "video");
        RecentStore.touch(themed(), "content://a", "a.jpg", "image");

        List<RecentStore.Item> all = RecentStore.all(themed());
        assertEquals(2, all.size());
        assertEquals("content://a", all.get(0).uri);
        assertEquals("video", all.get(1).kind);
    }

    @Test
    public void gainProcessorHalvesVolume() {
        AudioProcessor.AudioFormat fmt = new AudioProcessor.AudioFormat(
                new androidx.media3.common.Format.Builder()
                        .setSampleRate(44100)
                        .setChannelCount(2)
                        .setPcmEncoding(C.ENCODING_PCM_16BIT)
                        .build());
        GainAudioProcessor gain = new GainAudioProcessor(0.5f, 0, 0, 1000);
        try {
            gain.configure(fmt);
        } catch (Exception e) {
            throw new AssertionError(e);
        }
        ByteBuffer in = ByteBuffer.allocateDirect(8).order(ByteOrder.nativeOrder());
        in.putShort((short) 1000);
        in.putShort((short) 1000);
        in.putShort((short) -1000);
        in.putShort((short) -1000);
        in.position(0);
        gain.queueInput(in);
        ByteBuffer out = gain.getOutput();
        assertNotNull(out);
        assertTrue(out.remaining() > 0);
        out.order(ByteOrder.nativeOrder());
        short first = out.getShort();
        assertTrue("音量 50% 后样本应约等于 500，实际 " + first, Math.abs(first - 500) <= 2);
    }

    @Test
    public void gainProcessorFadesIn() {
        AudioProcessor.AudioFormat fmt = new AudioProcessor.AudioFormat(
                new androidx.media3.common.Format.Builder()
                        .setSampleRate(8000)
                        .setChannelCount(1)
                        .setPcmEncoding(C.ENCODING_PCM_16BIT)
                        .build());
        GainAudioProcessor gain = new GainAudioProcessor(1f, 100, 0, 1000);
        try {
            gain.configure(fmt);
        } catch (Exception e) {
            throw new AssertionError(e);
        }
        ByteBuffer in = ByteBuffer.allocateDirect(2).order(ByteOrder.nativeOrder());
        in.putShort((short) 1000);
        in.position(0);
        gain.queueInput(in);
        ByteBuffer out = gain.getOutput();
        short s = out.order(ByteOrder.nativeOrder()).getShort();
        // 第 0 帧处于淡入起点，增益约为 0
        assertTrue("淡入起点应接近静音，实际 " + s, Math.abs(s) < 40);
    }

    @Test
    public void recentStoreCanDropDeadItem() {
        Context ctx = themed();
        RecentStore.touch(ctx, "content://media/1", "a.jpg", "image");
        RecentStore.touch(ctx, "content://media/2", "b.mp4", "video");
        assertEquals(2, RecentStore.all(ctx).size());

        // 权限失效的项必须能被摘掉，否则用户点一次崩一次
        RecentStore.remove(ctx, "content://media/2");
        java.util.List<RecentStore.Item> left = RecentStore.all(ctx);
        assertEquals(1, left.size());
        assertEquals("content://media/1", left.get(0).uri);

        // 重复 remove 不应改变结果
        RecentStore.remove(ctx, "content://media/2");
        assertEquals(1, RecentStore.all(ctx).size());
    }
}
