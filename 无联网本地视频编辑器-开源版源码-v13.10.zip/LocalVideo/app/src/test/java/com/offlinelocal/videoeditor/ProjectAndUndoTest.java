package com.offlinelocal.videoeditor;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import android.content.Context;

import androidx.test.core.app.ApplicationProvider;

import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.annotation.Config;

import java.util.List;

/**
 * 本批四项（时间轴重排 / 撤销快照 / 工程存档 / 草稿）的纯逻辑测试。
 */
@RunWith(RobolectricTestRunner.class)
@Config(sdk = 34)
public class ProjectAndUndoTest {

    // ---------------- 时间轴重排 ----------------

    @Test
    public void moveIndex_选中段被移走时跟随到新位置() {
        assertEquals(3, EditorMath.moveIndex(1, 1, 3));
    }

    @Test
    public void moveIndex_从前面移到后面时选中段前移一位() {
        assertEquals(1, EditorMath.moveIndex(2, 0, 4));
    }

    @Test
    public void moveIndex_从后面移到前面时选中段后移一位() {
        assertEquals(3, EditorMath.moveIndex(2, 4, 1));
    }

    @Test
    public void moveIndex_不相关时下标不变() {
        assertEquals(1, EditorMath.moveIndex(1, 4, 5));
    }

    // ---------------- 速度刻度 ----------------

    @Test
    public void speed_刻度往返一致() {
        for (float s : new float[]{0.25f, 0.5f, 1f, 1.37f, 2f, 3f, 4f}) {
            int p = EditorMath.speedToProgress(s);
            float back = EditorMath.progressToSpeed(p);
            assertTrue("speed " + s + " -> " + p + " -> " + back,
                    Math.abs(back - s) < 0.06f);
        }
        assertEquals(0, EditorMath.speedToProgress(0.25f));
        assertEquals(375, EditorMath.speedToProgress(4f));
    }

    // ---------------- 工程存档 ----------------

    @Test
    public void projectStore_保存后可读回且字段完整() {
        Context ctx = ApplicationProvider.getApplicationContext();
        JSONObject data = sampleData();
        String id = ProjectStore.save(ctx, null, data, "测试工程", 12000L, 2);
        assertNotNull(id);

        JSONObject loaded = ProjectStore.load(ctx, id);
        assertNotNull(loaded);
        assertEquals(2, loaded.optJSONArray("clips").length());
        assertEquals(37.5, loaded.optDouble("rotation"), 0.001);
        assertEquals("水印字", loaded.optString("watermarkText"));
        assertEquals(1, loaded.optJSONArray("cues").length());

        List<ProjectStore.Meta> list = ProjectStore.list(ctx);
        assertEquals(1, list.size());
        assertEquals("测试工程", list.get(0).title);
        assertEquals(2, list.get(0).clipCount);

        ProjectStore.delete(ctx, id);
        assertNull(ProjectStore.load(ctx, id));
        assertTrue(ProjectStore.list(ctx).isEmpty());
    }

    @Test
    public void projectStore_覆盖保存同一id不会产生两份() {
        Context ctx = ApplicationProvider.getApplicationContext();
        JSONObject a = sampleData();
        String id = ProjectStore.save(ctx, null, a, "第一版", 1000L, 1);
        ProjectStore.save(ctx, id, a, "第二版", 2000L, 1);
        List<ProjectStore.Meta> list = ProjectStore.list(ctx);
        assertEquals(1, list.size());
        assertEquals("第二版", list.get(0).title);
        ProjectStore.delete(ctx, id);
    }

    @Test
    public void draft_写入读取清除() {
        Context ctx = ApplicationProvider.getApplicationContext();
        ProjectStore.clearDraft(ctx);
        assertEquals(0, ProjectStore.draftClipCount(ctx));

        ProjectStore.saveDraft(ctx, sampleData(), "草稿工程", 8000L, 2);
        assertEquals(2, ProjectStore.draftClipCount(ctx));
        JSONObject d = ProjectStore.loadDraftData(ctx);
        assertNotNull(d);
        assertEquals(2, d.optJSONArray("clips").length());

        ProjectStore.clearDraft(ctx);
        assertEquals(0, ProjectStore.draftClipCount(ctx));
        assertNull(ProjectStore.loadDraftData(ctx));
    }

    @Test
    public void projectStore_读不存在的工程返回null() {
        Context ctx = ApplicationProvider.getApplicationContext();
        assertNull(ProjectStore.load(ctx, "不存在的id"));
        assertFalse(new java.io.File(ctx.getFilesDir(), "projects/不存在的id").exists());
    }

    @Test
    public void json往返_不改内容() throws Exception {
        JSONObject in = sampleData();
        JSONObject out = ProjectStore.roundTrip(in);
        assertEquals(in.toString(), out.toString());
    }

    // ---------------- 工具 ----------------

    private JSONObject sampleData() {
        try {
            JSONObject o = new JSONObject();
            JSONArray clips = new JSONArray();
            for (int i = 0; i < 2; i++) {
                JSONObject c = new JSONObject();
                c.put("uri", "content://media/external/video/media/" + (i + 100));
                c.put("name", "片段 " + (i + 1));
                c.put("durationMs", 6000);
                c.put("width", 1920);
                c.put("height", 1080);
                c.put("startMs", 0);
                c.put("endMs", 6000);
                clips.put(c);
            }
            o.put("clips", clips);
            o.put("currentIndex", 1);
            o.put("rotation", 37.5);
            o.put("zoom", 1.35);
            o.put("filterIndex", 3);
            o.put("filterStrength", 0.66);
            o.put("speed", 1.37);
            o.put("speedCurve", 2);
            o.put("mute", false);
            o.put("volume", 0.8);
            o.put("fadeAudio", true);
            o.put("aspect", 1.0);
            o.put("targetHeight", 720);
            o.put("mirrorH", true);
            o.put("mirrorV", false);
            o.put("watermarkText", "水印字");
            o.put("wmX", 0.3);
            o.put("wmY", 0.4);
            o.put("wmScale", 0.7);
            o.put("wmAlpha", 0.5);
            o.put("wmRotation", 12);
            o.put("wmColor", 0xFFFF0000);
            JSONArray cues = new JSONArray();
            JSONObject cue = new JSONObject();
            cue.put("start", 100);
            cue.put("end", 900);
            cue.put("text", "第一条字幕");
            cues.put(cue);
            o.put("cues", cues);
            return o;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    // ---------------- 解码上限分档 ----------------

    @Test
    public void safeMaxDim_至少返回可用值且不超过3584() {
        int dim = BitmapUtils.safeMaxDim();
        assertTrue("dim=" + dim, dim >= 1600 && dim <= 3584);
        assertEquals(0, dim % 1);
    }

    @Test
    public void speed_边界值被夹住() {
        assertEquals(0, EditorMath.speedToProgress(0.01f));
        assertEquals(375, EditorMath.speedToProgress(99f));
        assertEquals(0.25f, EditorMath.progressToSpeed(-10), 0.001f);
        assertEquals(4f, EditorMath.progressToSpeed(999), 0.001f);
    }

    /** 草稿写入必须带版本号；老草稿没版本也要读得出来，不能静默丢。 */
    @Test
    public void 草稿带版本号且老草稿可读() throws Exception {
        android.content.Context ctx = androidx.test.core.app.ApplicationProvider.getApplicationContext();
        org.json.JSONObject data = new org.json.JSONObject();
        data.put("speed", 1.5);
        ProjectStore.saveDraft(ctx, data, "t", 3200, 2);
        assertEquals(3, ProjectStore.draftVersion(ctx));
        org.json.JSONObject back = ProjectStore.loadDraftData(ctx);
        assertNotNull(back);
        assertEquals(1.5, back.optDouble("speed", 0), 0.001);

        // 手工造一份「老草稿」：没有 v 字段
        java.io.File dir = new java.io.File(ctx.getFilesDir(), "projects");
        dir.mkdirs();
        org.json.JSONObject legacy = new org.json.JSONObject();
        legacy.put("title", "老");
        legacy.put("data", new org.json.JSONObject().put("speed", 2.0));
        java.io.FileOutputStream fos = new java.io.FileOutputStream(new java.io.File(dir, "draft.json"));
        fos.write(legacy.toString().getBytes());
        fos.close();
        assertEquals("老草稿版本号为 0", 0, ProjectStore.draftVersion(ctx));
        org.json.JSONObject legacyData = ProjectStore.loadDraftData(ctx);
        assertNotNull("老草稿不能被当成损坏直接丢掉", legacyData);
        assertEquals(2.0, legacyData.optDouble("speed", 0), 0.001);
    }

    /** 版本快照：覆盖保存前留旧版，最多 10 份，可读回。 */
    @Test
    public void 工程版本快照可回滚() throws Exception {
        org.json.JSONObject d1 = new org.json.JSONObject();
        d1.put("schemaVersion", 4);
        d1.put("title", "v1");
        String id = ProjectStore.save(ApplicationProvider.getApplicationContext(), null, d1, "测试工程", 1000, 1);
        assertNotNull(id);
        org.json.JSONObject d2 = new org.json.JSONObject();
        d2.put("schemaVersion", 4);
        d2.put("title", "v2");
        ProjectStore.save(ApplicationProvider.getApplicationContext(), id, d2, "测试工程", 1000, 1);
        java.util.List<Long> versions = ProjectStore.listVersions(ApplicationProvider.getApplicationContext(), id);
        assertTrue("保存前应留下旧版本快照", versions.size() >= 1);
        org.json.JSONObject old = ProjectStore.loadVersion(
                ApplicationProvider.getApplicationContext(), id, versions.get(0));
        assertNotNull(old);
        assertEquals("v1", old.optString("title"));
    }
}
