package com.offlinelocal.videoeditor;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import android.graphics.Bitmap;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.annotation.GraphicsMode;

import java.util.List;

/** v12.19 描边 + 底色字幕的位图渲染测试。 */
@RunWith(RobolectricTestRunner.class)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
public class StyledSubtitleTest {

    private List<TimedTextOverlay.Cue> cues() {
        return List.of(new TimedTextOverlay.Cue(0, 2000, "你好，无联网本地视频编辑器"));
    }

    @Test
    public void 有字幕的帧要画出可见位图() {
        StyledSubtitleOverlay o = new StyledSubtitleOverlay(cues(), 72f, 0f, -0.7f, 0xFFFFFFFF, 2.5f, 115, 0);
        Bitmap b = o.getBitmap(500_000L);
        assertNotNull(b);
        assertTrue("位图要有宽度", b.getWidth() > 20);
        assertTrue("位图要有高度", b.getHeight() > 20);
        int painted = 0;
        for (int y = 0; y < b.getHeight(); y += 2) {
            for (int x = 0; x < b.getWidth(); x += 2) {
                if (b.getPixel(x, y) != 0) painted++;
            }
        }
        assertTrue("画面上要有实际像素", painted > 20);
    }

    @Test
    public void 没字幕的帧是全透明占位() {
        StyledSubtitleOverlay o = new StyledSubtitleOverlay(cues(), 72f, 0f, -0.7f, 0xFFFFFFFF, 2.5f, 0, 0);
        Bitmap b = o.getBitmap(3_000_000L);
        assertEquals(1, b.getWidth());
        assertEquals(0, b.getPixel(0, 0));
    }

    @Test
    public void 淡入动画起始透明结束不透明() {
        StyledSubtitleOverlay o = new StyledSubtitleOverlay(cues(), 72f, 0f, -0.7f, 0xFFFFFFFF, 2.5f, 0, 1);
        assertEquals(0f, o.getOverlaySettings(0).alphaScale, 0.05f);
        assertEquals(1f, o.getOverlaySettings(1_000_000L).alphaScale, 0.05f);
    }

    @Test
    public void 上滑动画起始位置更低() {
        StyledSubtitleOverlay o = new StyledSubtitleOverlay(cues(), 72f, 0f, -0.7f, 0xFFFFFFFF, 2.5f, 0, 2);
        float startY = o.getOverlaySettings(0).backgroundFrameAnchor.second;
        float endY = o.getOverlaySettings(1_000_000L).backgroundFrameAnchor.second;
        assertTrue("起始应更靠下", startY < endY);
    }
}
