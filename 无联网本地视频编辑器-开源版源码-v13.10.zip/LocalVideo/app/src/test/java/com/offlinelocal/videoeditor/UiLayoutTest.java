package com.offlinelocal.videoeditor;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import android.app.Application;
import android.view.LayoutInflater;
import android.view.View;

import androidx.appcompat.view.ContextThemeWrapper;
import androidx.test.core.app.ApplicationProvider;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.annotation.Config;

/** UI 换皮后的基础回归：布局能充气、关键控件都在，防止换样式时把 id 改丢。 */
@RunWith(RobolectricTestRunner.class)
@Config(sdk = 34)
public class UiLayoutTest {

    private View inflate(int layout) {
        Application app = ApplicationProvider.getApplicationContext();
        // MaterialButton / RangeSlider 要求上下文带 Material 主题，测试里也要带上
        ContextThemeWrapper themed = new ContextThemeWrapper(app, R.style.Theme_LocalVideo);
        return LayoutInflater.from(themed).inflate(layout, null, false);
    }

    @Test
    public void 首页关键控件齐全() {
        View root = inflate(R.layout.activity_main);
        assertNotNull(root.findViewById(R.id.cardContinue));
        assertNotNull(root.findViewById(R.id.cardVideo));
        assertNotNull(root.findViewById(R.id.cardImage));
        assertNotNull(root.findViewById(R.id.cardBatch));
        assertNotNull(root.findViewById(R.id.cardCollage));
        assertNotNull(root.findViewById(R.id.rowRecent));
        assertNotNull(root.findViewById(R.id.listProjects));
        assertNotNull(root.findViewById(R.id.btnHistory));
        assertNotNull(root.findViewById(R.id.btnAbout));
    }

    @Test
    public void 视频编辑页关键控件齐全() {
        View root = inflate(R.layout.activity_video_editor);
        assertNotNull(root.findViewById(R.id.playerView));
        assertNotNull(root.findViewById(R.id.toolRow));
        assertNotNull(root.findViewById(R.id.timelineScroll));
        assertNotNull(root.findViewById(R.id.trimSlider));
        assertNotNull(root.findViewById(R.id.panelHost));
        assertNotNull(root.findViewById(R.id.panelVideoFilter));
        assertNotNull(root.findViewById(R.id.panelSpeed));
        assertNotNull(root.findViewById(R.id.toolRow));
    }

    @Test
    public void 图片编辑页两行工具栏都在() {
        View root = inflate(R.layout.activity_image_editor);
        assertNotNull(root.findViewById(R.id.toolRow));
        assertNotNull(root.findViewById(R.id.toolRow2));
        assertNotNull(root.findViewById(R.id.canvas));
        assertNotNull(root.findViewById(R.id.btnSave));
        assertNotNull(root.findViewById(R.id.panelContainer));
    }

    /** 参考包 item_tool：图标 + 名称 + 状态值三件套，缺一个就等于回到"纯文字横排"。 */
    @Test
    public void toolChipHasIconNameAndStatus() {
        View chip = inflate(R.layout.item_tool);
        assertNotNull(chip.findViewById(R.id.ivToolIcon));
        assertNotNull(chip.findViewById(R.id.tvToolName));
        assertNotNull(chip.findViewById(R.id.tvToolStatus));
        android.widget.TextView name = chip.findViewById(R.id.tvToolName);
        assertNotNull(name.getText());
    }

    /**
     * 分组工具条的关键约束：每个工具都必须在某一个组里、且只出现一次，
     * 否则用户点了那组找不到它（片段里最怕的"改名导致点了没反应"）。
     */
    @Test
    public void everyToolBelongsToExactlyOneGroup() throws Exception {
        java.lang.reflect.Field f = VideoEditorActivity.class.getDeclaredField("TOOL_GROUPS");
        f.setAccessible(true);
        String[][] groups = (String[][]) f.get(null);
        java.lang.reflect.Field tf = VideoEditorActivity.class.getDeclaredField("TOOLS");
        tf.setAccessible(true);
        String[] tools = (String[]) tf.get(null);

        assertEquals("分组应为四组（基础/调整/叠加/导出）", 4, groups.length);
        assertEquals("基础", groups[0][0]);
        assertEquals("调整", groups[1][0]);
        assertEquals("叠加", groups[2][0]);
        assertEquals("导出", groups[3][0]);

        java.util.Map<String, Integer> seen = new java.util.HashMap<>();
        for (String[] g : groups) {
            for (int i = 1; i < g.length; i++) {
                seen.put(g[i], seen.getOrDefault(g[i], 0) + 1);
            }
        }
        for (String t : tools) {
            Integer c = seen.get(t);
            assertNotNull("工具「" + t + "」没有归组，用户找不到入口", c);
            assertEquals("工具「" + t + "」重复出现在多组", Integer.valueOf(1), c);
        }
        assertEquals("组内出现了 TOOLS 里没有的名字", tools.length, seen.size());
    }

    /** 状态值容器（tvToolStatus）必须在，且默认空着等 refreshToolLabels 回填。 */
    @Test
    public void toolChipIsSeventyBySeventyAndCardSized() {
        View chip = inflate(R.layout.item_tool);
        assertEquals(android.widget.LinearLayout.VERTICAL,
                ((android.widget.LinearLayout) chip).getOrientation());
        android.widget.TextView status = chip.findViewById(R.id.tvToolStatus);
        assertEquals("", status.getText().toString());
    }

    /** 视频编辑器：分组 Tab 行 + 自由裁剪层必须在（参考稿结构 1:1 对应）。 */
    @Test
    public void 视频编辑器有分组Tab和裁剪层() {
        View root = inflate(R.layout.activity_video_editor);
        assertNotNull("分组 Tab 容器丢了，工具条会退回一长串横滑", root.findViewById(R.id.categoryRow));
        assertNotNull(root.findViewById(R.id.toolRow));
        assertNotNull("自由裁剪层丢了，裁剪工具点了不会有框", root.findViewById(R.id.cropOverlay));
        assertNotNull(root.findViewById(R.id.btnSpeedReset));
        assertNotNull(root.findViewById(R.id.btnSpeed05));
        assertNotNull(root.findViewById(R.id.btnSpeed2));
    }

    /** 裁剪框默认整幅，setRect 会把比例夹在 0~1 且保底 10% 宽高。 */
    @Test
    public void 裁剪框默认整幅且夹紧边界() {
        com.offlinelocal.videoeditor.CropOverlayView v = new com.offlinelocal.videoeditor.CropOverlayView(
                ApplicationProvider.getApplicationContext());
        assertTrue("默认应是整幅", v.isFullFrame());
        v.setRect(-0.2f, 0.1f, 1.3f, 0.9f);
        assertEquals(0f, v.getLeftRatio(), 0.001f);
        assertEquals(1f, v.getRightRatio(), 0.001f);
        v.setRect(0.8f, 0.8f, 0.85f, 0.85f); // 太小要兜底
        assertTrue("裁剪框宽度不能塌成 0", v.getRightRatio() - v.getLeftRatio() >= 0.099f);
        v.reset();
        assertTrue(v.isFullFrame());
    }
}
