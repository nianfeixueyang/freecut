package com.offlinelocal.videoeditor;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.annotation.Config;
import org.robolectric.annotation.GraphicsMode;

import java.util.ArrayList;
import java.util.List;

/** 拼图清晰度与长图上限的回归测试。 */
@RunWith(RobolectricTestRunner.class)
@Config(sdk = 34)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
public class CollageQualityTest {

    private List<Bitmap> squares(int count, int side) {
        List<Bitmap> out = new ArrayList<>();
        for (int i = 0; i < count; i++) {
            Bitmap b = Bitmap.createBitmap(side, side, Bitmap.Config.ARGB_8888);
            Canvas c = new Canvas(b);
            c.drawColor(i % 2 == 0 ? 0xFF223344 : 0xFFAA5522);
            out.add(b);
        }
        return out;
    }

    @Test
    public void 九宫格输出宽度等于请求宽度而不是三倍() {
        Bitmap out = CollageEngine.build(squares(9, 600), 0, 8, 0, 0xFF000000, 900);
        assertNotNull(out);
        // 单格宽 =（900 - 4×gap）/3 ≈ 289，总宽应接近 900，而不是 2700
        assertTrue("实际宽 " + out.getWidth(), out.getWidth() <= 901);
        assertTrue("实际宽 " + out.getWidth(), out.getWidth() >= 850);
    }

    @Test
    public void 长图拼接超限时自动缩窄而不是OOM() {
        List<Bitmap> tall = new ArrayList<>();
        for (int i = 0; i < 3; i++) {
            Bitmap b = Bitmap.createBitmap(300, 9000, Bitmap.Config.ARGB_8888);
            Canvas c = new Canvas(b);
            // 每张画不同的横条位置，让重叠检测拿到确定的结果
            Paint p = new Paint();
            p.setColor(0xFF000000 + i * 0x101010);
            c.drawRect(0, i * 100, 300, i * 100 + 200, p);
            tall.add(b);
        }
        Bitmap out = CollageEngine.stitch(tall, 300);
        assertNotNull(out);
        assertTrue("高度应被裁到上限，实际 " + out.getHeight(),
                out.getHeight() <= CollageEngine.MAX_STITCH_HEIGHT);
        assertTrue("宽度应同步缩窄，实际 " + out.getWidth(), out.getWidth() < 300);
    }

    @Test
    public void 源图小于格子时不会被放大到离谱比例() {
        Bitmap out = CollageEngine.build(squares(4, 200), 1, 4, 0, 0xFF000000, 2160);
        assertNotNull(out);
        // 只有 200px 的源图，输出不应超过 2×200 的两列上限太多
        assertTrue("实际宽 " + out.getWidth(), out.getWidth() <= 2160);
        assertTrue(out.getHeight() > 0);
    }

    @Test
    public void 三列单格尺寸等于总宽除以三() {
        List<Bitmap> imgs = squares(3, 800);
        Bitmap out = CollageEngine.build(imgs, 0, 0, 0, 0xFF000000, 1200);
        assertNotNull(out);
        assertEquals(1200, out.getWidth());
    }
}
