package com.offlinelocal.videoeditor;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.ColorMatrix;

import androidx.appcompat.view.ContextThemeWrapper;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.RuntimeEnvironment;
import org.robolectric.annotation.Config;
import org.robolectric.annotation.GraphicsMode;

@RunWith(RobolectricTestRunner.class)
@Config(sdk = 34, qualifiers = "w411dp-h891dp-xxhdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
public class EditEngineTest {

    private Context themed() {
        return new ContextThemeWrapper(RuntimeEnvironment.getApplication(), R.style.Theme_LocalVideo);
    }

    private EditImageView canvas() {
        EditImageView v = new EditImageView(themed());
        v.setBitmap(Bitmap.createBitmap(200, 100, Bitmap.Config.ARGB_8888));
        return v;
    }

    @Test
    public void rotatesAndSwapsDimensions() {
        EditImageView v = canvas();
        v.rotate90(true);
        assertEquals(100, v.getBase().getWidth());
        assertEquals(200, v.getBase().getHeight());
        v.rotate90(false);
        assertEquals(200, v.getBase().getWidth());
        assertEquals(100, v.getBase().getHeight());
    }

    @Test
    public void flipsKeepDimensions() {
        EditImageView v = canvas();
        v.flip(true);
        v.flip(false);
        assertEquals(200, v.getBase().getWidth());
        assertEquals(100, v.getBase().getHeight());
    }

    @Test
    public void cropShrinksBitmap() {
        EditImageView v = canvas();
        v.setMode(EditImageView.Mode.CROP);
        v.resetCropToCenter();
        v.applyCrop();
        assertTrue(v.getBase().getWidth() < 200);
        assertTrue(v.getBase().getHeight() < 100);
        assertTrue(v.getBase().getWidth() > 0);
    }

    @Test
    public void cropAspectIsApplied() {
        EditImageView v = canvas();
        v.setMode(EditImageView.Mode.CROP);
        v.resetCropToCenter();
        v.setCropAspect(1f);
        v.applyCrop();
        int w = v.getBase().getWidth();
        int h = v.getBase().getHeight();
        assertTrue(w > 0 && h > 0);
        assertEquals(1f, (float) w / (float) h, 0.08f);
    }

    @Test
    public void textLayerRendersAndUndo() {
        EditImageView v = canvas();
        assertNotNull(v.addText("无联网本地视频编辑器"));
        v.setTextColor(0xFFFFFFFF);
        v.setTextSizeDp(20);
        v.setTextTypeface(1);
        v.setTextAlign(0);
        v.setTextStroke(2f, Color.BLACK);
        v.setTextShadow(true);
        Bitmap out = v.render();
        assertNotNull(out);
        assertEquals(200, out.getWidth());
        assertEquals(100, out.getHeight());
        assertEquals(1, v.overlayCount());
        assertTrue(v.undoStroke());
        assertEquals(0, v.overlayCount());
        assertEquals(null, v.addText("   "));
    }

    @Test
    public void stickerAndLayerOrderWork() {
        EditImageView v = canvas();
        Bitmap sticker = Bitmap.createBitmap(40, 40, Bitmap.Config.ARGB_8888);
        v.addText("A");
        assertNotNull(v.addSticker(sticker));
        assertEquals(2, v.overlayCount());
        assertEquals(1, v.selectedIndex());
        v.moveSelected(false);
        assertTrue(v.selectedIndex() < 1);
        v.selectLayer(1);
        v.setSelectedAlpha(0.4f);
        assertEquals(0.4f, v.getSelected().alpha, 0.001f);
        v.deleteSelected();
        assertEquals(1, v.overlayCount());
        v.clearOverlays();
        assertEquals(0, v.overlayCount());
    }

    @Test
    public void borderIsStoredAndRendered() {
        EditImageView v = canvas();
        v.setBorder(0xFFFFFFFF, 8f);
        assertEquals(0xFFFFFFFF, v.getBorderColor());
        Bitmap out = v.render();
        assertNotNull(out);
        v.setBorder(0, 0f);
        assertEquals(0, v.getBorderColor());
    }

    @Test
    public void mosaicModeAndRenderStayConsistent() {
        EditImageView v = canvas();
        v.setMode(EditImageView.Mode.MOSAIC);
        v.setMosaicBlockDp(16);
        assertEquals(EditImageView.Mode.MOSAIC, v.getMode());
        v.setDrawWidthDp(4f);
        v.setDrawColor(Color.RED);
        Bitmap out = v.render();
        assertNotNull(out);
        v.setMode(EditImageView.Mode.NONE);
        assertEquals(EditImageView.Mode.NONE, v.getMode());
    }


    @Test
    public void undoRedoTraversesHistory() {
        EditImageView v = canvas();
        v.addText("A");
        v.addText("B");
        assertEquals(2, v.overlayCount());
        assertTrue(v.undo());
        assertEquals(1, v.overlayCount());
        assertTrue(v.undo());
        assertEquals(0, v.overlayCount());
        assertTrue(v.redo());
        assertEquals(1, v.overlayCount());
        assertTrue(v.redo());
        assertEquals(2, v.overlayCount());
    }

    @Test
    public void blendModeIsStored() {
        EditImageView v = canvas();
        v.addText("混合");
        v.setSelectedBlend(1);
        assertEquals(1, v.getSelectedBlend());
        v.setSelectedBlend(3);
        assertEquals(3, v.getSelectedBlend());
        v.setSelectedBlend(5);
        assertEquals(1, v.getSelectedBlend());
    }

    @Test
    public void frameExpandsBitmap() {
        EditImageView v = canvas();
        int w = v.getBase().getWidth();
        int h = v.getBase().getHeight();
        v.applyFrame(1, 0xFFFFFFFF);
        assertTrue(v.getBase().getWidth() > w);
        assertTrue(v.getBase().getHeight() > h);
        assertNotNull(v.render());
    }

    @Test
    public void fineRotationCommitGrowsBounds() {
        EditImageView v = canvas();
        v.setFineRotation(12f);
        v.commitFineRotation();
        assertTrue(v.getBase().getWidth() >= 200);
        assertEquals(0f, v.getBase().getWidth() * 0f, 0.001f);
        assertNotNull(v.render());
    }

    @Test
    public void showOriginalToggles() {
        EditImageView v = canvas();
        v.addText("标题");
        v.setShowOriginal(true);
        assertTrue(v.isShowingOriginal());
        v.setShowOriginal(false);
        assertTrue(v.isShowingOriginal() == false);
    }

    @Test
    public void filterMatricesAreWellFormed() {
        for (Filters.Preset p : Filters.ALL) {
            ColorMatrix cm = Filters.imageMatrix(p, 0f, 0f, 0f, 0f);
            assertNotNull(cm);
            assertEquals(20, cm.getArray().length);

            float[] vm = Filters.videoMatrix(p);
            assertEquals(16, vm.length);
            assertEquals(1f, vm[15], 0.0001f);
        }
        float[] identity = Filters.videoMatrix(Filters.ALL[0]);
        assertEquals(1f, identity[0], 0.02f);
        assertEquals(1f, identity[5], 0.02f);
        assertEquals(1f, identity[10], 0.02f);
        assertEquals(0f, identity[1], 0.02f);
    }

    @Test
    public void adjustParametersChangeMatrix() {
        float[] base = Filters.imageMatrix(Filters.ALL[0], 0f, 0f, 0f, 0f).getArray();
        float[] bright = Filters.imageMatrix(Filters.ALL[0], 0.5f, 0f, 0f, 0f).getArray();
        assertTrue(bright[4] > base[4]);
        float[] warm = Filters.imageMatrix(Filters.ALL[0], 0f, 0f, 0f, 0.5f).getArray();
        assertTrue(warm[0] != base[0] || warm[12] != base[12]);
    }

    @Test
    public void vignetteDarkensCorners() {
        android.graphics.Bitmap bmp = android.graphics.Bitmap.createBitmap(160, 160,
                android.graphics.Bitmap.Config.ARGB_8888);
        bmp.eraseColor(android.graphics.Color.WHITE);
        EditImageView v = new EditImageView(themed());
        v.setBitmap(bmp);
        v.setVignette(1f);
        android.graphics.Bitmap out = v.render();
        int center = out.getPixel(80, 80) & 0xFF;
        int corner = out.getPixel(3, 3) & 0xFF;
        assertTrue("暗角应让四角变暗：中心 " + center + "，角 " + corner, corner < center - 25);
    }

    @Test
    public void tileWatermarkAddsPixels() {
        android.graphics.Bitmap bmp = android.graphics.Bitmap.createBitmap(240, 240,
                android.graphics.Bitmap.Config.ARGB_8888);
        bmp.eraseColor(android.graphics.Color.BLACK);
        EditImageView v = new EditImageView(themed());
        v.setBitmap(bmp);
        v.setTileWatermark("freecut", 0.6f);
        v.setWatermarkTiled(true);
        android.graphics.Bitmap out = v.render();
        int lit = 0;
        for (int y = 0; y < 240; y += 3) {
            for (int x = 0; x < 240; x += 3) {
                if ((out.getPixel(x, y) & 0xFFFFFF) != 0) lit++;
            }
        }
        assertTrue("平铺水印应画出文字，亮像素 " + lit, lit > 20);
    }

    @Test
    public void signatureBoardExportsPng() {
        SignatureView board = new SignatureView(themed());
        board.measure(android.view.View.MeasureSpec.makeMeasureSpec(300,
                        android.view.View.MeasureSpec.EXACTLY),
                android.view.View.MeasureSpec.makeMeasureSpec(200,
                        android.view.View.MeasureSpec.EXACTLY));
        board.layout(0, 0, 300, 200);
        android.graphics.Bitmap out = board.export();
        assertNotNull(out);
        assertTrue(out.getWidth() <= 300 && out.getHeight() <= 200);
    }

    @Test
    public void gradientMaskDarkensTop() {
        android.graphics.Bitmap bmp = android.graphics.Bitmap.createBitmap(160, 160,
                android.graphics.Bitmap.Config.ARGB_8888);
        bmp.eraseColor(android.graphics.Color.WHITE);
        EditImageView v = new EditImageView(themed());
        v.setBitmap(bmp);
        v.setGradientMask(1, 1f);
        android.graphics.Bitmap out = v.render();
        int top = out.getPixel(80, 3) & 0xFF;
        int bottom = out.getPixel(80, 156) & 0xFF;
        assertTrue("压顶部后上方应更暗：上 " + top + "，下 " + bottom, top < bottom - 40);
    }

    @Test
    public void singleWatermarkFollowsAnchorAndColor() {
        android.graphics.Bitmap bmp = android.graphics.Bitmap.createBitmap(240, 240,
                android.graphics.Bitmap.Config.ARGB_8888);
        bmp.eraseColor(android.graphics.Color.BLACK);
        EditImageView v = new EditImageView(themed());
        v.setBitmap(bmp);
        v.setTileWatermark("SIG", 1f);
        v.setWatermarkTiled(false);
        v.setWatermarkStyle(0.16f, 0xFFFFD750, 1f, 0f);
        v.setWatermarkAnchor(0.5f, 0.12f);

        android.graphics.Bitmap out = v.render();
        int topLit = 0;
        int bottomLit = 0;
        for (int y = 0; y < 60; y += 2) {
            for (int x = 0; x < 240; x += 2) {
                int px = out.getPixel(x, y);
                if (((px >> 16) & 0xFF) > 120 && ((px >> 8) & 0xFF) > 90) topLit++;
            }
        }
        for (int y = 180; y < 240; y += 2) {
            for (int x = 0; x < 240; x += 2) {
                if ((out.getPixel(x, y) & 0xFFFFFF) != 0) bottomLit++;
            }
        }
        assertTrue("水印应在上方，实际上方亮点 " + topLit + "，下方 " + bottomLit, topLit > 15);
        assertTrue("下方不应有水印", bottomLit == 0);
    }

    @Test
    public void biggerWatermarkCoversMorePixels() {
        android.graphics.Bitmap bmp = android.graphics.Bitmap.createBitmap(240, 240,
                android.graphics.Bitmap.Config.ARGB_8888);
        bmp.eraseColor(android.graphics.Color.BLACK);
        EditImageView v = new EditImageView(themed());
        v.setBitmap(bmp);
        v.setTileWatermark("AB", 1f);
        v.setWatermarkTiled(false);
        v.setWatermarkAnchor(0.5f, 0.5f);

        v.setWatermarkStyle(0.03f, 0xFFFFFFFF, 1f, 0f);
        int small = countLit(v.render());
        v.setWatermarkStyle(0.12f, 0xFFFFFFFF, 1f, 0f);
        int large = countLit(v.render());
        assertTrue("放大后覆盖像素应更多：小 " + small + "，大 " + large, large > small * 2);
    }

    private int countLit(android.graphics.Bitmap bmp) {
        int lit = 0;
        for (int y = 0; y < bmp.getHeight(); y += 2) {
            for (int x = 0; x < bmp.getWidth(); x += 2) {
                if ((bmp.getPixel(x, y) & 0xFFFFFF) != 0) lit++;
            }
        }
        return lit;
    }

    @Test
    public void imageFilterActuallyChangesPixels() {
        android.graphics.Bitmap bmp = android.graphics.Bitmap.createBitmap(40, 40,
                android.graphics.Bitmap.Config.ARGB_8888);
        android.graphics.Canvas c = new android.graphics.Canvas(bmp);
        c.drawColor(0xFFCC3311);
        EditImageView v = new EditImageView(themed());
        v.setBitmap(bmp);

        int before = bmp.getPixel(20, 20);
        // 黑白预设 + 满强度
        android.graphics.ColorMatrix cm = Filters.imageMatrix(Filters.ALL[2], 0f, 0f, 0f, 0f);
        android.graphics.ColorMatrix blended = Filters.blendWithIdentity(cm, 1f);
        v.setColorMatrix(blended);
        android.graphics.Bitmap out = v.render();
        int after = out.getPixel(out.getWidth() / 2, out.getHeight() / 2);

        int r = android.graphics.Color.red(after);
        int g = android.graphics.Color.green(after);
        int b = android.graphics.Color.blue(after);
        assertTrue("黑白滤镜应让三通道接近一致：" + r + "," + g + "," + b,
                Math.abs(r - g) < 6 && Math.abs(g - b) < 6);
        assertTrue("画面必须真的变了", after != before);

        // 强度 0 时应当回到原样（滑杆拉到 0 = 无效果）
        v.setColorMatrix(Filters.blendWithIdentity(cm, 0f));
        android.graphics.Bitmap plain = v.render();
        int zero = plain.getPixel(plain.getWidth() / 2, plain.getHeight() / 2);
        assertTrue("强度 0 必须等价原图", (zero & 0xFFFFFF) == (before & 0xFFFFFF));
    }

    @Test
    public void videoFilterMatrixIsValidRgbMatrix() {
        float[] m = Filters.videoMatrix(Filters.ALL[2]);
        assertEquals("色矩阵必须是 16 个元素", 16, m.length);
        // 黑白：三行权重之和都应约等于 contrast(1.10)
        for (int row = 0; row < 3; row++) {
            float sum = m[row] + m[4 + row] + m[8 + row];
            assertEquals("第 " + row + " 行权重和", 1.10f, sum, 0.02f);
        }
        assertEquals("没有 alpha 混合项", 0f, m[3], 0.001f);
        assertEquals("不做 RGB->alpha 混合", 0f, m[12], 0.001f);
        assertEquals("alpha 保持 1", 1f, m[15], 0.001f);
        // 中性灰输入应保持中性（三通道输出一致），这才是"黑白"的关键
        float grayIn = 0.5f;
        float outR = m[0] * grayIn + m[4] * grayIn + m[8] * grayIn;
        float outG = m[1] * grayIn + m[5] * grayIn + m[9] * grayIn;
        float outB = m[2] * grayIn + m[6] * grayIn + m[10] * grayIn;
        assertEquals("灰输入三通道需一致(R/G)", outR, outG, 0.01f);
        assertEquals("灰输入三通道需一致(G/B)", outG, outB, 0.01f);
    }

    @Test
    public void videoFilterStrengthBlendsTowardOriginal() {
        float[] full = Filters.videoMatrix(Filters.ALL[2], 1f);
        float[] none = Filters.videoMatrix(Filters.ALL[2], 0f);
        // 强度 0 = 单位矩阵，等于完全不过滤
        assertEquals(1f, none[0], 0.001f);
        assertEquals(0f, none[4], 0.001f);
        assertEquals(1f, none[5], 0.001f);
        // 强度拉满时黑白才彻底
        assertEquals(1.10f, full[0] + full[4] + full[8], 0.02f);

        float[] half = Filters.videoMatrix(Filters.ALL[2], 0.5f);
        assertEquals("一半强度应落在原片与满滤镜之间",
                0.5f * (1f + full[0]), half[0], 0.02f);
        // 强度超出范围要夹住
        assertEquals(1f, Filters.videoMatrix(Filters.ALL[2], -0.5f)[0], 0.001f);
        assertEquals(full[0], Filters.videoMatrix(Filters.ALL[2], 2f)[0], 0.001f);
    }

    @Test
    public void recentListCanDropDeadEntry() {
        android.content.Context ctx = themed();
        RecentStore.touch(ctx, "content://demo/a", "a.jpg", "image");
        RecentStore.touch(ctx, "content://demo/b", "b.jpg", "image");
        assertEquals(2, RecentStore.all(ctx).size());
        RecentStore.remove(ctx, "content://demo/a");
        assertEquals(1, RecentStore.all(ctx).size());
        assertEquals("content://demo/b", RecentStore.all(ctx).get(0).uri);
    }

    @Test
    public void videoPreviewMatrixMatchesExportMatrix() {
        for (int i = 0; i < Filters.ALL.length; i++) {
            float[] gl = Filters.videoMatrix(Filters.ALL[i], 1f);
            android.graphics.ColorMatrix cm = Filters.videoPreviewColorMatrix(Filters.ALL[i], 1f);
            float[] rows = cm.getArray();
            for (int r = 0; r < 4; r++) {
                for (int c = 0; c < 4; c++) {
                    assertEquals("预设 " + Filters.ALL[i].name + " 的 [" + r + "," + c + "] 必须与导出矩阵一致",
                            gl[c * 4 + r], rows[r * 5 + c], 0.001f);
                }
                assertEquals("预览不应引入偏移项", 0f, rows[r * 5 + 4], 0.001f);
            }
        }
        // 强度 0 时预览矩阵必须是单位矩阵（否则"拖到 0 还是变色"）
        android.graphics.ColorMatrix zero = Filters.videoPreviewColorMatrix(Filters.ALL[3], 0f);
        float[] z = zero.getArray();
        assertEquals(1f, z[0], 0.001f);
        assertEquals(0f, z[1], 0.001f);
        assertEquals(1f, z[6], 0.001f);
    }

    @Test
    public void mosaicStyleIsStoredAndClamped() {
        EditImageView v = new EditImageView(themed());
        v.setBitmap(android.graphics.Bitmap.createBitmap(120, 80,
                android.graphics.Bitmap.Config.ARGB_8888));
        v.setMosaicStyle(2, 200, 2);
        assertEquals("类型不会越界", 2, v.getMosaicStyle());
        v.setMosaicStyle(9, 4, 6);
        assertEquals("超过范围的类型要夹到 2", 2, v.getMosaicStyle());
        v.setMosaicStyle(-3, 4, 6);
        assertEquals("负数类型要夹到 0", 0, v.getMosaicStyle());
        // 设置样式不应抛异常，且仍能正常导出
        android.graphics.Bitmap out = v.render();
        assertTrue("样式切换后仍要能导出", out != null && out.getWidth() == 120);
    }
}
