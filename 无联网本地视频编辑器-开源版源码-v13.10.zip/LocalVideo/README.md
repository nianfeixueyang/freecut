# 无联网本地视频编辑器 LocalVideo

一个完全离线运行的 Android 图片 + 视频编辑器。照片、视频、GIF 动图都能进同一条剪辑链路。
没有账号、没有云端、没有统计 SDK，APK 里连 `INTERNET` 权限都没有申请。

- 应用名：无联网本地视频编辑器
- 包名：`com.offlinelocal.videoeditor`
- 支持：Android 7.0+（minSdk 24），targetSdk 34
- 语言：Java 17 + Media3 1.4.1
- 许可证：Apache License 2.0（见 `LICENSE`）
- 开源前必读：`docs/开源注意事项.md`

> 包名在 v13.10 从 `com.freecut.editor` 改为 `com.offlinelocal.videoeditor`，与旧版属于两个独立应用，不能覆盖安装、数据不迁移。

## 能做什么

**图片**
- 多图层：文字、内置/相册贴纸、涂鸦、马赛克，可拖动、双指缩放旋转、图层排序
- 裁剪、旋转、水平/垂直翻转、微调
- 20 套滤镜（图片与视频共用参数）、强度滑杆、自定义预设
- 暗角、颗粒、边框、平铺水印、文字描边/阴影/底色/对齐
- 分层草稿自动保存，退出后可继续编辑图层
- 批量处理：多选图片统一调色/边框/尺寸，逐张导出
- 拼图、长截图拼接

**视频**
- 多段拼接、裁剪、变速（0.25x–4x）、旋转、缩放、镜像
- 画面调色（亮度/对比度/饱和度/色温/色调）+ 滤镜 + 一键调色预设
- 运镜（推近/拉远/左右/上下）、关键帧、转场（自研 GL + 音频 crossfade）、黑场淡入淡出
- 字幕：导入 SRT 或手输，描边、底色、位置
- 音频：原声/配乐/配音三轨混音，4 秒分块流式解码，**配音闪避**（开口时配乐自动压低）
- 水印（文字/LOGO）、封面导出、九宫格截图
- GIF 动图 → mp4、图片 → 3 秒片段，全部本地转码
- 导出：H.264/H.265、多档分辨率、前台服务保活、失败自动降级重试、诊断日志

## 构建

环境：JDK 17、Android SDK Platform 34、Build-Tools 34.0.0、Gradle 8.7（仓库自带 wrapper）。

```bash
# 在根目录建 local.properties，写 sdk.dir=/path/to/Android/Sdk
./gradlew :app:assembleDebug        # 可直接安装的调试包
./gradlew :app:testDebugUnitTest    # 170 项 Robolectric 单元测试
./gradlew :app:assembleRelease      # 正式包
```

开源仓库里**没有签名密钥**。`assembleRelease` 会产出未签名 APK；要发布自己的版本，请生成自己的 keystore：

```bash
keytool -genkeypair -v -keystore app/keystore/freecut.jks -alias freecut \
        -keyalg RSA -keysize 2048 -validity 10000
```

然后在仓库根目录建 `keystore.properties`（**已在 .gitignore 里，绝对不要提交**）：

```properties
storePassword=你的口令
keyPassword=你的口令
keyAlias=freecut
```

也支持环境变量 `FREECUT_STORE_PASSWORD` / `FREECUT_KEY_PASSWORD` / `FREECUT_KEY_ALIAS`。
如果放了 keystore 却没给口令，Gradle 会直接报错并说明原因，不会偷偷用默认口令签名。

## 代码结构

```
app/src/main/java/com/offlinelocal/videoeditor/
├── MainActivity.java            首页：视频（含动图/图片）/图片/批量/拼图/最近打开
├── ImageEditorActivity.java     图片编辑：工具面板、预设、草稿、导出
├── EditImageView.java           图片画布：图层系统、裁剪、手势仲裁、滤镜、渲染
├── VideoEditorActivity.java     视频剪辑：时间线、效果链、字幕、音频、导出与降级
├── AudioMixer.java              三轨混音：分块解码、重采样、淡入淡出、配音闪避
├── GifToVideo.java              GIF/图片 → mp4（Movie 逐帧 + MediaCodec 编码）
├── TransitionRenderer.java      自研 GL 转场 + 音频交叉淡化
├── Filters.java                 滤镜参数表（图片 ColorMatrix / 视频 GL 矩阵共用）
├── ColorMatrixEffect.java       颜色矩阵接入 Media3 特效管线
├── TimelineView.java            多轨时间线（片段/字幕/音频）
├── SrtUtils.java                SRT 状态机解析
├── ImageDraft.java              分层草稿
├── Work.java                    统一线程池 + 按页面取消
├── ExportDiag.java              导出诊断环形日志
└── ...
app/src/test/java/com/offlinelocal/videoeditor/   170 项 Robolectric 测试
```

## 已知限制（别当成 bug 承诺）

- Media3 1.4.1 没有内置转场 API，转场是自研 GL 实现；部分机型编码器可能不兼容，导出有自动降级。
- `FOREGROUND_SERVICE_TYPE_MEDIA_PROCESSING` 是 API 35 才有的常量，本项目 compileSdk 34，前台服务仍用 `dataSync`。
- 长视频混音是 4 秒分块解码，极端长素材导出耗时与发热明显。
- 无真机自动化测试矩阵；CI 只跑 JVM/Robolectric 测试与编译。

## 贡献

见 `CONTRIBUTING.md`。安全问题请走私密渠道，见 `SECURITY.md`。

## 许可证与第三方

代码以 Apache-2.0 发布；第三方依赖许可见 `THIRD_PARTY_LICENSES.md` 与 `NOTICE`。
内置贴纸为本项目自制素材，随代码以 CC0-1.0 提供（见 `app/src/main/assets/stickers/README.txt`）。
