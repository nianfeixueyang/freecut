# 参与贡献

## 提交方式

1. Fork 仓库，从 `main` 切分支（`feat/xxx`、`fix/xxx`）。
2. 一个 PR 只做一件事；涉及导出的改动请附“改前/改后”对比或截图。
3. 提交信息末尾加 `Signed-off-by: 你的名字 <邮箱>`（DCO），表示你同意以 Apache-2.0 贡献该代码。
4. CI 必须绿：`./gradlew :app:testDebugUnitTest :app:assembleDebug`。

## 代码约定

- 只使用 Java 17 与现有依赖，不新增运行时依赖（尤其不要加需要联网/统计的 SDK）。
- 不改 `applicationId`、`minSdk`、`targetSdk`，除非 PR 里说明原因与影响。
- 新增功能必须补测试；核心路径（混音、导出、图层、草稿）改动必须带回归测试。
- 所有用户可见文案用简体中文，语气保持一致；异常路径必须有 toast 或诊断日志，禁止静默失败。
- 不要提交 `keystore.properties`、`*.jks`、`local.properties`、`build/`、真实素材或导出成片。

## 不适合直接提 PR 的内容

- 大规模重构（先开 Issue 讨论）
- 引入 GPL/AGPL 代码或素材
- 未授权的字体、图标、贴纸、音乐
- 修改许可证或 NOTICE

## 报告问题

请附带：机型、系统版本、LocalVideo 版本号、复现步骤、是否必现、`最近导出` 面板截图（若与导出相关）。日志请先脱敏（去掉文件路径中的个人信息）。
