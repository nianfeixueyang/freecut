# 第三方许可证清单

本项目以 Apache-2.0 发布。运行时依赖全部为 Apache-2.0；测试依赖（JUnit / Robolectric / androidx.test）不会打进 APK。

## 运行时依赖

### AndroidX AppCompat 1.6.1 / ConstraintLayout 2.1.4 / ExifInterface 1.3.7
- 许可证：Apache License 2.0
- 版权：The Android Open Source Project
- 义务：保留 NOTICE 与许可证副本

### Android Media3 1.4.1（transformer / effect / exoplayer / ui / common）
- 许可证：Apache License 2.0
- 版权：The Android Open Source Project
- 义务：保留 NOTICE；若修改源码需注明修改

### Material Components for Android 1.11.0
- 许可证：Apache License 2.0
- 版权：Google LLC
- 义务：保留 NOTICE

## 仅测试依赖（不随 APK 分发）

### JUnit 4.13.2
- 许可证：Eclipse Public License 1.0

### Robolectric 4.12.2
- 许可证：MIT License
- 版权：Robolectric contributors

### androidx.test:core 1.5.0
- 许可证：Apache License 2.0

## 素材

- `app/src/main/assets/stickers/*.png`（63 张）：本项目自制，CC0-1.0。
- 应用图标：本项目自制。
- 未使用任何第三方字体文件。

## 构建工具

- Gradle 8.7（Apache-2.0），Gradle Wrapper 随仓库分发。
- Android SDK Platform 34 / Build-Tools 34.0.0 **不随仓库分发**，使用者需自行安装并接受 Android SDK 许可协议。
